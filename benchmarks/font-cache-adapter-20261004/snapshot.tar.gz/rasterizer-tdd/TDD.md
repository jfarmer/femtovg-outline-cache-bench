Added cloned_handles_share_cached_geometry_without_borrowing_the_scale_context before the opaque handle API.

Red: standalone module cargo test failed with E0599 because SwashRasterizer::default did not exist. This was an API compile failure, not a reproduced runtime cache bug.

Green: targeted regression passed. The test renders different glyphs through original and cloned handles, then checks cross-handle cache hits against native Swash pixels while the shared ScaleContext is mutably borrowed.

All 14 module tests passed without the textlayout feature (1.78s) and with it (1.75s). The standalone crate uses the real module via #[path] and real font assets via a symlink; it excludes ongoing Font/text.rs integration edits.

A normalization check confirmed the private core implementation and rasterize_path remain identical to the measured simpler version except naming, visibility and rustfmt whitespace. git diff --check passed for the owned file.
