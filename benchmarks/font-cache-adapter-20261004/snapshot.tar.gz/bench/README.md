# Private Font cache adapter comparison

This is a small CPU comparison of three frozen source trees: upstream master
`6a5f15a`, the previously measured single-loop implementation (`simple`), and
the final private Font cache adapter (`adapter`). Source and binary hashes are
recorded in `BUILD.json` and each cohort's `METADATA.json`.

The demo and cold harnesses are copied from the earlier lower-touch experiment.
The stress harness is an unchanged copy of the published 2026-10-03 stress
scene. `HARNESS_PROVENANCE.json` records their original sources and hashes.
All three versions use normalized-identical Cargo locks and the same release
profile, harnesses, fonts and assets. Only the library source differs.

The main cohort uses the FemtoVG demo at DPI 2 with Roboto Flex, Vollkorn and
Rye; a non-Swash Roboto demo control; and 32 unique-size miss workloads with
Roboto Flex and Vollkorn. The separate stress cohort uses Fleur de Leah at
DPI 1, drawing 30 rows over three font sizes, including cold, warm and changing
size phases. The full 44-frame stress sequence is also retained.

There are six blocks, one for each permutation of the three versions. Each
demo/stress process runs one fresh trial; the cold harness reports the median
of seven fresh samples. Timings exclude font loading and Canvas creation.
Demo results measure CPU drawing; cold/stress results include the Void flush.
There are no windows or GPU timings.

The runner checks build/compiler/linker process names before, during and after
each process. Any interrupted block is retained but excluded, then the cohort
stops. Rerunning the identical command resumes at the first incomplete block.
No timing values are filtered. Six-block bootstrap intervals are exploratory.

After the source freeze and a coordinated build/timing window:

```sh
python3 build.py --target-dir /private/tmp/femtovg-review-fixes-perf/target
python3 run.py --out runs/comparison --blocks 6
python3 run.py --out runs/stress --blocks 6 --cases stress-FleurDeLeah
python3 analyze.py --out runs/comparison
python3 analyze.py --out runs/stress
```

`Simple` is the engineering control, not the master baseline for a PR claim.
This study checks whether the final integration changes the previous cache
benefit; it is not a fresh search over fonts or workloads.
