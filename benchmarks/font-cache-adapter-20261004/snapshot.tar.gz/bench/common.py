import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VARIANTS = ('master', 'simple', 'adapter')


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def files(root):
    return {str(p.relative_to(root)): sha256(p) for p in sorted(root.rglob('*'))
            if p.is_file() and not any(part in ('.git', '.serena', 'target', '__pycache__')
                                       for part in p.relative_to(root).parts)}


def tree_digest(entries):
    return hashlib.sha256(json.dumps(entries, sort_keys=True).encode()).hexdigest()


def source_snapshot(variant):
    entries = files(ROOT.parent / 'source' / variant)
    if not entries or 'Cargo.toml' not in entries:
        raise RuntimeError(f'Missing source checkout: {variant}')
    return {'tree_sha256': tree_digest(entries), 'files': entries}


def binary(variant, feature, kind):
    return ROOT / 'bin' / f'{variant}-{feature}-{kind}'
