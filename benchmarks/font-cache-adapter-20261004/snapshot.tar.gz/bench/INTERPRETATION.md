# Result

The private Font adapter preserves the previous single-loop cache benefit. It
does not show a convincing broad performance change against that engineering
control in this six-block comparison, and keeps the large savings against
master when hinted outlines can be reused across fractional positions.

Demo first-paint CPU drawing, Master → Adapter:

| Font | Master | Adapter |
|---|---:|---:|
| Roboto Flex | 1.965 ms | 1.839 ms |
| Vollkorn | 7.368 ms | 4.969 ms |
| Rye | 6.963 ms | 4.287 ms |
| Roboto Flex, Swash disabled | 4.305 ms | 4.263 ms |

The full per-phase comparison, including zoom and warm draws, is in
`runs/comparison/REPORT.md`. The non-Swash control shows no regression against
master in its paired point estimates; six blocks cannot prove equivalence.

Fleur de Leah stress, Master → Adapter:

| Phase | Master | Adapter |
|---|---:|---:|
| First paint | 95.422 ms | 20.786 ms |
| Each new-size frame | 96.885 ms | 23.025 ms |
| Complete 44-frame sequence | 1268.191 ms | 301.649 ms |

The adapter's complete stress sequence has a paired change of +0.01% against
the previous simple integration: its large benefit survives the encapsulation
change. These are selected stress cases, not application launch or GPU timing.

There is still a small cost when every outline lookup misses. The complete
32-unique-size Roboto sweep is 6.074 → 6.175 ms; Vollkorn is 48.260 → 50.111 ms.
Paired median changes are +2.22% and +2.21%; the Vollkorn interval is wholly
positive (+1.38% to +4.29%), whereas Roboto's spans zero. The adapter-versus-simple
intervals span zero for both sweeps. These data support a small miss penalty
already present in the single-loop implementation, not an unqualified claim
that every workload improves.

The main cohort completed all 108 processes without build interference. Stress
completed 18 clean accepted processes after three entire interrupted attempts
were excluded and preserved. A 30-second quiet interval preceded the final
resume. `AUDIT.json`, the process guards and attempt directories retain the
evidence. No timing values were filtered.

The comparison uses one of each permutation of the three versions, matching
locks/profile/harness/assets, immutable source snapshots and copied binaries.
The six-block percentile bootstrap intervals are exploratory and are intended
to catch an integration regression. Absolute timings should not be pooled with
earlier studies taken in different sessions.
