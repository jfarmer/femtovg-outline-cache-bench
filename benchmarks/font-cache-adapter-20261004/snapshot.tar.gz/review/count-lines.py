#!/usr/bin/env python3
"""Count physical Rust code lines from snapshots, without compiling/editing them.

Counts include attributes and brace-only lines. Comments and blank lines do not
count. Strings/chars/raw strings remain code, so comment-looking contents in
literals do not disappear. Source-specific test boundaries were reviewed;
test-only items are excluded from production and counted separately.
Whitespace at each line's edges is ignored for diff churn, avoiding artificial
changes from the atlas loop's indentation inside its restoration closure.
"""
import difflib
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
FILES = ['src/lib.rs', 'src/text.rs', 'src/text/font.rs', 'src/text/swash_rasterizer.rs']
EXTERNAL_TESTS = ['src/text/glyph_atlas_tests.rs', 'src/text/glyph_atlas_fallback_tests.rs']


def uncomment(source):
    result = []
    i = 0
    n = len(source)
    while i < n:
        if source.startswith('//', i):
            end = source.find('\n', i)
            if end < 0:
                result.extend(' ' * (n - i))
                break
            result.extend(' ' * (end - i))
            i = end
        elif source.startswith('/*', i):
            depth = 1
            result.extend('  ')
            i += 2
            while depth:
                assert i < n, 'unterminated block comment'
                if source.startswith('/*', i):
                    depth += 1
                    result.extend('  ')
                    i += 2
                elif source.startswith('*/', i):
                    depth -= 1
                    result.extend('  ')
                    i += 2
                else:
                    result.append('\n' if source[i] == '\n' else ' ')
                    i += 1
        else:
            raw = re.match(r'(?:b|c)?r(#{0,255})"', source[i:])
            if raw:
                ending = '"' + raw.group(1)
                end = source.find(ending, i + raw.end())
                assert end >= 0, 'unterminated raw string'
                end += len(ending)
                result.extend(source[i:end])
                i = end
            elif source[i] == '"':
                start = i
                i += 1
                while i < n:
                    if source[i] == '\\':
                        i += 2
                    elif source[i] == '"':
                        i += 1
                        break
                    else:
                        i += 1
                result.extend(source[start:i])
            elif source[i] == "'" and (char := re.match(r"'(?:[^'\\\n]|\\(?:[^\n]|u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}))'", source[i:])):
                result.extend(char.group(0))
                i += char.end()
            else:
                result.append(source[i])
                i += 1
    return ''.join(result)


def remove_test_function(source, name):
    # Only explicit test-only inline accessors are removed this way.
    match = re.search(r'(?m)^\s*#\[cfg\([^\n]*\btest\b[^\n]*\)\]\n\s*(?:pub\([^)]*\)\s+)?fn ' + name + r'\b', source)
    if not match:
        return source
    opening = source.index('{', match.end())
    depth = 1
    end = opening + 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[:match.start()] + '\n' * source[match.start():end].count('\n') + source[end:]


def code_lines(source):
    return [line.strip() for line in source.splitlines() if line.strip()]


def split_production(name, source):
    clean = uncomment(source)
    production = clean
    if name == 'src/lib.rs':
        boundary = re.search(r'(?m)^#\[cfg\(test\)\]\n#\[derive\(Default, Debug\)\]\npub struct RecordingRenderer', clean)
        assert boundary
        # This file's entire suffix is test support/tests, manually reviewed.
        production = clean[:boundary.start()]
    elif name == 'src/text/font.rs':
        boundary = re.search(r'(?m)^#\[cfg\(all\(test, any\(feature = "textlayout", feature = "swash"\)\)\)\]\nmod tests', clean)
        assert boundary
        production = clean[:boundary.start()]
        production = remove_test_function(production, 'glyph_cache_len')
    elif name == 'src/text/swash_rasterizer.rs':
        boundary = re.search(r'(?m)^#\[cfg\(test\)\]\nmod tests', clean)
        assert boundary
        production = remove_test_function(clean[:boundary.start()], 'scale_context')
        # Full version's single-glyph wrapper is test-only.
        production = remove_test_function(production, 'render')
    elif name == 'src/text.rs':
        production = re.sub(r'(?m)^#\[cfg\([^\n]*\btest\b[^\n]*\)\]\nmod glyph_atlas(?:_fallback)?_tests;\n', '', clean)
    else:
        raise AssertionError(name)
    all_lines = code_lines(clean)
    prod_lines = code_lines(production)
    return prod_lines, len(all_lines) - len(prod_lines)


def changed(before, after):
    added = deleted = 0
    for tag, i, j, k, l in difflib.SequenceMatcher(None, before, after, autojunk=False).get_opcodes():
        if tag != 'equal':
            deleted += j - i
            added += l - k
    return {'added': added, 'deleted': deleted, 'net': added - deleted, 'churn': added + deleted}


def main():
    check = uncomment('"https://x" // hi\n/* a /* b */ c */x')
    assert [line.strip() for line in check.splitlines()] == ['"https://x"', 'x']
    variants = {}
    lines = {}
    for variant in ['master', 'simple', 'adapter']:
        totals = {'production_code_lines': 0, 'test_support_code_lines': 0}
        files = {}
        lines[variant] = {}
        for name in FILES:
            path = ROOT / 'source' / variant / name
            if path.exists():
                raw = path.read_bytes()
                production, tests = split_production(name, raw.decode())
                file = {'sha256': hashlib.sha256(raw).hexdigest(), 'physical_lines': len(raw.splitlines()),
                        'production_code_lines': len(production), 'test_support_code_lines': tests}
            else:
                production = []
                file = {'absent': True, 'production_code_lines': 0, 'test_support_code_lines': 0}
            lines[variant][name] = production
            files[name] = file
            for key in totals:
                totals[key] += file[key]
        for name in EXTERNAL_TESTS:
            path = ROOT / 'source' / variant / name
            if path.exists():
                raw = path.read_bytes()
                tests = len(code_lines(uncomment(raw.decode())))
                files[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'physical_lines': len(raw.splitlines()),
                               'production_code_lines': 0, 'test_support_code_lines': tests}
                totals['test_support_code_lines'] += tests
        variants[variant] = {'totals': totals, 'files': files}
    comparisons = {}
    for before, after in [('master', 'simple'), ('master', 'adapter'), ('simple', 'adapter')]:
        per_file = {name: changed(lines[before][name], lines[after][name]) for name in FILES}
        integration = {k: sum(row[k] for name, row in per_file.items() if name != 'src/text/swash_rasterizer.rs')
                       for k in ['added', 'deleted', 'net', 'churn']}
        total = {k: sum(row[k] for row in per_file.values()) for k in ['added', 'deleted', 'net', 'churn']}
        comparisons[f'{before}_to_{after}'] = {'per_file_production_diff': per_file,
            'existing_file_integration_diff': integration, 'all_production_diff': total}
    result = {'method': __doc__, 'scope': FILES + EXTERNAL_TESTS,
        'limits': 'Physical code-line count, not statements or semantic complexity. Attributes/braces count. All production feature branches count; this is not per-feature compiled size. Test boundaries and inline accessors were manually identified. Adapter means this exact frozen Font-wrapper snapshot, including its encapsulation edits.',
        'variants': variants, 'comparisons': comparisons}
    (ROOT / 'review/LINE-COUNTS.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'totals': {n: d['totals'] for n, d in variants.items()}, 'comparisons': comparisons}, indent=2))


if __name__ == '__main__':
    main()
