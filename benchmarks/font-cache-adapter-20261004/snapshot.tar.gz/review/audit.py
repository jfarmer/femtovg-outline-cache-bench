"""Reconstruct the narrow adapter study from stdout without importing its runner/analyzer.

Run only after both cohorts and their analysis are complete. Writes only this
study's review/AUDIT.json and review/REPORT.md.
"""
import csv
import hashlib
import itertools
import json
import random
import statistics
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BENCH = ROOT / 'bench'
VARIANTS = ('master', 'simple', 'adapter')
CONTRASTS = (('simple', 'master'), ('adapter', 'master'), ('adapter', 'simple'))
DEMO_PHASES = [('first_paint', 1), ('warm', 30), ('zoom_in', 12), ('zoom_out', 12), ('pan', 10)]
STRESS_PHASES = [('first_paint', 1), ('warm', 30), ('new_size', 12), ('return', 1)]


def read_json(path):
    return json.loads(path.read_text())


def jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def file_map(root):
    return {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*'))
            if p.is_file() and not any(part in ('.git', '.serena', 'target', '__pycache__')
                                     for part in p.relative_to(root).parts)}


def digest(entries):
    return hashlib.sha256(json.dumps(entries, sort_keys=True).encode()).hexdigest()


def compare_numbers(expected, reported, prefix=''):
    errors = []
    if isinstance(expected, dict):
        assert set(expected) == set(reported), (prefix, set(expected) ^ set(reported))
        for key in expected:
            errors.extend(compare_numbers(expected[key], reported[key], prefix + '/' + key))
    elif isinstance(expected, list):
        assert len(expected) == len(reported), prefix
        for index, (a, b) in enumerate(zip(expected, reported)):
            errors.extend(compare_numbers(a, b, prefix + '/' + str(index)))
    elif isinstance(expected, (int, float)):
        error = abs(expected - reported)
        assert error <= max(1e-9, abs(expected) * 1e-12), (prefix, expected, reported)
        errors.append(error)
    else:
        assert expected == reported, (prefix, expected, reported)
    return errors


def provenance():
    build = read_json(BENCH / 'BUILD.json')
    assert build['harness'] == file_map(BENCH / 'harness-src')
    assert build['assets'] == file_map(BENCH / 'assets')
    locks = []
    manifests = []
    for variant in VARIANTS:
        record = build['variants'][variant]
        source = file_map(ROOT / 'source' / variant)
        assert source == record['source']['files']
        assert digest(source) == record['source']['tree_sha256']
        for binary in record['binaries'].values():
            assert sha(Path(binary['path'])) == binary['sha256']
        manifest = BENCH / 'harness' / variant / 'Cargo.toml'
        lock = manifest.with_name('Cargo.lock')
        assert sha(manifest) == record['manifest_sha256']
        assert sha(lock) == record['lock_sha256']
        locks.append(lock.read_text().replace('femtovg-font-cache-adapter-' + variant,
                                            'femtovg-font-cache-adapter-VARIANT'))
        text = manifest.read_text()
        assert 'default_swash = ["femtovg/default", "femtovg/swash"]' in text
        assert 'default_no_swash = ["femtovg/default"]' in text
        assert 'default-features = false' in text
        assert 'path = "../../../source/' + variant + '"' in text
        normalized = text.replace('femtovg-font-cache-adapter-' + variant,
                                  'femtovg-font-cache-adapter-VARIANT')
        normalized = normalized.replace('-' + variant + '"', '-VARIANT"')
        normalized = normalized.replace('source/' + variant, 'source/VARIANT')
        manifests.append(normalized)
        log = (BENCH / 'build-logs' / (variant + '-default_swash.log')).read_text()
        assert str(ROOT / 'source' / variant) in log
        assert 'Finished `release` profile' in log
    assert len(set(locks)) == 1
    assert digest({'lock': locks[0]}) == build['normalized_lock_sha256']
    assert len(set(manifests)) == 1
    records = read_json(BENCH / 'HARNESS_PROVENANCE.json')
    for record in records:
        actual = BENCH / record['path']
        original = Path(record['archive_source'])
        assert sha(actual) == record['sha256']
        assert sha(original) == record['archive_sha256']
        if record['change'] == 'none':
            assert actual.read_bytes() == original.read_bytes()
        elif record['path'] == 'harness-src/cold/cold.rs':
            before = original.read_text().splitlines()
            after = actual.read_text().splitlines()
            differing = [(a, b) for a, b in zip(before, after) if a != b]
            assert len(before) == len(after) and len(differing) == 1
            assert 'assets' in differing[0][0] and 'assets' in differing[0][1]
        else:
            raise AssertionError('Unexpected harness modification')
    prior = read_json(Path('/private/tmp/femtovg-lower-touch-20261003/bench/BUILD.json'))
    for variant in ('master', 'simple'):
        assert build['variants'][variant]['source'] == prior['variants'][variant]['source']
    return {'source_trees': {v: build['variants'][v]['source']['tree_sha256'] for v in VARIANTS},
            'normalized_lock_sha256': build['normalized_lock_sha256'],
            'binary_count': sum(len(build['variants'][v]['binaries']) for v in VARIANTS),
            'harness_records': len(records), 'rustc': build['rustc'], 'cargo': build['cargo'],
            'limitations': 'Build logs and saved binary hashes verified; no fresh compilation or resolved Cargo compiler-artifact JSON was requested.'}


def stdout_measurements(path, case):
    measurements = []
    if case['kind'] in ('scenes', 'stress'):
        rows = list(csv.DictReader(path.read_text().splitlines()))
        expected_phases = DEMO_PHASES if case['kind'] == 'scenes' else STRESS_PHASES
        assert [(r['phase'], int(r['frames'])) for r in rows] == expected_phases
        assert all(r['scene'] == ('demo' if case['kind'] == 'scenes' else 'proofsheet') and r['trial'] == '0' for r in rows)
        for row in rows:
            m = {'phase': row['phase'], 'frames': int(row['frames'])}
            for metric in ('draw_us', 'flush_us', 'total_us'):
                m[metric] = float(row[metric])
            assert abs(m['draw_us'] + m['flush_us'] - m['total_us']) <= 2e-6
            if case['kind'] == 'stress':
                for key in ('glyph_requests_per_frame', 'distinct_glyph_size_instances_per_frame',
                            'text_draw_calls_per_frame', 'logical_width', 'logical_height',
                            'nominal_characters_per_row'):
                    m[key] = int(row[key])
                assert tuple(m[key] for key in ('glyph_requests_per_frame', 'distinct_glyph_size_instances_per_frame',
                            'text_draw_calls_per_frame', 'logical_width', 'logical_height',
                            'nominal_characters_per_row')) == (1980, 198, 30, 1800, 1200, 66)
            measurements.append(m)
        if case['kind'] == 'stress':
            measurements.append({'phase': 'complete_sequence', 'frames': 44,
                                 'total_us': sum(m['frames'] * m['total_us'] for m in measurements)})
    else:
        values = {}
        for line in path.read_text().splitlines():
            tag, workload, key, value = line.split()
            assert tag == 'RESULT' and workload == 'grid_unique_sizes'
            assert key not in values
            values[key] = float(value)
        assert values['frames'] == 32 and values['glyphs'] == 3008
        total = values['ns_total']
        assert abs(total / 3008 - values['med_ns_per_glyph']) <= 0.01
        assert abs(total / 32 - values['med_ns_per_frame']) <= 0.03
        measurements.append({'phase': 'all_misses', 'frames': 32, 'glyphs': 3008, 'total_us': total / 1000})
    return measurements


def interval(values, seed):
    rng = random.Random(seed)
    values = sorted(statistics.median(rng.choices(values, k=len(values))) for _ in range(5000))
    return [values[125], values[4874]]


def cohort(name, build):
    out = BENCH / 'runs' / name
    plan = read_json(out / 'PLAN.json')
    assert read_json(out / 'METADATA.json')['build'] == build
    assert plan['blocks'] == 6
    expected_orders = [list(order) for order in itertools.permutations(VARIANTS)]
    assert plan['orders'] == expected_orders
    assert plan['demo_dpi'] == 2 and plan['stress_dpi'] == 1
    assert plan['trials_per_process'] == 1 and plan['cold_samples_per_process'] == 7
    reconstructed = []
    excluded = []
    process_count = 0
    accepted_attempts = []
    guard = jsonl(out / 'guard-checks.jsonl')
    for block, order in enumerate(expected_orders):
        attempts = sorted((out / 'attempts').glob(f'block-{block:02d}-*'))
        accepted = [a for a in attempts if read_json(a / 'STATUS.json')['status'] == 'accepted']
        assert len(accepted) == 1, (name, block)
        attempt = accepted[0]
        accepted_attempts.append(attempt.name)
        status = read_json(attempt / 'STATUS.json')
        local = []
        contexts = []
        for variant in order:
            for case in plan['cases']:
                prefix = {'block': block, 'order': order, 'variant': variant, 'case': case['name']}
                path = attempt / (variant + '-' + case['name'] + '.stdout')
                stderr = path.with_suffix('.stderr').read_text()
                if case['kind'] == 'cold':
                    expected = 'controlled scene=grid_unique_sizes glyphs=94 distinct_keys_per_new_instance=94 dpi=1\n'
                    assert stderr == expected * 7
                else:
                    assert stderr == ''
                for result in stdout_measurements(path, case):
                    local.append({**prefix, **result})
                process_count += 1
                checks = [r for r in guard if status['started_utc'] <= r['checked_utc'] <= status['ended_utc']
                          and r['context'].get('block') == block and r['context'].get('variant') == variant
                          and r['context'].get('case') == case['name']]
                stages = [r['context']['stage'] for r in checks]
                assert stages[0] == 'before_process' and stages[-1] == 'after_process'
                assert len(stages) >= 3 and all(s == 'during_process' for s in stages[1:-1])
                assert all(r['status'] == 'idle' and not r['pids'] for r in checks)
                contexts.extend([variant + '/' + case['name']] * len(checks))
        assert local == jsonl(attempt / 'partial-raw.jsonl')
        reconstructed.extend(local)
        for attempt in attempts:
            status = read_json(attempt / 'STATUS.json')
            if status['status'] != 'accepted':
                excluded.append({'attempt': attempt.name, 'status': status,
                                 'raw_rows': len(jsonl(attempt / 'partial-raw.jsonl')) if (attempt / 'partial-raw.jsonl').exists() else 0})
    raw = jsonl(out / 'raw.jsonl')
    assert raw == reconstructed
    assert len(raw) == len({(r['block'], r['variant'], r['case'], r['phase']) for r in raw})
    assert set(r['block'] for r in raw) == set(range(6))
    groups = {}
    for row in reconstructed:
        key = (row['case'], row['phase'])
        metric = 'draw_us' if row['case'].startswith('demo-') else 'total_us'
        groups.setdefault(key, {})[(row['block'], row['variant'])] = row[metric]
    computed = []
    for number, ((case, phase), values) in enumerate(sorted(groups.items())):
        assert set(values) == set(itertools.product(range(6), VARIANTS))
        result = {'case': case, 'phase': phase, 'blocks': 6,
                  'unit': 'us/sequence' if phase == 'complete_sequence' else 'us'}
        for variant in VARIANTS:
            result[variant] = statistics.median(values[(b, variant)] for b in range(6))
        for candidate, baseline in CONTRASTS:
            label = candidate + '_vs_' + baseline
            ratios = [(values[(b, candidate)] / values[(b, baseline)] - 1) * 100 for b in range(6)]
            result[label + '_percent'] = statistics.median(ratios)
            result[label + '_ci95'] = interval(ratios, 20261004 + number)
            result[label + '_delta_us'] = statistics.median(values[(b, candidate)] - values[(b, baseline)] for b in range(6))
        computed.append(result)
    errors = compare_numbers(computed, read_json(out / 'SUMMARY.json'), name)
    pair_orders = {a + '/' + b: dict(Counter('AB' if order.index(a) < order.index(b) else 'BA'
                       for order in expected_orders)) for a, b in CONTRASTS}
    return {'processes': process_count, 'raw_rows': len(raw), 'summary_rows': len(computed),
            'accepted_attempts': accepted_attempts, 'excluded_attempts': excluded,
            'pair_order_counts': pair_orders, 'maximum_summary_numeric_error': max(errors, default=0),
            'guard_checks': len(guard), 'guard_status_counts': dict(Counter(r['status'] for r in guard)),
            'quiet_intervals': jsonl(out / 'quiet-intervals.jsonl'), 'results': computed}


def line_counts():
    # Re-execute the already documented lexical counting helpers, but never its
    # writing main function. This checks reproducibility, not a new LOC metric.
    script = ROOT / 'review/count-lines.py'
    namespace = {'__name__': 'audit_count_helpers', '__file__': str(script)}
    exec(compile(script.read_text(), str(script), 'exec'), namespace)
    stored = read_json(ROOT / 'review/LINE-COUNTS.json')
    totals = {}
    for variant in VARIANTS:
        totals[variant] = 0
        for name in namespace['FILES']:
            path = ROOT / 'source' / variant / name
            prod = namespace['split_production'](name, path.read_text())[0] if path.exists() else []
            assert len(prod) == stored['variants'][variant]['files'][name]['production_code_lines']
            totals[variant] += len(prod)
    assert totals['adapter'] - totals['master'] == 334
    assert totals['adapter'] - totals['simple'] == 41
    old = read_json(Path('/private/tmp/femtovg-lower-touch-20261003/review/LINE-COUNTS.json'))
    assert old['comparisons']['master_to_full']['all_production_diff']['net'] == 439
    return {'production_code_lines': totals, 'adapter_net_vs_master': 334,
            'adapter_net_vs_simple': 41, 'prior_full_net_vs_master': 439,
            'adapter_fewer_than_prior_full': 105,
            'method': 'Reproduced saved lexical physical-line method: comments/blanks/test-only items excluded; attributes/braces and all feature branches included. Net additions are not total patch churn or statements.'}


def main():
    identity = provenance()
    build = read_json(BENCH / 'BUILD.json')
    cohorts = {name: cohort(name, build) for name in ('comparison', 'stress')}
    result = {'status': 'PASS', 'provenance': identity, 'line_counts': line_counts(), 'cohorts': cohorts,
              'statistics': 'Six complete blocks; each pair 3 AB/3 BA. Absolute values are marginal medians; deltas and percentages are medians of within-block differences/ratios. 5,000 paired-block resamples; seed 20261004+alphabetical group index; percentile indices 125 and 4874. Exploratory intervals, no multiplicity correction.',
              'limits': ['CPU benchmark with Void, no GPU/window/application performance claim.',
                         'Demo uses draw_us; cold/stress use total_us including Void flush. Do not mix these metrics.',
                         'Only default+Swash and a default-without-Swash Roboto demo control are timed; Swash-only/direct/stroke correctness depends on separate functional checks.',
                         'The seven cold samples are collapsed to one per-process median; individual sample times are not retained.',
                         'Name-based 0.1-second polling cannot prove absence of all transient/background load.',
                         'Prior non-Swash synthetic paragraph losses remain relevant; this limited demo control does not erase them.']}
    (ROOT / 'review/AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = ['The narrow Font-adapter comparison passed independent stdout, matrix and source-identity checks.', '',
             'All phase values and complete stress-sequence values agree with preserved stdout; accepted raw records and every reported median, paired delta, percentage and bootstrap interval were reconstructed without importing the benchmark runner/analyzer.', '',
             '| Cohort | Processes | Raw rows | Summary rows | Excluded attempts |',
             '|---|---:|---:|---:|---:|']
    for name, data in cohorts.items():
        lines.append(f'| {name} | {data["processes"]} | {data["raw_rows"]} | {data["summary_rows"]} | {len(data["excluded_attempts"])} |')
    lines += ['', 'Six permutations balance each comparison 3 AB/3 BA and each version twice in each position. The same locked dependencies, profile, harness and assets are used; source, manifest, lock and binary hashes match BUILD.json and each cohort metadata. Master and Simple match the earlier frozen lower-touch source identities. Build logs identify the intended source paths. No fresh build was performed by this audit.', '',
              'The documented LOC count reproduces: Adapter adds 334 production code lines over Master and 41 over Simple, leaving 105 fewer than the previous Full integration. This excludes tests/comments/blanks and includes braces/attributes and all feature branches; it measures physical lines, not semantic complexity.', '',
              '| Case | Phase | Master ms | Simple ms | Adapter ms | Paired Adapter−Simple ms | Adapter/Simple % (exploratory 95% interval) |',
              '|---|---|---:|---:|---:|---:|---|']
    for name, data in cohorts.items():
        for row in data['results']:
            if row['phase'] not in ('first_paint', 'all_misses', 'new_size', 'complete_sequence'):
                continue
            low, high = row['adapter_vs_simple_ci95']
            lines.append(f'| {row["case"]} | {row["phase"]} | {row["master"]/1000:.3f} | {row["simple"]/1000:.3f} | {row["adapter"]/1000:.3f} | {row["adapter_vs_simple_delta_us"]/1000:+.3f} | {row["adapter_vs_simple_percent"]:+.2f}% [{low:+.2f}, {high:+.2f}] |')
    lines += ['', result['statistics'], '', *result['limits'], '',
              'The source review found no cache-policy or rasterization changes from Simple: ownership moved behind Font and an opaque shared handle. Cache hits still allocate their existing variation-key storage when nonempty; the wrapper adds no handle clone per render. The measured effects belong to the complete integration, not an isolated wrapper instruction cost.']
    (ROOT / 'review/REPORT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'status': 'PASS', 'cohorts': {name: {key: value for key, value in data.items() if key not in ('results', 'quiet_intervals')} for name, data in cohorts.items()}, 'line_counts': result['line_counts']}, indent=2))


if __name__ == '__main__':
    main()
