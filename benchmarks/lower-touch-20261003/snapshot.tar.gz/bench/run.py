"""Balanced three-way CPU comparison. Failed blocks remain excluded on disk."""
import argparse
import csv
import io
import itertools
import json
import os
import platform
import shutil
import subprocess
import time
from pathlib import Path
from common import ROOT, VARIANTS, binary, files, sha256, source_snapshot
from guard import GuardMatched, append, ensure_idle, utc, wait_idle

CASES = [
    {'name': f'demo-{font}', 'kind': 'scenes', 'feature': 'default_swash', 'font': font}
    for font in ('RobotoFlex', 'Vollkorn', 'Rye')
] + [
    {'name': 'demo-RobotoFlex-no-swash', 'kind': 'scenes', 'feature': 'default_no_swash', 'font': 'RobotoFlex'}
] + [
    {'name': f'{workload}-{font}', 'kind': 'cold', 'feature': 'default_swash', 'font': font,
     'workload': workload}
    for font in ('RobotoFlex', 'Vollkorn')
    for workload in ('grid_singleton', 'grid_unique_sizes')
]
FONTS = {'RobotoFlex': 'RobotoFlex-VariableFont.ttf', 'Vollkorn': 'Vollkorn-Medium.ttf', 'Rye': 'Rye-Regular.ttf'}
p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
p.add_argument('--blocks', type=int, choices=(6, 12), default=12)
p.add_argument('--cases', nargs='+', choices=[c['name'] for c in CASES])
p.add_argument('--quiet-seconds', type=float, default=5)
args = p.parse_args()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
cases = [c for c in CASES if args.cases is None or c['name'] in args.cases]
orders = list(itertools.permutations(VARIANTS)) * (args.blocks // 6)
plan = {'blocks': args.blocks, 'orders': orders, 'cases': cases, 'demo_dpi': 2,
        'trials_per_process': 1, 'cold_samples_per_process': 7,
        'primary_metric': 'draw_us for demo, median ns_total converted to us for cold',
        'guard': 'before every process, every 0.1 seconds during, and after; exclude entire interrupted block',
        'resume': 'Only completed blocks accepted; excluded partial blocks remain immutable in attempts/' }
plan = json.loads(json.dumps(plan))
plan_path = out / 'PLAN.json'
if plan_path.exists() and json.loads(plan_path.read_text()) != plan:
    raise RuntimeError('Resume plan differs; use a fresh output directory')
plan_path.write_text(json.dumps(plan, indent=2) + '\n')
build = json.loads((ROOT / 'BUILD.json').read_text())
if build['harness'] != files(ROOT / 'harness-src') or build['assets'] != files(ROOT / 'assets'):
    raise RuntimeError('Harness/assets changed after build')
for variant in VARIANTS:
    if source_snapshot(variant) != build['variants'][variant]['source']:
        raise RuntimeError(f'{variant} source changed after build')
    for record in build['variants'][variant]['binaries'].values():
        if sha256(Path(record['path'])) != record['sha256']:
            raise RuntimeError('Binary differs from BUILD.json')
metadata = {'created_utc': utc(), 'platform': platform.platform(), 'cpu_count': os.cpu_count(), 'build': build}
metadata_path = out / 'METADATA.json'
if metadata_path.exists():
    if json.loads(metadata_path.read_text())['build'] != build:
        raise RuntimeError('Resume binary/source identities differ; use a fresh output directory')
else:
    metadata_path.write_text(json.dumps(metadata, indent=2) + '\n')
wait_idle(out, args.quiet_seconds, time.monotonic() + 60, {'stage': 'pre_run'})
completed = set()
raw_path = out / 'raw.jsonl'
if raw_path.exists():
    completed = {json.loads(line)['block'] for line in raw_path.read_text().splitlines()}
for block, order in enumerate(orders):
    if block in completed:
        continue
    attempts = out / 'attempts'
    attempts.mkdir(exist_ok=True)
    attempt_no = len(list(attempts.glob(f'block-{block:02d}-*')))
    attempt = attempts / f'block-{block:02d}-{attempt_no:02d}'
    attempt.mkdir()
    records = []
    started = utc()
    print(f'Block {block + 1}/{args.blocks}: {" ".join(order)}', flush=True)
    try:
        for variant in order:
            for case in cases:
                context = {'block': block, 'variant': variant, 'case': case['name']}
                ensure_idle(out, {'stage': 'before_process', **context})
                selected = binary(variant, case['feature'], case['kind'])
                env = os.environ.copy()
                font = ROOT / 'assets' / FONTS[case['font']]
                if case['kind'] == 'scenes':
                    command = [str(selected), 'demo', '1', '2']
                    env['FEMTOVG_REPLAY_TEXT_FONT'] = str(font)
                else:
                    command = [str(selected), case['workload'], str(font), '0', '7']
                stdout_path = attempt / f'{variant}-{case["name"]}.stdout'
                stderr_path = attempt / f'{variant}-{case["name"]}.stderr'
                with stdout_path.open('w') as stdout, stderr_path.open('w') as stderr:
                    process = subprocess.Popen(command, stdout=stdout, stderr=stderr, env=env)
                    try:
                        while process.poll() is None:
                            ensure_idle(out, {'stage': 'during_process', **context})
                            time.sleep(0.1)
                    except BaseException:
                        process.terminate()
                        try:
                            process.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait()
                        raise
                    if process.returncode:
                        raise RuntimeError(f'Benchmark exited {process.returncode}: {stderr_path}')
                ensure_idle(out, {'stage': 'after_process', **context})
                measurements = []
                if case['kind'] == 'scenes':
                    for row in csv.DictReader(io.StringIO(stdout_path.read_text())):
                        measurements.append({'phase': row['phase'], 'frames': int(row['frames']),
                                             'draw_us': float(row['draw_us']), 'flush_us': float(row['flush_us']),
                                             'total_us': float(row['total_us'])})
                else:
                    values = {}
                    for line in stdout_path.read_text().splitlines():
                        tag, workload, metric, value = line.split()
                        if tag != 'RESULT' or workload != case['workload']:
                            raise RuntimeError('Unexpected cold-harness result')
                        values[metric] = float(value)
                    measurements.append({'phase': 'all_misses', 'frames': int(values['frames']),
                                         'glyphs': int(values['glyphs']), 'total_us': values['ns_total'] / 1000})
                if not measurements:
                    raise RuntimeError('No measurements emitted')
                for result in measurements:
                    records.append({'block': block, 'order': order, 'variant': variant,
                                    'case': case['name'], **result})
                (attempt / 'partial-raw.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in records))
        (attempt / 'STATUS.json').write_text(json.dumps({'status': 'accepted', 'started_utc': started, 'ended_utc': utc()}, indent=2) + '\n')
        with raw_path.open('a') as stream:
            for record in records:
                stream.write(json.dumps(record) + '\n')
    except BaseException as error:
        (attempt / 'STATUS.json').write_text(json.dumps({'status': 'excluded', 'started_utc': started,
            'ended_utc': utc(), 'reason': str(error),
            'evidence': error.evidence if isinstance(error, GuardMatched) else None}, indent=2) + '\n')
        raise
print('Completed all blocks. Analyze with analyze.py --out', out, flush=True)
