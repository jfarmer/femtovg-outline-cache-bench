"""Absolute medians and paired percentage comparisons, grouped by block."""
import argparse
import csv
import json
import random
import statistics
from collections import defaultdict
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
args = p.parse_args()
out = args.out
groups = defaultdict(dict)
for line in (out / 'raw.jsonl').read_text().splitlines():
    row = json.loads(line)
    metric = 'draw_us' if row['case'].startswith('demo-') else 'total_us'
    key = (row['case'], row['phase'])
    groups[key][(row['block'], row['variant'])] = row[metric]


def interval(values, seed):
    rng = random.Random(seed)
    boot = sorted(statistics.median(rng.choices(values, k=len(values))) for _ in range(5000))
    return [boot[125], boot[4874]]


results = []
for group_no, ((case, phase), values) in enumerate(sorted(groups.items())):
    blocks = sorted({block for block, _ in values})
    blocks = [block for block in blocks if all((block, variant) in values for variant in ('master', 'full', 'simple'))]
    if not blocks:
        continue
    result = {'case': case, 'phase': phase, 'blocks': len(blocks), 'unit': 'us'}
    for variant in ('master', 'full', 'simple'):
        result[variant] = statistics.median(values[(block, variant)] for block in blocks)
    for candidate, baseline in [('full', 'master'), ('simple', 'master'), ('simple', 'full')]:
        label = f'{candidate}_vs_{baseline}'
        paired = [(values[(block, candidate)] / values[(block, baseline)] - 1) * 100 for block in blocks]
        result[label + '_percent'] = statistics.median(paired)
        result[label + '_ci95'] = interval(paired, 20261003 + group_no)
        result[label + '_delta_us'] = statistics.median(values[(block, candidate)] - values[(block, baseline)] for block in blocks)
    results.append(result)
(out / 'SUMMARY.json').write_text(json.dumps(results, indent=2) + '\n')
with (out / 'SUMMARY.csv').open('w') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(results[0]))
    writer.writeheader()
    writer.writerows(results)
lines = ['All values are microseconds of CPU drawing (demo) or the complete miss workload (cold).',
         'Demo setup/font loading and GPU rendering are excluded. Cold canvas/font setup is excluded.',
         '', '| Case | Phase | Master | Full | Simple | Simple / Master | Simple / Full |',
         '|---|---|---:|---:|---:|---:|---:|']
for row in results:
    lines.append(f'| {row["case"]} | {row["phase"]} | {row["master"]:.3f} | {row["full"]:.3f} | {row["simple"]:.3f} | {row["simple_vs_master_percent"]:+.2f}% | {row["simple_vs_full_percent"]:+.2f}% |')
lines += ['', 'Negative percentages mean lower CPU time. Paired block bootstrap intervals are in SUMMARY.json.',
          'Comparisons are an engineering experiment between three exact snapshots; see METADATA.json for source and binary identities.']
(out / 'REPORT.md').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
