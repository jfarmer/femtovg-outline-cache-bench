This experiment compares today's master, the full current cache, and a simpler
integration which restores the original single atlas loop. It keeps the arena,
working buffers, PNG classifier shortcut and rendering fixes in both candidates.

The demo harness is copied byte for byte from the published benchmark archive.
The cold harness is copied from the review-fixes archive, changing only the asset
path. HARNESS_PROVENANCE.json records both archived and prepared hashes. All three
manifests use the same dependency lock and release profile. No windows are opened.

After the three source snapshots in ../source/ are final:

```
python3 build.py
python3 run.py --out ./runs/comparison --blocks 12
python3 analyze.py --out ./runs/comparison
```

`build.py --variants master full` builds a subset if the prototype is still being
edited. This never performs benchmark timings. Builds and tests must finish before
run.py begins. Its process-name guard must run with permission to inspect processes;
it stops if that inspection fails or sees compilation before/during/after a child.
A stopped block is excluded in full. Re-running the same command resumes incomplete
blocks, preserving raw outputs and reasons for excluded attempts under attempts/.

The default plan has 12 blocks: each of the six three-variant orders appears twice.
Each demo process runs the archived initial draw, warm-up, warm frames, zoom and pan
with Roboto Flex, Vollkorn or Rye, at DPI 2. A no-Swash Roboto demo is the control.
Cold controls exercise all 94 distinct nonspace ASCII glyphs once, or all 94 glyphs
at each of 32 distinct sizes. Each cold process reports the median of seven fresh
canvases, excluding font loading/setup and including draw/flush.

Optional `--cases NAME ...` selects cases, and `--blocks 6` runs one balanced cycle.
Use a fresh output directory when changing the plan or binaries. Timing identities,
accepted raw results, discarded attempts, guard logs and summaries remain together.
The primary comparison is CPU drawing only; these are not whole-app launch timings.
