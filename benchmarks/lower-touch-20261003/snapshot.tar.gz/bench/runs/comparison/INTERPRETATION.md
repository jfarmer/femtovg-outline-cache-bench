The simpler integration keeps the important demo improvements. Vollkorn and Rye
remain about 29% and 40% faster than Master on the initial draw, and demo zoom
phases also improve. Its initial-draw differences from Full are not convincingly
different from zero in this comparison.

The miss controls explain the cost of removing run-level scaler reuse. They draw
94 distinct glyph IDs at one integer subpixel phase, either once or at each of 32
distinct font sizes. Every glyph/size is new to both the bitmap atlas and outline
cache, so geometry reuse cannot help those measured requests. Full constructs one
hinted scaler for each compatible glyph run; Simple constructs one for every
outline-cache miss. Both keep the same arena and working buffers.

For the 32-size Roboto Flex control (3,008 unique requests), Simple costs 5.871 ms,
compared with 5.695 ms for Master and 5.329 ms for Full. The paired Simple/Master
difference is +3.27%, with a block-bootstrap interval of +2.99% to +4.56%.
Simple/Full is +10.66%, with an interval of +7.99% to +11.95%. For Vollkorn the
same miss workload gives a smaller +1.38% Simple/Master difference (+0.13% to
+1.90%). The 94-glyph Roboto control remains faster than Master in both versions,
but Simple gives back part of Full's improvement (+13.76% Simple/Full).

These results support run-level scaler reuse as useful protection for workflows
that change glyph size often. They do not prove that keeping a second atlas loop
is the only way to achieve that reuse. The experiment removes the second loop
and the run abstraction together, so its measured difference includes their
combined integration and code-generation changes.

Warm demo frames primarily reuse the bitmap atlas and do not call either outline
cache. Most differences are small. The no-Swash warm Roboto difference is +2.25%
for Simple/Master, with an interval from -0.97% to +3.55%; it does not establish a
regression. A faster no-Swash initial draw cannot be credited to the Swash cache:
the cache is disabled there, and compiler layout, integration, or timing noise
can change the result. This experiment is too narrow to claim universally neutral
behavior outside Swash.

The demo results concern CPU layout/drawing with the Void renderer, at DPI 2.
The cold controls measure draw and flush on fresh canvases, excluding setup.
They do not measure application startup or GPU work. Absolute medians and paired
block comparisons are in SUMMARY.json; archive/source/binary identities and guard
evidence accompany the raw measurements.
