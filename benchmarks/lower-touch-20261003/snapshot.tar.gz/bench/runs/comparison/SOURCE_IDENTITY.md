# Source and measurement identities

Master is upstream commit 6a5f15ae55db439a4ed8b1e818c6521029c34fbd.
Full is b87a94ddfba46ee67ca35ba240104615ac1503d8 plus the current uncommitted encapsulation changes.
Simple is the isolated single-loop prototype made from Full. Source contents are frozen in the adjacent source snapshots; tree and per-file hashes below are authoritative.

| Variant | Source tree SHA-256 |
|---|---|
| master | `6d872a3877285ef6a38624d4f34154ea29404061f570350c11a4f3dcca2fb7d9` |
| full | `97aa2d1a8ec30a1a50a0b3bc841fd0a24200c6f8cb2b0db3e9176961661d4257` |
| simple | `e8457ec2821fe7be228216c36cf6d50620e664597efcc174bf59922d0233006e` |

Normalized shared dependency lock SHA-256: `1ef1915c26f5e3c89c097fbbc6d7b7c0929568304afb7ccba69ccdd9882c07ff`.
Build target directory used: `/private/tmp/femtovg-review-fixes-perf/target`. Binary copies were taken immediately after each corresponding build and are identified individually in METADATA.json.

Demo sources and cold sources are copied from the archived public benchmark repository. HARNESS_PROVENANCE.json records each source and its hash; only the cold asset path changed.

No windows were opened. The process-name guard rejected one sandbox-only preflight before timing because process inspection was unavailable. With process inspection permission, all 12 balanced blocks completed with no build/compiler matches and no timed exclusions.
