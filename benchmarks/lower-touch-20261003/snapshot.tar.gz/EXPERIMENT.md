# Smaller glyph-outline-cache integration

This experiment compares upstream master `6a5f15ae55db439a4ed8b1e818c6521029c34fbd`, the current full cache implementation, and a simpler integration. It answers whether the separate native atlas loop and reuse of a scaler across a run are worth retaining.

The full snapshot is commit `b87a94ddfba46ee67ca35ba240104615ac1503d8` plus the uncommitted encapsulation changes recorded in `full-workspace.diff`. The simple snapshot starts from precisely that full snapshot. Source hashes are recorded by the benchmark builder.

The simple version uses the existing atlas loop and per-glyph rendering entry point. The private rasterizer looks up geometry before accessing Swash's scaling context, and constructs its own scaler on a miss. The key and scaler use the same font, size and variation coordinates. It retains the arena, reusable native Outline and Zeno scratch, the budget growth correction, PNG classification shortcut, and all three rendering fixes. It removes the separate native atlas loop, quad helper, run/fallback segmentation and HintedGlyphRun abstraction.

The intended tradeoff is less integration code versus scaler construction on every outline miss. Cache hits still skip scaler construction. Color glyphs remain uncached and also use a scaler per glyph.

Validation on the isolated simple snapshot:

- Default plus Swash: 186 library tests passed.
- Swash only: 169 library tests passed.
- Default without Swash: 163 library tests passed.
- No default features: library check passed.
- Formatting check passed.
- A new regression test first reproduced the old cached-hit borrow panic, then passed: cached outline rendering needs no borrow of ScaleContext.

The performance comparison uses the existing CPU demo adapter without windows and the existing 94-glyph one-use and 32-size miss controls. Font/image loading and Canvas setup are outside the measured region. It measures CPU Canvas drawing and Void flush where specified, not GPU execution or app launch. The same harness, assets, dependency lock and release profile apply to all three versions. Twelve blocks balance all six version orders twice. Compiler/build process detection excludes a whole interrupted block and retains its raw observations.

No production working-tree changes are replaced by this experiment, and no PR is created.
