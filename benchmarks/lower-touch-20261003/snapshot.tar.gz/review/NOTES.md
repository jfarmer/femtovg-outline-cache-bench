# Read-only lower-touch review

The smaller snapshot keeps one `GlyphAtlas::render_atlas` loop and returns native rasterization to the existing per-glyph miss path. No lost finite-position correctness behavior was found by inspection. This review ran no builds, tests or timings and does not establish performance equivalence.

- Native fill eligibility controls floor-based nonnegative phases and phase-ten carry. Generic strokes and fonts unavailable to Swash retain the original signed-fraction/u8 phase behavior.
- Uploaded native outline and color-outline images mark fractional positioning; native bitmap and generic fallback entries use truncated origins on both cold and warm draws. The flag remains stored with the bitmap atlas entry.
- The font classifier retains the original PNG metadata predicate and two-batch ordering, including PNG/COLR overlap. Direct paths, strokes, non-Swash paths, and fonts unreadable by Swash keep generic path classification.
- Per-glyph native rendering returns and drops its context/scaler before generic fallback. This removes the shared-context conflict that the full version handled by ending run segments. The result-restoration closure remains around the whole atlas loop, so returned allocation/upload errors restore screen, image and layer targets. Existing generic PNG upload `unwrap` behavior is unchanged; the closure does not establish panic restoration.
- The optional cache-key arguments are constructed from the same font reference, size bits and normalized coordinates used immediately to build the miss scaler. Cache hits return before borrowing the scale context. Cold, unadmitted and color glyphs rebuild that scaler per glyph. This is a real tradeoff, and full-version timing claims cannot be inherited by the prototype.
- The only unnecessary production accessor found was `SwashRasterizer::scale_context`; root subsequently made it private and test-only before the count below. The reviewed cache budget and arena implementation otherwise remain unchanged.

The comparison changes both atlas-loop structure and scaler reuse. It does not isolate either cause or show that a separate native atlas loop is necessary.

## Size comparison

`count-lines.py` counts physical Rust lines containing code after lexically removing comments, preserving strings/characters/raw strings, excluding blank lines and manually reviewed test-only boundaries/accessors. Attributes and brace-only lines count. For changed-line counts, line-edge whitespace is ignored so wrapping the old loop in a restoration closure does not create indentation-only churn. The JSON records every input SHA256. These are source-size measures, not semantic complexity or compiled per-feature size.

| Measure relative to master | Full snapshot | Simple snapshot | Reduction |
|---|---:|---:|---:|
| Net added production code lines | 439 | 293 | 146 (33%) |
| Existing-file integration net addition | 182 | 68 | 114 (63%) |
| Existing-file integration added/deleted lines | +241/−59 | +115/−47 | Churn 300→162 |
| New rasterizer production code lines | 257 | 225 | 32 |
| Net added test/support code lines | 1,026 | 1,013 | 13 |

The existing-file integration scope is `lib.rs`, `text.rs`, and `text/font.rs`; the new cache module is separate. Counts include all production feature branches. `full` denotes the named local snapshot, which includes encapsulation changes beyond the historical b87 commit; its exact digests are recorded instead of assuming commit identity.

## One-loop scaler-reuse option

A single atlas loop can retain a configured native scaler if native rasterization and Swash-only generic fallback use different scale contexts. The native rasterizer would own a context separate from the existing `Font::glyph` context. An external Rc clone permits a native context borrow and private configured run to surround the one atlas loop; a native miss uses that run, and generic fallback safely uses its independent context inside the same loop. Phase flags, classification, quad construction and result restoration can stay in the current loop.

That route introduces another context and possibly duplicates font/proxy/hint buffers, adds a configured-run helper, and changes first-use memory/cache behavior. The geometry budget does not cap those contexts. With the current shared context, a retained scaler must release its borrow before Swash-only fallback can borrow the context; a lifetime boundary is unavoidable. The option is credible but needs its own functional, performance and memory checks. No second variant is proposed for this turn.
