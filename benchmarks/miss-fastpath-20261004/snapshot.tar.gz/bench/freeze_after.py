"""Freeze one tracked working tree; never builds or runs benchmarks."""
import argparse
import datetime
import hashlib
import json
import shutil
import subprocess
from pathlib import Path
from common import ROOT, files, source_snapshot, tree_digest

MASTER = '9d574e076d3ce6006d9a21a01e3ae8a3bc649a57'
BEFORE = '907bb375645613b3647efab4c0efe29b50ed5b18'
parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, default=Path('/Users/jesse/github/femtovg'))
args = parser.parse_args()
repo = args.repo.resolve()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)


def diff(ref):
    return git('diff', '--binary', ref, '--')


head = git('rev-parse', 'HEAD').decode().strip()
if head != BEFORE:
    raise RuntimeError(f'Expected working tree based on {BEFORE}; HEAD is {head}')
for ref in (MASTER, BEFORE):
    if git('rev-parse', ref).decode().strip() != ref:
        raise RuntimeError(f'Cannot resolve source ref: {ref}')

after = ROOT.parent / 'source' / 'after'
if after.exists() or (ROOT / 'BUILD.json').exists() or (ROOT / 'runs').exists():
    raise RuntimeError('This study is already frozen/built/timed; use a new study for changed source')
identities = {variant: source_snapshot(variant) for variant in ('master', 'before')}
tracked = [entry.decode() for entry in git('ls-files', '-z').split(b'\0') if entry]
patches = {'before': diff(BEFORE), 'master': diff(MASTER)}
source_before = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest()
                 for name in tracked if (repo / name).is_file()}

after.mkdir(parents=True)
for name in source_before:
    target = after / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo / name, target)

# Reject an edit racing the source copy instead of attaching mixed provenance.
source_after = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest()
                for name in tracked if (repo / name).is_file()}
if source_before != source_after or any(diff(ref) != patches[label]
                                       for label, ref in [('before', BEFORE), ('master', MASTER)]):
    raise RuntimeError('Tracked source changed during freezing; discard this partial study')
if files(after) != source_before:
    raise RuntimeError('Frozen copy differs from tracked source')
identities['after'] = source_snapshot('after')

changes = {}
for label, ref in [('before', BEFORE), ('master', MASTER)]:
    path = ROOT / f'after-vs-{label}.diff'
    path.write_bytes(patches[label])
    changes[label] = {'base': ref, 'patch_sha256': hashlib.sha256(patches[label]).hexdigest()}

record = {
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'master_commit': MASTER,
    'before_commit': BEFORE,
    'after_status': 'frozen tracked working tree based on before_commit',
    'after_commit': None,
    'tracked_source_base_commit': head,
    'after_tracked_source_matches_working_tree': True,
    'sources': identities,
    'changes': changes,
}
(ROOT / 'SOURCE_FREEZE.json').write_text(json.dumps(record, indent=2) + '\n')
print('Frozen after source:', identities['after']['tree_sha256'])
print('Recorded working-tree base, both patch hashes and all source file hashes.')
