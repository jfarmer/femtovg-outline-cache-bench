"""Run the existing library suites serially; never performs benchmark timings."""
import hashlib
import json
import subprocess
import time
from pathlib import Path

from common import ROOT

repository = Path('/Users/jesse/github/femtovg')
out = ROOT / 'validation'
out.mkdir(exist_ok=True)
source = repository / 'src/text/swash_rasterizer.rs'
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
commands = [
    ('format', ['cargo', 'fmt', '--check']),
    ('default-swash', ['cargo', 'nextest', 'run', '--lib', '--locked', '--offline', '--features', 'swash', '--status-level', 'fail', '--final-status-level', 'fail']),
    ('swash-only', ['cargo', 'nextest', 'run', '--lib', '--locked', '--offline', '--no-default-features', '--features', 'swash', '--status-level', 'fail', '--final-status-level', 'fail']),
    ('default-no-swash', ['cargo', 'nextest', 'run', '--lib', '--locked', '--offline', '--status-level', 'fail', '--final-status-level', 'fail']),
]
results = []
for name, command in commands:
    print('Running', name, flush=True)
    started = time.monotonic()
    log_path = out / f'{name}.log'
    with log_path.open('w') as log:
        process = subprocess.run(command, cwd=repository, stdout=log, stderr=subprocess.STDOUT)
    result = {'name': name, 'command': command, 'exit_code': process.returncode,
              'elapsed_seconds': time.monotonic() - started, 'log': str(log_path)}
    results.append(result)
    (out / 'RESULTS.json').write_text(json.dumps({'rasterizer_sha256': source_hash, 'results': results}, indent=2) + '\n')
    print('\n'.join(log_path.read_text().splitlines()[-8:]), flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
if hashlib.sha256(source.read_bytes()).hexdigest() != source_hash:
    raise RuntimeError('Rasterizer changed during validation')
print('All validations passed.', flush=True)
