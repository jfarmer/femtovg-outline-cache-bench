"""Absolute medians and paired percentage comparisons, grouped by block."""
import argparse
import csv
import json
import random
import statistics
from collections import defaultdict
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
args = p.parse_args()
out = args.out
groups = defaultdict(dict)
stress_counts = defaultdict(dict)
for line in (out / 'raw.jsonl').read_text().splitlines():
    row = json.loads(line)
    metric = 'draw_us' if row['case'].startswith('demo-') else 'total_us'
    key = (row['case'], row['phase'])
    groups[key][(row['block'], row['variant'])] = row[metric]
    if row['case'].startswith('stress-') and row['phase'] != 'complete_sequence':
        stress_counts[(row['block'], row['case'], row['phase'])][row['variant']] = tuple(
            row[name] for name in ('frames', 'glyph_requests_per_frame', 'distinct_glyph_size_instances_per_frame',
                                   'text_draw_calls_per_frame', 'logical_width', 'logical_height',
                                   'nominal_characters_per_row'))
for case, counts in stress_counts.items():
    if set(counts) != {'master', 'before', 'after'} or len(set(counts.values())) != 1:
        raise RuntimeError(f'Stress visible workload differs between variants: {case}')


def interval(values, seed):
    rng = random.Random(seed)
    boot = sorted(statistics.median(rng.choices(values, k=len(values))) for _ in range(5000))
    return [boot[125], boot[4874]]


results = []
for group_no, ((case, phase), values) in enumerate(sorted(groups.items())):
    blocks = sorted({block for block, _ in values})
    blocks = [block for block in blocks if all((block, variant) in values for variant in ('master', 'before', 'after'))]
    if not blocks:
        continue
    result = {'case': case, 'phase': phase, 'blocks': len(blocks),
              'unit': 'us/sequence' if phase == 'complete_sequence' else 'us'}
    for variant in ('master', 'before', 'after'):
        result[variant] = statistics.median(values[(block, variant)] for block in blocks)
    for candidate, baseline in [('before', 'master'), ('after', 'master'), ('after', 'before')]:
        label = f'{candidate}_vs_{baseline}'
        paired = [(values[(block, candidate)] / values[(block, baseline)] - 1) * 100 for block in blocks]
        result[label + '_percent'] = statistics.median(paired)
        result[label + '_ci95'] = interval(paired, 20261004 + group_no)
        result[label + '_delta_us'] = statistics.median(values[(block, candidate)] - values[(block, baseline)] for block in blocks)
    results.append(result)
(out / 'SUMMARY.json').write_text(json.dumps(results, indent=2) + '\n')
with (out / 'SUMMARY.csv').open('w') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(results[0]))
    writer.writeheader()
    writer.writerows(results)
lines = ['All values are microseconds of CPU drawing (demo), the complete miss workload (cold), or CPU drawing plus Void flush (stress).',
         'Demo setup/font loading and GPU rendering are excluded. Cold canvas/font setup is excluded.',
         '', '| Case | Phase | Master | Before | After | After / Master | After / Before |',
         '|---|---|---:|---:|---:|---:|---:|']
for row in results:
    lines.append(f'| {row["case"]} | {row["phase"]} | {row["master"]:.3f} | {row["before"]:.3f} | {row["after"]:.3f} | {row["after_vs_master_percent"]:+.2f}% | {row["after_vs_before_percent"]:+.2f}% |')
lines += ['', 'Negative percentages mean lower CPU time. Paired block bootstrap intervals are in SUMMARY.json.',
          'Master is frozen upstream 9d574e0; Before is committed cache branch 907bb37; After is the frozen working tree with the miss fast path. See METADATA.json for exact source and binary identities.']
(out / 'REPORT.md').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
