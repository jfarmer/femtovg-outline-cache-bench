# Normal-miss fast-path comparison

A narrow comparison of three frozen source trees: upstream master `9d574e0`,
committed cache branch `907bb37` (`before`), and the working-tree insertion
fast path (`after`). This study retains the existing scenes, assets, release
profile, normalized dependency locks and name-only build-process guard.
There are no new scenes, features or instrumentation. Earlier studies are
left intact. Source and binary identities are saved in BUILD.json.

The default run includes all seven existing cases in one six-block dataset:
the FemtoVG demo with Roboto Flex, Vollkorn and Rye; the non-Swash Roboto
control; the 32-size all-miss Roboto and Vollkorn controls; and Fleur de Leah
stress. Every order of the three variants appears once. The runner retains
interrupted blocks but excludes them and resumes at the first incomplete
block. No timing-based filtering is performed.

Demo timing is CPU drawing only. Miss/stress controls include Void flush.
Font loading and Canvas creation are excluded; there are no windows or GPU
timings. Six-block bootstrap intervals are exploratory.

Once the after source is frozen and the machine is quiet, run:

```sh
python3 freeze_after.py
python3 build.py --target-dir /Users/jesse/github/femtovg/target
python3 run.py --out runs/comparison --blocks 6
python3 analyze.py --out runs/comparison
python3 audit.py --out runs/comparison
```

The initial miss-only selection, if needed before the final validation, is:

```sh
python3 run.py --out runs/misses --blocks 6 --cases grid_unique_sizes-RobotoFlex grid_unique_sizes-Vollkorn
```

After source is frozen,
SOURCE_FREEZE.json records its correspondence to the base commit and both
patch hashes. Old absolute timing values are not relabeled or pooled with
this experiment.
