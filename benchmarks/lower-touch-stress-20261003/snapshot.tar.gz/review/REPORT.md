# Independent lower-touch stress audit

PASS: original stdout from all 108 processes independently reconstructs all 540 accepted raw records, including the 108 complete weighted sequence totals. No benchmark runner/analyzer was imported and no builds or timings were executed by this audit.

The matrix has 12 complete three-way blocks, with every variant in every order position four times and every pair in each relative order six times. No excluded attempts or guard matches. All variants report identical 1,980 requests, 198 glyph/font/size instances, 30 public text calls, 66 characters per row and 1800×1200 logical dimensions. There are 432 phase records and 4,752 measured frames.

All 15 summary rows and 45 paired contrast estimates/intervals match the stored analysis exactly. Bootstrap: 5,000 resamples of paired block changes, median statistic, seed 20261003 plus alphabetical-font/declared-phase group index; percentile order indices 125/4874. These are exploratory intervals without multiplicity adjustment. Additional paired absolute-delta intervals use the same protocol. Sequence totals include first paint 1, warm 30, changing size 12 and return 1 before pairing; marginal medians do not generally subtract to the paired median delta.

The exact archived stress harness and three font/applicable OFL files match their declared hashes. All three frozen source trees match the earlier prototype study byte-for-byte, their current compiled binary copies match BUILD.json, normalized locks match and explicit release profiles match. Build logs identify compilation from each intended local source. Full denotes the named encapsulation snapshot, not an assumed historical b87 source identity. Compiler-artifact JSON, resolved feature metadata and ambient build environment were not captured in this campaign; provenance relies on the explicit hash-bound build script, manifests, logs and source/binary hashes.

| Font | Phase | Master ms | Full ms | Simple ms | Simple−master ms [95% CI] | Simple−full ms [95% CI] |
|---|---|---:|---:|---:|---|---|
| FleurDeLeah | first_paint | 90.256 | 20.183 | 20.504 | -69.844 [-71.392, -69.162] | +0.454 [+0.165, +0.870] |
| FleurDeLeah | new_size | 91.617 | 21.734 | 21.740 | -69.636 [-70.178, -69.126] | -0.024 [-0.075, +0.288] |
| FleurDeLeah | warm | 0.154 | 0.144 | 0.139 | -0.015 [-0.019, -0.011] | -0.005 [-0.008, +0.000] |
| FleurDeLeah | return | 0.237 | 0.220 | 0.214 | -0.024 [-0.036, -0.013] | -0.005 [-0.018, +0.002] |
| FleurDeLeah | sequence44 | 1194.589 | 285.742 | 286.643 | -904.331 [-912.390, -902.708] | +0.003 [-0.561, +4.452] |
| RobotoFlex | first_paint | 4.705 | 3.966 | 4.001 | -0.709 [-0.802, -0.579] | -0.000 [-0.113, +0.068] |
| RobotoFlex | new_size | 5.101 | 4.207 | 4.302 | -0.822 [-0.867, -0.728] | +0.053 [-0.024, +0.116] |
| RobotoFlex | warm | 0.166 | 0.159 | 0.146 | -0.021 [-0.025, -0.014] | -0.013 [-0.016, -0.009] |
| RobotoFlex | return | 0.205 | 0.179 | 0.197 | -0.013 [-0.042, +0.009] | +0.014 [-0.002, +0.031] |
| RobotoFlex | sequence44 | 71.033 | 59.390 | 60.169 | -11.262 [-11.636, -10.033] | +0.350 [-0.725, +0.931] |
| Rye | first_paint | 52.129 | 13.078 | 13.380 | -38.671 [-38.975, -38.255] | +0.292 [+0.014, +0.410] |
| Rye | new_size | 52.772 | 13.767 | 13.926 | -38.839 [-39.174, -38.586] | +0.129 [+0.068, +0.272] |
| Rye | warm | 0.154 | 0.145 | 0.140 | -0.012 [-0.015, -0.010] | -0.005 [-0.007, -0.001] |
| Rye | return | 0.227 | 0.216 | 0.210 | -0.015 [-0.027, -0.003] | -0.000 [-0.022, +0.010] |
| Rye | sequence44 | 689.915 | 182.903 | 184.764 | -504.974 [-509.424, -501.621] | +1.735 [+0.635, +3.285] |

## Interpretation

Both caches retain the key phase-independent hinted geometry and check it before scaler construction. Simple can therefore retain the large cross-phase benefit while rebuilding its scaler on geometry misses. This combined comparison does not isolate loop structure from scaler lifetime. Requested phase bins and nominal request counts are not measured cache hit/miss, scaler-build or eviction counts.

DPI 1 with identity transform uses native sizes 14/20/28 pixels plus the size-change delta and row shifts 0..0.9 in 0.1 native units, requesting up to ten phase bins. Warm/return mostly exercise the outer bitmap atlas. Changing-size frames retain same-frame reuse and are not pure misses. This dense constructed CPU scene includes layout/drawing plus Void flush; it is not an established maximal workload or application/GPU/window frame-time claim.

Raw stdout contains phase means, not per-frame latency distributions. Per-phase count assertions are enforced by the unchanged harness. Guard logs show sampled before/during/after checks rather than continuous machine isolation. The original accepted record stream and study artifacts were read without alteration.

