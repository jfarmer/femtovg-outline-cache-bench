# Mechanism reviewed before numerical analysis

The byte-preserved proof sheet draws the same 66-character specimen at three font sizes, each in ten fractionally shifted rows. At DPI 1 and identity transform, those row origins shift by 0.1 native atlas unit, requesting up to ten canonical phase bins. Every reported frame has 1,980 public glyph requests and 198 distinct glyph/font/size instances. Actual cache hits, misses, scaler builds and evictions are not instrumented.

Both full and simple rasterizers key retained hinted geometry by font identity, glyph ID, exact font-size bits and normalized variation coordinates. Phase is absent from that key. Both look up this geometry before constructing a native scaler. Later rows can therefore produce different phase masks from the same retained geometry without rehinting or constructing another scaler. The simpler integration preserves this main source of reuse.

The tradeoff occurs on geometry misses: the full integration reuses a scaler across its text-run segment, while simple constructs one for each glyph that needs uncached geometry. The initial rows of a fresh context and every changing-size frame introduce new size-specific keys, so this scene still exercises that cost. Cache admission/pressure can create additional misses. The exact difference cannot be inferred from the nominal request count.

Warm and return frames primarily reuse the outer bitmap atlas. Their timings assess the whole rendering path; they do not measure hinted-outline hits or prove geometry retention. Changing-size frames include repeated same-frame reuse across the shifted rows and are not a pure miss-only control.

The expected interpretation is that simple can retain substantial cross-phase savings while giving up some miss overhead benefit. It is a hypothesis grounded in the cache lookup order, not a claim about the eventual measurements. The comparison changes both scaler lifetime and atlas-loop structure, so it cannot independently assign an observed difference to either change.

The scene measures adaptive page layout, public text layout/drawing, simple panel paths and Void flushing. Canvas creation and font loading are outside frame timing. It is a dense constructed CPU workload, not an established globally maximal font/workload or a GPU/window/app frame-time measurement.
