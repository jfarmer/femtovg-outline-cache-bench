#!/usr/bin/env python3
"""Independent stdout reconstruction; imports no benchmark runner/analyzer."""
import csv
import datetime
import hashlib
import io
import itertools
import json
from pathlib import Path
import random
import tomllib

STUDY = Path(__file__).resolve().parents[1]
BENCH = STUDY / 'bench'
RUN = BENCH / 'runs/comparison'
VARIANTS = ['master', 'full', 'simple']
FONTS = ['FleurDeLeah', 'Rye', 'RobotoFlex']
PHASES = [('first_paint', 1), ('warm', 30), ('new_size', 12), ('return', 1)]
REPORT_PHASES = ['first_paint', 'new_size', 'warm', 'return', 'sequence44']
COUNT_FIELDS = ['glyph_requests_per_frame', 'distinct_glyph_size_instances_per_frame',
                'text_draw_calls_per_frame', 'logical_width', 'logical_height', 'nominal_characters_per_row']
EXPECTED_COUNTS = [1980, 198, 30, 1800, 1200, 66]
PAIRS = [('full', 'master'), ('simple', 'master'), ('simple', 'full')]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]


def median(values):
    s = sorted(values)
    n = len(s)
    return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2


def interval(values, seed):
    # Equivalent to unweighted choices, reconstructed with independent indices.
    rng = random.Random(seed)
    n = len(values)
    samples = sorted(median([values[int(rng.random() * n)] for _ in range(n)]) for _ in range(5000))
    return [samples[125], samples[4874]]


def date(value):
    return datetime.datetime.fromisoformat(value)


def snapshot(directory):
    entries = {str(p.relative_to(directory)): sha(p) for p in directory.rglob('*')
               if p.is_file() and not any(part in ['.git', '.serena', 'target', '__pycache__']
                                         for part in p.relative_to(directory).parts)}
    return {'tree_sha256': hashlib.sha256(json.dumps(entries, sort_keys=True).encode()).hexdigest(), 'files': entries}


def identities():
    build = load(BENCH / 'BUILD.json')
    prior = load(BENCH / 'PRIOR_BUILD.json')
    metadata = load(RUN / 'METADATA.json')
    assert metadata['build'] == build
    harness = load(BENCH / 'HARNESS_PROVENANCE.json')
    h = harness['harness']
    assert sha(BENCH / h['path']) == sha(h['archive_path']) == h['sha256']
    assert h['sha256'] == '8a16f144fc32b0808cd4202d79b19ba1faf23b356894a5fa20c62541e0a418e5'
    assert build['harness'] == {str(p.relative_to(BENCH / 'harness-src')): sha(p)
                                for p in (BENCH / 'harness-src').rglob('*') if p.is_file()}
    assert build['assets'] == {str(p.relative_to(BENCH / 'assets')): sha(p)
                               for p in (BENCH / 'assets').rglob('*') if p.is_file()}
    for asset in harness['assets']:
        assert sha(BENCH / asset['path']) == sha(asset['archive_path']) == asset['sha256']
        if asset['path'].endswith(('.txt', 'LICENSE-Rye', 'LICENSE-FleurDeLeah')):
            assert 'SIL Open Font License, Version 1.1' in (BENCH / asset['path']).read_text()
    locks = []
    profiles = []
    result = {'harness_sha256': h['sha256'], 'font_and_applicable_license_bytes_match_archive': True,
              'toolchain': {'rustc': build['rustc'], 'cargo': build['cargo']}, 'variants': {}}
    for variant in VARIANTS:
        identity = build['variants'][variant]
        current = snapshot(STUDY / 'source' / variant)
        assert current == identity['source'] == prior['variants'][variant]['source']
        assert current == snapshot(Path('/private/tmp/femtovg-lower-touch-20261003/source') / variant)
        assert sha(identity['binary']['path']) == identity['binary']['sha256']
        manifest_path = BENCH / 'harness' / variant / 'Cargo.toml'
        lock_path = manifest_path.with_name('Cargo.lock')
        assert sha(manifest_path) == identity['manifest_sha256'] and sha(lock_path) == identity['lock_sha256']
        manifest = tomllib.loads(manifest_path.read_text())
        assert (manifest_path.parent / manifest['dependencies']['femtovg']['path']).resolve() == STUDY / 'source' / variant
        assert not manifest['dependencies']['femtovg']['default-features']
        assert manifest['features']['default_swash'] == ['femtovg/default', 'femtovg/swash']
        profiles.append(manifest['profile']['release'])
        normalized = lock_path.read_text().replace(f'femtovg-lower-touch-stress-{variant}', 'femtovg-lower-touch-stress-VARIANT')
        locks.append(normalized)
        log = (BENCH / 'build-logs' / f'{variant}.log').read_text()
        assert f'Compiling femtovg v0.27.0 ({STUDY / "source" / variant})' in log
        assert 'Finished `release` profile [optimized]' in log
        result['variants'][variant] = {'source_tree_sha256': current['tree_sha256'], 'source_files_verified': len(current['files']),
            'binary_sha256': identity['binary']['sha256'], 'manifest_sha256': identity['manifest_sha256'],
            'lock_sha256': identity['lock_sha256'], 'build_log_sha256': sha(BENCH / 'build-logs' / f'{variant}.log')}
    assert len(set(locks)) == 1
    assert hashlib.sha256(locks[0].encode()).hexdigest() == build['normalized_lock_sha256']
    assert profiles[0] == profiles[1] == profiles[2] == {'opt-level': 3, 'debug': False, 'lto': False,
                                                      'codegen-units': 16, 'incremental': False, 'panic': 'unwind'}
    result['same_explicit_profile_and_normalized_lock'] = True
    result['profile'] = profiles[0]
    result['build_evidence_limit'] = ('Build logs, hash-bound script, manifests and copied binaries identify the three local sources. '
        'This study does not preserve compiler-artifact JSON, Cargo feature-resolution metadata, or ambient RUSTFLAGS/environment. '
        'Full denotes the named encapsulation snapshot, not an assumed byte identity with historical b87.')
    return result


def observations():
    plan = load(RUN / 'PLAN.json')
    orders = list(itertools.permutations(VARIANTS)) * 2
    assert plan['blocks'] == 12 and plan['orders'] == [list(order) for order in orders]
    assert list(plan['fonts']) == FONTS and plan['dpi'] == plan['trials_per_process'] == 1
    assert plan['phase_frames'] == dict(PHASES)
    raw = jsonl(RUN / 'raw.jsonl')
    reconstructed = []
    statuses = sorted((RUN / 'attempts').glob('*/STATUS.json'))
    assert len(statuses) == 12 and all(load(path)['status'] == 'accepted' for path in statuses)
    assert [path.parent.name for path in statuses] == [f'block-{b:02d}-00' for b in range(12)]
    checks = jsonl(RUN / 'guard-checks.jsonl')
    assert all(c['status'] == 'idle' and c['pids'] == [] for c in checks)
    assert all(date(a['checked_utc']) <= date(b['checked_utc']) for a, b in zip(checks, checks[1:]))
    sequences = []
    for block, order in enumerate(orders):
        attempt = RUN / 'attempts' / f'block-{block:02d}-00'
        status = load(attempt / 'STATUS.json')
        assert date(status['started_utc']) <= date(status['ended_utc'])
        process_guards = [c for c in checks if c['context'].get('block') == block]
        before_order = [(c['context']['variant'], c['context']['font']) for c in process_guards
                        if c['context']['stage'] == 'before_process']
        assert before_order == [(variant, font) for variant in order for font in FONTS]
        for variant in order:
            for font in FONTS:
                relevant = [c for c in process_guards if c['context'].get('variant') == variant and c['context'].get('font') == font]
                stages = [c['context']['stage'] for c in relevant]
                assert stages[0] == 'before_process' and stages[-1] == 'after_process'
                assert all(stage == 'during_process' for stage in stages[1:-1])
                assert date(status['started_utc']) <= date(relevant[0]['checked_utc']) <= date(relevant[-1]['checked_utc']) <= date(status['ended_utc'])
                stderr = attempt / f'{variant}-{font}.stderr'
                assert stderr.read_text() == ''
                stdout = (attempt / f'{variant}-{font}.stdout').read_text()
                rows = list(csv.DictReader(io.StringIO(stdout)))
                assert [(r['phase'], int(r['frames'])) for r in rows] == PHASES
                measured = []
                for row in rows:
                    assert row['scene'] == 'proofsheet' and row['trial'] == '0'
                    assert [int(row[k]) for k in COUNT_FIELDS] == EXPECTED_COUNTS
                    record = {'block': block, 'order': list(order), 'variant': variant, 'font': font,
                              'phase': row['phase'], 'frames': int(row['frames']),
                              **{k: float(row[k]) for k in ['draw_us', 'flush_us', 'total_us']},
                              **{k: int(row[k]) for k in COUNT_FIELDS}}
                    assert record['draw_us'] > 0 and record['flush_us'] >= 0
                    assert abs(record['draw_us'] + record['flush_us'] - record['total_us']) < 0.000002
                    measured.append(record)
                reconstructed.extend(measured)
                sequence = {'block': block, 'order': list(order), 'variant': variant, 'font': font,
                            'phase': 'sequence44', 'frames': 44,
                            **{metric: sum(r[metric] * r['frames'] for r in measured)
                               for metric in ['draw_us', 'flush_us', 'total_us']}}
                reconstructed.append(sequence)
                sequences.append(sequence)
        assert jsonl(attempt / 'partial-raw.jsonl') == reconstructed[-45:]
    assert raw == reconstructed and len(raw) == 540
    assert len({(r['block'], r['variant'], r['font'], r['phase']) for r in raw}) == 540
    for candidate, baseline in PAIRS:
        assert sum(order.index(candidate) < order.index(baseline) for order in orders) == 6
    assert all(sum(order[position] == variant for order in orders) == 4 for variant in VARIANTS for position in range(3))
    return raw, {'accepted_blocks': 12, 'accepted_processes': 108, 'phase_records': 432, 'derived_sequence_records': 108,
        'raw_records': 540, 'measured_frames': 4752, 'excluded_attempts': 0, 'guard_checks': len(checks),
        'guard_matches': 0, 'all_pair_orders_balanced_6_AB_6_BA': True, 'all_variant_positions_balanced_4_each': True,
        'shape_count_dimensions_equal_all_variants_blocks_phases': True, 'expected_per_frame_counts': dict(zip(COUNT_FIELDS, EXPECTED_COUNTS)),
        'all_sequence44_values_reconstructed_from_stdout': True, 'all_weighted_sequences': sequences}


def numerical(rows):
    stored = load(RUN / 'SUMMARY.json')
    values = {(r['font'], r['phase'], r['block'], r['variant']): r['total_us'] for r in rows}
    results = []
    error = 0.0
    for group_no, (font, phase) in enumerate((font, phase) for font in sorted(FONTS) for phase in REPORT_PHASES):
        row = {'font': font, 'phase': phase, 'blocks': 12, 'unit': 'us',
               'meaning': 'complete 44-frame sequence' if phase == 'sequence44' else 'per-frame phase mean'}
        arrays = {variant: [values[(font, phase, block, variant)] for block in range(12)] for variant in VARIANTS}
        for variant in VARIANTS:
            row[variant] = median(arrays[variant])
        deltas = {}
        for candidate, baseline in PAIRS:
            label = f'{candidate}_vs_{baseline}'
            paired = [(c / b - 1) * 100 for c, b in zip(arrays[candidate], arrays[baseline])]
            absolute = [c - b for c, b in zip(arrays[candidate], arrays[baseline])]
            row[label + '_percent'] = median(paired)
            row[label + '_ci95'] = interval(paired, 20261003 + group_no)
            row[label + '_delta_us'] = median(absolute)
            deltas[label] = {'median_us': median(absolute), 'ci95_us': interval(absolute, 20261003 + group_no),
                             'paired_deltas_us': absolute, 'paired_percent_changes': paired}
        assert set(row) == set(stored[group_no])
        for key, value in row.items():
            expected = stored[group_no][key]
            if isinstance(value, str):
                assert value == expected
            else:
                pairs = zip(value, expected) if isinstance(value, list) else [(value, expected)]
                for a, b in pairs:
                    discrepancy = abs(a - b)
                    error = max(error, discrepancy)
                    assert discrepancy <= max(1e-8, abs(b) * 1e-11), (font, phase, key, a, b)
        results.append({'reconstructed_summary': row, 'absolute_paired_costs': deltas})
    assert len(stored) == len(results) == 15
    return results, error


def report(result):
    lines = ['# Independent lower-touch stress audit', '',
        'PASS: original stdout from all 108 processes independently reconstructs all 540 accepted raw records, including the 108 complete weighted sequence totals. No benchmark runner/analyzer was imported and no builds or timings were executed by this audit.', '',
        'The matrix has 12 complete three-way blocks, with every variant in every order position four times and every pair in each relative order six times. No excluded attempts or guard matches. All variants report identical 1,980 requests, 198 glyph/font/size instances, 30 public text calls, 66 characters per row and 1800×1200 logical dimensions. There are 432 phase records and 4,752 measured frames.', '',
        'All 15 summary rows and 45 paired contrast estimates/intervals match the stored analysis exactly. Bootstrap: 5,000 resamples of paired block changes, median statistic, seed20261003 plus alphabetical-font/declared-phase group index; percentile order indices125/4874. These are exploratory intervals without multiplicity adjustment. Additional paired absolute-delta intervals use the same protocol. Sequence totals include first paint1, warm30, changing size12 and return1 before pairing; marginal medians do not generally subtract to the paired median delta.', '',
        'The exact archived stress harness and three font/applicable OFL files match their declared hashes. All three frozen source trees match the earlier prototype study byte-for-byte, their current compiled binary copies match BUILD.json, normalized locks match and explicit release profiles match. Build logs identify compilation from each intended local source. Full denotes the named encapsulation snapshot, not an assumed historical b87 source identity. Compiler-artifact JSON, resolved feature metadata and ambient build environment were not captured in this campaign; provenance relies on the explicit hash-bound build script, manifests, logs and source/binary hashes.', '',
        '| Font | Phase | Master ms | Full ms | Simple ms | Simple−master ms [95% CI] | Simple−full ms [95% CI] |',
        '|---|---|---:|---:|---:|---|---|']
    for item in result['results']:
        row = item['reconstructed_summary']
        master = item['absolute_paired_costs']['simple_vs_master']
        full = item['absolute_paired_costs']['simple_vs_full']
        interval_text = lambda cost: f'{cost["median_us"]/1000:+.3f} [{cost["ci95_us"][0]/1000:+.3f}, {cost["ci95_us"][1]/1000:+.3f}]'
        lines.append(f'| {row["font"]} | {row["phase"]} | {row["master"]/1000:.3f} | {row["full"]/1000:.3f} | {row["simple"]/1000:.3f} | {interval_text(master)} | {interval_text(full)} |')
    lines.extend(['', '## Interpretation', '',
        'Both caches retain the key phase-independent hinted geometry and check it before scaler construction. Simple can therefore retain the large cross-phase benefit while rebuilding its scaler on geometry misses. This combined comparison does not isolate loop structure from scaler lifetime. Requested phase bins and nominal request counts are not measured cache hit/miss, scaler-build or eviction counts.', '',
        'DPI1 with identity transform uses native sizes14/20/28 pixels plus the size-change delta and row shifts0..0.9 in0.1 native units, requesting up to ten phase bins. Warm/return mostly exercise the outer bitmap atlas. Changing-size frames retain same-frame reuse and are not pure misses. This dense constructed CPU scene includes layout/drawing plus Void flush; it is not an established maximal workload or application/GPU/window frame-time claim.', '',
        'Raw stdout contains phase means, not per-frame latency distributions. Per-phase count assertions are enforced by the unchanged harness. Guard logs show sampled before/during/after checks rather than continuous machine isolation. The original accepted record stream and study artifacts were read without alteration.', ''])
    return '\n'.join(lines).replace('seed20261003', 'seed 20261003').replace('indices125', 'indices 125').replace('paint1', 'paint 1').replace('warm30', 'warm 30').replace('size12', 'size 12').replace('return1', 'return 1').replace('DPI1', 'DPI 1').replace('sizes14', 'sizes 14').replace('shifts0', 'shifts 0').replace('in0.', 'in 0.') + '\n'


def main():
    original_hashes = {str(p.relative_to(RUN)): sha(p) for p in RUN.rglob('*') if p.is_file()}
    provenance = identities()
    rows, structure = observations()
    results, error = numerical(rows)
    assert original_hashes == {str(p.relative_to(RUN)): sha(p) for p in RUN.rglob('*') if p.is_file()}
    result = {'status': 'PASS', 'audit_script_sha256': sha(Path(__file__)), 'structure': structure,
        'provenance': provenance, 'summary_rows_verified': 15, 'paired_contrasts_verified': 45,
        'largest_absolute_statistical_discrepancy': error, 'results': results,
        'original_run_files_unchanged': True, 'run_file_hashes': original_hashes}
    (STUDY / 'review/AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
    (STUDY / 'review/REPORT.md').write_text(report(result))
    print(json.dumps({k: result[k] for k in ['status', 'summary_rows_verified', 'paired_contrasts_verified', 'largest_absolute_statistical_discrepancy']}))


if __name__ == '__main__':
    main()
