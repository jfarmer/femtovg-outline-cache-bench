"""Absolute stress medians, paired comparisons, and scene-count equality audit."""
import argparse
import csv
import json
import random
import statistics
from collections import Counter, defaultdict
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
args = p.parse_args()
out = args.out
rows = [json.loads(line) for line in (out / 'raw.jsonl').read_text().splitlines()]
plan = json.loads((out / 'PLAN.json').read_text())
expected_blocks = plan['blocks']
assert len(rows) == expected_blocks * 3 * 3 * 5
keys = [(r['block'], r['variant'], r['font'], r['phase']) for r in rows]
assert len(set(keys)) == len(keys)
assert Counter(r['block'] for r in rows) == {b: 45 for b in range(expected_blocks)}
groups = defaultdict(dict)
scenes = defaultdict(set)
count_fields = ['frames', 'glyph_requests_per_frame', 'distinct_glyph_size_instances_per_frame',
                'text_draw_calls_per_frame', 'logical_width', 'logical_height', 'nominal_characters_per_row']
for row in rows:
    groups[(row['font'], row['phase'])][(row['block'], row['variant'])] = row['total_us']
    if row['phase'] != 'sequence44':
        scenes[(row['font'], row['phase'])].add(tuple(row[key] for key in count_fields))
assert all(len(values) == 1 for values in scenes.values()), 'Scene counts or dimensions differ between sources/blocks'
scene_summary = [{**{'font': font, 'phase': phase}, **dict(zip(count_fields, next(iter(values))))}
                 for (font, phase), values in sorted(scenes.items())]
(out / 'SCENE_COUNTS.json').write_text(json.dumps(scene_summary, indent=2) + '\n')


def interval(values, seed):
    rng = random.Random(seed)
    boot = sorted(statistics.median(rng.choices(values, k=len(values))) for _ in range(5000))
    return [boot[125], boot[4874]]


results = []
phase_order = ['first_paint', 'new_size', 'warm', 'return', 'sequence44']
for group_no, ((font, phase), values) in enumerate(sorted(groups.items(), key=lambda item: (item[0][0], phase_order.index(item[0][1])))):
    blocks = list(range(expected_blocks))
    assert all((block, variant) in values for block in blocks for variant in ['master', 'full', 'simple'])
    result = {'font': font, 'phase': phase, 'blocks': len(blocks), 'unit': 'us',
              'meaning': 'complete 44-frame sequence' if phase == 'sequence44' else 'per-frame phase mean'}
    for variant in ['master', 'full', 'simple']:
        result[variant] = statistics.median(values[(block, variant)] for block in blocks)
    for candidate, baseline in [('full', 'master'), ('simple', 'master'), ('simple', 'full')]:
        label = f'{candidate}_vs_{baseline}'
        paired = [(values[(block, candidate)] / values[(block, baseline)] - 1) * 100 for block in blocks]
        result[label + '_percent'] = statistics.median(paired)
        result[label + '_ci95'] = interval(paired, 20261003 + group_no)
        result[label + '_delta_us'] = statistics.median(values[(block, candidate)] - values[(block, baseline)] for block in blocks)
    results.append(result)
(out / 'SUMMARY.json').write_text(json.dumps(results, indent=2) + '\n')
with (out / 'SUMMARY.csv').open('w') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(results[0]))
    writer.writeheader()
    writer.writerows(results)
lines = ['All times are milliseconds of CPU draw + flush with the Void renderer, at DPI 1.',
         'The first four phases report time per frame. Sequence44 reports the complete weighted 44-frame total.',
         '', '| Font | Phase | Master | Full | Simple | Simple / Master | Simple / Full |',
         '|---|---|---:|---:|---:|---:|---:|']
for row in results:
    lines.append(f'| {row["font"]} | {row["phase"]} | {row["master"] / 1000:.3f} | {row["full"] / 1000:.3f} | {row["simple"] / 1000:.3f} | {row["simple_vs_master_percent"]:+.2f}% | {row["simple_vs_full_percent"]:+.2f}% |')
lines += ['', 'Source/binary identities are in METADATA.json; paired block-bootstrap intervals are in SUMMARY.json.',
          'Actual shaped glyph counts and viewport dimensions match across all three versions and all accepted blocks; see SCENE_COUNTS.json.']
statuses = [json.loads(path.read_text())['status'] for path in (out / 'attempts').glob('*/STATUS.json')]
checks = [json.loads(line) for line in (out / 'guard-checks.jsonl').read_text().splitlines()]
audit = {'accepted_rows': len(rows), 'accepted_blocks': statuses.count('accepted'),
         'excluded_blocks': statuses.count('excluded'), 'duplicates': 0, 'all_blocks_complete': True,
         'scene_counts_and_dimensions_equal_across_variants_and_blocks': True,
         'guard_checks': len(checks), 'matched_build_process_checks': sum(r['status'] == 'matched' for r in checks),
         'preflight_guard_failures': sum(r['status'] == 'guard_failed' for r in checks)}
assert audit['accepted_blocks'] == expected_blocks
(out / 'AUDIT.json').write_text(json.dumps(audit, indent=2) + '\n')
(out / 'REPORT.md').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
