The simpler integration retains the large savings in the extreme scene. Fleur
De Leah's first draw goes from 90.256 ms on Master to 20.504 ms on Simple; Full is
20.183 ms. During size changes, Master costs 91.617 ms per frame and Simple costs
21.740 ms, essentially matching Full's 21.734 ms. Rye and Roboto Flex also retain
large improvements over Master in both phases.

The small differences from Full are measurable in some cases. Simple's paired
first-draw penalty is +2.25% for Fleur De Leah (interval +0.82% to +3.66%) and
+2.24% for Rye (+0.11% to +3.16%). Rye's size-change penalty is +0.94% (+0.50% to
+1.98%). The Fleur size-change and complete-sequence comparisons do not establish
a difference; Roboto Flex's first-draw, size-change and complete-sequence
comparisons against Full likewise include zero in their intervals.

Every measured frame emits 1,980 actual shaped glyph requests: 66 characters at
three font sizes and ten horizontal phases, with 198 distinct glyph/size
instances and 30 text draw calls. The logical viewport is 1800 by 1200 for every
font, phase, source version and accepted block. These counts are measured from
the public text API; native rasterizer hits or scaler constructions are not
instrumented.

This scene changes sizes between frames, but repeats each glyph/size across ten
positions within the same frame. Cached hinted geometry can therefore still help
during size changes. It is a different workload from the earlier 32-size control,
which draws each glyph/size at just one phase and offers no outline reuse. The
combined evidence is that Simple preserves the main benefit when geometry is
reused, while giving back some miss protection when every request is new.

The complete 44-frame CPU sequence contains one initial draw, 30 warm frames,
12 size-change frames and one return. Fleur De Leah takes 1194.589 ms on Master,
285.742 ms on Full and 286.643 ms on Simple. These are total CPU draw/flush times
with the Void renderer at DPI 1, excluding font I/O, font registration and Canvas
construction. They are not app-launch or GPU timings.

Twelve balanced blocks used all six three-version orders twice. All 540 emitted
and derived observations are retained. The guard checked process names 573 times;
it saw no compilation, no timing attempts were excluded, and all source/font
identities were verified before the run. SUMMARY.json contains paired intervals
and absolute medians; SCENE_COUNTS.json records the shape and viewport equality.
