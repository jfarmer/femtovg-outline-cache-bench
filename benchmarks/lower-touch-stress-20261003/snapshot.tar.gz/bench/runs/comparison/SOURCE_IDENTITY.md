# Stress experiment identities

The three source snapshots match the prior lower-touch study byte for byte.

| Source | Tree SHA-256 |
|---|---|
| master | `6d872a3877285ef6a38624d4f34154ea29404061f570350c11a4f3dcca2fb7d9` |
| full | `97aa2d1a8ec30a1a50a0b3bc841fd0a24200c6f8cb2b0db3e9176961661d4257` |
| simple | `e8457ec2821fe7be228216c36cf6d50620e664597efcc174bf59922d0233006e` |

Unmodified archived harness SHA-256: `8a16f144fc32b0808cd4202d79b19ba1faf23b356894a5fa20c62541e0a418e5`.
Normalized shared dependency lock SHA-256: `a08e4b23cae60bc9e37ad0610b491663d158ce01f245700df8bf3d8541916515`.

Master: upstream 6a5f15ae55db439a4ed8b1e818c6521029c34fbd.
Full: b87a94ddfba46ee67ca35ba240104615ac1503d8 plus the frozen encapsulation changes from the preceding study.
Simple: the exact single-loop prototype from that study, with no new feature-code edits.

Full per-file source hashes, binary identities, compiler version, release profile and build logs accompany these results. The retained font licenses include Roboto Flex OFL; the legacy Apache LICENSE-Roboto was not used for that font.
