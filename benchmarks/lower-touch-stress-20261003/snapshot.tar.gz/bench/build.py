"""Build frozen stress snapshots; never time during compilation."""
import argparse
import hashlib
import json
import shutil
import subprocess
from pathlib import Path
from common import ROOT, VARIANTS, binary, files, sha256, source_snapshot

p = argparse.ArgumentParser()
p.add_argument('--target-dir', type=Path, default=ROOT / 'target')
args = p.parse_args()
(ROOT / 'bin').mkdir(exist_ok=True)
(ROOT / 'build-logs').mkdir(exist_ok=True)
prior = json.loads((ROOT / 'PRIOR_BUILD.json').read_text())
metadata = {'variants': {}, 'target_dir': str(args.target_dir.resolve()),
            'rustc': subprocess.check_output(['rustc', '-vV'], text=True),
            'cargo': subprocess.check_output(['cargo', '--version'], text=True),
            'harness': files(ROOT / 'harness-src'), 'assets': files(ROOT / 'assets')}
locks = [(ROOT / 'harness' / variant / 'Cargo.lock').read_text().replace(
         f'femtovg-lower-touch-stress-{variant}', 'femtovg-lower-touch-stress-VARIANT')
         for variant in VARIANTS]
if len(set(locks)) != 1:
    raise RuntimeError('Dependency locks differ beyond the root package name')
metadata['normalized_lock_sha256'] = hashlib.sha256(locks[0].encode()).hexdigest()
for variant in VARIANTS:
    source = source_snapshot(variant)
    if source != prior['variants'][variant]['source']:
        raise RuntimeError(f'{variant} differs from the earlier frozen snapshot')
    manifest = ROOT / 'harness' / variant / 'Cargo.toml'
    command = ['cargo', 'build', '--locked', '--offline', '--release',
               '--manifest-path', str(manifest), '--target-dir', str(args.target_dir),
               '--features', 'default_swash', '--bins']
    with (ROOT / 'build-logs' / f'{variant}.log').open('w') as log:
        print('Building', variant, flush=True)
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    if source_snapshot(variant) != source:
        raise RuntimeError(f'{variant} changed during its build')
    destination = binary(variant, 'default_swash', 'stress')
    shutil.copy2(args.target_dir / 'release' / f'hinting-stress-{variant}', destination)
    metadata['variants'][variant] = {'source': source,
        'binary': {'path': str(destination), 'sha256': sha256(destination)},
        'manifest_sha256': sha256(manifest),
        'lock_sha256': sha256(manifest.with_name('Cargo.lock'))}
    (ROOT / 'BUILD.json').write_text(json.dumps(metadata, indent=2) + '\n')
print('Stress binaries built and frozen; identities recorded in BUILD.json.', flush=True)
