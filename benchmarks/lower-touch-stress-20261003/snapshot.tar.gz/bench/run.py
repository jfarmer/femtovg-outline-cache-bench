"""Same archived stress scene in balanced three-way process blocks."""
import argparse
import csv
import io
import itertools
import json
import os
import platform
import subprocess
import time
from pathlib import Path
from common import ROOT, VARIANTS, binary, files, sha256, source_snapshot
from guard import GuardMatched, ensure_idle, utc, wait_idle

FONTS = {'FleurDeLeah': 'FleurDeLeah-Regular.ttf', 'Rye': 'Rye-Regular.ttf',
         'RobotoFlex': 'RobotoFlex-VariableFont.ttf'}
PHASE_FRAMES = {'first_paint': 1, 'warm': 30, 'new_size': 12, 'return': 1}
COUNT_FIELDS = ['glyph_requests_per_frame', 'distinct_glyph_size_instances_per_frame',
                'text_draw_calls_per_frame', 'logical_width', 'logical_height', 'nominal_characters_per_row']
p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
p.add_argument('--blocks', type=int, choices=(6, 12), default=12)
p.add_argument('--quiet-seconds', type=float, default=5)
args = p.parse_args()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
orders = list(itertools.permutations(VARIANTS)) * (args.blocks // 6)
plan = json.loads(json.dumps({'blocks': args.blocks, 'orders': orders, 'fonts': FONTS,
    'dpi': 1, 'trials_per_process': 1, 'phase_frames': PHASE_FRAMES,
    'primary_metric': 'total_us', 'sequence_metric': 'sum(phase total_us * phase frames), 44 frames',
    'guard': 'before each child, every 0.1 seconds during, and after; discard entire interrupted block',
    'resume': 'Completed blocks only; excluded partial attempts retained'}))
plan_path = out / 'PLAN.json'
if plan_path.exists() and json.loads(plan_path.read_text()) != plan:
    raise RuntimeError('Changed resume plan; use a fresh output directory')
plan_path.write_text(json.dumps(plan, indent=2) + '\n')
build = json.loads((ROOT / 'BUILD.json').read_text())
if build['harness'] != files(ROOT / 'harness-src') or build['assets'] != files(ROOT / 'assets'):
    raise RuntimeError('Harness or font bytes changed since build')
for variant in VARIANTS:
    identity = build['variants'][variant]
    if source_snapshot(variant) != identity['source']:
        raise RuntimeError(f'{variant} differs from the built source')
    if sha256(Path(identity['binary']['path'])) != identity['binary']['sha256']:
        raise RuntimeError(f'{variant} binary hash mismatch')
metadata = {'created_utc': utc(), 'platform': platform.platform(), 'cpu_count': os.cpu_count(), 'build': build}
metadata_path = out / 'METADATA.json'
if metadata_path.exists():
    if json.loads(metadata_path.read_text())['build'] != build:
        raise RuntimeError('Resume identities changed; use a fresh output directory')
else:
    metadata_path.write_text(json.dumps(metadata, indent=2) + '\n')
wait_idle(out, args.quiet_seconds, time.monotonic() + 60, {'stage': 'pre_run'})
raw_path = out / 'raw.jsonl'
completed = {json.loads(line)['block'] for line in raw_path.read_text().splitlines()} if raw_path.exists() else set()
for block, order in enumerate(orders):
    if block in completed:
        continue
    attempts = out / 'attempts'
    attempts.mkdir(exist_ok=True)
    attempt_no = len(list(attempts.glob(f'block-{block:02d}-*')))
    attempt = attempts / f'block-{block:02d}-{attempt_no:02d}'
    attempt.mkdir()
    started = utc()
    records = []
    print(f'Block {block + 1}/{args.blocks}: {" ".join(order)}', flush=True)
    try:
        for variant in order:
            for font, filename in FONTS.items():
                context = {'block': block, 'variant': variant, 'font': font}
                ensure_idle(out, {'stage': 'before_process', **context})
                command = [str(binary(variant, 'default_swash', 'stress')),
                           str(ROOT / 'assets' / font / filename), 'proofsheet', '1', '1']
                stdout_path = attempt / f'{variant}-{font}.stdout'
                stderr_path = attempt / f'{variant}-{font}.stderr'
                with stdout_path.open('w') as stdout, stderr_path.open('w') as stderr:
                    child = subprocess.Popen(command, stdout=stdout, stderr=stderr)
                    try:
                        while child.poll() is None:
                            ensure_idle(out, {'stage': 'during_process', **context})
                            time.sleep(0.1)
                    except BaseException:
                        child.terminate()
                        try:
                            child.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            child.kill()
                            child.wait()
                        raise
                    if child.returncode:
                        raise RuntimeError(f'Stress process exited {child.returncode}: {stderr_path}')
                ensure_idle(out, {'stage': 'after_process', **context})
                measured = []
                for row in csv.DictReader(io.StringIO(stdout_path.read_text())):
                    if row['scene'] != 'proofsheet' or int(row['trial']) != 0:
                        raise RuntimeError('Unexpected stress result')
                    result = {'block': block, 'order': order, 'variant': variant, 'font': font,
                              'phase': row['phase'], 'frames': int(row['frames']),
                              **{k: float(row[k]) for k in ['draw_us', 'flush_us', 'total_us']},
                              **{k: int(row[k]) for k in COUNT_FIELDS}}
                    measured.append(result)
                if {r['phase']: r['frames'] for r in measured} != PHASE_FRAMES or len(measured) != 4:
                    raise RuntimeError('Stress phase/frame sequence differs from the archived scene')
                records.extend(measured)
                records.append({'block': block, 'order': order, 'variant': variant, 'font': font,
                                'phase': 'sequence44', 'frames': 44,
                                **{metric: sum(r[metric] * r['frames'] for r in measured)
                                   for metric in ['draw_us', 'flush_us', 'total_us']}})
                (attempt / 'partial-raw.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in records))
        (attempt / 'STATUS.json').write_text(json.dumps({'status': 'accepted', 'started_utc': started, 'ended_utc': utc()}, indent=2) + '\n')
        with raw_path.open('a') as stream:
            for record in records:
                stream.write(json.dumps(record) + '\n')
    except BaseException as error:
        (attempt / 'STATUS.json').write_text(json.dumps({'status': 'excluded', 'started_utc': started,
            'ended_utc': utc(), 'reason': str(error),
            'evidence': error.evidence if isinstance(error, GuardMatched) else None}, indent=2) + '\n')
        raise
print('Stress comparison completed; run analyze.py --out', out, flush=True)
