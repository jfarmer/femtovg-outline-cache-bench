This is the same archived extreme hinting scene used in the public benchmark,
comparing the exact Master, Full and Simple snapshots from the lower-touch study.
It opens no windows. The Rust harness is byte-identical to the archived source.
Every copied source file was checked against the preceding study's BUILD.json.
Fonts are the archived Fleur De Leah, Rye and Roboto Flex files; Roboto Flex's
corrected OFL license is included. Provenance and hashes accompany the results.

```
python3 build.py --target-dir /private/tmp/femtovg-review-fixes-perf/target
python3 run.py --out runs/comparison --blocks 12
python3 analyze.py --out runs/comparison
```

The measured phases are one initial draw, 30 warm frames, 12 successive size
changes, and one return to the original sizes. Every frame draws three bands at
ten horizontal pixel offsets. The complete sequence has 44 frames. Its reported
total weights each phase mean by its frame count, then sums all four phases.
No font I/O/registration or canvas creation is inside the measured time.

Orders are all six permutations of Master/Full/Simple repeated twice. The runner
checks for compiler/build processes before, every 0.1 seconds during, and after
each child. It excludes an entire interrupted block and retains its raw outputs.
Permission to inspect process names is required. Repeating the same command
resumes incomplete blocks; changing the plan or binaries requires a new output
directory. No builds or tests may run during benchmark timing.

The analysis compares actual shaped counts, distinct glyph/size instances, text
draw calls, nominal text length and logical dimensions across every variant and
accepted block. Native outline-hit and scaler-build counts are not instrumented.
The primary metric is total CPU draw plus flush, using the Void renderer at DPI 1.
