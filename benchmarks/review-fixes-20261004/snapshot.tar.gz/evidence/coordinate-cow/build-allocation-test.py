from pathlib import Path

source = Path('/Users/jesse/github/femtovg/src/text/swash_rasterizer.rs').read_text()
header = '''
use std::{alloc::{GlobalAlloc, Layout, System}, cell::Cell};
struct Allocator;
thread_local! { static COUNT: Cell<Option<usize>> = const { Cell::new(None) }; }
unsafe impl GlobalAlloc for Allocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let _ = COUNT.try_with(|count| { if let Some(n) = count.get() { count.set(Some(n + 1)); } });
        System.alloc(layout)
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) { System.dealloc(ptr, layout); }
}
#[global_allocator]
static ALLOCATOR: Allocator = Allocator;
mod rasterizer {
'''
test = '''
#[test]
fn coordinate_cache_hits_have_no_key_allocation() {
    let data = std::fs::read("/Users/jesse/github/femtovg/examples/assets/RobotoFlex-VariableFont.ttf").unwrap();
    let font = FontRef::from_index(&data, 0).unwrap();
    let glyph = font.charmap().map('g');
    let coordinates = vec![0; font.variations().len()];
    let mut state = RasterizerState::new(Rc::default());
    for coords in [&[][..], coordinates.as_slice()] {
        for phase in 0..10 { state.render(font, 24.0, glyph, phase as f32 / 10.0, coords).unwrap(); }
    }
    let context = state.scale_context();
    let _guard = context.borrow_mut();
    let mut counts = Vec::new();
    for coords in [&[][..], coordinates.as_slice()] {
        crate::COUNT.with(|count| count.set(Some(0)));
        for index in 0..1000 { state.render(font, 24.0, glyph, (index % 10) as f32 / 10.0, coords).unwrap(); }
        counts.push(crate::COUNT.with(|count| count.replace(None).unwrap()));
    }
    assert_eq!(counts[0], counts[1], "empty versus nonempty coordinate hits: {counts:?}");
    println!("1000 hits: empty coords {} allocation calls; nonempty coords {}", counts[0], counts[1]);
}
}
'''
Path('/private/tmp/femtovg-cow-key-review/allocation-tests.rs').write_text(header + source + test)
