"""Independent reconstruction; imports no study runner/analyzer code.

Run only after every timing cohort has stopped. Writes review/ artifacts only.
"""
import csv
import hashlib
import itertools
import json
import math
import random
import re
import statistics as stats
import subprocess
from pathlib import Path

STUDY = Path(__file__).resolve().parents[1]
BENCH = STUDY / 'bench'
DEST = Path(__file__).resolve().parent
VARIANTS = ('master', 'before', 'after')


def read_json(path):
    return json.loads(path.read_text())


def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def assert_equal(actual, expected):
    if isinstance(expected, dict):
        assert set(actual) == set(expected), (set(actual), set(expected))
        for key in expected:
            assert_equal(actual[key], expected[key])
    elif isinstance(expected, list):
        assert len(actual) == len(expected)
        for a, e in zip(actual, expected):
            assert_equal(a, e)
    elif isinstance(expected, float):
        assert math.isclose(actual, expected, rel_tol=1e-11, abs_tol=1e-8), (actual, expected)
    else:
        assert actual == expected, (actual, expected)


def reconstruct(attempt, block, order, cases):
    rows = []
    for variant in order:
        for case in cases:
            path = attempt / f'{variant}-{case["name"]}.stdout'
            if case['kind'] == 'cold':
                values = {}
                for line in path.read_text().splitlines():
                    tag, workload, metric, value = line.split()
                    assert (tag, workload) == ('RESULT', case['workload'])
                    assert metric not in values
                    values[metric] = float(value)
                assert (values['frames'], values['glyphs']) == (32, 3008)
                measurements = [{'phase': 'all_misses', 'frames': 32, 'glyphs': 3008,
                                 'total_us': values['ns_total'] / 1000}]
            else:
                with path.open() as stream:
                    source = list(csv.DictReader(stream))
                phases = [('first_paint', 1), ('warm', 30)]
                phases += [('zoom_in', 12), ('zoom_out', 12), ('pan', 10)] if case['kind'] == 'scenes' else [('new_size', 12), ('return', 1)]
                assert [(s['phase'], int(s['frames'])) for s in source] == phases
                measurements = []
                for s in source:
                    assert s['scene'] == ('demo' if case['kind'] == 'scenes' else 'proofsheet')
                    assert s['trial'] == '0'
                    m = {'phase': s['phase'], 'frames': int(s['frames'])}
                    m.update({key: float(s[key]) for key in ('draw_us', 'flush_us', 'total_us')})
                    if case['kind'] == 'stress':
                        fields = ('glyph_requests_per_frame', 'distinct_glyph_size_instances_per_frame',
                                  'text_draw_calls_per_frame', 'logical_width', 'logical_height',
                                  'nominal_characters_per_row')
                        m.update({key: int(s[key]) for key in fields})
                        assert tuple(m[key] for key in fields) == (1980, 198, 30, 1800, 1200, 66)
                    measurements.append(m)
                if case['kind'] == 'stress':
                    measurements.append({'phase': 'complete_sequence', 'frames': 44,
                                         'total_us': sum(m['frames'] * m['total_us'] for m in measurements)})
            rows.extend({'block': block, 'order': order, 'variant': variant,
                         'case': case['name'], **m} for m in measurements)
    return rows


def confidence(values, seed):
    rng = random.Random(seed)
    samples = sorted(stats.median(rng.choices(values, k=len(values))) for _ in range(5000))
    return [samples[125], samples[4874]]


def summarize(rows):
    groups = {}
    for r in rows:
        key = (r['case'], r['phase'])
        pair = (r['block'], r['variant'])
        metric = 'draw_us' if r['case'].startswith('demo-') else 'total_us'
        assert pair not in groups.setdefault(key, {})
        groups[key][pair] = r[metric]
    summary = []
    for group_no, ((case, phase), values) in enumerate(sorted(groups.items())):
        blocks = sorted(set(b for b, _ in values))
        assert set(values) == set(itertools.product(blocks, VARIANTS))
        result = {'case': case, 'phase': phase, 'blocks': len(blocks),
                  'unit': 'us/sequence' if phase == 'complete_sequence' else 'us'}
        for variant in VARIANTS:
            result[variant] = stats.median(values[b, variant] for b in blocks)
        for candidate, baseline in [('before', 'master'), ('after', 'master'), ('after', 'before')]:
            label = f'{candidate}_vs_{baseline}'
            percentages = [(values[b, candidate] / values[b, baseline] - 1) * 100 for b in blocks]
            result[label + '_percent'] = stats.median(percentages)
            result[label + '_ci95'] = confidence(percentages, 20261004 + group_no)
            result[label + '_delta_us'] = stats.median(values[b, candidate] - values[b, baseline] for b in blocks)
        summary.append(result)
    return summary


def audit_cohort(out, build):
    plan = read_json(out / 'PLAN.json')
    assert_equal(read_json(out / 'METADATA.json')['build'], build)
    probe = 'warm_requests' in plan
    expected_orders = ([['before', 'after'] if n % 2 == 0 else ['after', 'before'] for n in range(plan['blocks'])]
                       if probe else list(map(list, itertools.permutations(VARIANTS))) * (plan['blocks'] // 6))
    assert plan['orders'] == expected_orders
    guards = read_rows(out / 'guard-checks.jsonl')
    accepted = {}
    excluded = []
    for attempt in sorted((out / 'attempts').iterdir()):
        block = int(re.fullmatch(r'block-(\d+)-(\d+)', attempt.name).group(1))
        status = read_json(attempt / 'STATUS.json')
        if status['status'] == 'excluded':
            partial = read_rows(attempt / 'partial-raw.jsonl') if (attempt / 'partial-raw.jsonl').exists() else []
            excluded.append({'attempt': attempt.name, 'records': len(partial), 'reason': status['reason'],
                             'evidence': status.get('evidence')})
            continue
        assert status['status'] == 'accepted' and block not in accepted
        order = expected_orders[block]
        window = [g for g in guards if status['started_utc'] <= g['checked_utc'] <= status['ended_utc']]
        assert window and all(g['status'] == 'idle' for g in window)
        if probe:
            restored = []
            for variant in order:
                original = read_rows(attempt / f'{variant}.stdout')
                assert [r['case'] for r in original] == ['coords_hits', 'empty_coords_hits', 'near_budget_roboto', 'near_budget_vollkorn']
                restored.extend({'block': block, 'order': order, 'variant': variant, **r} for r in original)
            process_keys = [(v, 'private_module_probe') for v in order]
        else:
            restored = reconstruct(attempt, block, order, plan['cases'])
            process_keys = [(v, c['name']) for v in order for c in plan['cases']]
        for variant, case in process_keys:
            stages = {g['context']['stage'] for g in window if g['context'].get('block') == block
                      and g['context'].get('variant') == variant and g['context'].get('case') == case}
            assert {'before_process', 'after_process'} <= stages
        assert_equal(read_rows(attempt / 'partial-raw.jsonl'), restored)
        accepted[block] = restored
    assert set(accepted) == set(range(plan['blocks']))
    restored = [r for block in range(plan['blocks']) for r in accepted[block]]
    assert_equal(read_rows(out / 'raw.jsonl'), restored)
    if probe:
        summary = []
        for case, variant in sorted(set((r['case'], r['variant']) for r in restored)):
            group = [r for r in restored if (r['case'], r['variant']) == (case, variant)]
            assert len(group) == plan['blocks']
            result = {'case': case, 'variant': variant, 'blocks': len(group)}
            for key in group[0]:
                if key not in ('case', 'variant', 'block', 'order'):
                    assert key == 'ns_total' or len(set(r[key] for r in group)) == 1
                    result[key] = stats.median(r[key] for r in group)
            summary.append(result)
    else:
        summary = summarize(restored)
    assert_equal(read_json(out / 'SUMMARY.json'), summary)
    return {'path': str(out), 'blocks': plan['blocks'], 'accepted_records': len(restored),
            'accepted_processes': sum(len(list((out / 'attempts').glob(f'block-{b:02d}-*/*.stdout'))) for b in accepted)
            - sum(len(list((out / 'attempts' / e['attempt']).glob('*.stdout'))) for e in excluded),
            'excluded_attempts': excluded, 'summary': summary}


def main():
    build = read_json(BENCH / 'BUILD.json')
    normalized_locks = [(BENCH / 'harness' / variant / 'Cargo.lock').read_text()
                        .replace(f'femtovg-feedback-{variant}', 'femtovg-feedback-VARIANT')
                        for variant in VARIANTS]
    assert len(set(normalized_locks)) == 1
    assert hashlib.sha256(json.dumps({'lock': normalized_locks[0]}, sort_keys=True).encode()).hexdigest() == build['normalized_lock_sha256']
    feature_profiles = []
    for variant in VARIANTS:
        manifest = (BENCH / 'harness' / variant / 'Cargo.toml').read_text()
        feature_profiles.append(tuple((name, body.strip()) for name, body in
                                      re.findall(r'(?ms)^\[(features|profile\.release)\]\n(.*?)(?=^\[|\Z)', manifest)))
        assert 'default-features = false' in manifest
    assert len(set(feature_profiles)) == 1
    checked = 0
    for name in ('harness-src', 'harness', 'assets'):
        mapping = build[{'harness-src': 'harness', 'harness': 'harness_packages', 'assets': 'assets'}[name]]
        for relative, expected in mapping.items():
            assert digest(BENCH / name / relative) == expected
            checked += 1
    for variant, record in build['variants'].items():
        source = record['source']
        assert hashlib.sha256(json.dumps(source['files'], sort_keys=True).encode()).hexdigest() == source['tree_sha256']
        for relative, expected in source['files'].items():
            assert digest(STUDY / 'source' / variant / relative) == expected
            checked += 1
        for binary in record['binaries'].values():
            assert digest(Path(binary['path'])) == binary['sha256']
            checked += 1
    references = {'master': '9d574e076d3ce6006d9a21a01e3ae8a3bc649a57',
                  'before': 'af989d9b617e9f424cb05974b057e4099592267a',
                  'after': '907bb375645613b3647efab4c0efe29b50ed5b18'}
    reference_files = ('Cargo.toml', 'src/lib.rs', 'src/text.rs', 'src/text/font.rs',
                       'src/text/swash_rasterizer.rs', 'src/text/glyph_atlas_tests.rs',
                       'src/text/glyph_atlas_fallback_tests.rs')
    for variant, reference in references.items():
        for relative in reference_files:
            if relative not in build['variants'][variant]['source']['files']:
                continue
            blob = subprocess.check_output(['git', '-C', '/Users/jesse/github/femtovg',
                                            'show', f'{reference}:{relative}'])
            assert hashlib.sha256(blob).hexdigest() == build['variants'][variant]['source']['files'][relative]
    cohorts = [audit_cohort(BENCH / 'runs' / name, build)
               for name in ('comparison-final', 'stress-final', 'probe-final')]
    assert len(cohorts) == 3, 'Expected completed comparison, stress and mechanism probe'
    old = BENCH / 'runs' / 'comparison'
    assert not (old / 'raw.jsonl').exists() and not (old / 'attempts').exists()
    old_guards = read_rows(old / 'guard-checks.jsonl')
    prestart = {'path': str(old), 'timing_samples': 0, 'guard_records': len(old_guards),
                'guard_status_counts': {s: sum(r['status'] == s for r in old_guards)
                                        for s in sorted(set(r['status'] for r in old_guards))}}
    probes = {(r['case'], r['variant']): r for r in cohorts[-1]['summary']}
    mechanism = {}
    for case in ('coords_hits', 'empty_coords_hits', 'near_budget_roboto', 'near_budget_vollkorn'):
        before, after = (probes[case, v] for v in ('before', 'after'))
        assert before['requests'] == after['requests'] == (4096 if 'hits' in case else 4000)
        entry = {'requests': after['requests'], 'allocations_before': before['allocations'],
                 'allocations_after': after['allocations']}
        if case.startswith('near_budget'):
            for r in (before, after):
                assert r['high_water_bytes'] <= 1048576
            for variant, r in [('before', before), ('after', after)]:
                entry['capacity_changes_' + variant] = sum(r[k] for k in ('point_grows', 'verb_grows', 'point_trims', 'verb_trims'))
                entry['peak_entries_' + variant] = r['peak_entries']
                entry['modeled_high_water_bytes_' + variant] = r['high_water_bytes']
        mechanism[case] = entry
    result = {'status': 'PASS', 'method': 'Independent stdout/matrix/statistical reconstruction; no runner imports',
              'verified_file_hashes': checked, 'source_git_references': references,
              'after_source_tree_sha256': build['variants']['after']['source']['tree_sha256'],
              'after_source_file_count': len(build['variants']['after']['source']['files']),
              'normalized_locks_and_feature_profiles_equal': True,
              'cohorts': cohorts, 'preserved_prestart_attempt': prestart, 'mechanism_counts': mechanism,
              'limits': ['CPU/Void measurements do not measure backend/GPU render-target switch cost.',
                         'Six balanced blocks; exploratory percentile intervals, no multiplicity correction.',
                         'Probe is a combined review-fix comparison with counters; capacity observations are net per request.',
                         'Cumulative allocator requested bytes are not retained memory or RSS.']}
    (DEST / 'AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# Independent feedback performance audit', '', 'PASS: accepted stdout, complete block matrices, guard windows, source/harness/assets/binary hashes and reported summaries agree.', '']
    for cohort in cohorts:
        lines.append(f'- `{Path(cohort["path"]).name}`: {cohort["blocks"]} accepted blocks, {cohort["accepted_processes"]} processes, {cohort["accepted_records"]} records, {len(cohort["summary"])} summary rows; {len(cohort["excluded_attempts"])} excluded attempts retained.')
    lines += ['', 'Each three-way pair is balanced 3 AB / 3 BA. Six permutations also balance positions. Absolute medians, median paired deltas/percentages and every 5,000-resample seed/percentile interval were reconstructed without importing the analyzer.', '', '## Limits', '']
    lines.extend('- ' + limit for limit in result['limits'])
    lines += ['', 'Public API and per-glyph target-switch review: [API_REVIEW.md](../bench/API_REVIEW.md).', '']
    lines += ['## Source and exclusions', '',
              f'Final source: `{references["after"]}`; frozen 150-file tree `{result["after_source_tree_sha256"]}`. Upstream is `9d574e0`; the before-fixes cache control is `af989d9`. Dependency locks match after normalizing the harness package name; feature wiring and release profiles match. Build metadata records rustc 1.96.0, opt-level 3, no LTO, 16 codegen units.', '',
              'The interrupted stress block `block-02-00` retains five partial records and the Cargo-nextest PID evidence (12113/12114). Its entire block was excluded; the accepted replacement used the same logical order. No comparison/probe blocks were excluded. The old `comparison` directory contains 55 pre-start guard checks (53 matched, one failed, one idle), with no attempts or timing samples; it was not reused.', '',
              '## Representative final results', '',
              'Absolute values below are marginal medians in milliseconds. Percentages and intervals are medians of paired block differences in relative time; they need not equal the ratio of marginal medians. Demo measures drawing/layout at DPI 2; stress measures drawing plus Void flush at DPI 1. Font/canvas setup and GPU rendering are excluded.', '',
              '| Workload | Master ms | Final ms | Paired change (95% exploratory CI) |',
              '|---|---:|---:|---:|']
    selected = [('demo-RobotoFlex', 'first_paint'), ('demo-Vollkorn', 'first_paint'),
                ('demo-Rye', 'first_paint'), ('grid_unique_sizes-RobotoFlex', 'all_misses'),
                ('grid_unique_sizes-Vollkorn', 'all_misses'), ('stress-FleurDeLeah', 'first_paint'),
                ('stress-FleurDeLeah', 'complete_sequence')]
    main_rows = {(r['case'], r['phase']): r for c in cohorts[:-1] for r in c['summary']}
    for key in selected:
        r = main_rows[key]
        ci = r['after_vs_master_ci95']
        lines.append(f'| {key[0]} / {key[1]} | {r["master"]/1000:.3f} | {r["after"]/1000:.3f} | {r["after_vs_master_percent"]:+.2f}% [{ci[0]:+.2f}, {ci[1]:+.2f}] |')
    lines += ['', 'The all-miss rows are complete 32-frame/3,008-request sequences. Roboto has a measured cost: paired +195.52 µs/sequence (+6.11 µs/frame); Vollkorn is +231.71 µs/sequence, with its relative interval crossing zero. All five no-Swash demo intervals cross zero; this does not prove equivalence or cover every generic stroke workload. Warm Roboto is also +3.676 µs/frame versus the before-fixes cache control (paired +1.653%, CI [+1.003%, +2.463%]); versus master, that warm interval crosses zero. No blanket zero-regression claim is supported.', '',
              '## Mechanism counts', '',
              'Across 4,096 warmed requests with two normalized coordinates, allocations fall from 8,192 to 4,096: one allocation removed per hit. Empty-coordinate requests remain at 4,096 allocations. Remaining allocations include the rendered image buffer, so this is not an allocation-free rasterizer.', '',
              'Across 4,000 near-budget requests, observed point/verb capacity changes including trims fall from 552 to 38 (Roboto) and 636 to 50 (Vollkorn). Peak cached entries are 3,417→3,331 and 1,681→1,661, respectively; modeled high-water values remain at most 1 MiB. This combined growth/key comparison does not isolate how much retention difference comes from Cow key metadata versus arena spare capacity. Private native buffers and map spare capacity are outside the soft accounting budget.', '',
              'Probe timings include allocation-counter overhead and are diagnostic. The counts support removal of hit-side coordinate allocation and amortized arena growth; they do not establish an application speedup from each fix in isolation.', '']
    (DEST / 'REPORT.md').write_text('\n'.join(lines))
    print(json.dumps({k: v for k, v in result.items() if k != 'cohorts'}))


if __name__ == '__main__':
    main()
