"""Check complete cohort identities, balanced orders and retained exclusions."""
import argparse
from collections import Counter
import json
import math
from pathlib import Path
from common import ROOT, VARIANTS, files, sha256, source_snapshot

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
out = args.out.resolve()
plan = json.loads((out / 'PLAN.json').read_text())
metadata = json.loads((out / 'METADATA.json').read_text())
build = metadata['build']
assert build == json.loads((ROOT / 'BUILD.json').read_text())
assert build['harness'] == files(ROOT / 'harness-src')
assert build['assets'] == files(ROOT / 'assets')
for variant in VARIANTS:
    identity = build['variants'][variant]
    assert source_snapshot(variant) == identity['source']
    assert sha256(ROOT / 'harness' / variant / 'Cargo.toml') == identity['manifest_sha256']
    assert sha256(ROOT / 'harness' / variant / 'Cargo.lock') == identity['lock_sha256']
    assert all(sha256(Path(binary['path'])) == binary['sha256'] for binary in identity['binaries'].values())

rows = [json.loads(line) for line in (out / 'raw.jsonl').read_text().splitlines()]
keys = [(row['block'], row['variant'], row['case'], row['phase']) for row in rows]
assert len(keys) == len(set(keys)), 'Duplicate measurement'
for row in rows:
    assert row['order'] == plan['orders'][row['block']]
    assert row['variant'] in VARIANTS
    for key in ('draw_us', 'flush_us', 'total_us'):
        if key in row:
            assert math.isfinite(row[key]) and row[key] >= 0
expected_phases = {'scenes': {'first_paint', 'warm', 'zoom_in', 'zoom_out', 'pan'},
                   'cold': {'all_misses'},
                   'stress': {'first_paint', 'warm', 'new_size', 'return', 'complete_sequence'}}
for block in range(plan['blocks']):
    for case in plan['cases']:
        for variant in VARIANTS:
            phases = {row['phase'] for row in rows if row['block'] == block and row['variant'] == variant
                      and row['case'] == case['name']}
            assert phases == expected_phases[case['kind']], (block, variant, case['name'], phases)
for position in range(3):
    assert Counter(order[position] for order in plan['orders']) == Counter({v: plan['blocks'] // 3 for v in VARIANTS})

statuses = [json.loads(path.read_text()) for path in sorted((out / 'attempts').glob('*/STATUS.json'))]
assert sum(status['status'] == 'accepted' for status in statuses) == plan['blocks']
guards = [json.loads(line) for line in (out / 'guard-checks.jsonl').read_text().splitlines()]
assert not any(check['status'] == 'guard_failed' for check in guards)
audit = {'complete_blocks': plan['blocks'], 'accepted_processes': plan['blocks'] * len(plan['cases']) * len(VARIANTS),
         'measurement_rows': len(rows), 'excluded_attempts': [status for status in statuses if status['status'] == 'excluded'],
         'guard_checks': len(guards), 'matched_guard_checks': sum(check['status'] == 'matched' for check in guards),
         'source_files': {v: len(build['variants'][v]['source']['files']) for v in VARIANTS},
         'source_tree_sha256': {v: build['variants'][v]['source']['tree_sha256'] for v in VARIANTS},
         'artifacts': {name: sha256(out / name) for name in ('PLAN.json', 'METADATA.json', 'raw.jsonl')},
         'verified': 'Source, harness, assets, locks and copied binary identities; unique complete measurement matrix; balanced orders; retained attempt statuses'}
(out / 'AUDIT.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit, indent=2))
