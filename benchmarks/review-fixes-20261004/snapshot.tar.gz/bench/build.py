"""Build frozen source snapshots serially; never performs benchmark timings."""
import argparse
import json
import shutil
import subprocess
from pathlib import Path
from common import ROOT, VARIANTS, binary, files, sha256, source_snapshot, tree_digest

p = argparse.ArgumentParser()
p.add_argument('--variants', nargs='+', choices=VARIANTS, default=VARIANTS)
p.add_argument('--target-dir', type=Path, default=ROOT / 'target')
args = p.parse_args()
(ROOT / 'bin').mkdir(exist_ok=True)
(ROOT / 'build-logs').mkdir(exist_ok=True)
metadata_path = ROOT / 'BUILD.json'
metadata = json.loads(metadata_path.read_text()) if metadata_path.exists() else {'variants': {}}
metadata['rustc'] = subprocess.check_output(['rustc', '-vV'], text=True)
metadata['cargo'] = subprocess.check_output(['cargo', '--version'], text=True)
metadata['target_dir'] = str(args.target_dir.resolve())
metadata['harness'] = files(ROOT / 'harness-src')
metadata['harness_packages'] = files(ROOT / 'harness')
metadata['assets'] = files(ROOT / 'assets')
metadata['study'] = 'Feedback fixes vs upstream master and pre-fix cache branch'
metadata['source_freeze'] = json.loads((ROOT / 'SOURCE_FREEZE.json').read_text())
normalized_locks = []
for variant in VARIANTS:
    lock = (ROOT / 'harness' / variant / 'Cargo.lock').read_text()
    normalized_locks.append(lock.replace(f'femtovg-feedback-{variant}', 'femtovg-feedback-VARIANT'))
if len(set(normalized_locks)) != 1:
    raise RuntimeError('Dependency lockfiles differ beyond the root package name')
metadata['normalized_lock_sha256'] = tree_digest({'lock': normalized_locks[0]})
for variant in args.variants:
    before = source_snapshot(variant)
    manifest = ROOT / 'harness' / variant / 'Cargo.toml'
    outputs = {}
    for feature in ('default_swash', 'default_no_swash'):
        command = ['cargo', 'build', '--locked', '--offline', '--release',
                   '--manifest-path', str(manifest), '--target-dir', str(args.target_dir),
                   '--features', feature]
        command += ['--bins'] if feature == 'default_swash' else ['--bin', f'scenes-{variant}']
        with (ROOT / 'build-logs' / f'{variant}-{feature}.log').open('w') as log:
            print('Building', variant, feature, flush=True)
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
        for kind in (('scenes', 'cold', 'stress') + (() if variant == 'master' else ('probe',))) if feature == 'default_swash' else ('scenes',):
            destination = binary(variant, feature, kind)
            shutil.copy2(args.target_dir / 'release' / f'{kind}-{variant}', destination)
            outputs[f'{feature}-{kind}'] = {'path': str(destination), 'sha256': sha256(destination)}
    after = source_snapshot(variant)
    if after != before:
        raise RuntimeError(f'{variant} changed during the build; outputs cannot be timed')
    metadata['variants'][variant] = {'source': before, 'binaries': outputs,
                                    'manifest_sha256': sha256(manifest),
                                    'lock_sha256': sha256(manifest.with_name('Cargo.lock'))}
    metadata_path.write_text(json.dumps(metadata, indent=2) + '\n')
print('All requested binaries built; identities saved in BUILD.json.', flush=True)
