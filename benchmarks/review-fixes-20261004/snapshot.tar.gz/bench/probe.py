"""Before/after mechanism counts from the verbatim private rasterizer module."""
import argparse
import json
import os
import platform
import statistics
import subprocess
import time
from collections import defaultdict
from pathlib import Path
from common import ROOT, binary, files, sha256, source_snapshot
from guard import GuardMatched, ensure_idle, utc, wait_idle

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
p.add_argument('--blocks', type=int, choices=(6, 12), default=6)
p.add_argument('--quiet-seconds', type=float, default=5)
args = p.parse_args()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
plan = {'blocks': args.blocks,
        'orders': [['before', 'after'] if n % 2 == 0 else ['after', 'before'] for n in range(args.blocks)],
        'warm_requests': 4096, 'near_budget_requests': 4000,
        'primary_metrics': 'allocator calls on warmed nonempty coordinate hits; net arena capacity changes per request near budget',
        'counts_note': 'Capacity observations occur before and after each render; intermediate transitions inside one render are not individually observed. Allocator totals include all native/image work.',
        'timing_note': 'Counter overhead is present. Diagnostic timings are not application performance claims.',
        'guard': 'before, every 0.1 seconds during, after; interrupted entire block excluded'}
plan_path = out / 'PLAN.json'
if plan_path.exists() and json.loads(plan_path.read_text()) != plan:
    raise RuntimeError('Resume plan differs; choose a fresh output directory')
plan_path.write_text(json.dumps(plan, indent=2) + '\n')
build = json.loads((ROOT / 'BUILD.json').read_text())
if build['harness'] != files(ROOT / 'harness-src') or build['harness_packages'] != files(ROOT / 'harness') or build['assets'] != files(ROOT / 'assets'):
    raise RuntimeError('Harness/assets changed after build')
for variant in ('before', 'after'):
    if source_snapshot(variant) != build['variants'][variant]['source']:
        raise RuntimeError('Source changed after build')
    identity = build['variants'][variant]['binaries']['default_swash-probe']
    if sha256(Path(identity['path'])) != identity['sha256']:
        raise RuntimeError('Probe binary changed after build')
metadata = {'created_utc': utc(), 'platform': platform.platform(), 'build': build}
metadata_path = out / 'METADATA.json'
if metadata_path.exists():
    if json.loads(metadata_path.read_text())['build'] != build:
        raise RuntimeError('Resume build identity differs')
else:
    metadata_path.write_text(json.dumps(metadata, indent=2) + '\n')
wait_idle(out, args.quiet_seconds, time.monotonic() + 60, {'stage': 'pre_probe'})
raw_path = out / 'raw.jsonl'
completed = {json.loads(s)['block'] for s in raw_path.read_text().splitlines()} if raw_path.exists() else set()
for block, order in enumerate(plan['orders']):
    if block in completed:
        continue
    attempts = out / 'attempts'
    attempts.mkdir(exist_ok=True)
    attempt = attempts / f'block-{block:02d}-{len(list(attempts.glob(f"block-{block:02d}-*"))):02d}'
    attempt.mkdir()
    rows = []
    started = utc()
    print(f'Probe block {block+1}/{args.blocks}: {" ".join(order)}', flush=True)
    try:
        for variant in order:
            context = {'block': block, 'variant': variant, 'case': 'private_module_probe'}
            ensure_idle(out, {'stage': 'before_process', **context})
            stdout_path = attempt / f'{variant}.stdout'
            stderr_path = attempt / f'{variant}.stderr'
            with stdout_path.open('w') as stdout, stderr_path.open('w') as stderr:
                process = subprocess.Popen([str(binary(variant, 'default_swash', 'probe'))], stdout=stdout, stderr=stderr)
                try:
                    while process.poll() is None:
                        ensure_idle(out, {'stage': 'during_process', **context})
                        time.sleep(0.1)
                except BaseException:
                    process.terminate()
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                    raise
                if process.returncode:
                    raise RuntimeError(f'Probe exited {process.returncode}: {stderr_path}')
            ensure_idle(out, {'stage': 'after_process', **context})
            measurements = [json.loads(s) for s in stdout_path.read_text().splitlines()]
            if [s['case'] for s in measurements] != ['coords_hits', 'empty_coords_hits', 'near_budget_roboto', 'near_budget_vollkorn']:
                raise RuntimeError('Unexpected probe workload/order')
            for row in measurements:
                rows.append({'block': block, 'order': order, 'variant': variant, **row})
            (attempt / 'partial-raw.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in rows))
        (attempt / 'STATUS.json').write_text(json.dumps({'status': 'accepted', 'started_utc': started, 'ended_utc': utc()}, indent=2) + '\n')
        with raw_path.open('a') as stream:
            for row in rows:
                stream.write(json.dumps(row) + '\n')
    except BaseException as error:
        (attempt / 'STATUS.json').write_text(json.dumps({'status': 'excluded', 'started_utc': started,
            'ended_utc': utc(), 'reason': str(error), 'evidence': error.evidence if isinstance(error, GuardMatched) else None}, indent=2) + '\n')
        raise

groups = defaultdict(list)
for line in raw_path.read_text().splitlines():
    row = json.loads(line)
    groups[(row['case'], row['variant'])].append(row)
summary = []
for (case, variant), rows in sorted(groups.items()):
    if len(rows) != args.blocks:
        raise RuntimeError('Incomplete probe blocks')
    result = {'case': case, 'variant': variant, 'blocks': len(rows)}
    for key in rows[0]:
        if key not in ('case', 'variant', 'block', 'order'):
            if key != 'ns_total' and len({row[key] for row in rows}) != 1:
                raise RuntimeError(f'Allocation/state count varied between blocks: {case} {variant} {key}')
            result[key] = statistics.median(row[key] for row in rows)
    summary.append(result)
(out / 'SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
