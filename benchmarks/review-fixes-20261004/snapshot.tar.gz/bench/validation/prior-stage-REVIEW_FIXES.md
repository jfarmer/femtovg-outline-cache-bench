# Review fixes and scope

These changes remain in the single Swash outline-cache PR.

PR-specific fixes:

- **4:** Restoration tests now assert that the live layer survives and that its
  state remains usable, rather than only checking an already-released target.
- **8:** Arena growth no longer repeatedly grows by one outline near its
  budget. Bounded geometric headroom and spare-capacity trimming preserve
  fitting working sets while limiting allocation work.
- **9:** Cache hits borrow normalized coordinates for lookup. Coordinates are
  owned only when a new key is inserted; the larger key is budgeted.
- **11:** Remove the constructor argument left unused by Font encapsulation.

Related preexisting bugs repaired in the touched rendering path:

- **1:** Generic atlas rendering uses `Canvas::offscreen_pass` instead of
  `save/reset`, preserving open layers, transforms and canvas state. The
  debug-inspector initialization path without image-loading is covered too.
- **2:** Blank generic paths such as spaces skip atlas allocation and rendering.
  A nonempty outline whose native bitmap happens to be tiny/empty still gets
  its generic fallback.
- **6:** Generic PNG glyph uploads return an error instead of panicking. This
  does not fix the separate, preexisting debug image-loading initialization
  `unwrap`, which remains deferred.

Deferred existing atlas issues: **3** bitmap/generic positioning policy, **5**
reservation recovery after upload failure, and **7** duplicate phase entries
for phase-independent bitmaps. **10** retains a cheap handle to the same
shared ScaleContext; it is not a second scaling context.

TDD evidence in `validation/`:

- Added live-layer and generic PNG upload checks failed against the old code.
  The final targeted atlas suites passed: 12 with default + Swash, 11 with
  Swash-only, and 11 with Swash + debug-inspector without image-loading.
- The initial debug-inspector run had three false test failures: an existing
  native positioning helper counted the inspector initialization clear quad.
  Selecting the actual glyph draw command corrected those assertions; the
  final run passed all 11 tests. Both logs are retained.
- The near-budget regression failed with 1,688 capacity changes across 1,858
  inserts. It now passes its bound of fewer than 64 changes; all 16 rasterizer
  module tests passed.
- For 1,000 cached renders with nonempty coordinates, allocation calls fell
  from 2,000 to 1,000, matching empty-coordinate hits. The remaining calls
  allocate native image buffers. This is an allocation probe, not an
  application timing result.
- The full library matrix passed 197 / 181 / 169 tests for default + Swash,
  Swash-only and default without Swash. The no-default-feature check passed.
  The final targeted runs followed the debug test-helper correction.

`VALIDATION.json` records log hashes and sources. `SOURCE_FREEZE.json` records
the final tracked source trees, exact base refs and patch hashes.

**Fresh timings are pending a quiet build window.** Other sessions are
building; no benchmark builds or timings were started for this task. The
prepared scripts retain the existing demo, miss controls and Fleur stress
scene, plus separate allocation and near-budget probes. They compare frozen
upstream master `9d574e0`, pre-fix cache branch `af989d9`, and the final updated
working tree. Earlier benchmark results are retained and are not relabeled
as timings of this version.
