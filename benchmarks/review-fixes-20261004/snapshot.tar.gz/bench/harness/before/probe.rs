include!("../../harness-src/probe/allocator.rs");
#[allow(dead_code)]
mod native {
    include!("../../../source/before/src/text/swash_rasterizer.rs");
    include!("../../harness-src/probe/driver.rs");
}
fn main() { native::probe_main(); }
