"""Describe diagnostic counts without treating them as application timings."""
import json
from common import ROOT

rows = json.loads((ROOT / 'runs/probe-final/SUMMARY.json').read_text())
data = {(row['case'], row['variant']): row for row in rows}
lines = ['# Allocation and arena-growth probes', '',
         'Six alternating Before/PR blocks use the exact frozen production rasterizer',
         'module. Before is `af989d9`; PR is `907bb37`. These are diagnostic workloads,',
         'with allocator-counter overhead, rather than application-speed measurements.', '',
         '| Workload | Requests | Before allocations | PR allocations |',
         '|---|---:|---:|---:|']
for case, label in [('coords_hits', 'Cached outlines, nonempty variation coordinates'),
                    ('empty_coords_hits', 'Cached outlines, default coordinates')]:
    before, after = (data[(case, variant)] for variant in ('before', 'after'))
    lines.append(f'| {label} | {int(after["requests"])} | {int(before["allocations"])} | {int(after["allocations"])} |')
lines += ['', 'Borrowing coordinates removes one key allocation per nonempty-coordinate',
          'hit. Each call still allocates its raster image. This did not produce a',
          'clear speedup in the recorded diagnostic timings.', '',
          '| Near-budget workload | Requests | Capacity changes, Before / PR | Reallocations, Before / PR | Peak entries, Before / PR |',
          '|---|---:|---:|---:|---:|']
for case, label in [('near_budget_roboto', 'Roboto Flex'), ('near_budget_vollkorn', 'Vollkorn')]:
    before, after = (data[(case, variant)] for variant in ('before', 'after'))
    def changes(row):
        return sum(int(row[name]) for name in ('point_grows', 'verb_grows', 'point_trims', 'verb_trims'))
    lines.append(f'| {label} | {int(after["requests"])} | {changes(before)} / {changes(after)} | '
                 f'{int(before["reallocations"])} / {int(after["reallocations"])} | '
                 f'{int(before["peak_entries"])} / {int(after["peak_entries"])} |')
lines += ['', 'Capacity changes count both growth and shrink, observed before and after',
          'each render. Intermediate changes inside a render are not individually',
          'observed. Allocator totals include native working and image buffers too.',
          'A reallocation or capacity change does not prove that physical storage moved.', '',
          'Both versions stayed within the modeled 1 MiB budget. The PR holds slightly',
          'fewer peak entries in these workloads. The borrowed/owned key is eight bytes',
          'larger and its metadata is charged; this combined growth-policy/key comparison',
          'does not isolate the contribution of each change to retention.', '',
          'The probe shows much less repeated arena allocation, not a CPU speedup from',
          'that policy alone. Raw diagnostic timings and cumulative allocator requested',
          'bytes remain in the results; requested bytes are not retained memory or RSS.', '',
          'See `runs/probe-final/{PLAN.json,METADATA.json,raw.jsonl,SUMMARY.json}` for',
          'workload settings, source/binary identities, all six blocks, and full counts.']
(ROOT / 'PROBE-REPORT.md').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
