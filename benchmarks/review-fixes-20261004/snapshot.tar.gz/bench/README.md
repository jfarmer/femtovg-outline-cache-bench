# Final review-fix comparison

Three frozen source trees: upstream Master `9d574e0`, pre-fix cache branch
`af989d9` (`before`), and final committed PR code `907bb375` (`after`). The demo,
cold miss controls and Fleur stress scene are copied unchanged from the public
font-cache-adapter-20261004 archive. All variants use identical normalized
locks, release profile, harness, fonts and assets. Source, harness, asset,
manifest, lock and copied executable identities are recorded in `BUILD.json`.

The completed cohorts are `runs/comparison-final`, `runs/stress-final` and
`runs/probe-final`, with six balanced blocks each. The three-way cohorts use
every variant order once; the mechanism probe alternates Before/PR. Demo
timing is CPU drawing only; cold and stress include Void flush. Font loading
and canvas creation are excluded. No windows open and no GPU work is measured.
The build-process guard checks before, during and after each process;
interrupted blocks remain on disk but are excluded. No timing-based filtering
is performed. `runs/comparison` retains earlier failed pre-run guard checks
for a superseded source freeze; it has no accepted timings.

A separate Before/PR probe includes the frozen production rasterizer verbatim,
exercising nonempty RobotoFlex coordinates on outline hits and arena capacity
changes near the budget. Allocation counters include native/image work.
Observed capacity changes do not establish that heap storage physically moved.
The probe has counter overhead and makes no application-speed claim.

See [review scope and test stages](REVIEW_FIXES.md), the [API review](API_REVIEW.md),
and the final cohort reports. No public API or dependency changed. The final
source preserves generic atlas target batching, including without Swash.

To rebuild all three variants and collect new results in a quiet build window:

```sh
python3 build.py
python3 run.py --out runs/new-comparison --blocks 6
python3 run.py --out runs/new-stress --blocks 6 --cases stress-FleurDeLeah
python3 analyze.py --out runs/new-comparison
python3 analyze.py --out runs/new-stress
python3 probe.py --out runs/new-probe --blocks 6
```

Six-block bootstrap intervals are exploratory. RobotoFlex's all-miss control
is slower than Master; these results do not prove universal equivalence or
improvement. Earlier studies remain in the benchmark repository and must not
be pooled with this run's absolute timings. Void measurements do not measure
GPU/backend costs or application startup.
