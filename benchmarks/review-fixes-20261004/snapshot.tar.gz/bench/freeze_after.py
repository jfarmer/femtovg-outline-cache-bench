"""Freeze committed tracked source and pin the final comparison identity."""
import argparse
import datetime
import json
import shutil
import subprocess
from pathlib import Path
from common import ROOT, files, sha256, source_snapshot

p = argparse.ArgumentParser()
p.add_argument('--after-commit', required=True)
args = p.parse_args()
repo = Path('/Users/jesse/github/femtovg')
def git(*arguments):
    return subprocess.check_output(['git', '-C', str(repo), *arguments])
if git('rev-parse', 'HEAD').decode().strip() != args.after_commit:
    raise RuntimeError('Requested commit is not current HEAD')
if subprocess.run(['git', '-C', str(repo), 'diff', '--quiet', 'HEAD']).returncode:
    raise RuntimeError('Tracked source is dirty')
metadata_path = ROOT / 'SOURCE_FREEZE.json'
previous = json.loads(metadata_path.read_text())
for name in ('SOURCE_FREEZE', 'BUILD'):
    source = ROOT / f'{name}.json'
    saved = ROOT / f'{name}.a6eb669.json'
    if source.exists() and not saved.exists():
        shutil.copy2(source, saved)
destination = ROOT.parent / 'source' / 'after'
tracked = [Path(name.decode()) for name in git('ls-files', '-z').split(b'\0') if name]
tracked_names = {str(path) for path in tracked}
for stale in destination.rglob('*'):
    if stale.is_file() and str(stale.relative_to(destination)) not in tracked_names:
        raise RuntimeError(f'Unexpected untracked snapshot member: {stale}')
for path in tracked:
    target = destination / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo / path, target)
snapshot = source_snapshot('after')
if snapshot['files'] != {str(path): sha256(repo / path) for path in tracked}:
    raise RuntimeError('Frozen source differs from committed tracked tree')
previous['sources']['after'] = snapshot
previous['after_commit'] = args.after_commit
previous['freeze'] = 'Committed tracked source after review and batching fixes'
previous['created_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
for variant, base in [('before', 'af989d9'), ('master', '9d574e0')]:
    patch = ROOT / f'after-vs-{variant}.diff'
    patch.write_bytes(git('diff', base, args.after_commit))
    previous['changes'][variant] = {
        'base': git('rev-parse', base).decode().strip(),
        'patch_sha256': sha256(patch),
    }
metadata_path.write_text(json.dumps(previous, indent=2) + '\n')
print(json.dumps({'after_commit': args.after_commit,
                  'tree_sha256': snapshot['tree_sha256'],
                  'files': len(snapshot['files'])}, indent=2))
