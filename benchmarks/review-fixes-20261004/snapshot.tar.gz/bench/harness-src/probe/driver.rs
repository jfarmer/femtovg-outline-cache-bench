// Mechanism probe appended after the unchanged production module. This accesses
// private state to observe it; it does not duplicate cache lookup/growth logic.
pub fn probe_main() {
    use std::time::Instant;
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../assets");
    let roboto = std::fs::read(root.join("RobotoFlex-VariableFont.ttf")).unwrap();
    let font = FontRef::from_index(&roboto, 0).unwrap();
    let coords: Vec<i16> = font.variations().normalized_coords([("wght", 450.0)]).collect();
    assert!(!coords.is_empty() && coords.iter().any(|&x| x != 0));
    for (case, instance) in [("coords_hits", &coords[..]), ("empty_coords_hits", &[][..])] {
        let mut state = RasterizerState::new(Rc::new(RefCell::new(ScaleContext::new())));
        let glyph = font.charmap().map('g');
        for phase in 0..10 { state.render(font, 24.0, glyph, phase as f32 * 0.1, instance).unwrap(); }
        assert_eq!(state.outlines.len(), 1);
        let before = crate::allocation_counts();
        let start = Instant::now();
        for i in 0..4096 {
            let image = state.render(font, 24.0, glyph, (i % 10) as f32 * 0.1, instance).unwrap();
            std::hint::black_box(image);
        }
        let ns = start.elapsed().as_nanos();
        let after = crate::allocation_counts();
        assert_eq!(state.outlines.len(), 1);
        println!("{{\"case\":\"{case}\",\"requests\":4096,\"coords\":{},\"allocations\":{},\"reallocations\":{},\"requested_bytes\":{},\"ns_total\":{ns}}}",
                 instance.len(), after.0-before.0, after.1-before.1, after.2-before.2);
    }
    let vollkorn = std::fs::read(root.join("Vollkorn-Medium.ttf")).unwrap();
    let serif = FontRef::from_index(&vollkorn, 0).unwrap();
    for (case, face, instance) in [("near_budget_roboto", font, &coords[..]),
                                    ("near_budget_vollkorn", serif, &[][..])] {
        let ids: Vec<_> = (33u8..=126).map(|ch| face.charmap().map(ch as char)).collect();
        assert!(ids.iter().all(|&id| id != 0));
        let mut state = RasterizerState::new(Rc::new(RefCell::new(ScaleContext::new())));
        let (mut point_grows, mut verb_grows, mut point_trims, mut verb_trims) = (0,0,0,0);
        let (mut clears, mut first_clear, mut peak_entries, mut high_water_bytes) = (0,0,0,0);
        let before = crate::allocation_counts();
        let start = Instant::now();
        for i in 0..4000 {
            let capacity = (state.points.capacity(), state.verbs.capacity());
            let entries = state.outlines.len();
            let image = state.render(face, 16.0 + (i / ids.len()) as f32 * 0.5,
                ids[i % ids.len()], 0.0, instance).unwrap();
            std::hint::black_box(image);
            let after = (state.points.capacity(), state.verbs.capacity());
            point_grows += usize::from(after.0 > capacity.0);
            verb_grows += usize::from(after.1 > capacity.1);
            point_trims += usize::from(after.0 < capacity.0);
            verb_trims += usize::from(after.1 < capacity.1);
            if state.outlines.len() < entries {
                clears += 1;
                if first_clear == 0 { first_clear = i + 1; }
            }
            peak_entries = peak_entries.max(state.outlines.len());
            high_water_bytes = high_water_bytes.max(state.outline_bytes);
            assert!(state.outline_bytes <= state.outline_budget);
        }
        let ns = start.elapsed().as_nanos();
        let after = crate::allocation_counts();
        println!("{{\"case\":\"{case}\",\"requests\":4000,\"point_grows\":{point_grows},\"verb_grows\":{verb_grows},\"point_trims\":{point_trims},\"verb_trims\":{verb_trims},\"clears\":{clears},\"first_clear_request\":{first_clear},\"peak_entries\":{peak_entries},\"high_water_bytes\":{high_water_bytes},\"final_entries\":{},\"allocations\":{},\"reallocations\":{},\"requested_bytes\":{},\"ns_total\":{ns}}}",
                 state.outlines.len(), after.0-before.0, after.1-before.1, after.2-before.2);
    }
}
