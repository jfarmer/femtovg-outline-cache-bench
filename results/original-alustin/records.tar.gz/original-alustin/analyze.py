#!/usr/bin/env python3
"""Analyze completed Alustin master/patch process pairs without launching a GUI.

Example:
  python3 analyze.py cpu-12-valid startup-12 pixels --output analysis \
    --exclude cpu-12 'Aborted on query ar; entire incomplete batch excluded'

All included launches are retained. One fresh process is one observation;
master/patch are paired within round, backend, and system-font setting.
"""

import argparse
from collections import defaultdict
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import random
import statistics
import sys


HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("paired_runner", HERE / "run.py")
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)

NAMES = {
    "observed_search_response_ms": "Observed search-response readiness, ms from spawn",
    "first_frame_since_main_ms": "First rendered frame, ms since main",
    "search_frame_since_main_ms": "Search response rendered, ms since main",
    "search_after_first_frame_ms": "First frame to rendered search response, ms",
    "first_callback_wall_ms": "First BeforeRendering to AfterRendering callback interval, ms",
    "spawn_to_main_ms": "Spawn to main, ms",
    "peak_rss_mib": "Process lifetime peak RSS, MiB",
}
for phase in ("first_frame", "search_frame"):
    for part in ("render", "component_items", "final_flush"):
        for measure in ("wall", "thread_cpu"):
            NAMES[f"{phase}.{part}.{measure}_ms"] = f"{phase} femtovg.{part}, {measure}, ms"


def resolve(path):
    path = Path(path)
    return path.resolve() if path.is_absolute() else (HERE / path).resolve()


def read(path):
    return json.loads(Path(path).read_text())


def median(values):
    return statistics.median(values)


def percentile(values, q):
    """Linear interpolation between adjacent sorted bootstrap order statistics."""
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    lo, hi = math.floor(position), math.ceil(position)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (position - lo)


def ci(values):
    return [percentile(values, 0.025), percentile(values, 0.975)]


def scalar_metrics(sample):
    events = runner.event_map(sample)
    first = events["first_frame_rendered"]["since_main_ms"]
    search = events["interactive_frame_rendered"]["since_main_ms"]
    values = {
        "observed_search_response_ms": sample["launch_to_probe_observed_ms"],
        "first_frame_since_main_ms": first,
        "search_frame_since_main_ms": search,
        "search_after_first_frame_ms": search - first,
        "first_callback_wall_ms": first - events["first_render_started"]["since_main_ms"],
    }
    if sample.get("spawn_to_main_ms") is not None:
        values["spawn_to_main_ms"] = sample["spawn_to_main_ms"]
    if sample.get("peak_rss_bytes") is not None:
        values["peak_rss_mib"] = sample["peak_rss_bytes"] / 2**20
    return values


def load_batch(directory):
    manifest = read(directory / "summary.json")
    if not manifest.get("complete"):
        raise ValueError(f"{directory} is incomplete; explicitly exclude the entire batch instead")
    launches = manifest["launches"]
    if not launches:
        raise ValueError(f"{directory} contains no launches")
    groups = defaultdict(dict)
    raw_rows = []
    for launch in launches:
        if not launch.get("validated") or launch.get("exit_code") != 0:
            raise ValueError(f"unvalidated/failed included launch: {launch['label']}")
        report = read(launch["report"])
        if len(report.get("samples", [])) != 1:
            raise ValueError(f"expected one raw sample: {launch['report']}")
        sample = report["samples"][0]
        events = runner.event_map(sample)
        version, backend, fonts = launch["version"], launch["backend"], launch["fonts"]
        if version not in ("master", "patch"):
            raise ValueError(f"unknown version {version}")
        if Path(sample["executable_path"]).resolve() != Path(manifest["binaries"][version]["path"]).resolve():
            raise ValueError(f"raw executable identity differs: {launch['label']}")
        dimensions = events["first_frame_rendered"]["details"]
        if events["interactive_frame_rendered"]["details"]["query"] != "a":
            raise ValueError(f"invalid search response: {launch['label']}")
        if (dimensions["physical_width"], dimensions["physical_height"], dimensions["scale_factor"]) != (2560, 1600, 2.0):
            raise ValueError(f"unexpected dimensions/DPR: {launch['label']}")
        if sample["backend_requested"] != backend or sample["system_fonts_disabled"] != (fonts == "off"):
            raise ValueError(f"raw configuration differs: {launch['label']}")
        expected_api = "WGPU30" if backend == "winit-femtovg-wgpu" else "OpenGL"
        if events["renderer_setup"]["details"]["graphics_api"] != expected_api:
            raise ValueError(f"graphics API differs: {launch['label']}")
        metrics = scalar_metrics(sample)
        if manifest["mode"] == "cpu":
            spans = sample["slint_internal_spans"]
            for phase, marker in (("first_frame", "first_frame_rendered"),
                                  ("search_frame", "interactive_frame_rendered")):
                # Recompute from raw spans rather than trusting the runner's CSV.
                totals = runner.frame_spans(spans, marker)
                if totals != launch["frames"][phase]:
                    raise ValueError(f"raw frame aggregation differs: {launch['label']} {phase}")
                for part in ("render", "component_items", "final_flush"):
                    for measure, suffix in (("wall", ""), ("thread_cpu", ".thread_cpu_ns")):
                        name = f"femtovg.{part}{suffix}"
                        if name not in totals:
                            raise ValueError(f"missing {phase} {name}: {launch['label']}")
                        metrics[f"{phase}.{part}.{measure}_ms"] = totals[name]["ms"]
        if any(not math.isfinite(value) or value < 0 for value in metrics.values()):
            raise ValueError(f"non-finite/negative metric: {launch['label']}")
        key = (backend, fonts, launch["round"])
        if version in groups[key]:
            raise ValueError(f"duplicate version in pair {key}")
        row = {"batch": directory.name, "mode": manifest["mode"], "backend": backend,
               "fonts": fonts, "round": launch["round"], "version": version,
               "label": launch["label"], "report": launch["report"], "metrics": metrics}
        groups[key][version] = row
        raw_rows.append(row)
    for key, pair in groups.items():
        if set(pair) != {"master", "patch"}:
            raise ValueError(f"unmatched process pair {key}")
    group_rounds = defaultdict(list)
    for backend, fonts, round_number in groups:
        group_rounds[backend, fonts].append(round_number)
    expected = list(range(1, manifest["rounds"] + 1))
    if any(sorted(rounds) != expected for rounds in group_rounds.values()):
        raise ValueError(f"missing rounds in {directory}")
    return manifest, groups, raw_rows


def analyze_group(directory, mode, backend, fonts, pairs, bootstrap, seed):
    metrics = set(pairs[0]["master"]["metrics"])
    if any(set(pair[version]["metrics"]) != metrics for pair in pairs for version in ("master", "patch")):
        raise ValueError(f"metric set changed within {directory.name}/{backend}/{fonts}")
    rng = random.Random(seed)
    n = len(pairs)
    # Use the same resampled pair indices for all metrics in one configuration.
    samples = [[rng.randrange(n) for _ in range(n)] for _ in range(bootstrap)] if n >= 3 else []
    rows = []
    for name in sorted(metrics):
        master = [pair["master"]["metrics"][name] for pair in pairs]
        patch = [pair["patch"]["metrics"][name] for pair in pairs]
        differences = [new - old for old, new in zip(master, patch)]
        ratios = [new / old for old, new in zip(master, patch)] if all(value > 0 for value in master) else None
        delta_ci = ci([median([differences[i] for i in indices]) for indices in samples]) if samples else None
        ratio_ci = ci([median([ratios[i] for i in indices]) for indices in samples]) if samples and ratios else None
        rows.append({
            "batch": directory.name, "mode": mode, "backend": backend, "fonts": fonts,
            "metric": name, "description": NAMES[name], "units": "MiB" if name == "peak_rss_mib" else "ms",
            "n_pairs": n, "master_median": median(master), "patch_median": median(patch),
            "master_min": min(master), "master_max": max(master), "patch_min": min(patch), "patch_max": max(patch),
            "median_paired_delta": median(differences), "median_paired_delta_ci95": delta_ci,
            "median_paired_ratio": median(ratios) if ratios else None,
            "median_paired_change_pct": 100 * (median(ratios) - 1) if ratios else None,
            "median_paired_change_pct_ci95": [100 * (value - 1) for value in ratio_ci] if ratio_ci else None,
            "pairs": [{"round": pair["master"]["round"], "master": old, "patch": new,
                       "delta": new - old, "patch_over_master_ratio": new / old if old > 0 else None}
                      for pair, old, new in zip(pairs, master, patch)],
        })
    return rows


def write_csv(path, rows, fields):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("batches", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, default=HERE / "analysis")
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=72531)
    parser.add_argument("--exclude", nargs=2, action="append", default=[], metavar=("BATCH", "REASON"))
    args = parser.parse_args()
    if args.bootstrap < 1:
        parser.error("bootstrap must be positive")
    directories = [resolve(path) for path in args.batches]
    exclusions = [(resolve(path), reason) for path, reason in args.exclude]
    if len(set(directories)) != len(directories) or set(directories) & {path for path, _ in exclusions}:
        parser.error("included paths must be unique and separate from excluded batches")
    summary = {
        "statistics": {
            "observation": "One fresh process; one master/patch pair within round, backend, and font setting",
            "absolute": "Independent medians across all retained included launches",
            "effect": "Median of within-round patch-minus-master deltas and patch/master ratios; percentage=100*(median paired ratio-1)",
            "ci": "Percentile bootstrap of paired median effects, resampling process pairs with replacement; no CI with fewer than three pairs",
            "bootstrap_resamples": args.bootstrap, "seed": args.seed,
            "percentiles": "Linear interpolation between sorted bootstrap order statistics at 2.5% and 97.5%",
            "scope": "Exploratory per-metric 95% intervals without multiple-comparison adjustment; no GPU-completion or presentation-latency claim",
            "retention": "All included runs retained; no outlier filtering. Excluded entire batches are listed with explicit reasons and raw files retained.",
        },
        "batches": [], "excluded_batches": [], "results": [], "pixels": [],
    }
    raw_rows, pair_rows = [], []
    for directory, reason in exclusions:
        manifest = read(directory / "summary.json")
        summary["excluded_batches"].append({"path": str(directory), "reason": reason,
                                            "mode": manifest["mode"], "complete": manifest.get("complete", False),
                                            "raw_launches": len(manifest["launches"]),
                                            "validated_launches": sum(bool(row.get("validated")) for row in manifest["launches"])})
    for directory in directories:
        manifest, groups, raw = load_batch(directory)
        summary["batches"].append({"path": str(directory), "mode": manifest["mode"], "rounds": manifest["rounds"],
                                  "app_commit": manifest["app_commit"], "source_revisions": manifest["source_revisions"],
                                  "binaries": manifest["binaries"], "inputs": manifest["inputs"],
                                  "environment": manifest["environment"], "harness": manifest["harness"],
                                  "raw_launches": len(raw)})
        if manifest["mode"] == "pixels":
            expected_count = len(groups)
            if len(manifest["pixel_comparisons"]) != expected_count:
                raise ValueError(f"missing pixel comparisons in {directory}")
            summary["pixels"].extend({"batch": directory.name, **row} for row in manifest["pixel_comparisons"])
            continue
        raw_rows.extend(raw)
        configurations = sorted({(backend, fonts) for backend, fonts, _ in groups})
        for backend, fonts in configurations:
            pairs = [groups[key] for key in sorted(groups) if key[:2] == (backend, fonts)]
            token = f"{directory.name}/{backend}/{fonts}"
            seed = args.seed ^ int.from_bytes(hashlib.sha256(token.encode()).digest()[:8], "big")
            rows = analyze_group(directory, manifest["mode"], backend, fonts, pairs, args.bootstrap, seed)
            summary["results"].extend(rows)
            for row in rows:
                pair_rows.extend({"batch": row["batch"], "mode": row["mode"], "backend": backend,
                                  "fonts": fonts, "metric": row["metric"], "units": row["units"], **pair}
                                 for pair in row["pairs"])
    output = resolve(args.output)
    output.mkdir(parents=True, exist_ok=True)
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    fields = ("batch", "mode", "backend", "fonts", "metric", "units", "n_pairs", "master_median", "patch_median",
              "median_paired_delta", "median_paired_delta_ci95", "median_paired_ratio",
              "median_paired_change_pct", "median_paired_change_pct_ci95")
    write_csv(output / "summary.csv", [{key: row[key] for key in fields} for row in summary["results"]], fields)
    pair_fields = ("batch", "mode", "backend", "fonts", "metric", "units", "round", "master", "patch", "delta", "patch_over_master_ratio")
    write_csv(output / "pairs.csv", pair_rows, pair_fields)
    (output / "launches.json").write_text(json.dumps(raw_rows, indent=2) + "\n")
    print(f"Wrote {len(summary['results'])} metric summaries, {len(raw_rows)} timed launches, {len(summary['pixels'])} pixel comparisons to {output}")
    primary = {"observed_search_response_ms", "search_frame_since_main_ms", "peak_rss_mib",
               "first_frame.render.thread_cpu_ms", "first_frame.component_items.thread_cpu_ms",
               "search_frame.render.thread_cpu_ms"}
    for row in summary["results"]:
        if row["metric"] in primary:
            interval = row["median_paired_change_pct_ci95"]
            change = row["median_paired_change_pct"]
            effect = f"{change:+.2f}%" if change is not None else "ratio unavailable"
            bounds = f" [{interval[0]:+.2f}, {interval[1]:+.2f}]" if interval else " [CI unavailable]"
            print(f"{row['batch']} {row['backend']} fonts-{row['fonts']} {row['metric']}: "
                  f"{row['master_median']:.3f} -> {row['patch_median']:.3f} {row['units']}; paired {effect}{bounds}; n={row['n_pairs']}")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError) as error:
        print(f"Analysis failed: {error}", file=sys.stderr)
        sys.exit(1)
