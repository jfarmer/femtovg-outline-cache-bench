#!/usr/bin/env python3
"""Pair today's Alustin with FemtoVG master and patch using startup_bench.

This script launches GUI processes only when invoked with startup, cpu, or pixels.
Use --help to inspect it without launching applications. Build both application
variants and one common startup_bench harness before running it.
"""

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import struct
import subprocess
import sys
import zlib


ROOT = Path("/Users/jesse/github/alustin-gui-v2")
HERE = Path(__file__).resolve().parent
BACKENDS = ("winit-femtovg-wgpu", "winit-femtovg")


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def file_info(path):
    path = Path(path).resolve(strict=True)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def git_head(root):
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=root, text=True
    ).strip()


def event_map(sample):
    return {event["event"]: event for event in sample["events"]}


def frame_spans(spans, marker):
    markers = [span for span in spans if span["name"] == marker]
    if len(markers) != 1:
        raise ValueError(f"expected one {marker} span, found {len(markers)}")
    at = markers[0]["start_ns"]
    frames = [span for span in spans if span["name"] == "femtovg.render"
              and span["start_ns"] <= at <= span["start_ns"] + span["duration_ns"]]
    if len(frames) != 1:
        raise ValueError(f"expected one rendered frame containing {marker}, found {len(frames)}")
    frame = frames[0]
    lo, hi = frame["start_ns"], frame["start_ns"] + frame["duration_ns"]
    totals = {}
    for span in spans:
        name = span["name"]
        if (name.startswith("femtovg.") and lo <= span["start_ns"]
                and span["start_ns"] + span["duration_ns"] <= hi):
            row = totals.setdefault(name, {"ms": 0.0, "calls": 0})
            value = span["amount"] if name.endswith("thread_cpu_ns") else span["duration_ns"]
            row["ms"] += value / 1_000_000
            row["calls"] += 1
    if "femtovg.render.thread_cpu_ns" not in totals:
        raise ValueError(f"missing renderer thread-CPU measurement in {marker}")
    return totals


def validate_report(report, binary, expected_sha, backend, fonts, mode):
    if len(report.get("samples", [])) != 1:
        raise ValueError("startup_bench must return exactly one sample")
    sample = report["samples"][0]
    ran = sample.get("executable_path")
    if not ran or Path(ran).resolve() != binary:
        raise ValueError(f"ran {ran!r}, expected {str(binary)!r}")
    if digest(ran) != expected_sha:
        raise ValueError(f"running executable no longer matches its recorded SHA-256: {ran}")
    if sample.get("backend_requested") != backend:
        raise ValueError("requested backend differs from configuration")
    if sample.get("system_fonts_disabled") != (fonts == "off"):
        raise ValueError("system-font setting differs from configuration")
    events = event_map(sample)
    if events["interactive_frame_rendered"]["details"]["query"] != "a":
        raise ValueError("search response did not finish with query a")
    dimensions = events["first_frame_rendered"]["details"]
    if (dimensions.get("physical_width"), dimensions.get("physical_height"),
            dimensions.get("scale_factor")) != (2560, 1600, 2.0):
        raise ValueError(f"unexpected first-frame dimensions/DPR: {dimensions}")
    api = events["renderer_setup"]["details"]["graphics_api"]
    expected_api = "WGPU30" if backend == "winit-femtovg-wgpu" else "OpenGL"
    if api != expected_api:
        raise ValueError(f"graphics API {api!r}, expected {expected_api!r}")
    frames = {}
    if mode == "cpu":
        spans = sample.get("slint_internal_spans", [])
        for phase, marker in (("first_frame", "first_frame_rendered"),
                              ("search_frame", "interactive_frame_rendered")):
            frames[phase] = frame_spans(spans, marker)
    return sample, frames


def png_rgba(path):
    """Decode non-interlaced RGB/RGBA8 PNGs for exact screenshot pixel parity."""
    data = Path(path).read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"not PNG: {path}")
    pos, compressed = 8, []
    width = height = depth = color = interlace = None
    while pos < len(data):
        length = struct.unpack_from(">I", data, pos)[0]
        kind = data[pos + 4:pos + 8]
        chunk = data[pos + 8:pos + 8 + length]
        crc = struct.unpack_from(">I", data, pos + 8 + length)[0]
        if zlib.crc32(kind + chunk) != crc:
            raise ValueError(f"PNG CRC mismatch: {path}")
        pos += 12 + length
        if kind == b"IHDR":
            width, height, depth, color, compression, filtering, interlace = struct.unpack(">IIBBBBB", chunk)
            if (depth, color, compression, filtering, interlace) not in ((8, 2, 0, 0, 0), (8, 6, 0, 0, 0)):
                raise ValueError(f"unsupported PNG format {(depth, color, interlace)}")
        elif kind == b"IDAT":
            compressed.append(chunk)
        elif kind == b"IEND":
            break
    if width is None:
        raise ValueError("PNG has no dimensions")
    bpp = 4 if color == 6 else 3
    stride = width * bpp
    raw = zlib.decompress(b"".join(compressed))
    if len(raw) != height * (stride + 1):
        raise ValueError("PNG decoded size mismatch")
    previous, rows = bytearray(stride), bytearray()
    for y in range(height):
        offset = y * (stride + 1)
        filt = raw[offset]
        row = bytearray(raw[offset + 1:offset + 1 + stride])
        if filt not in range(5):
            raise ValueError(f"unsupported PNG filter {filt}")
        for x in range(stride):
            left = row[x - bpp] if x >= bpp else 0
            up = previous[x]
            upper_left = previous[x - bpp] if x >= bpp else 0
            if filt == 1:
                prediction = left
            elif filt == 2:
                prediction = up
            elif filt == 3:
                prediction = (left + up) // 2
            elif filt == 4:
                p = left + up - upper_left
                distances = (abs(p - left), abs(p - up), abs(p - upper_left))
                prediction = (left, up, upper_left)[distances.index(min(distances))]
            else:
                prediction = 0
            row[x] = (row[x] + prediction) & 255
        rows.extend(row)
        previous = row
    if color == 2:
        rgba = bytearray(width * height * 4)
        rgba[0::4], rgba[1::4], rgba[2::4], rgba[3::4] = rows[0::3], rows[1::3], rows[2::3], b"\xff" * (width * height)
        rows = rgba
    return width, height, bytes(rows)


def write_results(output, result, rows):
    (output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    if rows:
        fields = list(dict.fromkeys(key for row in rows for key in row))
        with (output / "launches.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("startup", "cpu", "pixels"))
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--harness", type=Path)
    parser.add_argument("--master", type=Path, required=True)
    parser.add_argument("--patch", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rounds", type=int, default=12)
    parser.add_argument("--backends", nargs="+", choices=BACKENDS, default=list(BACKENDS))
    parser.add_argument("--fonts", nargs="+", choices=("off", "on"), default=["off", "on"])
    parser.add_argument("--save", type=Path)
    parser.add_argument("--catalog", type=Path)
    parser.add_argument("--icon-pack", type=Path)
    parser.add_argument("--font", type=Path, help="Imported UI font to hash, not a font override")
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()
    if args.rounds < 1 or args.timeout < 1:
        parser.error("rounds and timeout must be positive")
    if len(set(args.backends)) != len(args.backends) or len(set(args.fonts)) != len(args.fonts):
        parser.error("backends and font configurations must be unique")
    root = args.root.resolve(strict=True)
    harness = (args.harness or root / "target/release/examples/startup_bench").resolve(strict=True)
    binaries = {"master": args.master.resolve(strict=True), "patch": args.patch.resolve(strict=True)}
    if binaries["master"] == binaries["patch"]:
        parser.error("master and patch must be distinct executable paths")
    paths = {
        "save": args.save or root / "fixtures/sample_save_large.save",
        "catalog": args.catalog or root / "item_names.json",
        "icon_pack": args.icon_pack or root / "logs/slint-startup/icon-pack/icons-128-raw.pack",
        "font": args.font or root / "crates/alustin-gui/assets/fonts/Vollkorn-Medium.ttf",
    }
    inputs = {name: file_info(path) for name, path in paths.items()}
    binary_info = {name: file_info(path) for name, path in binaries.items()}
    env = dict(os.environ)
    for key in ("SLINT_FONT_PATH", "SLINT_DEFAULT_FONT", "ALUSTIN_TEST_SAVE", "ALUSTIN_ICONS",
                "MTL_SHADER_CACHE_SIZE", "SLINT_TRACE_RENDERER_STARTUP", "SLINT_MCP_PORT",
                "SLINT_DEBUG_PERFORMANCE", "SLINT_SLOW_ANIMATIONS", "FEMTOVG_REQUIRE_GPU",
                "SLINT_REVEAL_DELAY_MS", "SLINT_PRESENT_WITH_TRANSACTION", "SLINT_MACOS_MATCH_BACKGROUND",
                "SLINT_GPU_WARMUP_PIPELINE_HANDOFF", "SLINT_WINDOW_ID"):
        env.pop(key, None)
    fixed_env = {
        "SLINT_SCALE_FACTOR": "2", "SLINT_LAZY_SHADERS": "0", "SLINT_GPU_WARMUP": "1",
        "WINIT_MACOS_WINDOW_ANIMATION": "0", "WGPU_METAL_INITIAL_DRAWABLE": "1",
        "ALUSTIN_ITEM_NAMES": inputs["catalog"]["path"],
        "ALUSTIN_FEMTOVG_DIAGNOSTICS": "1" if args.mode == "cpu" else "0",
        "SLINT_STARTUP_DIAGNOSTICS": "1" if args.mode == "cpu" else "0",
    }
    env.update(fixed_env)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    rounds = 1 if args.mode == "pixels" else args.rounds
    result = {
        "mode": args.mode, "app_commit": git_head(root), "root": str(root),
        "source_revisions": {"master": "f57a2c39", "patch": "7a278ca4"},
        "harness": file_info(harness), "binaries": binary_info, "inputs": inputs,
        "platform": platform.platform(), "environment": fixed_env, "rounds": rounds,
        "cache_policy": "Fresh processes; OS and Metal shader caches uncontrolled; retain every launch",
        "pairing": "Adjacent master/patch launches per backend and fonts within each round; alternate version order; rotate configuration order",
        "metrics": "Startup readiness includes report/IPC, excludes compositor scanout. CPU mode renderer spans are host wall/thread CPU; nested spans overlap. Pixels mode is excluded from timing statistics.",
        "order": [], "launches": [], "pixel_comparisons": [],
    }
    rows = []
    groups = [(backend, fonts) for fonts in args.fonts for backend in args.backends]
    write_results(output, result, rows)
    for round_index in range(rounds):
        offset = round_index % len(groups)
        ordered = groups[offset:] + groups[:offset]
        versions = ["master", "patch"] if round_index % 2 == 0 else ["patch", "master"]
        round_order = []
        result["order"].append(round_order)
        for backend, fonts in ordered:
            screenshots = {}
            for version in versions:
                label = f"{round_index + 1:02}-{backend}-fonts-{fonts}-{version}"
                round_order.append(label)
                child_output = output / label
                launch_env = dict(env, SLINT_NO_SYSTEM_FONTS="1" if fonts == "off" else "0")
                command = [str(harness), "--runs", "1", "--timeout", str(args.timeout),
                           "--backend", backend, "--binary", str(binaries[version]),
                           "--save", inputs["save"]["path"], "--icon-pack", inputs["icon_pack"]["path"],
                           "--output", str(child_output)]
                if fonts == "off":
                    command.append("--no-system-fonts")
                if args.mode == "cpu":
                    command.append("--slint-internals")
                if args.mode == "pixels":
                    command.append("--screenshot")
                record = {"label": label, "round": round_index + 1, "backend": backend,
                          "fonts": fonts, "version": version, "command": command,
                          "report": str(child_output / "summary.json"), "validated": False}
                result["launches"].append(record)
                write_results(output, result, rows)
                with (output / f"{label}.harness.stdout").open("w") as stdout, (output / f"{label}.harness.stderr").open("w") as stderr:
                    completed = subprocess.run(command, cwd=root, env=launch_env, stdout=stdout,
                                               stderr=stderr, timeout=args.timeout + 30)
                record["exit_code"] = completed.returncode
                write_results(output, result, rows)
                if completed.returncode:
                    raise RuntimeError(f"{label} harness exited {completed.returncode}; raw outputs retained")
                report = json.loads((child_output / "summary.json").read_text())
                sample, frames = validate_report(report, binaries[version], binary_info[version]["sha256"],
                                                 backend, fonts, args.mode)
                events = event_map(sample)
                record.update(validated=True, frames=frames)
                row = {"round": round_index + 1, "backend": backend, "fonts": fonts, "version": version,
                       "startup_ms": sample["launch_to_probe_observed_ms"],
                       "first_frame_since_main_ms": events["first_frame_rendered"]["since_main_ms"],
                       "search_frame_since_main_ms": events["interactive_frame_rendered"]["since_main_ms"],
                       "first_callback_ms": events["first_frame_rendered"]["since_main_ms"] - events["first_render_started"]["since_main_ms"],
                       "spawn_to_main_ms": sample.get("spawn_to_main_ms"),
                       "peak_rss_bytes": sample.get("peak_rss_bytes"), "report": record["report"]}
                for phase, spans in frames.items():
                    for name in ("femtovg.render", "femtovg.render.thread_cpu_ns",
                                 "femtovg.component_items", "femtovg.component_items.thread_cpu_ns",
                                 "femtovg.final_flush", "femtovg.final_flush.thread_cpu_ns"):
                        if name in spans:
                            row[f"{phase}.{name}.ms"] = spans[name]["ms"]
                rows.append(row)
                if args.mode == "pixels":
                    screenshots[version] = child_output / "run-1.png"
                write_results(output, result, rows)
                print(f"{label}: {row['startup_ms']:.3f} ms; validated", flush=True)
            if args.mode == "pixels":
                master = png_rgba(screenshots["master"])
                patch = png_rgba(screenshots["patch"])
                comparison = {"backend": backend, "fonts": fonts,
                              "master_png": file_info(screenshots["master"]),
                              "patch_png": file_info(screenshots["patch"]),
                              "master_dimensions": master[:2], "patch_dimensions": patch[:2],
                              "master_rgba_sha256": hashlib.sha256(master[2]).hexdigest(),
                              "patch_rgba_sha256": hashlib.sha256(patch[2]).hexdigest(),
                              "rgba_identical": master == patch}
                result["pixel_comparisons"].append(comparison)
                write_results(output, result, rows)
                print(f"pixels {backend} fonts-{fonts}: identical={comparison['rgba_identical']}", flush=True)
    result["complete"] = True
    write_results(output, result, rows)
    if args.mode == "pixels" and not all(row["rgba_identical"] for row in result["pixel_comparisons"]):
        raise RuntimeError("screenshot pixel mismatch; all comparisons retained")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, RuntimeError, KeyError, subprocess.SubprocessError) as error:
        print(f"Benchmark failed: {error}", file=sys.stderr)
        sys.exit(1)
