from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
root=Path(__file__).resolve().parent
app=Path('/Users/jesse/github/alustin-gui-v2')
target=Path('/private/tmp/slint-wgpu-evidence/target')
label=sys.argv[1]
assert label in ['master','patch']
source=root/label
metadata=subprocess.check_output(['cargo','metadata','--locked','--offline','--format-version','1',
    '--features','alustin-gui/femtovg-benchmark','--config',f'patch.crates-io.femtovg.path="{source}"'],cwd=app)
(root/(label+'-metadata.json')).write_bytes(metadata)
data=json.loads(metadata)
package=next(p for p in data['packages'] if p['name']=='femtovg')
assert Path(package['manifest_path']).resolve()==source/'Cargo.toml'
node=next(n for n in data['resolve']['nodes'] if n['id']==package['id'])
assert 'swash' in node['features'] and 'wgpu' in node['features'] and 'textlayout' not in node['features']
dest=root/'bin'/label
dest.mkdir(parents=True,exist_ok=True)
shutil.copy2(target/'release/alustin-gui',dest/'alustin-gui')
if label=='master': shutil.copy2(target/'release/examples/startup_bench',root/'bin/startup_bench')
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
swash=next(p for p in data['packages'] if p['name']=='swash')
swashnode=next(n for n in data['resolve']['nodes'] if n['id']==swash['id'])
skrifaid=next(d['pkg'] for d in swashnode['deps'] if d['name']=='skrifa')
skrifa=next(p for p in data['packages'] if p['id']==skrifaid)
out={'binary':str(dest/'alustin-gui'),'binary_sha256':digest(dest/'alustin-gui'),
    'app_lock_sha256':digest(app/'Cargo.lock'),'features':node['features'],
    'swash':swash['version'],'swash_skrifa':skrifa['version'],
    'source_sha256':{str(p.relative_to(source)):digest(p) for p in source.rglob('*') if p.is_file()},
    'app_tracked_diff':subprocess.check_output(['git','diff'],cwd=app,text=True),
    'build_command':['cargo','build','--release','--locked','--offline','-p','alustin-gui',
      '--bin','alustin-gui','--example','startup_bench','--features','femtovg-benchmark',
      '--config',f'patch.crates-io.femtovg.path="{source}"','--target-dir',str(target)],
}
(root/(label+'-build.json')).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['source_sha256','app_tracked_diff']},indent=2))
