#!/usr/bin/env python3
"""Add matched, optional glyph tracing to a separate FemtoVG archive copy.

Usage: python3 instrument.py /private/tmp/alustin-femtovg-outline-review/NAME
Use --check to validate the source matches without writing. No build or lockfile
operation is performed. The primary, uninstrumented comparison must remain separate.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import tomllib

ARCHIVE_ROOT = Path("/private/tmp/alustin-femtovg-outline-review").resolve()


def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise ValueError(f"{label}: expected exactly one source match, found {count}")
    return source.replace(old, new, 1)


def span(name: str, variable: str, indent: int = 8) -> str:
    return " " * indent + (
        f'let {variable} = tracing::info_span!(target: "alustin_startup", '
        f'"femtovg.{name}").entered();\n'
    )


def instrument_text(source: str, candidate: bool) -> str:
    start = source.index("    fn render_glyph_swash<T: Renderer>(")
    end = source.index("    // Returns (texture index, image id, glyph padding box)", start)
    body = source[start:end]
    if "femtovg.glyph_" in body:
        raise ValueError("glyph tracing already exists; use a fresh secondary archive")
    body = replace_once(
        body,
        "        let font_ref = match font.swash_font_ref() {\n",
        span("glyph_cache_miss", "_glyph_miss")
        + "        let font_ref = match font.swash_font_ref() {\n",
        "glyph miss entry",
    )
    body = replace_once(
        body,
        "        let img = imgref::Img::new(&pixels[..], padded_width, padded_height);\n",
        span("glyph_upload", "_glyph_upload")
        + "        let img = imgref::Img::new(&pixels[..], padded_width, padded_height);\n",
        "glyph upload",
    )
    if candidate:
        body = replace_once(
            body,
            """        let image =
            self.swash_rasterizer
                .borrow_mut()
                .render(font_ref, font_size, glyph_id, subpixel_x, normalized_coords);
""",
            "        let image = {\n"
            + span("glyph_rasterize", "_glyph_rasterize", 12)
            + """            self.swash_rasterizer
                .borrow_mut()
                .render(font_ref, font_size, glyph_id, subpixel_x, normalized_coords)
        };
""",
            "candidate raster wrapper",
        )
    else:
        body = replace_once(
            body,
            "        let image = {\n",
            "        let image = {\n" + span("glyph_rasterize", "_glyph_rasterize", 12),
            "master raster wrapper",
        )
        body = replace_once(
            body,
            """            let scaler_builder = scale_context
                .builder(font_ref)
                .size(font_size)
                .hint(true)
                .normalized_coords(normalized_coords);
            let mut scaler = scaler_builder.build();
""",
            "            let mut scaler = {\n"
            + span("glyph_scaler_build", "_glyph_scaler", 16)
            + """                let scaler_builder = scale_context
                    .builder(font_ref)
                    .size(font_size)
                    .hint(true)
                    .normalized_coords(normalized_coords);
                scaler_builder.build()
            };
"""
            + span("glyph_render", "_glyph_render", 12),
            "master scaler and render scopes",
        )
    return source[:start] + body + source[end:]


def instrument_rasterizer(source: str) -> str:
    if "femtovg.glyph_" in source:
        raise ValueError("rasterizer tracing already exists; use a fresh secondary archive")
    source = replace_once(
        source,
        "        if let Some(outline) = self.outlines.get(&key) {\n",
        "        if let Some(outline) = self.outlines.get(&key) {\n"
        + span("glyph_render", "_glyph_render", 12),
        "candidate cached rendering",
    )
    return replace_once(
        source,
        """        let mut scaler = scale_context
            .builder(font)
            .size(font_size)
            .hint(true)
            .normalized_coords(normalized_coords)
            .build();
""",
        "        let mut scaler = {\n"
        + span("glyph_scaler_build", "_glyph_scaler", 12)
        + """            scale_context
                .builder(font)
                .size(font_size)
                .hint(true)
                .normalized_coords(normalized_coords)
                .build()
        };
"""
        + span("glyph_render", "_glyph_render"),
        "candidate scaler and miss-render scopes",
    )


def instrument_manifest(source: str) -> str:
    manifest = tomllib.loads(source)
    if manifest["package"]["name"] != "femtovg":
        raise ValueError("argument must be the FemtoVG crate directory")
    if "tracing" in manifest["dependencies"]:
        raise ValueError("tracing dependency already exists; use a fresh secondary archive")
    return replace_once(source, "[dependencies]\n", '[dependencies]\ntracing = "0.1"\n', "manifest")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="separate FemtoVG archive directory")
    parser.add_argument("--check", action="store_true", help="validate without writes")
    args = parser.parse_args()
    root = args.archive.resolve(strict=True)
    if root == ARCHIVE_ROOT or not root.is_relative_to(ARCHIVE_ROOT):
        parser.error(f"archive must be a separate directory beneath {ARCHIVE_ROOT}")
    if (root / ".git").exists():
        parser.error("use an archive snapshot, not a Git checkout")
    paths = [root / "Cargo.toml", root / "src/text.rs"]
    rasterizer = root / "src/text/swash_rasterizer.rs"
    candidate = rasterizer.exists()
    for path in paths + ([rasterizer] if candidate else []):
        if not path.resolve(strict=True).is_relative_to(root):
            parser.error(f"refusing a source symlink outside the archive: {path}")
    changes = {
        paths[0]: instrument_manifest(paths[0].read_text()),
        paths[1]: instrument_text(paths[1].read_text(), candidate),
    }
    if candidate:
        changes[rasterizer] = instrument_rasterizer(rasterizer.read_text())
    # All source matches are validated before any write. The lockfile is untouched.
    for path, source in changes.items():
        if not args.check:
            path.write_text(source)
        print(f'{"checked" if args.check else "instrumented"}: {path}')


if __name__ == "__main__":
    main()
