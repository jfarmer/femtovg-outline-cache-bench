from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

root=Path(__file__).resolve().parent
femtovg=Path('/Users/jesse/github/femtovg')
app=Path('/Users/jesse/github/alustin-gui-v2')
root.mkdir(exist_ok=True)
for ref,label in [('master','master'),('HEAD','patch')]:
    dest=root/label
    dest.mkdir(exist_ok=False)
    raw=subprocess.check_output(['git','archive',ref],cwd=femtovg)
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        archive.extractall(dest,filter='data')
manifest=app/'crates/alustin-gui/Cargo.toml'
text=manifest.read_text()
marker='[features]\n'
assert marker in text and 'femtovg-benchmark' not in text
text=text.replace(marker,marker+'# Narrow renderer build for the master/outline-cache application comparison.\n'
    'femtovg-benchmark = ["slint/renderer-femtovg-wgpu", "startup-diagnostics"]\n\n',1)
manifest.write_text(text)
startup=app/'crates/alustin-gui/src/startup.rs'
text=startup.read_text()
marker='#[cfg(feature = "renderer-bench")]\n                            slint::GraphicsAPI::WGPU30'
assert marker in text
startup.write_text(text.replace(marker,
    '#[cfg(any(feature = "renderer-bench", feature = "femtovg-benchmark"))]\n                            slint::GraphicsAPI::WGPU30'))
out={
    'app_main':subprocess.check_output(['git','rev-parse','HEAD'],cwd=app,text=True).strip(),
    'app_branch':subprocess.check_output(['git','branch','--show-current'],cwd=app,text=True).strip(),
    'femtovg_master':subprocess.check_output(['git','rev-parse','master'],cwd=femtovg,text=True).strip(),
    'femtovg_patch':subprocess.check_output(['git','rev-parse','HEAD'],cwd=femtovg,text=True).strip(),
    'rustc':subprocess.check_output(['rustc','--version'],text=True).strip(),
    'initial_app_lock_sha256':hashlib.sha256((app/'Cargo.lock').read_bytes()).hexdigest(),
}
(root/'provenance.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
