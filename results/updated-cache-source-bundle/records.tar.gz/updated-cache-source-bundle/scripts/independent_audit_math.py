"""Independent arithmetic for retained-data audits; no benchmark/helper imports."""
import hashlib,math,random
from pathlib import Path

def median(values):
    values=sorted(values);n=len(values)
    if not n:raise AssertionError('empty observation set')
    return values[n//2] if n%2 else (values[n//2-1]+values[n//2])/2

def quantile(values,q):
    values=sorted(values);at=(len(values)-1)*q;lo=math.floor(at);hi=math.ceil(at)
    return values[lo]+(values[hi]-values[lo])*(at-lo)

def close(actual,expected):
    if not math.isclose(float(actual),expected,rel_tol=1e-10,abs_tol=1e-6):
        raise AssertionError(f'reported {actual!r}, independently computed {expected!r}')

def draws(n,count,seed):
    rng=random.Random(seed)
    return [[rng.randrange(n) for _ in range(n)] for _ in range(count)]

def interval(values,samples):
    values=[median(values[index] for index in sample) for sample in samples]
    return [quantile(values,.025),quantile(values,.975)]

def token_seed(seed,token):
    return seed^int.from_bytes(hashlib.sha256(token.encode()).digest()[:8],'big')

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def baseline_pairs(versions):
    assert versions == ['master', 'prior', 'updated45', 'final'], versions
    return [('master','prior'), ('master','updated45'), ('master','final'),
            ('prior','updated45'), ('prior','final'), ('updated45','final')]

def pairs(versions):
    return baseline_pairs(versions)

def declared_pairs(versions,declared):
    expected=baseline_pairs(versions);declared=list(map(tuple,declared))
    assert declared==expected,('unexpected comparison plan',declared,expected)
    return declared
