#!/usr/bin/env python3
"""Inspect openly licensed candidates using the prior comparison's same reader."""
from pathlib import Path
import importlib.util
import json

HERE = Path(__file__).resolve().parent
READER = Path('/private/tmp/femtovg-hinted-font-candidates/font_metadata.py')
spec = importlib.util.spec_from_file_location('font_metadata_reader',READER)
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
sources = {
    'Ubuntu-Medium.ttf': {
        'repository':'https://github.com/google/fonts',
        'commit':'a50de97857f6626d6628c91e6a34c12ee8a16ede',
        'path':'ufl/ubuntu/Ubuntu-Medium.ttf', 'license_file':'Ubuntu-LICENSE.txt'},
    'Ubuntu-Regular.ttf': {
        'repository':'https://github.com/google/fonts',
        'commit':'a50de97857f6626d6628c91e6a34c12ee8a16ede',
        'path':'ufl/ubuntu/Ubuntu-Regular.ttf', 'license_file':'Ubuntu-LICENSE.txt'},
    'NotoSans-Regular.ttf': {
        'repository':'https://github.com/notofonts/noto-fonts',
        'commit':'ffebf8c1ee449e544955a7e813c54f9b73848eac',
        'path':'hinted/ttf/NotoSans/NotoSans-Regular.ttf', 'license_file':'NotoSans-OFL.txt'},
    'Lato-Regular.ttf': {
        'repository':'https://github.com/google/fonts',
        'commit':'f3b885d5590e307e02542f1a724cec55d567fdaa',
        'path':'ofl/lato/Lato-Regular.ttf', 'license_file':'Lato-OFL.txt'},
    'OpenSans-Regular.ttf': {
        'repository':'https://github.com/googlefonts/opensans',
        'commit':'bd7e37632246368c60fdcbd374dbf9bad11969b6',
        'path':'fonts/ttf/OpenSans-Regular.ttf', 'license_file':'OpenSans-OFL.txt'},
    'Carlito-Regular.ttf': {
        'repository':'https://github.com/googlefonts/carlito',
        'commit':'3a810cab78ebd6e2e4eed42af9e8453c4f9b850a',
        'path':'fonts/ttf/Carlito-Regular.ttf', 'license_file':'Carlito-OFL.txt'},
}
result = {'method':'Same FontTools glyph-program byte reader as Arial/Liberation/Vollkorn comparison',
          'fonttools_version':reader.fontTools.__version__, 'sources':sources,
          'fonts':{name:reader.inspect(HERE/name) for name in sources}}
(HERE/'candidate-metadata.json').write_text(json.dumps(result,indent=2)+'\n')
for name, data in result['fonts'].items():
    print(json.dumps({'file':name,'family':data['family'],'version':data['version'],
        'sha256':data['sha256'],'glyph_programs':data['glyf_programs'],
        'ascii_programs':data['ascii_programs'],
        'fpgm_bytes':data['embedded_program_tables']['fpgm']['table_bytes'],
        'prep_bytes':data['embedded_program_tables']['prep']['table_bytes'],
        'license':data['license_description']}))
