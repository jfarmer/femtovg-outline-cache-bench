# Gray8 mixed-scene pixel discrepancy

Original cohort failure is preserved in `/private/tmp/femtovg-miss-final-review/results/pixels-provenance.json`. All 20 non-text phases match master; all eight text phases differ at (794,16), and size_advance has one additional pixel differing by one gray level. The recurrent pixel is the rust-colored instruction text at the top right, not the screen-space RUST strokes.

CPU instrumentation identifies two fill quads covering (794.5,16.5): glyph 85 (`r`) screen (789,15)..(797,26), and glyph 72 (`e`) screen (794,15)..(805,27). In master, the `e` starts at atlas (325,451), so this screen pixel samples its zero left padding at atlas (325,452). A 72px stroked R occupies the adjacent atlas allocation (267,388), dimensions (57,68), whose right edge ends before this padding texel. GPU path rendering does not clip to that allocated glyph rectangle.

The causal clone changes only the GPU path-mask factor from 1/8 to zero, leaving all glyph allocations, glyph metrics, quads, native Swash mask uploads, render targets, and deferred commands in place. Native Metal produces:

| Variant | RGBA at (794,16) |
| --- | --- |
| Master diagnostic | 206,147,122,255 |
| Gray8 diagnostic | 209,159,137,255 |
| Master, identical packing, zero path-mask RGB | 209,159,137,255 |

Thus the extra coverage in master comes from path stroke writes contaminating the neighboring native-mask padding. Splitting R8 and RGBA textures removes those writes, making Gray8 differ from master. The original implementation should be excluded from production/cache timing comparisons requiring exact master parity. Preserving its packing would require shared logical placement across both texture formats; preserving contamination additionally conflicts with the purpose of physically separating formats. A fix to the old path-atlas overflow belongs in a separate change with explicit before/after rendering validation.

This is an untimed causal diagnostic. Instrumented source copies, immutable binaries, raw CPU/GPU stdout/stderr, first-frame RGBA images, and SHA256 provenance are retained in this directory. No frozen benchmark source or native Swash code was changed. The additional size_advance gray-level discrepancy was not separately localized causally; the persistent failure alone is sufficient to exclude this Gray8 prototype.
