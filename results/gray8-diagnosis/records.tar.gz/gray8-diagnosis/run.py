from pathlib import Path
import os,subprocess,json
r=Path(__file__).resolve().parent
results={}
for version in ('master','gray8','master_no_path_draw'):
 out=r/(version+'-pixels')
 if out.exists():raise RuntimeError('Refusing previous '+str(out))
 env=dict(os.environ,FEMTOVG_REQUIRE_GPU='metal')
 p=subprocess.run([str(r/(version+'-runner')),'gpu','1','1',str(out)],env=env,capture_output=True,text=True,timeout=90)
 (r/(version+'-gpu.stdout')).write_text(p.stdout)
 (r/(version+'-gpu.stderr')).write_text(p.stderr)
 if p.returncode:raise RuntimeError(version+' GPU failed '+p.stderr)
 data=(out/'text-first_paint.rgba').read_bytes()
 results[version]={str((x,y)):list(data[(y*1000+x)*4:(y*1000+x)*4+4]) for x,y in ((794,16),(603,599))}
 print(version,results[version],flush=True)
(r/'pixel-results.json').write_text(json.dumps(results,indent=2)+'\n')
