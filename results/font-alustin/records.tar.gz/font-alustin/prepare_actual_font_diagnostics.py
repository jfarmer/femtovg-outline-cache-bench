#!/usr/bin/env python3
"""Generate (never apply) an env-gated actual-font diagnostic patch.

The gate runs only in the renderer's existing first-use font insertion path.
Enabled untimed runs dump each distinct actual FontData blob/index once. Skrifa
already used by Slint supplies names and cmap coverage; the verifier computes
SHA-256 outside the app. No new Rust dependency is needed.
"""

import argparse
import difflib
import hashlib
import json
from pathlib import Path


RELATIVE = "crates/alustin-gui/vendor/i-slint-renderer-femtovg/font_cache.rs"
ROOT = Path(__file__).resolve().parent

HELPER = r'''

/// Untimed validation only: record the actual font passed by shaped text to FemtoVG.
/// Primary timing runs leave ALUSTIN_FONT_DIAGNOSTICS_DIR unset.
fn benchmark_actual_font(font: &parley::FontData) {
    use i_slint_common::sharedfontique::skrifa::{self, MetadataProvider, string::StringId};
    use std::collections::HashSet;
    use std::fmt::Write as _;
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};

    type Diagnostics = (PathBuf, Mutex<HashSet<(u64, u32)>>);
    static DIAGNOSTICS: OnceLock<Option<Diagnostics>> = OnceLock::new();
    let Some((directory, seen)) = DIAGNOSTICS.get_or_init(|| {
        std::env::var_os("ALUSTIN_FONT_DIAGNOSTICS_DIR")
            .filter(|path| !path.is_empty())
            .map(|path| (PathBuf::from(path), Mutex::new(HashSet::new())))
    }) else {
        return;
    };
    let key = (font.data.id(), font.index);
    let mut seen = seen.lock().expect("actual-font diagnostic lock");
    if !seen.insert(key) {
        return;
    }

    let data: &[u8] = font.data.as_ref();
    let face = skrifa::FontRef::from_index(data, font.index)
        .expect("actual-font diagnostic face was already accepted by Slint");
    let family = face.localized_strings(StringId::TYPOGRAPHIC_FAMILY_NAME)
        .english_or_first()
        .or_else(|| face.localized_strings(StringId::FAMILY_NAME).english_or_first())
        .map(|name| name.to_string()).unwrap_or_default();
    let postscript = face.localized_strings(StringId::POSTSCRIPT_NAME)
        .english_or_first().map(|name| name.to_string()).unwrap_or_default();
    let hex = |text: &str| {
        let mut encoded = String::with_capacity(text.len() * 2);
        for byte in text.bytes() { write!(&mut encoded, "{byte:02x}").unwrap(); }
        encoded
    };
    let cmap = face.charmap();
    let has_ascii = (32u32..=126).all(|c| cmap.map(c).is_some_and(|g| g.to_u32() != 0));
    let has_checkmark = cmap.map(0x2713u32).is_some_and(|g| g.to_u32() != 0);
    let stem = format!("face-{}-{}", key.0, key.1);
    let blob_file = format!("{stem}.font.bin");
    std::fs::create_dir_all(directory).expect("actual-font diagnostic directory");
    std::fs::write(directory.join(&blob_file), data).expect("actual-font diagnostic blob");
    // UTF-8 hex avoids depending on a JSON serializer or hand-written string escaping.
    // Postprocessing decodes the names and attaches SHA-256 of these exact blob bytes.
    let metadata = format!(concat!(
        "{{\"schema\":1,\"blob_id\":{},\"face_index\":{},\"bytes\":{},",
        "\"blob_file\":\"{}\",\"family_utf8_hex\":\"{}\",",
        "\"postscript_utf8_hex\":\"{}\",\"has_ascii\":{},\"has_checkmark\":{}}}\n"
    ), key.0, key.1, data.len(), blob_file, hex(&family), hex(&postscript), has_ascii, has_checkmark);
    std::fs::write(directory.join(format!("{stem}.font.json")), metadata)
        .expect("actual-font diagnostic metadata");
    eprintln!("Alustin actual font: family={family:?}, face_index={}, bytes={}", font.index, data.len());
}
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("/Users/jesse/github/alustin-gui-v2"))
    parser.add_argument("--output", type=Path, default=ROOT)
    args = parser.parse_args()
    source = (args.repo / RELATIVE).read_text()
    marker = "        *self.fonts.entry((font.data.clone().into(), font.index)).or_insert_with(move || {\n"
    if source.count(marker) != 1 or "fn benchmark_actual_font(" in source:
        raise ValueError("expected the uninstrumented existing font insertion path exactly once")
    modified = source.replace(marker, marker + "            benchmark_actual_font(font);\n", 1) + HELPER
    args.output.mkdir(parents=True, exist_ok=True)
    prepared = args.output / "font_cache.diagnostic.rs"
    patch = args.output / "actual-font-diagnostics.patch"
    prepared.write_text(modified)
    patch.write_text("".join(difflib.unified_diff(source.splitlines(keepends=True), modified.splitlines(keepends=True),
                                                  fromfile="a/" + RELATIVE, tofile="b/" + RELATIVE)))
    (args.output / "actual-font-diagnostics-inputs.json").write_text(json.dumps({
        "source": str(args.repo / RELATIVE),
        "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
        "prepared_sha256": hashlib.sha256(modified.encode()).hexdigest(),
        "gate": "ALUSTIN_FONT_DIAGNOSTICS_DIR", "repo_modified": False,
        "scope": "Unique actual font blobs passed to the renderer; no per-glyph routing or fallback character counts",
    }, indent=2) + "\n")
    print(f"Prepared {patch}; no repository files changed.")


if __name__ == "__main__":
    main()
