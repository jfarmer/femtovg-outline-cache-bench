// Copyright © SixtyFPS GmbH <info@slint.dev>
// SPDX-License-Identifier: GPL-3.0-only OR LicenseRef-Slint-Royalty-free-2.0 OR LicenseRef-Slint-Software-3.0

// cspell:ignore Noto fontconfig

use femtovg::TextContext;
use i_slint_common::sharedfontique::HashedBlob;
use i_slint_core::textlayout::sharedparley::parley;
use std::cell::RefCell;
use std::collections::HashMap;

pub struct FontCache {
    pub(crate) text_context: femtovg::TextContext,
    fonts: HashMap<(HashedBlob, u32), femtovg::FontId>,
}

impl Default for FontCache {
    fn default() -> Self {
        let text_context = TextContext::default();
        Self { text_context, fonts: Default::default() }
    }
}

impl FontCache {
    pub fn font(&mut self, font: &parley::FontData) -> femtovg::FontId {
        let text_context = self.text_context.clone();

        *self.fonts.entry((font.data.clone().into(), font.index)).or_insert_with(move || {
            benchmark_actual_font(font);
            text_context.add_shared_font_with_index(font.data.clone(), font.index).unwrap()
        })
    }
}

thread_local! {
    pub static FONT_CACHE: RefCell<FontCache> = RefCell::new(Default::default())
}


/// Untimed validation only: record the actual font passed by shaped text to FemtoVG.
/// Primary timing runs leave ALUSTIN_FONT_DIAGNOSTICS_DIR unset.
fn benchmark_actual_font(font: &parley::FontData) {
    use i_slint_common::sharedfontique::skrifa::{self, MetadataProvider, string::StringId};
    use std::collections::HashSet;
    use std::fmt::Write as _;
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};

    type Diagnostics = (PathBuf, Mutex<HashSet<(u64, u32)>>);
    static DIAGNOSTICS: OnceLock<Option<Diagnostics>> = OnceLock::new();
    let Some((directory, seen)) = DIAGNOSTICS.get_or_init(|| {
        std::env::var_os("ALUSTIN_FONT_DIAGNOSTICS_DIR")
            .filter(|path| !path.is_empty())
            .map(|path| (PathBuf::from(path), Mutex::new(HashSet::new())))
    }) else {
        return;
    };
    let key = (font.data.id(), font.index);
    let mut seen = seen.lock().expect("actual-font diagnostic lock");
    if !seen.insert(key) {
        return;
    }

    let data: &[u8] = font.data.as_ref();
    let face = skrifa::FontRef::from_index(data, font.index)
        .expect("actual-font diagnostic face was already accepted by Slint");
    let family = face.localized_strings(StringId::TYPOGRAPHIC_FAMILY_NAME)
        .english_or_first()
        .or_else(|| face.localized_strings(StringId::FAMILY_NAME).english_or_first())
        .map(|name| name.to_string()).unwrap_or_default();
    let postscript = face.localized_strings(StringId::POSTSCRIPT_NAME)
        .english_or_first().map(|name| name.to_string()).unwrap_or_default();
    let hex = |text: &str| {
        let mut encoded = String::with_capacity(text.len() * 2);
        for byte in text.bytes() { write!(&mut encoded, "{byte:02x}").unwrap(); }
        encoded
    };
    let cmap = face.charmap();
    let has_ascii = (32u32..=126).all(|c| cmap.map(c).is_some_and(|g| g.to_u32() != 0));
    let has_checkmark = cmap.map(0x2713u32).is_some_and(|g| g.to_u32() != 0);
    let stem = format!("face-{}-{}", key.0, key.1);
    let blob_file = format!("{stem}.font.bin");
    std::fs::create_dir_all(directory).expect("actual-font diagnostic directory");
    std::fs::write(directory.join(&blob_file), data).expect("actual-font diagnostic blob");
    // UTF-8 hex avoids depending on a JSON serializer or hand-written string escaping.
    // Postprocessing decodes the names and attaches SHA-256 of these exact blob bytes.
    let metadata = format!(concat!(
        "{{\"schema\":1,\"blob_id\":{},\"face_index\":{},\"bytes\":{},",
        "\"blob_file\":\"{}\",\"family_utf8_hex\":\"{}\",",
        "\"postscript_utf8_hex\":\"{}\",\"has_ascii\":{},\"has_checkmark\":{}}}\n"
    ), key.0, key.1, data.len(), blob_file, hex(&family), hex(&postscript), has_ascii, has_checkmark);
    std::fs::write(directory.join(format!("{stem}.font.json")), metadata)
        .expect("actual-font diagnostic metadata");
    eprintln!("Alustin actual font: family={family:?}, face_index={}, bytes={}", font.index, data.len());
}
