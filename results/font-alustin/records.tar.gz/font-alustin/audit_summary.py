#!/usr/bin/env python3
"""Independent raw-report arithmetic and actual-font audit; never launches an app."""

from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import random
import statistics


ROOT = Path(__file__).resolve().parent
analysis = json.loads((ROOT / "analysis/summary.json").read_text())
lookup = {(row["mode"], row["backend"], row["font"], row["metric"]): row for row in analysis["results"]}
checked, launches, selected_metric_count = [], {}, 0
seed_base = analysis["statistics"]["seed"]
resamples = analysis["statistics"]["bootstrap_resamples"]


def close(actual, expected):
    assert math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12), (actual, expected)


def percentile(ordered, q):
    pos = (len(ordered) - 1) * q
    lower = int(pos)
    upper = min(lower + 1, len(ordered) - 1)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (pos - lower)


def frame_cpu(sample, marker_name):
    spans = sample["slint_internal_spans"]
    marker = [span for span in spans if span["name"] == marker_name]
    assert len(marker) == 1
    point = marker[0]["start_ns"]
    renders = [span for span in spans if span["name"] == "femtovg.render"
               and span["start_ns"] <= point <= span["start_ns"] + span["duration_ns"]]
    assert len(renders) == 1
    frame = renders[0]
    begin, end = frame["start_ns"], frame["start_ns"] + frame["duration_ns"]
    amounts = [span["amount"] for span in spans if span["name"] == "femtovg.render.thread_cpu_ns"
               and begin <= span["start_ns"] and span["start_ns"] + span["duration_ns"] <= end]
    assert len(amounts) == 1
    return amounts[0] / 1_000_000


for mode, folder in (("cpu", "cpu-12"), ("startup", "startup-12")):
    manifest = json.loads((ROOT / folder / "summary.json").read_text())
    assert manifest["complete"] is True and manifest["rounds"] == 12
    assert len(manifest["launches"]) == 192 and len(manifest["accepted_pairs"]) == 96
    assert all(row["included"] and row["validated"] and row["attempt"] == 1 for row in manifest["launches"])
    launches[folder] = len(manifest["launches"])
    raw = defaultdict(dict)
    for launch in manifest["launches"]:
        sample = json.loads(Path(launch["report"]).read_text())["samples"][0]
        events = {row["event"]: row for row in sample["events"]}
        assert events["interactive_frame_rendered"]["details"]["query"] == "a"
        values = {"observed_search_response_ms": sample["launch_to_probe_observed_ms"],
                  "peak_rss_mib": sample["peak_rss_bytes"] / 2**20}
        if mode == "cpu":
            values["first_frame.render.thread_cpu_ms"] = frame_cpu(sample, "first_frame_rendered")
            values["search_frame.render.thread_cpu_ms"] = frame_cpu(sample, "interactive_frame_rendered")
        raw[launch["backend"], launch["font"], launch["round"]][launch["version"]] = values
    for backend in manifest["backends"]:
        for font in manifest["fonts"]:
            pairs = [raw[backend, font, round_number] for round_number in range(1, 13)]
            assert all(set(pair) == {"master", "patch"} for pair in pairs)
            seed = seed_base ^ int.from_bytes(hashlib.sha256(f"{folder}/{backend}/{font}".encode()).digest()[:8], "big")
            rng = random.Random(seed)
            indices = [[rng.randrange(12) for _ in range(12)] for _ in range(resamples)]
            for metric in pairs[0]["master"]:
                row = lookup[mode, backend, font, metric]
                a = [pair["master"][metric] for pair in pairs]
                b = [pair["patch"][metric] for pair in pairs]
                differences = [new - old for old, new in zip(a, b)]
                ratios = [new / old for old, new in zip(a, b)]
                assert row["n_pairs"] == 12
                close(row["master_median"], statistics.median(a))
                close(row["patch_median"], statistics.median(b))
                close(row["median_paired_delta"], statistics.median(differences))
                close(row["median_paired_change_pct"], 100 * (statistics.median(ratios) - 1))
                delta_samples = sorted(statistics.median(differences[i] for i in ix) for ix in indices)
                ratio_samples = sorted(statistics.median(ratios[i] for i in ix) for ix in indices)
                for position, quantile in enumerate((0.025, 0.975)):
                    close(row["median_paired_delta_ci95"][position], percentile(delta_samples, quantile))
                    close(row["median_paired_change_pct_ci95"][position], 100 * (percentile(ratio_samples, quantile) - 1))
                selected_metric_count += 1
            checked.append({"batch": folder, "backend": backend, "font": font, "pairs": 12})

pixels = json.loads((ROOT / "pixels-font-validation/summary.json").read_text())
assert pixels["complete"] and len(pixels["launches"]) == 16 and len(pixels["pixel_comparisons"]) == 8
assert all(row["rgba_identical"] for row in pixels["pixel_comparisons"])
faces = []
for launch in pixels["launches"]:
    actual = launch["actual_fonts"]
    assert actual["complete"] and launch["font_verification_exit_code"] == 0
    recorded_faces = actual["actual_fonts"]
    assert len(recorded_faces) == 2 and {row["role"] for row in recorded_faces} == {"primary", "fallback"}
    for face in recorded_faces:
        metadata_path = Path(face["metadata_file"])
        metadata = json.loads(metadata_path.read_text())
        blob = (metadata_path.parent / metadata["blob_file"]).read_bytes()
        assert len(blob) == metadata["bytes"]
        assert hashlib.sha256(blob).hexdigest() == face["sha256"]
        assert bytes.fromhex(metadata["family_utf8_hex"]).decode() == face["family"]
        assert face["face_index"] == 0
        if face["role"] == "primary":
            assert face["sha256"] == pixels["fonts"][launch["font"]]["file"]["sha256"]
            assert face["family"] == pixels["fonts"][launch["font"]]["family"]
        else:
            assert face["family"] == "Inter" and face["sha256"] == actual["allowed_fallbacks"][0]["sha256"]
        faces.append({"label": launch["label"], "role": face["role"], "family": face["family"], "sha256": face["sha256"]})

report = {"complete": True, "scope": "Independent raw-report CPU extraction, paired arithmetic/CI recomputation, actual-font blob hash verification; no app launches or performance measurements",
          "timed_launches": launches, "configuration_checks": checked,
          "selected_metric_summaries_verified": selected_metric_count,
          "retained_all_timed_launches": True, "timing_retries": 0,
          "actual_font_launches": 16, "actual_font_faces_verified": faces,
          "pixel_pairs_already_raw_redecoded_by_primary_analyzer": 8}
(ROOT / "analysis/independent-arithmetic-audit.json").write_text(json.dumps(report, indent=2) + "\n")
print(f"Verified {selected_metric_count} metric summaries from all 384 raw timed reports, and 32 exact actual font blobs from 16 untimed launches.")
