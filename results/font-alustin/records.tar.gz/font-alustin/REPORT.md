The current outline-cache patch has a substantial first-frame CPU benefit in Alustin with Vollkorn, a smaller benefit with Arial, and little benefit with Liberation Serif or Roboto Flex. This font dependence appears within the same real application, with the same save, icons, UI, renderer configuration, and paired master/patch executables.

This comparison uses FemtoVG master `f57a2c39e9836c146556c58c98d80c5bf7899029` and patch `7a278ca4f947658d01c355c450edc6abcdbe3958`. Alustin is based on current main `ac35d4e0b5c52edb7defb9feccdadfd584635c14`, on branch `perf/femtovg-outline-master-compare`, with shared benchmark-only font selection and instrumentation. Both builds replace Alustin's vendored FemtoVG with exact upstream snapshots, so the earlier application-local cache is absent on both sides. The active FemtoVG features are `swash` and `wgpu`; both use Swash 0.2.10 and Swash's Skrifa 0.40.0. [Build provenance](build/provenance.json), [independent source/dependency audit](build/independent-audit.json), and [shared app diff](build/app-input.diff) record the complete inputs.

First-frame renderer thread CPU, measured in a separate diagnostics-enabled batch:

| Font | Renderer | Master ms | Patch ms | Paired Δ ms | Paired change (95% CI) |
| --- | --- | ---: | ---: | ---: | ---: |
| Vollkorn | WGPU/Metal | 23.003 | 17.897 | -5.167 | -22.38% [-24.05, -20.83] |
| Vollkorn | OpenGL | 25.357 | 20.358 | -4.716 | -18.99% [-20.56, -17.32] |
| Liberation Serif | WGPU/Metal | 14.277 | 14.050 | -0.194 | -1.36% [-3.33, +1.59] |
| Liberation Serif | OpenGL | 17.109 | 16.672 | -0.312 | -1.85% [-4.75, -0.52] |
| Arial | WGPU/Metal | 16.154 | 15.200 | -0.863 | -5.36% [-7.11, -3.91] |
| Arial | OpenGL | 18.225 | 17.286 | -0.736 | -4.08% [-5.20, -2.75] |
| Roboto Flex | WGPU/Metal | 14.828 | 14.971 | -0.071 | -0.49% [-2.46, +0.96] |
| Roboto Flex | OpenGL | 16.783 | 16.446 | -0.090 | -0.53% [-2.38, +2.02] |

Vollkorn saves about 4.7–5.2 ms of paired first-frame renderer CPU. Arial saves about 0.7–0.9 ms. Liberation Serif's OpenGL reduction is small but its interval excludes zero; its WGPU interval includes zero. Roboto Flex's intervals include zero on both backends. Final-flush CPU intervals include zero for all eight configurations, consistent with the gain occurring before final flush.

Launch-to-observed-search readiness, measured in the separate diagnostics-disabled startup batch:

| Font | Renderer | Master ms | Patch ms | Paired Δ ms | Paired change (95% CI) |
| --- | --- | ---: | ---: | ---: | ---: |
| Vollkorn | WGPU/Metal | 164.259 | 156.850 | -9.769 | -5.92% [-11.57, +0.05] |
| Vollkorn | OpenGL | 279.717 | 264.828 | -10.727 | -3.76% [-6.85, -0.67] |
| Liberation Serif | WGPU/Metal | 155.471 | 159.897 | -1.246 | -0.81% [-3.77, +1.90] |
| Liberation Serif | OpenGL | 262.957 | 264.509 | +1.931 | +0.74% [-0.64, +3.31] |
| Arial | WGPU/Metal | 156.397 | 156.610 | +1.163 | +0.75% [-1.60, +2.54] |
| Arial | OpenGL | 263.708 | 267.008 | +3.151 | +1.23% [-0.84, +3.35] |
| Roboto Flex | WGPU/Metal | 155.087 | 155.379 | +0.092 | +0.04% [-3.45, +1.82] |
| Roboto Flex | OpenGL | 266.071 | 262.355 | -3.032 | -1.15% [-2.76, +1.34] |

The Vollkorn startup signal is smaller and noisier than its renderer CPU benefit: OpenGL's interval excludes zero; WGPU's narrowly includes zero. All other fonts' startup intervals include zero. These values include application initialization, font registration, model loading, rendering, and report/IPC observation. They do not measure GPU completion or compositor scanout. The first-frame renderer result does not establish an equivalent reduction in total startup time.

Search-frame renderer thread CPU from the diagnostics-enabled batch:

| Font | Renderer | Master ms | Patch ms | Paired Δ ms | Paired change (95% CI) |
| --- | --- | ---: | ---: | ---: | ---: |
| Vollkorn | WGPU/Metal | 2.607 | 2.351 | -0.181 | -6.87% [-10.42, -6.04] |
| Vollkorn | OpenGL | 2.509 | 2.306 | -0.183 | -7.32% [-15.67, -4.05] |
| Liberation Serif | WGPU/Metal | 2.188 | 2.235 | -0.007 | -0.29% [-3.64, +6.30] |
| Liberation Serif | OpenGL | 1.906 | 1.958 | +0.043 | +2.25% [-2.52, +6.83] |
| Arial | WGPU/Metal | 2.203 | 2.197 | +0.027 | +1.21% [-4.18, +4.80] |
| Arial | OpenGL | 2.162 | 2.186 | -0.023 | -1.09% [-7.68, +2.62] |
| Roboto Flex | WGPU/Metal | 2.223 | 2.248 | +0.009 | +0.41% [-3.56, +3.13] |
| Roboto Flex | OpenGL | 2.262 | 2.188 | -0.050 | -2.33% [-6.34, -0.30] |

Vollkorn's search frame saves about 0.18 ms on both backends. The other fonts have small mixed estimates: Roboto/OpenGL has an exploratory small reduction; the other intervals include zero. This experiment covers first display and one injected search response, rather than a general steady-state interaction or scrolling workload.

Process-lifetime peak RSS from the diagnostics-disabled startup batch:

| Font | Renderer | Master MiB | Patch MiB | Paired Δ MiB | Paired change (95% CI) |
| --- | --- | ---: | ---: | ---: | ---: |
| Vollkorn | WGPU/Metal | 274.812 | 275.789 | +0.375 | +0.14% [-0.15, +0.62] |
| Vollkorn | OpenGL | 250.016 | 250.820 | +0.148 | +0.06% [-0.20, +0.45] |
| Liberation Serif | WGPU/Metal | 275.617 | 274.602 | -0.555 | -0.20% [-0.50, +0.04] |
| Liberation Serif | OpenGL | 249.977 | 250.695 | -0.008 | -0.00% [-0.27, +0.71] |
| Arial | WGPU/Metal | 276.516 | 276.133 | -0.133 | -0.05% [-0.16, +0.34] |
| Arial | OpenGL | 251.133 | 251.078 | -0.414 | -0.16% [-0.80, +0.44] |
| Roboto Flex | WGPU/Metal | 278.758 | 277.867 | -0.812 | -0.29% [-0.74, +0.19] |
| Roboto Flex | OpenGL | 249.508 | 250.734 | +0.438 | +0.17% [+0.04, +0.81] |

Memory results have small mixed differences. Roboto/OpenGL is the one positive interval in this startup RSS matrix: paired +0.438 MiB, with a delta interval of [+0.102, +2.008] MiB. The separate CPU cohort instead has slightly lower Roboto/OpenGL RSS, so these data do not show a consistent memory increase across the two cohorts. This is a process-wide peak measurement, rather than direct cache allocation accounting. The 1 MiB logical outline-cache limit does not imply a 1 MiB process RSS limit.

All 384 timed launches are retained: four fonts × two backends × twelve master/patch pairs, separately for CPU and startup. There were no retries, excluded attempts, or duration-based outlier filtering. Measurements were collected on Apple M4 Max, macOS 26.6.2 arm64, with Rust/Cargo 1.96.0 release builds. Each launch was a fresh process; font/backend order rotated and adjacent version order alternated. The OS and Metal shader caches remained uncontrolled. The save is the 2,559,348-byte large fixture; the catalog and 95,719,946-byte raw 128px icon pack are fixed and hashed. The application renders a 2560×1600 physical window at DPR 2, with GPU warmup, eager shaders, and window animation disabled. System-font discovery is disabled for every font, including Arial, and each selected font file is explicitly registered through Slint's existing font-path mechanism. The bundled Inter fallback remains common.

An additional sixteen untimed screenshot launches validate every font/backend/version combination. All eight master/patch screenshot pairs have identical decoded RGBA pixels. The actual renderer font blobs are byte-for-byte the requested primary file plus the exact bundled Inter fallback, with face index zero; no unexpected face appears. Font replacements visibly change the application screenshots. These dumps and screenshots are excluded from timing. [Screenshot and actual-font evidence](pixels-font-validation/summary.json), [visual inspection record](visual-check.json), and [independent arithmetic/font-blob audit](analysis/independent-arithmetic-audit.json) retain the checks. Representative rendered images: [Vollkorn](pixels-font-validation/01-winit-femtovg-wgpu-vollkorn-attempt1-master/run-1.png), [Liberation Serif](pixels-font-validation/01-winit-femtovg-wgpu-liberation-attempt1-master/run-1.png), [Arial](pixels-font-validation/01-winit-femtovg-wgpu-arial-attempt1-master/run-1.png), [Roboto Flex](pixels-font-validation/01-winit-femtovg-wgpu-roboto-attempt1-master/run-1.png).

Every table uses twelve process pairs per row. Absolute columns are independent process medians; paired delta and percentage columns summarize within-round differences and ratios. Therefore, a paired percentage can differ in sign from the difference between the two absolute medians, as in noisy Liberation/WGPU startup. Confidence intervals use 10,000 bootstrap resamples of process pairs and are exploratory, with no adjustment for the many metrics/configurations. The analyzer revalidates raw reports and recomputes span aggregation; an independent audit recomputes 48 CPU/search/startup/RSS summaries and their intervals from all raw reports. [Full statistics](analysis/summary.json), [summary CSV](analysis/summary.csv), and [all paired values](analysis/pairs.csv) retain the unrounded values.

Changing the selected font changes glyph geometry, metrics, shaping, and potentially layout/reuse. This evaluates the effect of a real application's font choice; it does not isolate hint execution from those other font differences. It also does not compare hinting enabled versus disabled. Consequently, the results support font-dependent cache profitability without proving that hint-program size or any single table-presence test can predict the benefit. The same-font synthetic/demo comparison supplies the complementary environment.

[Reproduction instructions](README.md) give the exact build/runtime configuration and launch commands. The original application lock was restored after both builds; the resolved comparison lock is archived in `build/resolved.Cargo.lock`. Existing earlier benchmarks and their raw results remain preserved in their original directories. This report contains only the current patch-versus-master application font matrix collected on 2026-10-01.
