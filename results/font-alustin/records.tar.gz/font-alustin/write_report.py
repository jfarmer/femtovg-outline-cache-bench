#!/usr/bin/env python3
"""Render the completed Alustin font comparison from its validated statistics."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
analysis = json.loads((ROOT / "analysis/summary.json").read_text())
rows = {(row["mode"], row["backend"], row["font"], row["metric"]): row for row in analysis["results"]}
fonts = (("vollkorn", "Vollkorn"), ("liberation", "Liberation Serif"), ("arial", "Arial"), ("roboto", "Roboto Flex"))
backends = (("winit-femtovg-wgpu", "WGPU/Metal"), ("winit-femtovg", "OpenGL"))


def table(mode, metric, unit="ms", precision=3):
    lines = [f"| Font | Renderer | Master {unit} | Patch {unit} | Paired Δ {unit} | Paired change (95% CI) |",
             "| --- | --- | ---: | ---: | ---: | ---: |"]
    for font, family in fonts:
        for backend, renderer in backends:
            row = rows[mode, backend, font, metric]
            interval = row["median_paired_change_pct_ci95"]
            lines.append(f"| {family} | {renderer} | {row['master_median']:.{precision}f} | {row['patch_median']:.{precision}f} | "
                         f"{row['median_paired_delta']:+.{precision}f} | {row['median_paired_change_pct']:+.2f}% "
                         f"[{interval[0]:+.2f}, {interval[1]:+.2f}] |")
    return "\n".join(lines)


report = """The current outline-cache patch has a substantial first-frame CPU benefit in Alustin with Vollkorn, a smaller benefit with Arial, and little benefit with Liberation Serif or Roboto Flex. This font dependence appears within the same real application, with the same save, icons, UI, renderer configuration, and paired master/patch executables.

This comparison uses FemtoVG master `f57a2c39e9836c146556c58c98d80c5bf7899029` and patch `7a278ca4f947658d01c355c450edc6abcdbe3958`. Alustin is based on current main `ac35d4e0b5c52edb7defb9feccdadfd584635c14`, on branch `perf/femtovg-outline-master-compare`, with shared benchmark-only font selection and instrumentation. Both builds replace Alustin's vendored FemtoVG with exact upstream snapshots, so the earlier application-local cache is absent on both sides. The active FemtoVG features are `swash` and `wgpu`; both use Swash 0.2.10 and Swash's Skrifa 0.40.0. [Build provenance](build/provenance.json), [independent source/dependency audit](build/independent-audit.json), and [shared app diff](build/app-input.diff) record the complete inputs.

First-frame renderer thread CPU, measured in a separate diagnostics-enabled batch:

""" + table("cpu", "first_frame.render.thread_cpu_ms") + """

Vollkorn saves about 4.7–5.2 ms of paired first-frame renderer CPU. Arial saves about 0.7–0.9 ms. Liberation Serif's OpenGL reduction is small but its interval excludes zero; its WGPU interval includes zero. Roboto Flex's intervals include zero on both backends. Final-flush CPU intervals include zero for all eight configurations, consistent with the gain occurring before final flush.

Launch-to-observed-search readiness, measured in the separate diagnostics-disabled startup batch:

""" + table("startup", "observed_search_response_ms") + """

The Vollkorn startup signal is smaller and noisier than its renderer CPU benefit: OpenGL's interval excludes zero; WGPU's narrowly includes zero. All other fonts' startup intervals include zero. These values include application initialization, font registration, model loading, rendering, and report/IPC observation. They do not measure GPU completion or compositor scanout. The first-frame renderer result does not establish an equivalent reduction in total startup time.

Search-frame renderer thread CPU from the diagnostics-enabled batch:

""" + table("cpu", "search_frame.render.thread_cpu_ms") + """

Vollkorn's search frame saves about 0.18 ms on both backends. The other fonts have small mixed estimates: Roboto/OpenGL has an exploratory small reduction; the other intervals include zero. This experiment covers first display and one injected search response, rather than a general steady-state interaction or scrolling workload.

Process-lifetime peak RSS from the diagnostics-disabled startup batch:

""" + table("startup", "peak_rss_mib", "MiB") + """

Memory results have small mixed differences. Roboto/OpenGL is the one positive interval in this startup RSS matrix: paired +0.438 MiB, with a delta interval of [+0.102, +2.008] MiB. The separate CPU cohort instead has slightly lower Roboto/OpenGL RSS, so these data do not show a consistent memory increase across the two cohorts. This is a process-wide peak measurement, rather than direct cache allocation accounting. The 1 MiB logical outline-cache limit does not imply a 1 MiB process RSS limit.

All 384 timed launches are retained: four fonts × two backends × twelve master/patch pairs, separately for CPU and startup. There were no retries, excluded attempts, or duration-based outlier filtering. Measurements were collected on Apple M4 Max, macOS 26.6.2 arm64, with Rust/Cargo 1.96.0 release builds. Each launch was a fresh process; font/backend order rotated and adjacent version order alternated. The OS and Metal shader caches remained uncontrolled. The save is the 2,559,348-byte large fixture; the catalog and 95,719,946-byte raw 128px icon pack are fixed and hashed. The application renders a 2560×1600 physical window at DPR 2, with GPU warmup, eager shaders, and window animation disabled. System-font discovery is disabled for every font, including Arial, and each selected font file is explicitly registered through Slint's existing font-path mechanism. The bundled Inter fallback remains common.

An additional sixteen untimed screenshot launches validate every font/backend/version combination. All eight master/patch screenshot pairs have identical decoded RGBA pixels. The actual renderer font blobs are byte-for-byte the requested primary file plus the exact bundled Inter fallback, with face index zero; no unexpected face appears. Font replacements visibly change the application screenshots. These dumps and screenshots are excluded from timing. [Screenshot and actual-font evidence](pixels-font-validation/summary.json), [visual inspection record](visual-check.json), and [independent arithmetic/font-blob audit](analysis/independent-arithmetic-audit.json) retain the checks. Representative rendered images: [Vollkorn](pixels-font-validation/01-winit-femtovg-wgpu-vollkorn-attempt1-master/run-1.png), [Liberation Serif](pixels-font-validation/01-winit-femtovg-wgpu-liberation-attempt1-master/run-1.png), [Arial](pixels-font-validation/01-winit-femtovg-wgpu-arial-attempt1-master/run-1.png), [Roboto Flex](pixels-font-validation/01-winit-femtovg-wgpu-roboto-attempt1-master/run-1.png).

Every table uses twelve process pairs per row. Absolute columns are independent process medians; paired delta and percentage columns summarize within-round differences and ratios. Therefore, a paired percentage can differ in sign from the difference between the two absolute medians, as in noisy Liberation/WGPU startup. Confidence intervals use 10,000 bootstrap resamples of process pairs and are exploratory, with no adjustment for the many metrics/configurations. The analyzer revalidates raw reports and recomputes span aggregation; an independent audit recomputes 48 CPU/search/startup/RSS summaries and their intervals from all raw reports. [Full statistics](analysis/summary.json), [summary CSV](analysis/summary.csv), and [all paired values](analysis/pairs.csv) retain the unrounded values.

Changing the selected font changes glyph geometry, metrics, shaping, and potentially layout/reuse. This evaluates the effect of a real application's font choice; it does not isolate hint execution from those other font differences. It also does not compare hinting enabled versus disabled. Consequently, the results support font-dependent cache profitability without proving that hint-program size or any single table-presence test can predict the benefit. The same-font synthetic/demo comparison supplies the complementary environment.

[Reproduction instructions](README.md) give the exact build/runtime configuration and launch commands. The original application lock was restored after both builds; the resolved comparison lock is archived in `build/resolved.Cargo.lock`. Existing earlier benchmarks and their raw results remain preserved in their original directories. This report contains only the current patch-versus-master application font matrix collected on 2026-10-01.
"""
(ROOT / "REPORT.md").write_text(report)
print(f"Wrote {ROOT / 'REPORT.md'}")
