#!/usr/bin/env python3
"""Add a feature-gated font choice for the paired Alustin cache experiment.

This edits benchmark-only host wiring and a default-preserving UI property.
It does not build or launch the app. Run on the existing benchmark branch.
"""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/Users/jesse/github/alustin-gui-v2')
HERE = Path(__file__).resolve().parent

def replace_once(path, old, new):
    text = path.read_text()
    if new in text:
        return
    if text.count(old) != 1:
        raise RuntimeError(f'expected one insertion point: {path}')
    path.write_text(text.replace(old, new, 1))

branch = subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip()
if branch != 'perf/femtovg-outline-master-compare':
    raise RuntimeError(f'unexpected branch {branch!r}')

replace_once(ROOT / 'crates/alustin-gui/ui/forge.slint',
    '    default-font-family: "Vollkorn";',
    '    // Host override is used only by the font/cache benchmark.\n'
    '    in property <string> benchmark-font-family: "Vollkorn";\n'
    '    default-font-family: root.benchmark-font-family;')

replace_once(ROOT / 'crates/alustin-gui/src/main.rs',
    '    let ui = trace.measure("window_created", ForgeWindow::new)?;\n'
    '    trace.install(&ui, args.startup_probe, args.startup_observe_presentation)?;',
    '    let ui = trace.measure("window_created", ForgeWindow::new)?;\n'
    '    #[cfg(feature = "femtovg-benchmark")]\n'
    '    if let Ok(family) = std::env::var("ALUSTIN_BENCH_FONT_FAMILY") {\n'
    '        let font_path = std::env::var("SLINT_FONT_PATH")?;\n'
    '        ui.set_benchmark_font_family(family.as_str().into());\n'
    '        trace.event("benchmark_font_configured", || {\n'
    '            json!({"family": ui.get_benchmark_font_family().as_str(), "font_path": font_path})\n'
    '        });\n'
    '    }\n'
    '    trace.install(&ui, args.startup_probe, args.startup_observe_presentation)?;')

# Archive the prior experiment's resolved override lock, then restore the app's
# original vendored dependency lock. The builder archives its own override lock
# and restores the original afterward. Refuse to overwrite an unrelated edit.
lock = ROOT / 'Cargo.lock'
current = lock.read_bytes()
original = subprocess.check_output(['git', 'show', 'HEAD:Cargo.lock'], cwd=ROOT)
expected_previous = '5f3ac225f41ca3e189ef63d5a5035bf9bddcc0c0c821a965a5801eab7e26fb24'
if current != original:
    if hashlib.sha256(current).hexdigest() != expected_previous:
        raise RuntimeError('Cargo.lock has an unrelated edit; leaving it untouched')
    (HERE / 'previous-experiment-resolved.Cargo.lock').write_bytes(current)
    lock.write_bytes(original)

(HERE / 'font-configuration.json').write_text(json.dumps({
    'branch': branch, 'selection': 'Existing SLINT_FONT_PATH registration plus root family binding',
    'runtime_registration': 'All four font factors explicitly register their selected file, including embedded Vollkorn',
    'fallback': 'Bundled Inter remains available; all four selected faces lack U+2713',
    'primary_event': 'benchmark_font_configured records the requested binding; untimed actual-face validation is separate',
}, indent=2) + '\n')
print('Prepared the default-preserving font override; restored the original app lock.')
