"""Exercise validation and pair retry with fake reports; never execute an app."""

import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
spec = importlib.util.spec_from_file_location("font_pair_runner", HERE / "run.py")
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


def fixture(root):
    root.mkdir(exist_ok=True)
    for name in ("master-app", "patch-app", "harness", "font.ttf", "save", "catalog", "icons"):
        (root / name).write_text(name)


def exercise(root, contaminated_calls=(), wrong_family=False):
    fixture(root)
    calls = []

    def fake_run(command, **kwargs):
        def value(flag):
            return command[command.index(flag) + 1]

        destination = Path(value("--output"))
        destination.mkdir()
        calls.append(command)
        query = "ar" if len(calls) in contaminated_calls else "a"
        sample = {
            "executable_path": value("--binary"), "backend_requested": value("--backend"),
            "system_fonts_disabled": True, "launch_to_probe_observed_ms": 10.0,
            "spawn_to_main_ms": 1.0, "peak_rss_bytes": 1024,
            "events": [
                {"event": "benchmark_font_configured", "since_main_ms": 1.0,
                 "details": {"family": "Wrong" if wrong_family else "Arial", "font_path": value("--font-path")}},
                {"event": "renderer_setup", "since_main_ms": 2.0, "details": {"graphics_api": "OpenGL"}},
                {"event": "first_render_started", "since_main_ms": 3.0, "details": {}},
                {"event": "first_frame_rendered", "since_main_ms": 5.0,
                 "details": {"physical_width": 2560, "physical_height": 1600, "scale_factor": 2.0}},
                {"event": "interactive_frame_rendered", "since_main_ms": 7.0, "details": {"query": query}},
            ],
        }
        report = {"samples": [sample], "system_fonts_disabled": True, "font_path": value("--font-path")}
        (destination / "summary.json").write_text(json.dumps(report))
        return SimpleNamespace(returncode=0)

    original_subprocess, original_head, original_argv = runner.subprocess, runner.git_head, sys.argv
    runner.subprocess = SimpleNamespace(run=fake_run)
    runner.git_head = lambda root: "test-only-no-git-process"
    sys.argv = [str(HERE / "run.py"), "startup", "--root", str(root), "--harness", str(root / "harness"),
                "--master", str(root / "master-app"), "--patch", str(root / "patch-app"),
                "--font", "arial", "Arial", str(root / "font.ttf"), "--save", str(root / "save"),
                "--catalog", str(root / "catalog"), "--icon-pack", str(root / "icons"),
                "--fonts", "arial", "--backends", "winit-femtovg", "--rounds", "1", "--output", str(root / "results")]
    error = None
    try:
        runner.main()
    except (ValueError, RuntimeError) as caught:
        error = caught
    finally:
        runner.subprocess, runner.git_head, sys.argv = original_subprocess, original_head, original_argv
    report_path = root / "results/summary.json"
    if not report_path.exists():
        raise AssertionError(f"Fixture failed before checkpoint: {error!r}")
    result = json.loads(report_path.read_text())
    return calls, result, error


def main():
    import uuid
    root = HERE / f"smoke-fixtures-{uuid.uuid4().hex[:8]}"
    root.mkdir(exist_ok=False)
    calls, result, error = exercise(root / "retry", contaminated_calls={1})
    assert error is None and result["complete"] is True
    assert len(calls) == 4 and len(result["launches"]) == 4
    assert [row["version"] for row in result["launches"]] == ["master", "patch", "patch", "master"]
    assert [row["included"] for row in result["launches"]] == [False, False, True, True]
    assert [row["validated"] for row in result["launches"]] == [False, True, True, True]
    assert result["accepted_pairs"][0]["attempt"] == 2
    assert all("exclusion_reason" in row for row in result["launches"][:2])
    calls, result, error = exercise(root / "bounded", contaminated_calls=set(range(1, 7)))
    assert isinstance(error, RuntimeError) and len(calls) == 6
    assert result["complete"] is False and result["accepted_pairs"] == []
    assert all(row["included"] is False for row in result["launches"])
    calls, result, error = exercise(root / "structural", wrong_family=True)
    assert isinstance(error, ValueError) and len(calls) == 1
    assert result["complete"] is False and "font event family" in result["launches"][0]["validation_error"]
    print("Retry, bounded exhaustion, pair retention, and structural-abort checks passed; only fake subprocess reports used.")


if __name__ == "__main__":
    main()
