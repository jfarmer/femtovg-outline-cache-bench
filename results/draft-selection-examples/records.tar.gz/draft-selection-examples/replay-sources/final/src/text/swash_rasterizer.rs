use std::{
    cell::RefCell,
    mem::{size_of, size_of_val},
    ops::Range,
    rc::Rc,
};

use fnv::FnvHashMap;
use swash::{
    scale::{
        image::{Content, Image},
        outline::Outline,
        Render, ScaleContext, Scaler, Source, StrikeWith,
    },
    zeno::{Format, Mask, Origin, Point, Scratch, Vector, Verb},
    CacheKey, FontRef,
};

const COLOR_SOURCES: [Source; 2] = [Source::ColorOutline(0), Source::ColorBitmap(StrikeWith::BestFit)];
const OUTLINE_CACHE_BUDGET: usize = 1 << 20;

#[derive(Debug, Hash, PartialEq, Eq)]
struct OutlineKey {
    font: CacheKey,
    glyph_id: u16,
    font_size: u32,
    normalized_coords: Box<[i16]>,
}

struct CachedPath {
    points: Range<usize>,
    verbs: Range<usize>,
}

/// Renders glyphs using Swash, retaining eager hinted geometry in compact arenas.
pub(crate) struct SwashRasterizer {
    scale_context: Rc<RefCell<ScaleContext>>,
    scratch: Scratch,
    scaled_outline: Outline,
    outlines: FnvHashMap<OutlineKey, CachedPath>,
    points: Vec<Point>,
    verbs: Vec<Verb>,
    metadata_bytes: usize,
    outline_bytes: usize,
    outline_budget: usize,
    scratch_points_capacity_estimate: usize,
    scratch_verbs_capacity_estimate: usize,
    scratch_layers_capacity_estimate: usize,
    scratch_peak_estimate: usize,
}

impl SwashRasterizer {
    pub(crate) fn new(scale_context: Rc<RefCell<ScaleContext>>) -> Self {
        Self::with_outline_budget(scale_context, OUTLINE_CACHE_BUDGET)
    }

    fn with_outline_budget(scale_context: Rc<RefCell<ScaleContext>>, outline_budget: usize) -> Self {
        Self {
            scale_context,
            scratch: Scratch::new(),
            scaled_outline: Outline::new(),
            outlines: FnvHashMap::default(),
            points: Vec::new(),
            verbs: Vec::new(),
            metadata_bytes: 0,
            outline_bytes: 0,
            outline_budget,
            scratch_points_capacity_estimate: 0,
            scratch_verbs_capacity_estimate: 0,
            scratch_layers_capacity_estimate: 0,
            scratch_peak_estimate: 0,
        }
    }

    pub(crate) fn scale_context(&self) -> Rc<RefCell<ScaleContext>> {
        Rc::clone(&self.scale_context)
    }

    /// Returns an alpha/color image, eagerly retaining every outline that fits.
    pub(crate) fn render(
        &mut self,
        font: FontRef<'_>,
        font_size: f32,
        glyph_id: u16,
        subpixel_x: f32,
        normalized_coords: &[i16],
    ) -> Option<Image> {
        let key = OutlineKey {
            font: font.key,
            glyph_id,
            font_size: font_size.to_bits(),
            normalized_coords: normalized_coords.into(),
        };
        if let Some(path) = self.outlines.get(&key) {
            return Some(rasterize_path(
                &self.points[path.points.clone()],
                &self.verbs[path.verbs.clone()],
                &mut self.scratch,
                subpixel_x,
            ));
        }
        let context = Rc::clone(&self.scale_context);
        let mut context_borrow = context.borrow_mut();
        let mut scaler = context_borrow
            .builder(font)
            .size(font_size)
            .hint(true)
            .normalized_coords(normalized_coords)
            .build();
        self.render_miss(key, glyph_id, subpixel_x, &mut scaler)
    }

    /// Reuses the native run scaler only when the eager arena cache misses.
    pub(crate) fn render_with_scaler<'borrow, 'context: 'borrow>(
        &mut self,
        font: FontRef<'_>,
        font_size: f32,
        glyph_id: u16,
        subpixel_x: f32,
        normalized_coords: &[i16],
        make_scaler: impl FnOnce() -> &'borrow mut Scaler<'context>,
    ) -> Option<Image> {
        let key = OutlineKey {
            font: font.key,
            glyph_id,
            font_size: font_size.to_bits(),
            normalized_coords: normalized_coords.into(),
        };
        if let Some(path) = self.outlines.get(&key) {
            return Some(rasterize_path(
                &self.points[path.points.clone()],
                &self.verbs[path.verbs.clone()],
                &mut self.scratch,
                subpixel_x,
            ));
        }
        self.render_miss(key, glyph_id, subpixel_x, make_scaler())
    }

    fn render_miss(
        &mut self,
        key: OutlineKey,
        glyph_id: u16,
        subpixel_x: f32,
        scaler: &mut Scaler<'_>,
    ) -> Option<Image> {
        if let Some(image) = Render::new(&COLOR_SOURCES)
            .format(Format::Alpha)
            .offset(Vector::new(subpixel_x, 0.0))
            .render(scaler, glyph_id)
        {
            return Some(image);
        }
        if !scaler.has_outlines() {
            return None;
        }
        let success = scaler.scale_outline_into(glyph_id, &mut self.scaled_outline);
        // Include failed draws too: a failed pen can already have grown buffers.
        self.observe_scratch_capacity_estimate();
        if !success {
            self.enforce_retained_budget();
            return None;
        }
        let image = rasterize_path(
            self.scaled_outline.points(),
            self.scaled_outline.verbs(),
            &mut self.scratch,
            subpixel_x,
        );
        self.insert_scaled_outline(key);
        self.enforce_retained_budget();
        Some(image)
    }

    // Swash does not expose Outline Vec capacities. Its pinned 0.2.10 source
    // pushes points, verbs and layers individually from empty Vecs and never
    // shrinks them. Charge next-power-of-two high-water bounds with RawVec's
    // minimum capacities, plus a conservative 64 bytes per private layer.
    // These scratch capacities are estimates; arena capacities below are exact.
    fn observe_scratch_capacity_estimate(&mut self) {
        fn capacity_bound(len: usize, minimum: usize) -> usize {
            if len == 0 {
                0
            } else {
                len.max(minimum).next_power_of_two()
            }
        }
        self.scratch_points_capacity_estimate = self
            .scratch_points_capacity_estimate
            .max(capacity_bound(self.scaled_outline.points().len(), 4));
        self.scratch_verbs_capacity_estimate = self
            .scratch_verbs_capacity_estimate
            .max(capacity_bound(self.scaled_outline.verbs().len(), 8));
        self.scratch_layers_capacity_estimate = self
            .scratch_layers_capacity_estimate
            .max(capacity_bound(self.scaled_outline.len(), 4));
        self.scratch_peak_estimate = self.scratch_peak_estimate.max(self.scratch_bytes_estimate());
        self.refresh_bytes();
    }

    fn scratch_bytes_estimate(&self) -> usize {
        size_of::<Outline>()
            + self.scratch_points_capacity_estimate * size_of::<Point>()
            + self.scratch_verbs_capacity_estimate * size_of::<Verb>()
            + self.scratch_layers_capacity_estimate * 64
    }

    fn refresh_bytes(&mut self) {
        self.outline_bytes = self.metadata_bytes
            + self.points.capacity() * size_of::<Point>()
            + self.verbs.capacity() * size_of::<Verb>()
            + self.scratch_bytes_estimate();
    }

    fn clear_cached_paths(&mut self) {
        self.outlines.clear();
        self.points.clear();
        self.verbs.clear();
        self.metadata_bytes = 0;
        self.refresh_bytes();
    }

    fn enforce_retained_budget(&mut self) {
        self.refresh_bytes();
        if self.outline_bytes > self.outline_budget {
            self.clear_cached_paths();
        }
        if self.outline_bytes > self.outline_budget {
            // An oversized glyph may use temporary working memory, but must
            // not make the retained scratch high-water state unbounded.
            self.scaled_outline = Outline::new();
            self.scratch_points_capacity_estimate = 0;
            self.scratch_verbs_capacity_estimate = 0;
            self.scratch_layers_capacity_estimate = 0;
            self.refresh_bytes();
        }
    }

    fn insert_scaled_outline(&mut self, key: OutlineKey) {
        let metadata = size_of::<OutlineKey>() + size_of::<CachedPath>() + size_of_val(&*key.normalized_coords);
        let points_len = self.scaled_outline.points().len();
        let verbs_len = self.scaled_outline.verbs().len();
        let scratch_bytes = self.scratch_bytes_estimate();
        let budget = self.outline_budget;
        let fits = |point_capacity: usize, verb_capacity: usize, metadata_bytes: usize| {
            metadata_bytes + point_capacity * size_of::<Point>() + verb_capacity * size_of::<Verb>() + scratch_bytes
                <= budget
        };
        if !fits(points_len, verbs_len, metadata) {
            return;
        }
        fn grow(capacity: usize, required: usize) -> usize {
            if required <= capacity {
                capacity
            } else {
                required.max(capacity.saturating_mul(2)).max(8)
            }
        }
        let mut point_capacity = grow(self.points.capacity(), self.points.len() + points_len);
        let mut verb_capacity = grow(self.verbs.capacity(), self.verbs.len() + verbs_len);
        if !fits(point_capacity, verb_capacity, self.metadata_bytes + metadata) {
            self.clear_cached_paths();
            point_capacity = grow(self.points.capacity(), points_len);
            verb_capacity = grow(self.verbs.capacity(), verbs_len);
            // Near the capacity ceiling, an exact growth may fit when a
            // doubling does not. Geometry remains eagerly admitted.
            if !fits(point_capacity, verb_capacity, metadata) {
                point_capacity = self.points.capacity().max(points_len);
                verb_capacity = self.verbs.capacity().max(verbs_len);
            }
            if !fits(point_capacity, verb_capacity, metadata) {
                return;
            }
        }
        if point_capacity > self.points.capacity() {
            self.points.reserve_exact(point_capacity - self.points.len());
        }
        if verb_capacity > self.verbs.capacity() {
            self.verbs.reserve_exact(verb_capacity - self.verbs.len());
        }
        let points_start = self.points.len();
        let verbs_start = self.verbs.len();
        self.points.extend_from_slice(self.scaled_outline.points());
        self.verbs.extend_from_slice(self.scaled_outline.verbs());
        self.outlines.insert(
            key,
            CachedPath {
                points: points_start..self.points.len(),
                verbs: verbs_start..self.verbs.len(),
            },
        );
        self.metadata_bytes += metadata;
        self.refresh_bytes();
    }
}

fn rasterize_path(points: &[Point], verbs: &[Verb], scratch: &mut Scratch, subpixel_x: f32) -> Image {
    let offset = Vector::new(subpixel_x, 0.0);
    let mut image = Image::new();
    image.placement = Mask::with_scratch((points, verbs), scratch)
        .format(Format::Alpha)
        .origin(Origin::BottomLeft)
        .offset(offset)
        .render_offset(offset)
        .inspect(|format, width, height| image.data.resize(format.buffer_size(width, height), 0))
        .render_into(&mut image.data[..], None);
    image.content = Content::Mask;
    image.source = Source::Outline;
    image
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn run_scaler_matches_native_render_for_outlines_color_invalid_and_variations() {
        for face in faces() {
            let font = FontRef::from_index(&face.data, 0).unwrap();
            for coords in &face.instances {
                for size in [9.0, 16.5, 40.0] {
                    let mut rasterizer = rasterizer();
                    let context = rasterizer.scale_context();
                    let mut reference = ScaleContext::new();
                    for offset in subpixel_offsets() {
                        let mut context_borrow = context.borrow_mut();
                        let mut context_ref = Some(&mut *context_borrow);
                        let mut scaler = None;
                        let mut setups = 0;
                        for glyph_id in face.glyph_ids.clone() {
                            let actual = rasterizer.render_with_scaler(font, size, glyph_id, offset, coords, || {
                                scaler.get_or_insert_with(|| {
                                    setups += 1;
                                    context_ref
                                        .take()
                                        .unwrap()
                                        .builder(font)
                                        .size(size)
                                        .hint(true)
                                        .normalized_coords(coords)
                                        .build()
                                })
                            });
                            let expected = render_uncached(&mut reference, font, size, glyph_id, offset, coords);
                            assert_same_image(
                                actual.as_ref(),
                                expected.as_ref(),
                                &format!("{} {coords:?} {size} glyph {glyph_id} phase {offset}", face.name),
                            );
                        }
                        assert!(setups <= 1, "one setup per run segment");
                    }
                }
            }
        }
    }

    #[test]
    fn run_scaler_is_lazy_and_second_phase_hits_never_request_it() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let mut rasterizer = rasterizer();
        let context = rasterizer.scale_context();
        let glyph_ids = ['A', 'g', 'W'].map(|ch| font.charmap().map(ch));
        {
            let mut context_borrow = context.borrow_mut();
            let mut context_ref = Some(&mut *context_borrow);
            let mut scaler = None;
            let mut setups = 0;
            for glyph_id in glyph_ids {
                rasterizer
                    .render_with_scaler(font, 24.0, glyph_id, 0.0, &[], || {
                        scaler.get_or_insert_with(|| {
                            setups += 1;
                            context_ref.take().unwrap().builder(font).size(24.0).hint(true).build()
                        })
                    })
                    .unwrap();
            }
            assert_eq!(setups, 1);
        }
        for glyph_id in glyph_ids {
            rasterizer
                .render_with_scaler(font, 24.0, glyph_id, 0.3, &[], || {
                    panic!("a cached outline must not request the run scaler")
                })
                .unwrap();
        }
    }

    fn read_font(file: &str) -> Vec<u8> {
        let path = format!("{}/examples/assets/{file}", env!("CARGO_MANIFEST_DIR"));
        std::fs::read(&path).unwrap_or_else(|err| panic!("{path}: {err}"))
    }

    /// The offsets `GlyphAtlas::render_atlas` passes: the fractional part of a
    /// glyph's position, quantized to tenths.
    fn subpixel_offsets() -> impl Iterator<Item = f32> {
        (-9..=10).map(|tenths| tenths as f32 / 10.0)
    }

    /// Renders through swash's `Render` alone, with no outline cache: the
    /// reference `SwashRasterizer::render` must match.
    fn render_uncached(
        context: &mut ScaleContext,
        font: FontRef<'_>,
        font_size: f32,
        glyph_id: u16,
        subpixel_x: f32,
        normalized_coords: &[i16],
    ) -> Option<Image> {
        let mut scaler = context
            .builder(font)
            .size(font_size)
            .hint(true)
            .normalized_coords(normalized_coords)
            .build();
        Render::new(&[
            Source::ColorOutline(0),
            Source::ColorBitmap(StrikeWith::BestFit),
            Source::Outline,
        ])
        .format(Format::Alpha)
        .offset(Vector::new(subpixel_x, 0.0))
        .render(&mut scaler, glyph_id)
    }

    fn placement(image: &Image) -> (i32, i32, u32, u32) {
        let p = image.placement;
        (p.left, p.top, p.width, p.height)
    }

    fn rasterizer() -> SwashRasterizer {
        SwashRasterizer::new(Rc::default())
    }

    fn assert_same_image(actual: Option<&Image>, expected: Option<&Image>, case: &str) {
        let (actual, expected) = match (actual, expected) {
            (Some(actual), Some(expected)) => (actual, expected),
            (None, None) => return,
            (actual, expected) => panic!("{case}: rendered {}, expected {}", actual.is_some(), expected.is_some()),
        };
        assert_eq!(placement(actual), placement(expected), "{case}: placement");
        assert_eq!(actual.content, expected.content, "{case}: content");
        assert_eq!(
            format!("{:?}", actual.source),
            format!("{:?}", expected.source),
            "{case}: source"
        );
        assert!(actual.data == expected.data, "{case}: coverage differs");
    }

    struct Face {
        name: &'static str,
        data: Vec<u8>,
        glyph_ids: std::ops::Range<u16>,
        /// Normalized coordinates to render at; the face's default instance is empty.
        instances: Vec<Vec<i16>>,
    }

    fn faces() -> Vec<Face> {
        let roboto = read_font("RobotoFlex-VariableFont.ttf");
        let axis_count = FontRef::from_index(&roboto, 0).unwrap().variations().len();
        // F2Dot14: halfway along the first axis, a quarter back along the last.
        let mut roboto_instance = vec![0; axis_count];
        roboto_instance[0] = 0x2000;
        roboto_instance[axis_count - 1] = -0x1000;

        vec![
            Face {
                name: "Roboto Flex",
                data: roboto,
                glyph_ids: 0..80,
                instances: vec![Vec::new(), roboto_instance],
            },
            Face {
                name: "Amiri",
                data: read_font("amiri-regular.ttf"),
                glyph_ids: 0..80,
                instances: vec![Vec::new()],
            },
            Face {
                name: "Entypo",
                data: read_font("entypo.ttf"),
                glyph_ids: 0..40,
                instances: vec![Vec::new()],
            },
            Face {
                name: "Bungee Color subset",
                data: read_font("BungeeColor-Subset.ttf"),
                // Glyph 9 is past the last glyph, 8.
                glyph_ids: 0..10,
                instances: vec![Vec::new()],
            },
        ]
    }

    // One rasterizer serves every face, instance and size, so an outline cached
    // under a key that left out the face, the size or the coordinates, or that
    // rounded the size, would be reused for another glyph and fail the
    // comparison.
    #[test]
    fn renders_like_swash_render_at_every_subpixel_offset() {
        let faces = faces();
        let mut rasterizer = rasterizer();
        let mut context = ScaleContext::new();

        for face in &faces {
            let font = FontRef::from_index(&face.data, 0).unwrap();
            for coords in &face.instances {
                for font_size in [9.0, 12.0, 16.1, 16.5, 16.9, 40.0] {
                    for glyph_id in face.glyph_ids.clone() {
                        for subpixel_x in subpixel_offsets() {
                            let actual = rasterizer.render(font, font_size, glyph_id, subpixel_x, coords);
                            let expected = render_uncached(&mut context, font, font_size, glyph_id, subpixel_x, coords);
                            let case = format!(
                                "{} {coords:?} glyph {glyph_id} at {font_size}px, offset {subpixel_x}",
                                face.name
                            );
                            assert_same_image(actual.as_ref(), expected.as_ref(), &case);
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn color_glyphs_render_from_color_sources_and_are_not_cached() {
        // BungeeColor-Subset.ttf is Bungee Color Regular, Version 1.000, from
        // google/fonts ofl/bungeecolor, SHA-256
        // cf21a786e54f43694f4edbb51a38f81331a4c3414217c524c8cb2d091aa7fd63,
        // subset with fontTools 4.59.1:
        //   pyftsubset BungeeColor-Regular.ttf --unicodes=U+0020,U+0041 \
        //     --layout-features='' --drop-tables+=DSIG,GSUB,GPOS --name-IDs='*'
        // Glyph 2 is A, whose COLR layers are glyphs 7 and 8.
        const COLOR_A: u16 = 2;
        const LAYER_OF_A: u16 = 7;

        let data = read_font("BungeeColor-Subset.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let mut rasterizer = rasterizer();

        let color = rasterizer.render(font, 24.0, COLOR_A, 0.3, &[]).unwrap();
        assert_eq!(color.content, Content::Color);
        assert!(matches!(color.source, Source::ColorOutline(0)));
        assert!(rasterizer.outlines.is_empty());

        // A layer glyph has no color layers of its own, so even in a color
        // face it renders from, and caches, its plain outline.
        let layer = rasterizer.render(font, 24.0, LAYER_OF_A, 0.3, &[]).unwrap();
        assert_eq!(layer.content, Content::Mask);
        assert!(matches!(layer.source, Source::Outline));
        assert_eq!(rasterizer.outlines.len(), 1);
    }

    #[test]
    fn subpixel_offsets_reuse_the_cached_outline() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let glyph_id = font.charmap().map('g');
        let mut rasterizer = rasterizer();

        let first = rasterizer.render(font, 16.0, glyph_id, 0.0, &[]).unwrap();
        assert!(first.data.iter().any(|&coverage| coverage > 0));

        // Swap the cached outline for an empty one: renders at every offset must
        // then cover nothing, which they only do if they skip hinting.
        assert_eq!(rasterizer.outlines.len(), 1);
        for cached in rasterizer.outlines.values_mut() {
            cached.points = 0..0;
            cached.verbs = 0..0;
        }

        for subpixel_x in subpixel_offsets() {
            let image = rasterizer.render(font, 16.0, glyph_id, subpixel_x, &[]).unwrap();
            assert!(image.data.iter().all(|&coverage| coverage == 0), "offset {subpixel_x}");
        }
    }

    #[test]
    fn arena_and_scratch_capacity_are_charged_and_reused_after_clears() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let mut rasterizer = SwashRasterizer::with_outline_budget(Rc::default(), 4096);
        let mut context = ScaleContext::new();
        let mut cleared = false;
        let mut prior_entries = 0;
        for (i, ch) in ('!'..='~').cycle().take(400).enumerate() {
            let glyph = font.charmap().map(ch);
            let size = 16.0 + (i / 94) as f32;
            let actual = rasterizer.render(font, size, glyph, 0.3, &[]);
            let expected = render_uncached(&mut context, font, size, glyph, 0.3, &[]);
            assert_same_image(actual.as_ref(), expected.as_ref(), "bounded arena churn");
            assert!(rasterizer.outline_bytes <= 4096);
            assert_eq!(
                rasterizer.outline_bytes,
                rasterizer.metadata_bytes
                    + rasterizer.points.capacity() * size_of::<Point>()
                    + rasterizer.verbs.capacity() * size_of::<Verb>()
                    + rasterizer.scratch_bytes_estimate()
            );
            cleared |= rasterizer.outlines.len() < prior_entries;
            prior_entries = rasterizer.outlines.len();
        }
        assert!(cleared);
        assert!(rasterizer.scratch_peak_estimate > size_of::<Outline>());
    }

    #[test]
    fn empty_outlines_still_charge_metadata_and_coordinates() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let space = font.charmap().map(' ');
        let mut coords = vec![0; font.variations().len()];
        let mut rasterizer = SwashRasterizer::with_outline_budget(Rc::default(), 1024);
        for first_axis in 0..20 {
            coords[0] = first_axis * 0x100;
            rasterizer.render(font, 16.0, space, 0.0, &coords);
            assert!(rasterizer.outline_bytes <= 1024);
            assert_eq!(
                rasterizer.metadata_bytes,
                rasterizer.outlines.len()
                    * (size_of::<OutlineKey>() + size_of::<CachedPath>() + size_of_val(&coords[..]))
            );
        }
    }

    #[test]
    fn outlines_larger_than_the_budget_are_not_cached() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let glyph_id = font.charmap().map('g');

        let mut rasterizer = SwashRasterizer::with_outline_budget(Rc::default(), 1);
        let image = rasterizer.render(font, 16.0, glyph_id, 0.0, &[]).unwrap();
        assert!(image.placement.width > 0);
        assert!(rasterizer.outlines.is_empty());
        assert!(rasterizer.outline_bytes <= size_of::<Outline>());
        assert!(rasterizer.scaled_outline.points().is_empty());
    }
}
