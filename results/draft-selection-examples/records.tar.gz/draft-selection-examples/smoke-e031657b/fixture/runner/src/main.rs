synthetic fixture; no Rust is compiled
