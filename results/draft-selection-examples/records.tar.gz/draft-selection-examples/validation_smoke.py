#!/usr/bin/env python3
"""Validate driver/statistics using labelled fake data; no benchmark launches."""
import csv
import io
import json
from pathlib import Path
import statistics
import tempfile

import run
import summarize


def main():
    assert sum(len(phases) for phases in run.PHASES.values()) == 28
    # Williams orders balance each version's position and each directed adjacency.
    assert all(sorted(order) == list(range(len(run.VERSIONS))) for order in run.ORDER)
    assert all({order[position] for order in run.ORDER} == set(range(len(run.VERSIONS))) for position in range(len(run.VERSIONS)))
    adjacencies = [(row[i],row[i+1]) for row in run.ORDER for i in range(len(run.VERSIONS)-1)]
    assert len(set(adjacencies)) == len(run.VERSIONS)*(len(run.VERSIONS)-1)
    factors={v:1.0-i*.05 for i,v in enumerate(run.VERSIONS)}
    rows=[]
    raw={}
    for block in range(1,4):
        raw[block]={}
        for version in run.VERSIONS:
            stream=io.StringIO()
            writer=csv.DictWriter(stream,fieldnames=run.CSV_FIELDS)
            writer.writeheader()
            for trial in range(2):
                for scene,phases in run.PHASES.items():
                    for phase,frames in phases.items():
                        duration=(100+block+trial)*factors[version]
                        row={'scene':scene,'phase':phase,'trial':trial,'frames':frames,
                             'draw_us':duration,'submit_us':duration+2,'complete_us':duration+5,
                             'new_atlas_entries':94*frames if scene.startswith('grid_') else frames}
                        writer.writerow(row)
            parsed=run.parse_rows(stream.getvalue(),2)
            raw[block][version]=parsed
            rows.extend({'backend':'cpu','font':'stock','dpi':'2','block':str(block),'version':version,**row} for row in parsed)
        run.validate_block(raw[block])
    first=[row for row in rows if row['scene']=='grid_singleton']
    indices=[[0,1,2],[2,2,0],[1,1,1]]
    for reference,candidate in summarize.COMPARISONS:
        result=summarize.metric_summary(first,'draw_us',reference,candidate,3,2,3,indices)
        expected=100*(factors[candidate]/factors[reference]-1)
        assert abs(result['paired_delta_pct']-expected)<1e-10
        assert all(abs(bound-expected)<1e-10 for bound in result['paired_bootstrap95'])
    # Invalid atlas counts must be rejected, even when timing rows look valid.
    stream=io.StringIO()
    writer=csv.DictWriter(stream,fieldnames=run.CSV_FIELDS)
    writer.writeheader()
    invalid=[dict(row) for row in raw[1]['master']]
    target=next(row for row in invalid if row['scene']=='grid_two_phases')
    target['new_atlas_entries']='0'
    writer.writerows(invalid)
    try:
        run.parse_rows(stream.getvalue(),2)
    except ValueError:
        pass
    else:
        raise AssertionError('controlled atlas-hit contamination accepted')
    # The summary loader must compare aggregate CSV against every retained raw
    # stdout; corrupting aggregate timings cannot silently change the result.
    with tempfile.TemporaryDirectory(prefix='statistics-fixture-',dir=Path(__file__).resolve().parent) as directory:
        root=Path(directory)
        launches=[]
        for block,versions in raw.items():
            for version,data in versions.items():
                stdout=root/f'{block}-{version}.csv'
                with stdout.open('w',newline='') as stream:
                    writer=csv.DictWriter(stream,fieldnames=run.CSV_FIELDS)
                    writer.writeheader();writer.writerows(data)
                launches.append({'block':block,'font':'stock','dpi':2,'version':version,
                                 'stdout':str(stdout),'rows':len(data),'validated':True,'exit_code':0})
        metadata={'complete':True,'versions':list(run.VERSIONS),'blocks':3,'fonts':['stock'],'dpis':[2],
                  'trials_per_process':2,'launches':launches}
        (root/'cpu-provenance.json').write_text(json.dumps(metadata))
        def write_rows():
            with (root/'cpu-results.csv').open('w',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=run.RESULT_FIELDS)
                writer.writeheader();writer.writerows(rows)
        write_rows()
        loaded,accepted=summarize.read_mode(root,'cpu')
        assert len(accepted)==3*len(run.VERSIONS)*2*28
        rows[0]['draw_us']='1.0'
        write_rows()
        try:
            summarize.read_mode(root,'cpu')
        except ValueError:
            pass
        else:
            raise AssertionError('corrupted aggregate CSV accepted')
    print('Passed: balanced orders, 28-phase parsing, known reference-comparison effects, atlas-hit rejection, raw/aggregate consistency. No benchmark or GPU executed.')


if __name__=='__main__':
    main()
