#!/usr/bin/env python3
"""Read-only guards for exact relocated, previously compiled selection inputs."""
from pathlib import Path
import argparse,hashlib,json,subprocess

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def files(root): return {str(p.relative_to(root)):sha(p) for p in sorted(Path(root).rglob('*')) if p.is_file()}
def require(condition,message):
    if not condition: raise ValueError('Selection reuse guard: '+message)
def exact_files(root,expected):
    require(files(root)==expected,'source/files changed: '+str(root))
def exact_sha(path,expected):require(sha(path)==expected,'artifact changed: '+str(path))
def toolchain(data):
    rustc=data.get('compiler',data.get('rustc'))
    require(subprocess.check_output(['rustc','--version'],text=True).strip()==rustc,'Rust compiler changed')
    require(subprocess.check_output(['cargo','--version'],text=True).strip()==data['cargo'],'Cargo toolchain changed')
def verify_replay(root):
    from build_replay import dependency_graph,normalized_command
    root=Path(root);data=json.loads((root/'replay-build-provenance.json').read_text())
    origin=data['selection_reuse'];old_path=Path(origin['path']);exact_sha(old_path,origin['sha256'])
    old=json.loads(old_path.read_text());previous=old_path.parent
    require(old.get('complete') and data.get('complete'),'incomplete replay build')
    require(set(data['variants'])=={'master','current','final'},'selection variants changed')
    toolchain(data);exact_files(root/'runner/src',data['runner_source'])
    exact_sha(root/'runner/Cargo.lock',data['resolved_lock_sha256'])
    require((root/'runner/Cargo.toml').read_text()==data['initial_manifest'],'runner manifest changed')
    require(data['runner_source']==old['runner_source'] and data['resolved_lock_sha256']==old['resolved_lock_sha256'],'original drawing/lock changed')
    snapshot=json.loads((root/'snapshot-provenance.json').read_text());graphs=[]
    for version,record in data['variants'].items():
        archived=old['variants'][version]
        for field in ('pure_source_files','timed_source_files','manifest','swash','skrifa'):
            require(record[field]==archived[field],version+' original '+field+' changed')
        require(normalized_command(record['build_command'])==normalized_command(archived['build_command']),version+' build flags changed')
        for directory,field in [('snapshots','pure_source_files'),('replay-sources','timed_source_files')]:
            exact_files(root/directory/version,record[field]);exact_files(previous/directory/version,record[field])
        require(snapshot[version]['source_files']==record['pure_source_files'],version+' snapshot provenance differs')
        exact_sha(record['binary'],record['binary_sha256']);exact_sha(archived['binary'],record['binary_sha256'])
        metadata_path=root/(version+'-replay-metadata.json')
        exact_sha(metadata_path,record['reused_metadata_sha256']);exact_sha(previous/metadata_path.name,record['reused_metadata_sha256'])
        graphs.append(dependency_graph(json.loads(metadata_path.read_text())))
    require(all(graph==graphs[0] for graph in graphs),'resolved replay graph/features differ')
    return {'complete':True,'scope':'Read-only exact replay source/drawing/manifest/toolchain/flags/lock/metadata/binary guards','versions':list(data['variants'])}
def verify_app(root):
    from baseline_build_helpers import app_inputs,git,graph,digest
    root=Path(root);data=json.loads((root/'build/provenance.json').read_text())
    origin=data['selection_reuse'];old_path=Path(origin['path']);exact_sha(old_path,origin['sha256'])
    old=json.loads(old_path.read_text());previous=old_path.parent;app=Path(data['application_root'])
    require(old.get('complete') and data.get('complete') and data['app_lock_restored'] and data['final_app_inputs_match'],'incomplete app build')
    require(set(data['variants'])=={'master','current','final'},'selection variants changed');toolchain(data)
    require(git(app,'rev-parse','HEAD').decode().strip()==data['app_commit'],'app HEAD changed')
    require(app_inputs(app)==data['app_tracked_inputs'],'app tracked inputs changed')
    exact_sha(app/'Cargo.lock',data['initial_app_lock_sha256'])
    require(digest(git(app,'diff','--binary','HEAD'))==data['app_input_diff_sha256'],'app tracked diff changed')
    exact_sha(root/'build/resolved.Cargo.lock',data['resolved_lock_sha256'])
    expected=json.loads((root/'build/dependency-graph.json').read_text())
    exact_sha(root/'build/dependency-graph.json',origin['dependency_graph_sha256'])
    for version,record in data['variants'].items():
        archived=old['variants'][version]
        require(record['source_sha256']==archived['source_sha256'],version+' source record changed')
        exact_files(record['source_directory'],record['source_sha256']);exact_files(archived['source_directory'],record['source_sha256'])
        for info in (record['binary'],archived['binary']):
            exact_sha(info['path'],record['binary']['sha256']);require(Path(info['path']).stat().st_size==info['bytes'],version+' binary length changed')
        metadata_path=root/'build'/(version+'-metadata.json');exact_sha(metadata_path,record['reused_metadata_sha256'])
        metadata=json.loads(metadata_path.read_text());femtovg=next(p for p in metadata['packages'] if p['name']=='femtovg')
        compiled_source=Path(femtovg['manifest_path']).resolve().parent
        normalized,versions=graph(metadata,app,compiled_source)
        exact_files(compiled_source,record['source_sha256'])
        require(normalized==expected,version+' dependency graph changed')
        require(versions=={k:record[k] for k in ['swash','skrifa','femtovg_features']},version+' native versions/features changed')
        exact_sha(record['metadata_origin_path'],record['reused_metadata_sha256'])
        exact_sha(root/'build/resolved.Cargo.lock',record['resolved_lock_sha256'])
    for info in (data['harness'],old['harness']):exact_sha(info['path'],data['harness']['sha256'])
    return {'complete':True,'scope':'Read-only exact application HEAD/tracked inputs/diff/locks/toolchain/native graphs/source/binary/harness guards','versions':list(data['variants'])}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=('replay','app'));p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args()
    print(json.dumps((verify_replay if a.mode=='replay' else verify_app)(a.root),indent=2))
if __name__=='__main__':main()
