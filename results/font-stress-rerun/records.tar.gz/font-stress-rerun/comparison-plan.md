# Source-only comparison preparation

No script here has been executed during measurement. The existing collector,
analyzer, frozen selection and native pixel proof remain unchanged. After both
serial backend campaigns have completed, create the fresh analysis and audit:

```sh
python3 -B /private/tmp/femtovg-font-stress-search-20261002/analyze_font_confirm.py --cpu /private/tmp/femtovg-font-stress-rerun-20261002/confirm-cpu --gpu /private/tmp/femtovg-font-stress-rerun-20261002/confirm-gpu --control-font Vollkorn-Medium --output /private/tmp/femtovg-font-stress-rerun-20261002/analysis
python3 -B /private/tmp/femtovg-font-stress-search-20261002/independent_font_confirmation_audit.py --root /private/tmp/femtovg-font-stress-rerun-20261002 --path-map /private/tmp/femtovg-font-stress-rerun-20261002/audit-path-map.json --output /private/tmp/femtovg-font-stress-rerun-20261002/independent-rerun-audit.json
python3 -B /private/tmp/femtovg-font-stress-rerun-20261002/compare_confirmations.py --old-root /private/tmp/femtovg-font-stress-search-20261002 --new-root /private/tmp/femtovg-font-stress-rerun-20261002 --output /private/tmp/femtovg-font-stress-rerun-20261002/comparison
```

After timing the parent will copy the seven identical frozen files into the
rerun root, so the checker can omit --path-map for its live run. Before those
copies, the prepared map is an equivalent exact-file alias configuration.

The audit map contains exactly seven file aliases for the frozen selection and
its six retained selection inputs. It cannot redirect new analysis or timed raw
output into the original campaign. Absolute recorded original pixel/source
references remain live references to their original verified bytes.

For offline archive auditing, verify and materialize the rerun, original
font-stress-search and updated-cache-examples archives. The usual longest-prefix
historical map resolves recorded raw/pixel/core provenance into those verified
archives. The unchanged checker additionally reads selection files relative to
the materialized rerun root. Either retain identical selection/input copies in
the rerun archive, or add the same seven aliases **from materialized rerun paths
to materialized original selection paths**. The live alias map itself is not an
offline substitution: it deliberately points to original live historical files.

The comparison reads completed independent proof bindings and all 1,116 summary
rows. It keeps both campaigns separate, records all warm outcomes, preserves
each control comparison, and does not treat matching block numbers as paired
across campaigns. It reports recorded collector/analysis UTC values without
inventing per-process timing boundaries absent from the unchanged collector.
