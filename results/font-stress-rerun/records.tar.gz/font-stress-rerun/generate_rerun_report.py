#!/usr/bin/env python3
"""Render an additive repeat report from completed, independently audited data.

Does not compute effects, intervals, new comparisons or timing exclusions.
Writes only the repeat reports and their exact input manifest.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

FONTS = ('Rye-Regular', 'DoulosSIL-Regular', 'Vollkorn-Medium')

def require(condition, message):
    if not condition: raise ValueError(message)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def table(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |',
        '| ' + ' | '.join('---' for _ in headers) + ' |',
        *['| ' + ' | '.join(str(v) for v in row) + ' |' for row in rows]])

def saving(row, scale=1000, digits=3):
    return f"{row['mean_paired_savings_us']/scale:.{digits}f} [{row['savings_ci95_low_us']/scale:.{digits}f}, {row['savings_ci95_high_us']/scale:.{digits}f}]"

def extra_cost(row, digits=2):
    return f"{-row['mean_paired_savings_us']:.{digits}f} [{-row['savings_ci95_high_us']:.{digits}f}, {-row['savings_ci95_low_us']:.{digits}f}]"

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--old-root', type=Path, default=Path('/private/tmp/femtovg-font-stress-search-20261002'))
    args = parser.parse_args(); root = args.root.resolve(strict=True); old_root = args.old_root.resolve(strict=True)
    inputs = {}
    def record(path):
        path = Path(path).resolve(strict=True)
        inputs[str(path)] = {'sha256': sha(path), 'bytes': path.stat().st_size}
        return path
    def read(path):
        return json.loads(record(path).read_text())
    summary = read(root/'analysis/summary.json')
    raw = read(root/'analysis/raw-audit.json')
    independent = read(root/'independent-rerun-audit.json')
    comparison = read(root/'comparison/comparison.json')
    comparison_inputs = read(root/'comparison/comparison-inputs.json')
    analysis_inputs = read(root/'analysis/analysis-inputs.json')
    original = read(old_root/'analysis/summary.json')
    old_independent = read(old_root/'independent-confirmation-audit.json')
    selection = read(root/'selection-frozen.json')
    for name, value in (('summary',summary), ('live raw audit',raw), ('independent audit',independent),
                        ('comparison',comparison), ('analysis inputs',analysis_inputs), ('comparison inputs',comparison_inputs),
                        ('original summary',original), ('original independent audit',old_independent), ('selection',selection)):
        require(value.get('complete') is True, 'Incomplete report input: ' + name)
    require(raw['metadata_only'] is False, 'Completed live identity/pixel audit required')
    require(independent['summary_sha256'] == sha(root/'analysis/summary.json'), 'Independent rerun audit does not bind this summary')
    require(old_independent['summary_sha256'] == sha(old_root/'analysis/summary.json'), 'Original independent audit does not bind its summary')
    require(independent['endpoint_comparisons'] == 1116 and independent['interval_comparisons'] == 2234,
            'Expected full independent rerun audit coverage')
    require(comparison['unchanged_recorded_inputs'] is True and comparison['endpoint_count'] == 1116,
            'Comparison must verify unchanged original inputs and retain every endpoint')
    for path, expected in comparison_inputs['inputs'].items():
        p = record(path)
        require(inputs[str(p)] == expected, 'Comparison input changed: ' + path)
    for name, expected in comparison_inputs['outputs'].items():
        p = record(root/'comparison'/name)
        require(inputs[str(p)] == expected, 'Comparison output changed: ' + name)
    for section in ('inputs', 'outputs'):
        for value in analysis_inputs[section].values():
            if isinstance(value,dict) and {'path','sha256','bytes'} <= value.keys():
                p = record(value['path'])
                require(inputs[str(p)] == {k:value[k] for k in ('sha256','bytes')}, 'Analysis binding changed: ' + str(p))
    metas = {}
    for mode, trials in (('cpu',5), ('gpu',3)):
        data = read(root/f'confirm-{mode}/{mode}-provenance.json'); metas[mode] = data
        require(data['complete'] and not data['exploratory'] and data['blocks']==12
                and data['versions']==['master','final'] and data['trials_per_process']==trials
                and data['fonts']==list(FONTS) and set(data['dpis'])=={1,2}
                and len(data['launches'])==144, 'Unexpected repeat protocol: ' + mode)
        previous = read(old_root/f'confirm-{mode}/{mode}-provenance.json')
        for field in ('identity','font_files','fonts','dpis','phases','versions','blocks',
                      'trials_per_process','selection_manifest','pixel_proof','order'):
            require(data[field]==previous[field], 'Repeat changed recorded input: ' + mode + '/' + field)
    require(metas['cpu']['identity']==metas['gpu']['identity'], 'CPU/GPU repeat source identities differ')
    for font, value in metas['cpu']['font_files'].items():
        p = record(value['path'])
        require(inputs[str(p)]=={k:value[k] for k in ('sha256','bytes')}, 'Selected font changed: ' + font)
    for value in (metas['cpu']['pixel_proof'], metas['cpu']['selection_manifest'], metas['cpu']['driver']):
        p = record(value['path']); require(inputs[str(p)]=={k:value[k] for k in ('sha256','bytes')}, 'Original fixed proof/driver changed')
    for relative, expected in selection['selection_inputs'].items():
        require(sha(record(root/relative))==expected, 'Selection alias changed: ' + relative)
    for p in (root/'analysis/summary.csv',root/'analysis/primary-table.md',root/'comparison/COMPARISON.md',
              root/'comparison/comparison.csv',root/'rerun-context.md'):
        record(p)
    for name in ('hardware.json','current-workspace-identity.json','alias-provenance.json','rerun-provenance.json','quiet-provenance.json'):
        if (root/name).is_file(): record(root/name)
    logs = [p for p in sorted(root.iterdir()) if p.is_file()
            and (p.suffix in ('.stdout','.stderr','.log') or p.name in
                 ('analyzer-stdout.txt','analyzer-stderr.txt','analysis-stdout.txt','analysis-stderr.txt'))]
    for p in logs: record(p)
    record(__file__)
    indexed = {(r['backend'],r['font'],r['dpi'],r['scene'],r['phase'],r['metric']):r for r in summary['results']}
    old_indexed = {(r['backend'],r['font'],r['dpi'],r['scene'],r['phase'],r['metric']):r for r in original['results']}
    require(len(indexed)==len(summary['results'])==1116 and set(indexed)==set(old_indexed), 'Incomplete endpoint matrix')
    def row(font, backend='cpu', dpi=2, scene='demo', phase='first_paint', metric=None):
        return indexed[backend,font,dpi,scene,phase,metric or ('draw_us' if backend=='cpu' else 'complete_us')]
    rye = row('Rye-Regular'); rye_gpu = row('Rye-Regular','gpu')
    primary_table = table(['Font','CPU master → final (ms)','CPU saving, 95% CI (ms)','GPU completion master → final (ms)','GPU completion saving, 95% CI (ms)'],
        [(f, f"{row(f)['reference_mean_process_median_us']/1000:.3f} → {row(f)['candidate_mean_process_median_us']/1000:.3f}", saving(row(f)),
          f"{row(f,'gpu')['reference_mean_process_median_us']/1000:.3f} → {row(f,'gpu')['candidate_mean_process_median_us']/1000:.3f}", saving(row(f,'gpu'))) for f in FONTS])
    sequence_table = table(['Font','CPU saving across 65 reported demo frames (ms)','GPU completion saving (ms)'],
        [(f,saving(row(f,phase='reported_sequence')),saving(row(f,'gpu',phase='reported_sequence'))) for f in FONTS])
    zoom_table = table(['Font','CPU zoom in saving (ms/frame)','CPU zoom out saving (ms/frame)','CPU warm saving (µs/frame)','CPU pan saving (µs/frame)'],
        [(f,saving(row(f,phase='zoom_in')),saving(row(f,phase='zoom_out')),
          saving(row(f,phase='warm'),1,2),saving(row(f,phase='pan'),1,2)) for f in FONTS])
    text_table = table(['Font','DPR','Extra final CPU text/warm cost, 95% CI (µs/frame)'],
        [(f,dpi,extra_cost(row(f,dpi=dpi,scene='text',phase='warm'))) for f in FONTS for dpi in (1,2)])
    advantages = {r['font']:r for r in summary['primary_control_advantage']}
    require(set(advantages)=={'Rye-Regular','DoulosSIL-Regular'}, 'Missing simultaneous control comparisons')
    control_table = table(['Font versus Vollkorn','Additional CPU saving, 95% CI (ms)','Inference'],
        [(f,f"{advantages[f]['mean_additional_paired_savings_us']/1000:.3f} [{advantages[f]['additional_savings_ci95_us'][0]/1000:.3f}, {advantages[f]['additional_savings_ci95_us'][1]/1000:.3f}]",
          advantages[f]['classification']) for f in ('Rye-Regular','DoulosSIL-Regular')])
    old_new_table = table(['Font','Original CPU saving, 95% CI (ms)','Repeat CPU saving, 95% CI (ms)','Original → repeat inference'],
        [(f,saving(old_indexed['cpu',f,2,'demo','first_paint','draw_us']),saving(row(f)),
          old_indexed['cpu',f,2,'demo','first_paint','draw_us']['classification']+' → '+row(f)['classification']) for f in FONTS])
    old_new_gpu_table = table(['Font','Original GPU completion saving, 95% CI (ms)','Repeat GPU completion saving, 95% CI (ms)'],
        [(f,saving(old_indexed['gpu',f,2,'demo','first_paint','complete_us']),saving(row(f,'gpu'))) for f in FONTS])
    final_source = metas['cpu']['identity']['sources']['final']['pure_snapshot']
    current = read(root/'current-workspace-identity.json')
    require(current.get('complete') is True and current['files']=={name:final_source[name] for name in
            ('src/lib.rs','src/text.rs','src/text/swash_rasterizer.rs')},
            'Current workspace production files must match the exact measured final')
    source_table = table(['Frozen final source','SHA-256'],[(name,final_source[name]) for name in ('src/lib.rs','src/text.rs','src/text/swash_rasterizer.rs')])
    main = f'''# Repeat of the favorable-font performance measurements

With the unchanged FemtoVG demo at DPR2, Rye Regular reduced CPU Canvas draw time from **{rye['reference_mean_process_median_us']/1000:.3f} to {rye['candidate_mean_process_median_us']/1000:.3f} ms** on first paint, saving **{saving(rye)} ms**. Real offscreen GPU completion changed from **{rye_gpu['reference_mean_process_median_us']/1000:.3f} to {rye_gpu['candidate_mean_process_median_us']/1000:.3f} ms**, saving **{saving(rye_gpu)} ms**. Positive savings mean faster final execution; intervals are nominal 95% bootstrap intervals.

This is a complete fresh repeat of the fixed three-font master/final cohort, requested because of a background-load concern. Overlap between the reported game activity and the original measurement was not established. The original [numeric report](FONT-STRESS-SEARCH.md) and [archive](results/font-stress-search/) remain unchanged. The repeat changes no font, scene, production source, executable, native pixel proof, selection, schedule or estimator. It adds observations rather than selecting runs from either cohort.

## Fresh repeat against master

{primary_table}

The primary endpoint remains first-paint host CPU draw time at DPR2. GPU completion is a secondary endpoint. These are deliberately selected favorable fonts from the retained 56-face search, not an estimate for typical fonts or a claim of universal improvement. The complete patch is measured, including scaler reuse and correctness fixes; this campaign does not isolate the arena cache alone.

{control_table}

The control comparison subtracts the simultaneously measured Vollkorn master/final savings within each block. A `larger_savings` interval excludes zero in the positive direction; `uncertain` means the interval crosses zero. Greater saving in a selected font does not imply an order-of-magnitude increase over the prior favorable font.

{sequence_table}

The 65-frame demo total sums each trial's measured phase time × recorded frames before taking the process median. It includes first paint, 30 warm frames, 12 zoom-in, 12 zoom-out and 10 pan frames. It excludes 119 unreported warm-up frames; it is not elapsed wall-clock replay duration. CPU draw, GPU submit and GPU completion are cumulative alternative endpoints and must not be added together.

{zoom_table}

## Costs and limits

Atlas-warm text costs remain explicit. Positive values below mean extra final CPU cost; a negative value would mean a saving.

{text_table}

All text, variation, unique-size, unique-variation, pollution and hot-return phases at both DPRs are retained, including regressions and uncertain intervals, in the [1,116-endpoint CSV](analysis/font-stress-rerun/summary.csv). Variation controls keep Roboto rather than the substituted font. These repeated controls are not independent font-specific evidence. The repeat does not establish universally faster misses, warm frames or cache churn. The prior [revised-cache report](REVISED-OUTLINE-CACHE.md) retains the separate capacity/memory investigation and Alustin evidence; this font repeat does not remeasure those applications or memory costs.

## Original cohort versus repeat

{old_new_table}

{old_new_gpu_table}

The [complete comparison](analysis/font-stress-rerun/comparison/COMPARISON.md), [all endpoint pairs](analysis/font-stress-rerun/comparison/comparison.csv), and [structured comparison](analysis/font-stress-rerun/comparison/comparison.json) retain both cohorts. They verify identical recorded inputs and preserve all 1,116 endpoints. Estimates remain separate: blocks are not paired across cohorts, no pooled estimate or between-cohort change interval is computed, and confidence-interval overlap is not an equivalence test. This comparison cannot establish that background activity caused any difference.

## Protocol and checks

The repeat retained 144 CPU plus 144 GPU processes: 12 paired blocks × three fonts × two DPRs × two versions. Every font/DPR has six master→final and six final→master orders, with configurations rotated by block. CPU uses five trials per process through Canvas with the Void renderer; GPU uses three with real offscreen WGPU/Metal. Every process contributes all 28 phases. No process was retried or excluded. These are draw/submit/completion measurements, not application startup, displayed FPS or Alustin measurements.

Absolute effects are means of paired process medians. Nominal 95% intervals use 10,000 whole-block bootstrap resamples with seed 72531; the same backend resamples are shared across fonts/DPRs/endpoints. Percentages in the machine-readable output are ratios of means. The intervals are conditional on the selected fonts and unadjusted for the many secondary endpoints. Both cohorts use the same Apple M4 Max machine with 128 GiB RAM. One-machine repeats and order checks do not prove absence of thermal drift, DVFS or competing work throughout an interval.

The original native pixel proof's 504 captures are reused unchanged; this repeat takes no new pixel captures. Final RGBA and atlas counts match the independent uncached-master reference keyed by actual signed raster-offset bits; master's original aliasing behavior is preserved separately. Live source/executable/font/raw/pixel binding passed the new analyzer. The unchanged direct raw/indexed-bootstrap checker reproduced **{independent['endpoint_comparisons']:,} effects and {independent['interval_comparisons']:,} intervals**. [Audit](analysis/font-stress-rerun-independent-audit.json), [complete analysis](analysis/font-stress-rerun/summary.json), and [raw/live audit](analysis/font-stress-rerun/raw-audit.json) retain the validation.

{source_table}

[Rerun context](analysis/font-stress-rerun/rerun-context.md) records the initial process-name observation and its limited scope. The same machine and frozen baseline/final source identities as the [original protocol](FONT-STRESS-SEARCH.md) apply. [Current workspace identity](analysis/font-stress-rerun/current-workspace-identity.json) verifies that the three production files still match this measured final, and [hardware](analysis/font-stress-rerun/hardware.json) retains the machine observation. No new source build occurred for this repeat. The [new raw archive](results/font-stress-rerun/) retains the attempts, analysis, exact seven selection aliases and report inputs; original absolute source/pixel references resolve through the unchanged companion archives. [Offline verification and reproduction](docs/font-stress-rerun-reproduction.md) describe that mapping and the separately disclosed fresh-build path.

[The report input manifest](analysis/font-stress-rerun-original-report-inputs.json) binds the displayed report to its source estimates, independent proofs and all-endpoint comparison. Original numerical reports, source bundles and archives remain preserved.
'''
    warning_logs = [p for p in logs if 'RuntimeWarning' in p.read_text(errors='replace')]
    if warning_logs:
        main += '\nCaptured analyzer logs contain RuntimeWarning output. The unchanged direct checker reproduced the retained finite effects and intervals; no warning cause is inferred and no measurements are excluded. The logs remain visible under [analysis logs](analysis/font-stress-rerun/logs/).\n'
    summary_md = f'''# Summary of the repeated favorable-font cohort

The fixed master/final comparison was repeated in full after a background-load concern. Overlap with the original measurement is unestablished; both numerical cohorts remain retained.

{primary_table}

{control_table}

Rye CPU text/warm at DPR2 has an extra final cost of **{extra_cost(row('Rye-Regular',scene='text',phase='warm'))} µs/frame**. All fonts, costs, uncertain intervals and every phase remain in the [full CSV](analysis/font-stress-rerun/summary.csv). This remains selected favorable-font evidence, not universal improvement.

The repeat retains all 288 processes, the original binaries/fonts/scenes/native pixels, and the balanced schedule. Independent checking reproduced {independent['endpoint_comparisons']:,} effects and {independent['interval_comparisons']:,} intervals. No runs were excluded or pooled across cohorts.

[Full report](FONT-STRESS-RERUN.md), [original report](FONT-STRESS-SEARCH.md), and [all original-versus-repeat comparisons](analysis/font-stress-rerun/comparison/COMPARISON.md) supply the evidence and limits.
'''
    for name, text in (('FONT-STRESS-RERUN.md',main), ('SUMMARY-FONT-STRESS-RERUN.md',summary_md)):
        (root/name).write_text(text); record(root/name)
    manifest = {'complete': True, 'generated_utc': datetime.now(timezone.utc).isoformat(),
        'files': inputs, 'generator': str(Path(__file__).resolve()),
        'scope': 'Render completed original/repeat estimates and independent comparisons; no new estimator, timing or exclusion; original reports are not modified.'}
    (root/'FONT-STRESS-RERUN.inputs.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'complete':True,'report_inputs':len(inputs),'root':str(root)}))

if __name__ == '__main__': main()
