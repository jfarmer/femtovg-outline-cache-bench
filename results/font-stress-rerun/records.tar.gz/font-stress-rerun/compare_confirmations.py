#!/usr/bin/env python3
"""Compare two completed, independently audited confirmation campaigns.

All endpoints are retained. This summarizes existing estimates and does not
pool campaigns, pair blocks across campaigns or estimate a CI for their change.
Run only after serial measurement, analysis and independent raw audits finish.
"""
import argparse
from collections import Counter
import csv
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path

KEYS = ('backend', 'font', 'dpi', 'scene', 'phase', 'metric', 'reference_version', 'candidate_version')
FIELDS = ('reference_mean_process_median_us', 'candidate_mean_process_median_us',
          'mean_paired_savings_us', 'savings_ci95_low_us', 'savings_ci95_high_us',
          'ratio_of_means_change_pct', 'ratio_change_ci95_low_pct', 'ratio_change_ci95_high_pct',
          'classification')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--old-root', type=Path, required=True)
    parser.add_argument('--new-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True, help='Fresh comparison directory')
    parser.add_argument('--path-map', type=Path, help='Optional longest-prefix map for archived raw provenance')
    parser.add_argument('--old-audit', default='independent-confirmation-audit.json', help='Proof filename relative to original root')
    parser.add_argument('--new-audit', default='independent-rerun-audit.json', help='Proof filename relative to rerun root')
    args = parser.parse_args()
    maps = sorted((json.loads(args.path_map.read_text()) if args.path_map else {}).items(), key=lambda x: -len(x[0]))
    def resolve(path):
        value = str(path)
        for old, new in maps:
            if value == old or value.startswith(old.rstrip('/') + '/'):
                return Path(new + value[len(old):])
        return Path(value)
    inputs = {}
    def read(path):
        target = resolve(path)
        data = target.read_bytes()
        inputs[str(path)] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
        return json.loads(data)
    roots = {'original': args.old_root.resolve(), 'rerun': args.new_root.resolve()}
    summaries, proofs, metas, indexed = {}, {}, {}, {}
    chronology = []
    for label, root in roots.items():
        summaries[label] = read(root / 'analysis/summary.json')
        proof = read(root / (args.old_audit if label == 'original' else args.new_audit))
        proofs[label] = proof
        raw = read(root / 'analysis/raw-audit.json')
        assert proof['complete'] and raw['complete'] and summaries[label]['complete']
        assert proof['endpoint_comparisons'] == 1116 and proof['interval_comparisons'] == 2234
        assert proof['summary_sha256'] == inputs[str(root / 'analysis/summary.json')]['sha256']
        assert summaries[label]['methodology']['versions'] == ['master', 'final']
        rows = summaries[label]['results']
        assert all(math.isfinite(v) for r in rows for v in r.values() if isinstance(v, float))
        indexed[label] = {tuple(r[k] for k in KEYS): r for r in rows}
        assert len(indexed[label]) == len(rows) == 1116
        metas[label] = {}
        for mode in ('cpu', 'gpu'):
            meta = read(root / f'confirm-{mode}/{mode}-provenance.json')
            assert meta['complete'] and not meta['exploratory'] and meta['blocks'] == 12
            assert meta['versions'] == ['master', 'final']
            assert meta['trials_per_process'] == (5 if mode == 'cpu' else 3)
            assert len(meta['launches']) == 144 and all(l['validated'] and l['exit_code'] == 0 for l in meta['launches'])
            metas[label][mode] = meta
            chronology.append({'campaign': label, 'backend': mode, 'created_utc': meta['created_utc'],
                'meaning': 'Collector creation/start record; per-process start/end and campaign completion timestamps are not recorded by the unchanged collector.'})
        chronology.append({'campaign': label, 'stage': 'analysis',
            'created_utc': summaries[label]['methodology']['created_utc'],
            'meaning': 'Analyzer creation record after both completed backend inputs; this is not the exact end of measurement.'})
    assert set(indexed['original']) == set(indexed['rerun'])
    for mode in ('cpu', 'gpu'):
        old, new = metas['original'][mode], metas['rerun'][mode]
        for field in ('identity', 'font_files', 'fonts', 'dpis', 'phases', 'versions', 'blocks',
                      'trials_per_process', 'selection_manifest', 'pixel_proof', 'order'):
            assert old[field] == new[field], (mode, field)
        assert [(l['block'], l['font'], l['dpi'], l['version']) for l in old['launches']] == [
            (l['block'], l['font'], l['dpi'], l['version']) for l in new['launches']]
    assert metas['original']['cpu']['identity'] == metas['original']['gpu']['identity']
    points = []
    transitions = Counter()
    for key in sorted(indexed['original']):
        old, new = indexed['original'][key], indexed['rerun'][key]
        assert old['frames'] == new['frames'] and old['unit'] == new['unit']
        item = dict(zip(KEYS, key), frames=old['frames'], unit=old['unit'])
        for field in FIELDS:
            item['original_' + field] = old[field]
            item['rerun_' + field] = new[field]
        item['savings_point_change_us'] = new['mean_paired_savings_us'] - old['mean_paired_savings_us']
        item['point_direction_changed'] = (old['mean_paired_savings_us'] < 0) != (new['mean_paired_savings_us'] < 0)
        item['classification_changed'] = old['classification'] != new['classification']
        transitions[old['classification'] + '→' + new['classification']] += 1
        points.append(item)
    advantages = []
    old_adv = {(r['font'], r['control_font']): r for r in summaries['original']['primary_control_advantage']}
    new_adv = {(r['font'], r['control_font']): r for r in summaries['rerun']['primary_control_advantage']}
    assert set(old_adv) == set(new_adv) and len(old_adv) == 2
    for key in sorted(old_adv):
        old, new = old_adv[key], new_adv[key]
        advantages.append({'font': key[0], 'control_font': key[1],
            'original_mean_additional_paired_savings_us': old['mean_additional_paired_savings_us'],
            'rerun_mean_additional_paired_savings_us': new['mean_additional_paired_savings_us'],
            'original_ci95_us': old['additional_savings_ci95_us'],
            'rerun_ci95_us': new['additional_savings_ci95_us'],
            'original_classification': old['classification'], 'rerun_classification': new['classification']})
    chronology.sort(key=lambda x: datetime.fromisoformat(x['created_utc']))
    primary = [p for p in points if p['backend'] == 'cpu' and p['dpi'] == 2 and p['scene'] == 'demo'
               and p['phase'] == 'first_paint' and p['metric'] == 'draw_us']
    gpu_primary_secondary = [p for p in points if p['backend'] == 'gpu' and p['dpi'] == 2 and p['scene'] == 'demo'
                            and p['phase'] == 'first_paint' and p['metric'] == 'complete_us']
    warm = [p for p in points if p['scene'] in ('demo', 'text') and p['phase'] == 'warm'
            and p['metric'] == ('draw_us' if p['backend'] == 'cpu' else 'complete_us')]
    scope = ('Separate repeats on the same machine, unchanged fixed fonts/scene/source/binaries and recorded pixel reference. '
             'All 1,116 endpoint estimates retained without exclusions. Original and rerun block labels are not paired across '
             'campaigns; no pooled estimate or CI for between-campaign change is computed. CI overlap is not an equivalence test. '
             'Game/background-load overlap with original measurement is not established; recorded collector starts are shown '
             'without inferring missing per-process timestamps or an exact campaign end.')
    result = {'complete': True, 'scope': scope, 'endpoint_count': len(points),
        'unchanged_recorded_inputs': True, 'classification_transitions': dict(sorted(transitions.items())),
        'primary_cpu_demo_DPR2': primary, 'secondary_gpu_demo_DPR2': gpu_primary_secondary,
        'primary_control_advantages': advantages, 'warm_draw_and_completion': warm,
        'chronology': chronology, 'all_endpoints': points}
    output = args.output.resolve()
    if output.exists():
        raise ValueError('Output must be fresh: ' + str(output))
    output.mkdir(parents=True)
    (output / 'comparison.json').write_text(json.dumps(result, indent=2) + '\n')
    with (output / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(points[0])); writer.writeheader(); writer.writerows(points)
    def table(headers, rows):
        return '\n'.join(['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join('---' for _ in headers) + ' |',
            *['| ' + ' | '.join(str(v) for v in r) + ' |' for r in rows]])
    def effect(p, prefix, scale=1000, digits=3):
        return f"{p[prefix+'mean_paired_savings_us']/scale:.{digits}f} [{p[prefix+'savings_ci95_low_us']/scale:.{digits}f}, {p[prefix+'savings_ci95_high_us']/scale:.{digits}f}]"
    heading = '# Original and rerun confirmation comparison\n\n' + scope + '\n\n'
    first_table = table(['Font', 'Original CPU saving, ms [95% CI]', 'Rerun CPU saving, ms [95% CI]', 'Original → rerun inference'],
        [(p['font'], effect(p, 'original_'), effect(p, 'rerun_'), p['original_classification']+' → '+p['rerun_classification']) for p in primary])
    gpu_table = table(['Font', 'Original GPU completion saving, ms [95% CI]', 'Rerun GPU completion saving, ms [95% CI]'],
        [(p['font'], effect(p, 'original_'), effect(p, 'rerun_')) for p in gpu_primary_secondary])
    advantage_table = table(['Font versus control', 'Original extra saving, ms [95% CI]', 'Rerun extra saving, ms [95% CI]', 'Original → rerun inference'],
        [(p['font']+' versus '+p['control_font'],
          f"{p['original_mean_additional_paired_savings_us']/1000:.3f} [{p['original_ci95_us'][0]/1000:.3f}, {p['original_ci95_us'][1]/1000:.3f}]",
          f"{p['rerun_mean_additional_paired_savings_us']/1000:.3f} [{p['rerun_ci95_us'][0]/1000:.3f}, {p['rerun_ci95_us'][1]/1000:.3f}]",
          p['original_classification']+' → '+p['rerun_classification']) for p in advantages])
    warm_table = table(['Font/DPR/backend/scene', 'Original saving, µs [95% CI]', 'Rerun saving, µs [95% CI]', 'Original → rerun inference'],
        [(f"{p['font']} / {p['dpi']} / {p['backend']} / {p['scene']}", effect(p, 'original_', 1, 2), effect(p, 'rerun_', 1, 2),
          p['original_classification']+' → '+p['rerun_classification']) for p in warm])
    time_table = table(['UTC record', 'Campaign', 'Backend/stage'], [(t['created_utc'], t['campaign'], t.get('backend', t.get('stage'))) for t in chronology])
    markdown = heading + 'Primary CPU demo first paint at DPR2; positive savings mean faster final execution.\n\n' + first_table
    markdown += '\n\nGPU completion is a secondary endpoint.\n\n' + gpu_table + '\n\nAdditional saving versus simultaneous Vollkorn.\n\n' + advantage_table
    markdown += '\n\nAll warm draw/completion outcomes are retained below, including regressions and uncertain intervals.\n\n' + warm_table
    markdown += '\n\nRecorded chronology (start/analysis records only).\n\n' + time_table
    markdown += '\n\n[All 1,116 endpoint comparisons](comparison.csv) and [complete structured comparison](comparison.json) retain every phase and metric. Classification-transition counts are descriptive and the many secondary intervals are not multiplicity-adjusted.\n'
    (output / 'COMPARISON.md').write_text(markdown)
    inputs[str(Path(__file__).resolve())] = {'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'bytes': Path(__file__).stat().st_size}
    outputs = {p.name: {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size} for p in output.iterdir() if p.is_file()}
    (output / 'comparison-inputs.json').write_text(json.dumps({'complete': True, 'inputs': inputs, 'outputs': outputs}, indent=2) + '\n')
    print(json.dumps({'complete': True, 'endpoints': len(points), 'output': str(output)}))


if __name__ == '__main__':
    main()
