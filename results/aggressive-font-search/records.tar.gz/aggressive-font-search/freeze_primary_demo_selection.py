#!/usr/bin/env python3
"""Freeze five confirmation fonts after all independent exploratory analyses.

This command prepares reviewable selection, pixel, collection and analysis
commands only. It never executes a renderer, timing kernel, build or download.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
STUDY=ROOT/'demo-only-replay-v2'
COLLECTOR=STUDY/'replay_campaign_v3.py'
ANALYSIS=ROOT/'demo-confirmation-analysis-v1'


def require(value,message):
    if not value: raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def info(path):
    path=Path(path).resolve(strict=True);raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--font',action='append',nargs=2,metavar=('LABEL','PATH'),required=True)
    parser.add_argument('--rationale',required=True,help='State the selected stress candidates and why each belongs in confirmation')
    parser.add_argument('--output',type=Path,default=ROOT/'primary-selection-v1')
    args=parser.parse_args()
    labels=[label for label,_ in args.font]
    require(len(labels)==5 and len(set(labels))==5,'Choose exactly five distinct fonts')
    require({'Rye-Regular','Vollkorn-Medium'}<=set(labels),'Fresh Rye and Vollkorn controls are required')
    output=args.output.resolve()
    require(not output.exists(),'Retain previous and failed selections; use a fresh directory')
    cohorts={'broad':ROOT,'hinted':ROOT/'hinted-supplement-v1','ornate':ROOT/'ornate-supplement-v1'}
    evidence=[];known={}
    for cohort,root in cohorts.items():
        for name,relative in [
            ('demo-analysis','demo-screen-v1/independent-analysis/analysis.json'),
            ('demo-fraction-audit','demo-screen-v1/independent-analysis/independent-fraction-audit.json'),
            ('demo-archive-audit','demo-screen-v1/independent-analysis/archive-fraction-audit.json'),
            ('native-ranking','supporting/native-prescreen-ranking.json'),
            ('static-inspection','supporting/font-inspection.json'),
            ('static-priors','supporting/static-priors.json'),
            ('native-protocol','native-prescreen-protocol-v1.json'),
        ]:
            path=root/relative;record=load(path)
            require(record.get('complete') is True,'Exploratory evidence incomplete: '+str(path))
            evidence.append((cohort+'-'+name+'.json',path))
        native=load(root/'native-prescreen-protocol-v1.json')
        inspection={font['label']:font for font in load(root/'supporting/font-inspection.json')['fonts']}
        for font in native['fonts']:
            key=font['label'],font['sha256']
            known.setdefault(key,[]).append((font,inspection[font['label']]))
    fonts=[];coverage=[]
    for label,path in args.font:
        record=info(path)
        entries=known.get((label,record['sha256']),[])
        require(entries,'Selected font is outside the frozen search: '+label)
        require(any({key:font[key] for key in ('path','bytes','sha256')}==record for font,_ in entries),'Selected path/bytes differ from search')
        inspected=entries[0][1]
        graphic={}
        for size in ('11','12','14','15','16'):
            corpus=inspected['corpora']['demo_'+size+'_graphic']
            require(corpus['missing_codepoints']==[] and corpus['mapped_distinct_characters']==corpus['requested_distinct_characters'],'Selected font lacks actual demo text')
            require(all(entry['glyph_id']!=0 and entry['expanded_points']>0 for entry in corpus['per_codepoint'].values()),'Selected actual-demo character lacks font geometry')
            graphic[size]={key:corpus[key] for key in ('requested_distinct_characters','mapped_distinct_characters','mapped_unique_glyphs','missing_codepoints')}
        fonts.append({'label':label,**record});coverage.append({'font':label,'five_size_demo_graphic_mapping':graphic})
    spec=importlib.util.spec_from_file_location('frozen_demo_collector',COLLECTOR)
    collector=importlib.util.module_from_spec(spec);spec.loader.exec_module(collector)
    identity=collector.input_identity(STUDY)
    output.mkdir();(output/'inputs').mkdir()
    copied={};originals=[]
    for name,path in evidence:
        destination=output/'inputs'/name;destination.write_bytes(path.read_bytes())
        copied['inputs/'+name]=info(destination)['sha256'];originals.append(info(path))
    for name,path in [('analysis-source-preparation',ANALYSIS/'source-preparation.json'),('analysis-live-source-preflight',ANALYSIS/'source-identity-preflight.json')]:
        require(load(path)['complete'],'Analysis source proof incomplete')
        destination=output/'inputs'/(name+'.json');destination.write_bytes(path.read_bytes())
        copied['inputs/'+destination.name]=info(destination)['sha256'];originals.append(info(path))
    selection_path=output/'selection.json'
    selection={'complete':True,'frozen_utc':datetime.now(timezone.utc).isoformat(),'fonts':fonts,
        'rationale':args.rationale,'selection_inputs':copied,'original_selection_inputs':originals,
        'coverage':coverage,'input_identity':identity,'collector':info(COLLECTOR),'freezer':info(Path(__file__)),
        'confirmation':{'versions':['master','final'],'backend':'cpu','dpis':[2],'blocks':12,'trials_per_process':5,
                        'scene':'demo','phases':{'first_paint':1,'warm':30,'zoom_in':12,'zoom_out':12,'pan':10},
                        'unmeasured_warmups_per_trial':119,'reported_sequence_frames':65,
                        'bootstrap_resamples':10000,'bootstrap_seed':72531,'control_font':'Rye-Regular'},
        'scope':'Separate fresh primary confirmation after exploratory font search. Original demo drawing, fixed icon/emoji/fallback fonts, regular-font override only. No other scenes run in this additional campaign; previous full-scene benchmarks remain preserved. Actual first-paint atlas sizes are 11–16px at requested DPR2. Intervals are conditional on these selected fonts, unadjusted for multiple endpoints.'}
    write(selection_path,selection)
    common=['--versions','master','final','--dpi','2','--selection-manifest',str(selection_path)]
    for font in fonts: common+=['--font',font['label'],font['path']]
    pixels=ROOT/'primary-pixels-v1';cpu=ROOT/'primary-confirm-cpu-v1';analysis=ROOT/'primary-analysis-v1'
    commands={
        'pixels':[sys.executable,'-B',str(COLLECTOR),'--mode','pixels','--output',str(pixels),*common],
        'cpu':[sys.executable,'-B',str(COLLECTOR),'--mode','cpu','--blocks','12','--trials','5','--pixel-proof',str(pixels/'pixels-provenance.json'),'--output',str(cpu),*common],
        'analyze':[sys.executable,'-B',str(ANALYSIS/'analyze_demo_confirm.py'),'--cpu',str(cpu),'--output',str(analysis),'--control-font','Rye-Regular'],
        'independent_audit':[sys.executable,'-B',str(ANALYSIS/'independent_demo_confirmation_audit.py'),'--root',str(ROOT),'--cpu',str(cpu),'--analysis',str(analysis),'--control-font','Rye-Regular','--output',str(analysis/'independent-audit.json')],
    }
    write(output/'protocol.json',{'complete':True,'source_only_protocol':True,'collection_executed':False,
        'selection':info(selection_path),'commands':commands,'expected_cpu_processes':120,'expected_cpu_rows':3000,
        'expected_pixel_processes':15,'expected_rgba_snapshots':75,
        'analyzer':info(ANALYSIS/'analyze_demo_confirm.py'),'independent_auditor':info(ANALYSIS/'independent_demo_confirmation_audit.py'),
        'collector':info(COLLECTOR),'freezer':info(Path(__file__)),
        'policy':'Run pixels first, retain native-offset oracle agreement and any master/native differences. Then fresh balanced master/final primary collection; preserve every process/trial and all failures. Root owns all timing and rendering. Optional six-block no-retention diagnostics are separately frozen after primary selection/result; no six-block data enters primary CIs.'})
    print(json.dumps({'complete':True,'selection':str(selection_path),'protocol':str(output/'protocol.json'),'collection_executed':False,'expected_cpu_processes':120,'expected_cpu_rows':3000}))


if __name__=='__main__':
    main()
