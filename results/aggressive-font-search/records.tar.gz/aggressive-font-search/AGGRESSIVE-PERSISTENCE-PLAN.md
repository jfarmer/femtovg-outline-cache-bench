# Additive persistence plan for the aggressive Latin font investigation

This is an implementation plan, not a completed installation or result report.
The completed CJK study is a prerequisite. The actual benchmark repository has
not been modified by this plan.

The installation should append one `aggressive-font-search` campaign to the
reviewed CJK baseline of 31 campaigns and 15 analysis audits. All historical
campaign and audit entries must compare equal to the baseline prefix after the
append. The number of additional audits must come from the final explicit
manifest, rather than from assuming that a directory or script represents a
completed cohort.

## Retained source and raw records

Archive this investigation root losslessly, including its three independently
frozen acquisition/static/native cohorts:

- The original 29 candidate fonts, plus the Rye/Vollkorn controls in the native
  protocol. Preserve the completed 20/21/29 acquisition snapshots, initial DNS
  failures, source corrections, unchanged official font/licensing/metadata
  bytes, and all screening/coverage/program-count results.
- `hinted-supplement-v1`, with its own ten-font manifest, static outputs,
  protocol and native rejection records. The original ASCII94 precondition
  rejects HerrVonMuellerhoff; its fully covered demo corpus and subsequent
  application evaluation must remain separately represented.
- `ornate-supplement-v1`, with its own eight-font manifest, primary upstream
  descriptions and request plan/outcomes. Root completed all 40 requests with
  HTTP 200 and verified the pinned bytes; measurements are still pending.

Retain every actual application campaign, its selection frozen before timing,
all subprocess outcomes, raw trials, full arithmetic/paired-block outputs,
and independent source-bound audits. Preserve native prescreen costs as
exploratory measurements; application screening and a later balanced
confirmation must receive separate labels and claims.

The existing archive helper can omit only its declared compiler/cache trees,
compiled artifacts and symlinks with recorded reasons. Font bytes, original
failed processes, raw timings, sources, lock files, image captures and
provenance are retained. Identical bytes may be losslessly represented as tar
hardlinks, preserving every original path/checksum. Each archive file must
remain below the repository hosting limit; use the CJK-reviewed lossless
storage format if needed and prove decoded tar identity when recompressing.

## Visible result and verification interface

Prepare `AGGRESSIVE-FONT-SEARCH.md` and
`SUMMARY-AGGRESSIVE-FONT-SEARCH.md` only after actual completed results are
available. Each should distinguish hinting work, outline geometry and net
application savings. Report absolute per-glyph microseconds and application
milliseconds first. Synthetic costs are not evidence of an application's
cache-hit rate or net speedup. A stronger selected font needs a fresh,
balanced application comparison with same-cohort Rye and Vollkorn controls.

A final `aggressive-persistence-manifest.json` should bind the reports, report
inputs, visible static/native/application tables, exact audit sources and
completed audit artifacts. Initially incomplete templates must remain
explicitly `complete: false`. Do not copy a stale completed flag from CJK.

Add these only when the actual auditors support the necessary offline inputs:

- An aggressive native suite, selecting all three declared native roots and
  retaining each root's trials/repeats/profile/coverage protocol. It should
  independently verify request counts, raw duration arithmetic, order and
  source/font/lock identities; include rejected process records rather than
  making the old ASCII precondition disappear. Reuse the existing generic
  `independent_cjk_native_audit.py`: its `--screen LABEL ROOT`, `--path-map`,
  `--allow-missing-binaries` and `--output` arguments already support arbitrary
  labels. Add the explicit suite name and shared dispatch/materialization
  branch rather than copying the same independent numerical implementation.
- Application screening audit plans for each actual completed cohort. The
  existing independent English demo auditor is generic enough to consider,
  but its dimensions, current collector identity and required cross-campaign
  source dependencies must be verified from the new data.
- A confirmation audit only for a separately frozen and completed final
  campaign. Reuse an existing auditor if it validates the real schema; never
  rename a historical cohort or fabricate its expected directory structure.

Full archive materialization is required for these suites because they audit
font/source bytes, not merely JSON/CSV metadata. Cross-campaign historical
paths should resolve through the existing longest-prefix verified path map.
Compiled binaries are intentionally omitted; preserve their original live
identity checks and make the offline missing-binary policy explicit.

## Stage and installation checklist

1. Require the installed CJK baseline and verify its index, visible copy
   manifest and bundled source manifest. Record the exact baseline hashes.
2. Validate every declared completed audit against its source digest and
   original input bindings. Require each declared font asset's pinned Git blob
   identity and unchanged license/metadata bytes.
3. Prepare a fresh stage outside the source and destination repositories.
   Copy only the additive archive, reports, declared visible artifacts and
   required auditor/installer sources. Do not change old result reports.
4. Adapt `verify-results.py` only to add the new visible report-input binding,
   full materialization and explicit audit dispatch. Append `archive-study.py`
   registration. Reuse the CJK archive helper/storage support without another
   prune or decoder change unless a concrete new target/storage need exists.
5. Append the README link, index entries and visible copy bindings. Every new
   visible file must resolve back to an identical archived source file.
6. Produce a complete installation plan that binds old repository files,
   staged bytes and audited live inputs. Review the staged diff and archive
   dimensions before installation.
7. Create a disposable view of the baseline plus stage, then verify its new
   archive and every declared new audit offline. Keep stdout/stderr, path maps,
   audit outputs and verification artifact. No build or renderer is needed.
8. Root reviews the concrete stage and performs the actual repository write
   under the normal filesystem approval policy. Recheck historical hashes and
   run verification against the installed repository. No commit/push is
   implied by this staging plan.

## Current blockers to a final manifest

All three native and exploratory application cohorts have completed their
live independent audits. The original exact rational demo effects auditor is
preserved unchanged; its separately source-bound archive-capable adaptation
also passed all three live cohorts, with all compiled bodies present. It
checks font/source/build/raw/order identities without importing frozen
collectors or wrappers. A relocated extraction and explicit missing-binary
policy check still belongs to disposable-view installation verification.

The primary selection is separately frozen in
`primary-selection-v1/{selection.json,protocol.json}`: WaterBrush-Regular,
DiplomataSC-Regular, FleurDeLeah-Regular, Rye-Regular and Vollkorn-Medium.
Its recorded commands declare the actual pixel/CPU/analysis/audit paths.
Collection and its independent final audit remain pending. No winning-font
or completed-confirmation claim is assigned to that unfinished operation.
