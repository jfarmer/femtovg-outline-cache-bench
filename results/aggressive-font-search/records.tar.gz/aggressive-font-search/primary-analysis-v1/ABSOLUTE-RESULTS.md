# Fresh unchanged-demo confirmation

Absolute CPU host drawing results for fresh five-font unchanged-demo confirmation, requested DPR2. Twelve balanced blocks, five trials, 10,000 shared whole-block percentile bootstrap resamples. Positive savings compare complete current patch against master; positive warm/pan costs mean the patch is slower. Intervals are conditional on selected fonts and unadjusted for multiple endpoints.

| Font | Master first paint (ms) | Patch first paint (ms) | Saved (95% CI, ms) | Saved in 65 frames (95% CI, ms) |
|---|---:|---:|---:|---:|
| WaterBrush-Regular | 7.516 | 4.866 | 2.650 [2.561, 2.745] | 50.339 [48.993, 51.827] |
| DiplomataSC-Regular | 6.741 | 3.982 | 2.759 [2.710, 2.808] | 57.300 [55.575, 59.664] |
| FleurDeLeah-Regular | 6.703 | 4.431 | 2.272 [2.209, 2.332] | 42.830 [38.325, 45.503] |
| Rye-Regular | 6.422 | 3.744 | 2.677 [2.617, 2.736] | 53.855 [52.769, 55.022] |
| Vollkorn-Medium | 6.759 | 4.488 | 2.271 [2.173, 2.386] | 46.087 [44.351, 48.492] |

| Font | Additional first-paint saving against fresh Rye (µs, 95% CI) |
|---|---:|
| WaterBrush-Regular | -27.36 [-114.19, +79.11] |
| DiplomataSC-Regular | +81.79 [+29.42, +142.95] |
| FleurDeLeah-Regular | -405.44 [-462.32, -348.56] |
| Vollkorn-Medium | -406.64 [-524.39, -256.54] |

DiplomataSC saves a modest additional 81.79 µs on the prespecified first-paint endpoint against Rye in this selected demonstration workload. WaterBrush’s additional-saving interval crosses zero; this does not establish equivalence. Fleur and Vollkorn save less than Rye here. Every selected font improves first paint, both zoom phases and the recorded 65-frame sequence against master.

| Font | Warm cost (µs/frame, 95% CI) | Pan cost (µs/frame, 95% CI) |
|---|---:|---:|
| WaterBrush-Regular | +0.05 [-1.83, +1.73] | -1.12 [-2.53, +0.32] |
| DiplomataSC-Regular | +1.64 [-0.25, +3.26] | -0.76 [-3.26, +1.56] |
| FleurDeLeah-Regular | -0.21 [-2.65, +2.70] | +2.37 [-1.29, +7.86] |
| Rye-Regular | -0.03 [-1.20, +1.20] | +0.23 [-2.34, +3.45] |
| Vollkorn-Medium | +1.10 [-0.19, +2.49] | +0.40 [-1.59, +2.12] |

All warm/pan intervals include zero in this confirmation. That leaves small overheads uncertain and does not establish an unqualified performance improvement. The complete-patch comparison includes outline retention, run preparation, classification changes and the bitmap-phase correctness fixes. A separately frozen retention ablation is needed to attribute savings to retained outlines alone.

Only the regular font changes. Geometry, glyph widths, line wrapping and cache reuse differ between fonts; standalone native outline cost or stored hint-byte totals do not predict application savings on their own. The 65-frame total excludes the 119 unmeasured warmup frames. These host drawing results are neither end-to-end startup nor FPS estimates. Earlier full-scene benchmarks and all 47 exploratory font candidates remain preserved.

Verification passes with empty stderr: 120 processes and 3,000 original rows, native-reference atlas counts, live font/source/executable/RGBA bytes, 6 AB plus 6 BA pairs per font, and independently regenerated shared bootstrap indices. The independent auditor agrees on all 90 endpoints, 184 intervals and four same-block control advantages. The pixel campaign captures 75 images from 15 processes; patch images match the native actual-offset oracle, and original-master differences remain recorded.

Original [summary.json](summary.json), [all endpoint results](summary.csv), [paired processes](paired-processes.csv), [raw and live-input audit](raw-audit.json), [independent bootstrap audit](independent-audit.json), and [absolute machine-readable results](absolute-results.json) retain the evidence.
