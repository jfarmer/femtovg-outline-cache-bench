#!/usr/bin/env python3
"""Bind final Latin study reports and actual completed artifacts for staging.

This performs hashes and metadata reads, never builds or runs a renderer.
Do not execute during root's quiet timing window. It refuses absent core
results, report/input changes, incomplete confirmation or duplicate visible
destinations; it never overwrites a previously completed final manifest.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
COHORTS = (("broad-29", ""), ("hinted-10", "hinted-supplement-v1"),
           ("ornate-8", "ornate-supplement-v1"))
VISIBLE = Path("analysis/aggressive-font-search")
STATIC = ("font-inspection.json", "font-inspection.csv", "hinter-metadata.json",
          "static-priors.json", "static-priors.csv", "native-prescreen-audit.json",
          "native-prescreen-audit.csv", "native-prescreen-ranking.json", "native-prescreen-ranking.csv")
APPLICATION = ("analysis.json", "effects.csv", "summary.md",
               "independent-fraction-audit.json", "archive-fraction-audit.json")
PRIMARY_ANALYSIS = ("summary.json", "summary.csv", "primary-table.md", "paired-processes.csv",
                    "raw-audit.json", "bootstrap-indices.json", "analysis-inputs.json", "independent-audit.json")


def load(path):
    return json.loads(Path(path).read_text())


def binding(path):
    path = Path(path).resolve(strict=True)
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"sha256": digest, "bytes": path.stat().st_size}


def complete(path):
    value = load(path)
    if value.get("complete") is not True:
        raise ValueError("Completed evidence required: " + str(path))
    return value


def safe(value):
    path = Path(value)
    if path.is_absolute() or not value or any(x in ("", ".", "..") for x in value.split("/")):
        raise ValueError("Safe relative path required: " + repr(value))
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--confirmation", type=Path,
        help="Completed JSON with completed_audit, audit_plan and optional visible source/destination map")
    group.add_argument("--confirmation-protocol", type=Path,
        help="Actual frozen selection protocol; derive the independent audit plan from its recorded command")
    parser.add_argument("--extra-visible", type=Path,
        help="Optional explicit JSON source-relative/destination-relative map for additional mechanism/report artifacts")
    parser.add_argument("--bind", type=Path, action="append", default=[],
        help="Additional exact report input; relative paths resolve under this study root")
    args = parser.parse_args()
    manifest_path = ROOT / "aggressive-persistence-manifest.json"
    inputs_path = ROOT / "AGGRESSIVE-FONT-SEARCH.inputs.json"
    if manifest_path.exists() or inputs_path.exists():
        raise ValueError("Fresh final manifest/input paths required; preserve older completed artifacts")
    manifest = load(ROOT / "aggressive-persistence-manifest.template.json")
    if manifest["complete"] is not False:
        raise ValueError("Explicitly incomplete source template required")
    confirmation_input = args.confirmation or args.confirmation_protocol
    if args.confirmation_protocol:
        protocol = complete(args.confirmation_protocol)
        if protocol.get("source_only_protocol") is not True:
            raise ValueError("Frozen source-only primary protocol required")
        command = protocol["commands"]["independent_audit"]
        script = str(ROOT / "demo-confirmation-analysis-v1/independent_demo_confirmation_audit.py")
        if command.count(script) != 1:
            raise ValueError("Prepared independent confirmation auditor required")
        arguments = command[command.index(script) + 1:]
        flags = {"--root": "audit_root", "--cpu": "cpu", "--gpu": "gpu", "--analysis": "analysis", "--selection": "selection", "--control-font": "control_font", "--collector-fix-proof": "collector_fix_proof", "--output": "completed_audit"}
        derived = {}
        for offset in range(0, len(arguments), 2):
            flag, value = arguments[offset:offset + 2]
            if flag not in flags or flags[flag] in derived:
                raise ValueError("Unexpected/duplicate frozen independent audit argument: " + flag)
            if flag != "--control-font":
                path = Path(value)
                if not path.is_absolute() or not path.is_relative_to(ROOT):
                    raise ValueError("Explicit original confirmation inputs must be under this study root")
                value = "" if path == ROOT else path.relative_to(ROOT).as_posix()
            derived[flags[flag]] = value
        completed_audit = derived.pop("completed_audit")
        derived.update(suite="aggressive-demo-confirmation", campaign="aggressive-font-search", required_campaigns=["font-stress-search", "updated-cache-examples", "cjk-font-search"])
        confirmation = {"complete": True, "completed_audit": completed_audit, "audit_plan": derived, "original_audit_command": command}
        selection = safe(Path(protocol["selection"]["path"]).relative_to(ROOT).as_posix())
        confirmation["audit_plan"].setdefault("selection", selection.as_posix())
        confirmation["visible"] = {Path(args.confirmation_protocol).resolve().relative_to(ROOT).as_posix(): (VISIBLE / "confirmation/frozen-protocol.json").as_posix()}
        if derived.get("cpu"):
            cpu_provenance = safe(derived["cpu"]) / "cpu-provenance.json"
            confirmation["visible"][cpu_provenance.as_posix()] = (VISIBLE / "confirmation/cpu-provenance.json").as_posix()
        pixel_command = protocol["commands"].get("pixels", [])
        if "--output" in pixel_command:
            pixel_root = Path(pixel_command[pixel_command.index("--output") + 1])
            if not pixel_root.is_absolute() or not pixel_root.is_relative_to(ROOT):
                raise ValueError("Frozen pixel proof must stay under the study root")
            pixels = pixel_root.relative_to(ROOT) / "pixels-provenance.json"
            confirmation["visible"][pixels.as_posix()] = (VISIBLE / "confirmation/pixels-provenance.json").as_posix()
    else:
        confirmation = complete(args.confirmation)
    plan = confirmation["audit_plan"]
    if plan["suite"] != "aggressive-demo-confirmation" or plan["campaign"] != "aggressive-font-search":
        raise ValueError("Explicit final selected-font audit plan required")
    if plan["required_campaigns"] != ["font-stress-search", "updated-cache-examples", "cjk-font-search"]:
        raise ValueError("Exact cross-campaign companion set required")
    final_audit = complete(ROOT / safe(confirmation["completed_audit"]))
    if not final_audit.get("live_source_font_binary_rgba_checks_in_completed_analysis"):
        raise ValueError("Completed independent final confirmation required")
    visible, inputs = {}, {}

    def add(original, destination):
        original, destination = safe(str(original)), safe(str(destination))
        path = ROOT / original
        if not path.is_file():
            raise ValueError("Declared result source missing: " + str(original))
        if str(original) in visible or str(destination) in visible.values():
            raise ValueError("Duplicate visible source/destination: " + str(original))
        visible[str(original)] = str(destination)
        inputs[str(original)] = binding(path)

    def bind(original):
        path = Path(original)
        path = path if path.is_absolute() else ROOT / safe(str(path))
        key = path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else str(path)
        inputs[key] = binding(path)

    for label, child in COHORTS:
        root = Path(child)
        acquired = complete(ROOT / root / "acquired-files.json")
        if any(asset.get("complete") is not True for asset in acquired["files"]):
            raise ValueError("Unfinished font asset")
        complete(ROOT / root / "supporting/native-prescreen-audit.json")
        complete(ROOT / root / "demo-screen-v1/independent-analysis/archive-fraction-audit.json")
        for name in STATIC:
            add(root / "supporting" / name, VISIBLE / label / "native-static" / name)
        add(root / "native-prescreen-protocol-v1.json", VISIBLE / label / "native-protocol.json")
        add(root / "acquired-files.json", VISIBLE / label / "acquired-files.json")
        for name in APPLICATION:
            add(root / "demo-screen-v1/independent-analysis" / name, VISIBLE / label / "demo-screen" / name)
        add(root / "demo-selection-v1/selection.json", VISIBLE / label / "demo-selection.json")
        add(root / "demo-selection-v1/protocol.json", VISIBLE / label / "demo-protocol.json")
        add(root / "demo-screen-v1/cpu-provenance.json", VISIBLE / label / "demo-provenance.json")
        bind(root / "run_native_prescreen.py")
        bind(root / "run_aggressive_demo_screen.py")
    # Count-only engine/VM proofs are retained as supporting mechanism evidence;
    # no timing or confidence-interval scope is inferred from their existence.
    for pattern in ("supporting/engine-selection*.json", "supporting/engine-selection*.csv"):
        for path in sorted(ROOT.glob(pattern)):
            add(path.relative_to(ROOT), VISIBLE / "supporting" / path.name)
    for folder in sorted(ROOT.glob("mechanism-vm-*-v1")):
        if not folder.is_dir():
            continue
        prefix = folder.relative_to(ROOT)
        if (folder / "provenance.json").is_file():
            add(prefix / "provenance.json", VISIBLE / prefix / "provenance.json")
        for path in sorted((folder / "analysis").glob("*")):
            if path.is_file() and path.suffix in (".json", ".csv", ".md"):
                add(path.relative_to(ROOT), VISIBLE / prefix / "analysis" / path.name)
    analysis = safe(plan["analysis"]) if plan.get("analysis") else (safe(plan["audit_root"]) if plan["audit_root"] else Path()) / "analysis"
    complete(ROOT / analysis / "summary.json")
    complete(ROOT / analysis / "raw-audit.json")
    for name in PRIMARY_ANALYSIS:
        add(analysis / name, VISIBLE / "confirmation" / name)
    for field in ("selection", "collector_fix_proof"):
        if plan.get(field):
            source = safe(plan[field])
            add(source, VISIBLE / "confirmation" / (field.replace("_", "-") + source.suffix))
    for original, destination in confirmation.get("visible", {}).items():
        add(original, destination)
    if args.extra_visible:
        for original, destination in load(args.extra_visible).items():
            add(original, destination)
        bind(args.extra_visible)
    for destination, original in manifest["reports"].items():
        if not (ROOT / safe(original)).is_file():
            raise ValueError("Final report missing: " + original)
        bind(original)
    for original in ("install_aggressive_study.py", "finalize_aggressive_manifest.py",
                     "aggressive-persistence-manifest.template.json", "AGGRESSIVE-REPRODUCTION.md",
                     "supporting/audit_demo_screen_effects_archive.py", "supporting/archive-demo-auditor-source-proof.json",
                     "demo-confirmation-analysis-v1/independent_demo_confirmation_audit.py",
                     "demo-confirmation-analysis-v1/analyze_demo_confirm.py",
                     "demo-confirmation-analysis-v1/source-preparation.json"):
        bind(original)
    bind(confirmation_input)
    for original in args.bind:
        bind(original)
    manifest["visible"] = visible
    manifest["confirmations"] = [{key: confirmation[key] for key in ("completed_audit", "audit_plan", "original_audit_command") if key in confirmation}]
    manifest["analysis_audits"].append(plan)
    manifest["pending_audits"] = []
    manifest["complete"] = True
    manifest["finalized_utc"] = datetime.now(timezone.utc).isoformat()
    input_record = {"complete": True, "files": inputs,
        "scope": "Exact source/data/report bindings; native and application scopes remain those of their separately retained independent audits"}
    inputs_path.write_text(json.dumps(input_record, indent=2, sort_keys=True) + "\n")
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"complete": True, "visible_artifacts": len(visible), "audit_plans": len(manifest["analysis_audits"]), "inputs": len(inputs), "manifest": str(manifest_path)}))


if __name__ == "__main__":
    main()
