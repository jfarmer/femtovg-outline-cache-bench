# Primary unchanged-demo confirmation analysis

Font selection and matching native-offset-oracle pixels must be frozen before
fresh CPU collection: master/final, DPR2, 12 balanced blocks, five trials.
This preparation executes no collection or selection.

```sh
python3 -B analyze_demo_confirm.py --cpu CONFIRM_CPU --output FRESH_ANALYSIS --control-font Rye-Regular
python3 -B independent_demo_confirmation_audit.py --root ROOT --cpu CONFIRM_CPU --analysis FRESH_ANALYSIS --control-font Rye-Regular --output FRESH_INDEPENDENT_AUDIT
```

Default analysis verifies live source, executable, font and retained RGBA
bytes. The independent auditor separately recomputes original stdout medians,
weighted trial sequences, launch balance, seeded bootstrap indices, intervals
and same-block additional savings against Rye. Compiled/font/RGBA archive
integrity is a prerequisite for its offline mathematical audit.

Absolute microseconds and milliseconds are the primary report. Ratio fields
are retained as secondary diagnostics, and all phase costs and uncertain
intervals remain visible. Each chosen-font interval is conditional on the
exploratory selection; this is one machine and an unchanged demonstration
workload, not a population-level font threshold or end-to-end launch result.
