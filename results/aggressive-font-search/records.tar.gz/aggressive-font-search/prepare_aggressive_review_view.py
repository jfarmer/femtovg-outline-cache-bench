#!/usr/bin/env python3
"""Prepare a disposable verification view of a reviewed Latin study stage.

Check every bound visible file and archive/index entry before copying. Archive
bodies remain read-only inputs through symlinks; the actual repository and
stage are never edited. Run after renderer timing, because hashing competes
with it. Storage names/formats come from the index, not filename guessing.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def safe(value):
    path = Path(value)
    if path.is_absolute() or not value or any(part in ("", ".", "..") for part in value.split("/")):
        raise ValueError("Safe relative path required: " + repr(value))
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--view", type=Path, required=True)
    args = parser.parse_args()
    stage = args.stage.resolve(strict=True)
    proof = load(stage / "installation-plan.json")
    repo = Path(proof["repository"]).resolve(strict=True)
    source = Path(proof["source"]).resolve(strict=True)
    view = args.view.resolve()
    if not proof.get("complete") or proof.get("installed") or proof["stage"] != str(stage) or proof["new_labels"] != ["aggressive-font-search"]:
        raise ValueError("Complete uninstalled Latin plan for this exact stage required")
    if view.exists() or any(view.is_relative_to(root) for root in (repo, stage, source)):
        raise ValueError("Fresh review view outside repository/stage/source required")
    baseline = load(repo / "results/index.json")
    planned = load(stage / "results/index.json")
    if (len(baseline["campaigns"]), len(baseline["analysis_audits"])) != (31, 15):
        raise ValueError("Installed CJK baseline31/15 required")
    if planned["campaigns"][:31] != baseline["campaigns"] or planned["analysis_audits"][:15] != baseline["analysis_audits"]:
        raise ValueError("Historical campaign/audit entry changed")
    if len(planned["campaigns"]) != 32:
        raise ValueError("Exactly one additive campaign required")
    archive_paths = {str(safe(c["path"]) / safe(c["archive"]["path"])) for c in planned["campaigns"]}
    for name, expected in proof["old_repository_file_sha256"].items():
        safe(name)
        if sha(repo / name) != expected:
            raise ValueError("Repository changed after staging: " + name)
    for name, expected in proof["staged_files"].items():
        path = stage / safe(name)
        if not path.is_file() or sha(path) != expected["sha256"] or path.stat().st_size != expected["bytes"]:
            raise ValueError("Reviewed staged file changed: " + name)
    view.mkdir(parents=True)
    for name in proof["old_repository_file_sha256"]:
        if name in archive_paths:
            continue
        destination = view / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(repo / name, destination)
    for name in proof["staged_files"]:
        if name in archive_paths:
            continue
        destination = view / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(stage / name, destination)
    for campaign in planned["campaigns"]:
        relative = safe(campaign["path"]) / safe(campaign["archive"]["path"])
        archive = stage / relative if (stage / relative).is_file() else repo / relative
        if not archive.is_file() or archive.stat().st_size != campaign["archive"]["bytes"]:
            raise ValueError("Declared compressed archive missing or wrong size: " + str(relative))
        destination = view / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.symlink_to(archive)
    print("Disposable Latin study review view prepared:", view)
    print("Verify with:", view / "scripts/verify-results.py", "--campaign aggressive-font-search --output <fresh-path>")


if __name__ == "__main__":
    main()
