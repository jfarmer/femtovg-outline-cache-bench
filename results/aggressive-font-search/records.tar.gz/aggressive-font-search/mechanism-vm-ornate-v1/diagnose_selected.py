#!/usr/bin/env python3
"""Reuse sealed VM count binaries; collection and analysis are separate.

Only WaterBrush, LavishlyYours and DiplomataSC need fresh count runs. Exact
Rye/Vollkorn/Fleur files were already diagnosed and are bound, never rerun.
This script records no timings and performs no builds or dependency edits.
"""
import argparse
import ast
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
DIAGNOSTIC = Path('/private/tmp/femtovg-cjk-font-search-20261002/mechanism-diagnostic')
ORIGINAL_AUDITOR = DIAGNOSTIC.parent / 'supporting/analyze_mechanism_diagnostic.py'
CHOICES = {
    'WaterBrush-Regular': BASE / 'ornate-supplement-v1/native-prescreen-v1/provenance.json',
    'LavishlyYours-Regular': BASE / 'ornate-supplement-v1/native-prescreen-v1/provenance.json',
    'DiplomataSC-Regular': BASE / 'native-prescreen-v1/provenance.json',
}
REUSED = BASE / 'mechanism-vm-supplement-v1/analysis/count-summary.json'
REUSED_PROVENANCE = BASE / 'mechanism-vm-supplement-v1/provenance.json'
REUSED_LABELS = ['FleurDeLeah-Regular', 'Rye-Regular', 'Vollkorn-Medium']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def info(path):
    return {'path': str(path), 'sha256': sha(path), 'bytes': Path(path).stat().st_size}


def tree(path):
    return {str(p.relative_to(path)): sha(p) for p in sorted(Path(path).rglob('*')) if p.is_file()}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def check_sealed_sources():
    prep = json.loads((DIAGNOSTIC / 'prepare.json').read_text())
    assert prep['complete']
    assert tree(Path(prep['original_skrifa'])) == prep['original_skrifa_files']
    assert tree(DIAGNOSTIC / 'vendor/skrifa') == prep['instrumented_skrifa_files']
    assert sha(DIAGNOSTIC / 'package-native/src/main.rs') == sha(DIAGNOSTIC / 'package-counted/src/main.rs') == prep['driver_sha256']
    return prep


def check_reused_counts():
    reused = json.loads(REUSED.read_text())
    proof = json.loads(REUSED_PROVENANCE.read_text())
    assert reused['complete'] and reused['count_only'] and reused['vm_error_count'] == 0
    assert proof['complete'] and proof['count_only'] and len(proof['launches']) == 6
    assert reused['prepare_sha256'] == proof['prepare_sha256'] == sha(DIAGNOSTIC / 'prepare.json')
    assert reused['runs_provenance_sha256'] == sha(REUSED_PROVENANCE)
    assert set(row['font'] for row in reused['cases']) == set(REUSED_LABELS)
    for path, expected in reused['checked_raw_files'].items():
        assert sha(path) == expected
    for launch in proof['launches']:
        assert launch['complete'] and launch['exit_code'] == 0
        assert sha(launch['font_file']['path']) == launch['font_file']['sha256']
        assert sha(launch['build']) == launch['build_sha256']
        for field in ['stdout', 'stderr']:
            assert sha(launch[field]) == launch[field + '_sha256']
        assert {row['font_sha256'] for row in reused['cases'] if row['font'] == launch['font']} == {launch['font_file']['sha256']}
    return reused


def collect():
    assert not (ROOT / 'provenance.json').exists(), 'Preserve earlier attempts; use a fresh campaign.'
    check_sealed_sources()
    check_reused_counts()
    proof = {
        'complete': False, 'count_only': True, 'no_timing_results': True,
        'driver_sha256': sha(Path(__file__)), 'prepare_sha256': sha(DIAGNOSTIC / 'prepare.json'),
        'choices': {'en': list(CHOICES)}, 'launches': [], 'reused_counts': info(REUSED),
        'reused_provenance': info(REUSED_PROVENANCE),
        'scope': 'Three new unmodified regular font files using sealed original/count binaries. Both profiles and DPRs retained; DPR1 matches demo initial outline sizes. Exact previously counted Fleur/Rye/Voll files are reused, not rerun.',
    }
    write(ROOT / 'provenance.json', proof)
    for mode in ['native', 'counted']:
        build_path = DIAGNOSTIC / ('build-' + mode + '-01/build.json')
        built = json.loads(build_path.read_text())
        assert built['complete'] and sha(built['binary']) == built['binary_sha256']
        for label, reference_path in CHOICES.items():
            reference = json.loads(reference_path.read_text())
            assert reference['complete']
            font = reference['fonts'][label]
            assert sha(font['path']) == font['sha256']
            stem = mode + '-en-' + label
            command = [built['binary'], font['path'], font['sha256'], 'en']
            launch = {
                'complete': False, 'mode': mode, 'locale': 'en', 'font': label,
                'font_file': font, 'build': str(build_path), 'build_sha256': sha(build_path),
                'native_reference': info(reference_path), 'command': command,
                'stdout': str(ROOT / (stem + '.jsonl')), 'stderr': str(ROOT / (stem + '.stderr')),
            }
            proof['launches'].append(launch)
            write(ROOT / 'provenance.json', proof)
            with Path(launch['stdout']).open('x') as out, Path(launch['stderr']).open('x') as err:
                result = subprocess.run(command, stdout=out, stderr=err, timeout=120)
            launch.update(exit_code=result.returncode, stdout_sha256=sha(launch['stdout']), stderr_sha256=sha(launch['stderr']))
            write(ROOT / 'provenance.json', proof)
            assert result.returncode == 0, 'Failed count attempt and partial outputs retained.'
            rows = [json.loads(line) for line in Path(launch['stdout']).read_text().splitlines()]
            audits = [row for row in rows if row['kind'] == 'audit']
            assert len(audits) == 20
            original_launch = next(item for item in reference['launches'] if item['font'] == label)
            assert original_launch['complete']
            originals = list(csv.DictReader(Path(original_launch['stdout']).open()))
            for audit in audits:
                matches = [row for row in originals if (row['profile'], int(row['dpr']), float(row['logical_size'])) == (audit['profile'], audit['dpr'], audit['logical_size'])]
                assert len(matches) == 16
                for original in matches:
                    assert all(int(original[field]) == audit[field] for field in ['glyphs', 'points', 'verbs', 'audit_images'])
                    assert original['audit_digest'] == audit['audit_digest']
            assert sha(font['path']) == font['sha256'] and sha(built['binary']) == built['binary_sha256']
            launch.update(complete=True, rows=len(rows), case_audits=20,
                          native_retained_counts_and_alpha_digests_exact=True,
                          native_reference_stdout=info(Path(original_launch['stdout'])))
            write(ROOT / 'provenance.json', proof)
            print(stem + ': retained native geometry/counts and ten-phase alpha exact', flush=True)
    for label in CHOICES:
        pair = [launch for launch in proof['launches'] if launch['font'] == label]
        rows = [[json.loads(line) for line in Path(launch['stdout']).read_text().splitlines()] for launch in pair]
        assert len(rows[0]) == len(rows[1])
        for native, counted in zip(*rows):
            assert {k: v for k, v in native.items() if k != 'counts'} == {k: v for k, v in counted.items() if k != 'counts'}
    check_sealed_sources()
    check_reused_counts()
    assert info(REUSED) == proof['reused_counts']
    assert info(REUSED_PROVENANCE) == proof['reused_provenance']
    proof.update(complete=True, original_native_alpha_case_matches=120,
                 native_counted_hinted_and_unhinted_outline_hashes_exact=True)
    write(ROOT / 'provenance.json', proof)
    print(json.dumps({'complete': True, 'processes': 6, 'native_alpha_cases': 120, 'timings_recorded': False}))


def analyze():
    proof = json.loads((ROOT / 'provenance.json').read_text())
    assert proof['complete'] and proof['count_only'] and len(proof['launches']) == 6
    assert sha(Path(__file__)) == proof['driver_sha256']
    assert not (ROOT / 'analysis-execution.json').exists()
    original = ORIGINAL_AUDITOR.read_text()
    tail = original[original.index('lines = ["Dynamic TrueType execution diagnostic"'):]
    adapted = original[:-len(tail)]
    edits = [{'old': tail, 'new': 'Historical narrative omitted; final guards/completion retain fresh three-font scope.'}]

    def replace(old, new):
        nonlocal adapted
        assert adapted.count(old) == 1, old
        adapted = adapted.replace(old, new)
        edits.append({'old': old, 'new': new})

    replace('ROOT = BASE / "mechanism-diagnostic"', f'ROOT = Path({str(DIAGNOSTIC)!r})\nRUNS = Path({str(ROOT)!r})')
    replace('run = read(ROOT / "runs-01/provenance.json")', 'run = read(RUNS / "provenance.json")')
    replace('checked = {str(ROOT / "prepare.json"): sha(ROOT / "prepare.json"), str(ROOT / "runs-01/provenance.json"): sha(ROOT / "runs-01/provenance.json")}',
            'checked = {str(ROOT / "prepare.json"): sha(ROOT / "prepare.json"), str(RUNS / "provenance.json"): sha(RUNS / "provenance.json")}')
    replace('    reference = read(prep["native_references"][launch["locale"]]["provenance"])',
            '    assert sha(launch["native_reference"]["path"]) == launch["native_reference"]["sha256"]\n    assert sha(launch["native_reference_stdout"]["path"]) == launch["native_reference_stdout"]["sha256"]\n    checked[launch["native_reference"]["path"]] = launch["native_reference"]["sha256"]\n    checked[launch["native_reference_stdout"]["path"]] = launch["native_reference_stdout"]["sha256"]\n    reference = read(launch["native_reference"]["path"])')
    replace('assert len(all_rows) == 28 and matched_alpha_cases == run["original_native_alpha_case_matches"] == 560',
            'assert len(all_rows) == 6 and matched_alpha_cases == run["original_native_alpha_case_matches"] == 120')
    replace('out = ROOT / "analysis"', 'out = RUNS / "analysis"')
    replace('sha(ROOT / "runs-01/provenance.json")', 'sha(RUNS / "provenance.json")')
    replace('"processes": 28, "matched_native_alpha_cases"', '"processes": 6, "matched_native_alpha_cases"')
    adapted += 'for path, expected in checked.items():\n    assert sha(path) == expected\nassert tree(Path(prep["original_skrifa"])) == prep["original_skrifa_files"]\nprint(json.dumps({"complete": True, "processes": 6, "matched_native_alpha_cases": matched_alpha_cases, "vm_errors": total_vm_errors, "output": str(out)}))\n'
    ast.parse(adapted)
    auditor = ROOT / 'analyze_selected.py'
    auditor.write_text(adapted)
    write(ROOT / 'auditor-adaptation.json', {'complete': True, 'original_auditor': info(ORIGINAL_AUDITOR),
          'adapted_auditor': info(auditor), 'literal_source_edits': edits,
          'method': 'Original dispatch/origin/opcode arithmetic and native geometry/alpha/source guards retained; fresh paths, six-process cardinality and final native-reference bindings explicitly adapted.'})
    command = [sys.executable, '-B', str(auditor)]
    with (ROOT / 'analysis.stdout').open('x') as out, (ROOT / 'analysis.stderr').open('x') as err:
        status = subprocess.run(command, stdout=out, stderr=err).returncode
    write(ROOT / 'analysis-execution.json', {'complete': status == 0, 'command': command, 'exit_code': status,
          'auditor': info(auditor), 'stdout': info(ROOT / 'analysis.stdout'), 'stderr': info(ROOT / 'analysis.stderr')})
    assert status == 0
    new = json.loads((ROOT / 'analysis/count-summary.json').read_text())
    reused = check_reused_counts()
    assert info(REUSED) == proof['reused_counts']
    assert info(REUSED_PROVENANCE) == proof['reused_provenance']
    assert new['prepare_sha256'] == reused['prepare_sha256'] == sha(DIAGNOSTIC / 'prepare.json')
    assert new['vm_error_count'] == reused['vm_error_count'] == 0
    assert set(row['font'] for row in new['cases']) == set(CHOICES)
    assert set(row['font'] for row in reused['cases']) == set(REUSED_LABELS)
    combined = {
        'complete': True, 'count_only': True, 'no_timing_results': True,
        'collector_and_reporter': info(Path(__file__)), 'new_counts': info(ROOT / 'analysis/count-summary.json'),
        'reused_counts': info(REUSED), 'reused_provenance': info(REUSED_PROVENANCE),
        'prepare': info(DIAGNOSTIC / 'prepare.json'),
        'scope': 'Six exact unmodified regular font files; three fresh + three previously sealed counts. Same driver, dependencies and instrumentation. Unique ASCII94 and demo glyph profiles, not ordered production trace or application timing.',
        'cases': new['cases'] + reused['cases'],
        'profile_dpr_medians': new['profile_dpr_medians'] + reused['profile_dpr_medians'],
    }
    write(ROOT / 'analysis/combined-six-font-counts.json', combined)
    print((ROOT / 'analysis.stdout').read_text(), end='')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['collect', 'analyze'])
    args = parser.parse_args()
    {'collect': collect, 'analyze': analyze}[args.mode]()
