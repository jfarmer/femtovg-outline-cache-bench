#!/usr/bin/env python3
"""Run the preserved static inspector with frozen English demo corpora.

No rendering, timing, font mutation or production changes. Stored byte counts
and expanded points are pre-screen predictors, never executed VM counts.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[1]
INSPECTOR = Path('/private/tmp/femtovg-cjk-font-search-20261002/supporting/inspect_cjk_fonts.py')
DEMO_SOURCE = Path('/private/tmp/femtovg-cjk-font-search-20261002/mechanism-cost-screen/en/src/main.rs')
CONTROLS = {
    'Rye-Regular': Path('/private/tmp/femtovg-font-stress-search-20261002/fonts/rye/Rye-Regular.ttf'),
    'Vollkorn-Medium': Path('/private/tmp/femtovg-font-stress-search-20261002/fonts/controls/Vollkorn-Medium.ttf'),
}


def binding(path):
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    manifest = ROOT / 'acquired-files.json'
    data = json.loads(manifest.read_text())
    assert data['complete']
    source = DEMO_SOURCE.read_text()
    demo = source.split('const DEMO_TEXT:', 1)[1].split('];', 1)[0]
    values = re.findall(r'^\s*\(([0-9.]+),\s*("(?:\\.|[^"\\])*")\),', demo, flags=re.M)
    assert [float(size) for size, _ in values] == [11, 12, 14, 15, 16]
    texts = {'ascii94': ''.join(chr(i) for i in range(33, 127))}
    texts.update({'demo_' + size.replace('.0', ''): json.loads(text) for size, text in values})
    texts.update({'demo_' + size.replace('.0', '') + '_graphic':
                  ''.join(character for character in json.loads(text) if 33 <= ord(character) <= 126)
                  for size, text in values})
    corpora = {}
    command = [sys.executable, '-B', str(INSPECTOR), '--all-faces']
    files = []
    for item in data['files']:
        path = Path(item['path'])
        if path.suffix.lower() not in ('.ttf', '.ttc', '.otf'):
            continue
        actual = binding(path)
        assert actual['sha256'] == item['sha256'] and actual['bytes'] == item['bytes']
        files.append({'label': path.stem, **actual})
    files += [{'label': label, 'control': True, **binding(path)} for label, path in CONTROLS.items()]
    assert len({item['label'] for item in files}) == len(files)
    for item in files:
        command += ['--font', item['label'], item['path']]
    for name, text in texts.items():
        path = ROOT / ('supporting/corpus-' + name + '.txt')
        path.write_text(text)
        corpora[name] = binding(path)
        command += ['--text-file', name, str(path)]
    output = ROOT / 'supporting/font-inspection.json'
    command += ['--output', str(output)]
    write(ROOT / 'supporting/inspection-command.json', {
        'manifest': binding(manifest), 'inspector': binding(INSPECTOR),
        'wrapper': binding(Path(__file__)), 'frozen_english_source': binding(DEMO_SOURCE),
        'corpora': corpora, 'fonts': files, 'command': command,
    })
    with (ROOT / 'supporting/inspection.stdout').open('w') as out, (ROOT / 'supporting/inspection.stderr').open('w') as err:
        result = subprocess.run(command, stdout=out, stderr=err)
    assert result.returncode == 0, result.returncode
    inspection = json.loads(output.read_text())
    assert inspection['complete'] and inspection['inspector_sha256'] == binding(INSPECTOR)['sha256']
    extra = []
    for item in inspection['fonts']:
        with TTFont(item['path'], fontNumber=item['face_index'], lazy=False) as font:
            names = sorted({(record.nameID, record.toUnicode()) for record in font['name'].names})
            markers = [(name_id, value) for name_id, value in names
                       if re.search(r'ttfautohint|autohint|fontforge|glyphs|fontlab|fontcreator|fontographer|typetool|vtt|visual truetype|fontmake|makeotf', value, re.I)]
            ttfa = font.getTableData('TTFA') if 'TTFA' in font else b''
            extra.append({
                'label': item['label'], 'font_sha256': item['sha256'], 'face_index': item['face_index'],
                'creator_hinter_markers': [{'name_id': n, 'value': v} for n, v in markers],
                'name_records': [{'name_id': n, 'value': v} for n, v in names],
                'TTFA_present': bool(ttfa), 'TTFA_bytes': len(ttfa),
                'TTFA_ascii': ttfa.decode('ascii', errors='backslashreplace') if ttfa else None,
                'TTFA_sha256': hashlib.sha256(ttfa).hexdigest() if ttfa else None,
            })
    write(ROOT / 'supporting/hinter-metadata.json', {
        'complete': True, 'inspection': binding(output), 'inspector': binding(INSPECTOR),
        'wrapper': binding(Path(__file__)), 'fonts': extra,
        'method': 'Read unmodified SFNT name records and optional TTFA table. Creator strings are documentary metadata, not proof of runtime cost or interpreter selection.',
    })
    print(json.dumps({'complete': True, 'font_faces': len(inspection['fonts']), 'inspection': str(output)}))


if __name__ == '__main__':
    main()
