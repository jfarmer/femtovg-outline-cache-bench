#!/usr/bin/env python3
"""Report independent stored-byte and expanded-point predictors, not timings."""
import csv
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[1]


def mean(record):
    return record['total'] / record['count'] if record['count'] else None


def main():
    source = ROOT / 'supporting/font-inspection.json'
    data = json.loads(source.read_text())
    metadata_source = ROOT / 'supporting/hinter-metadata.json'
    metadata = json.loads(metadata_source.read_text())
    assert data['complete'] and metadata['complete']
    assert metadata['inspection']['sha256'] == hashlib.sha256(source.read_bytes()).hexdigest()
    by_name = {(r['label'], r['face_index']): r for r in metadata['fonts']}
    rows = []
    for font in data['fonts']:
        raw = font['corpora']['ascii94']
        ascii94 = raw['renderable_excluding_only_cc_controls']
        demo = [font['corpora'][f'demo_{size}_graphic']['renderable_excluding_only_cc_controls']
                for size in [11, 12, 14, 15, 16]]
        extra = by_name[(font['label'], font['face_index'])]
        glyph_programs = font['direct_glyf_program_bytes_all_glyphs']
        row = {
            'label': font['label'], 'font_sha256': font['sha256'], 'path': font['path'],
            'outline_type': 'TrueType' if 'glyf' in font['tables'] else 'CFF/CFF2',
            'ascii94_mapped_characters': ascii94['mapped_distinct_characters'],
            'ascii94_unique_glyphs': ascii94['mapped_unique_glyphs'],
            'ascii94_original_kernel_coverage_unique_requirement_passes':
                ascii94['mapped_distinct_characters'] == 94 and ascii94['mapped_unique_glyphs'] == 94,
            'demo_graphic_coverage_complete': all(not profile['missing_codepoints'] for profile in demo),
            'glyph_program_bytes_all_glyphs': glyph_programs['total'],
            'glyph_program_max_bytes': glyph_programs['max'],
            'fpgm_bytes': font['embedded_program_tables']['fpgm'].get('program_bytes', 0),
            'prep_bytes': font['embedded_program_tables']['prep'].get('program_bytes', 0),
            'ascii94_program_mean_bytes_per_unique_glyph': None,
            'ascii94_expanded_mean_points_per_unique_glyph': None,
            'demo_five_size_median_mean_program_bytes_per_unique_glyph': None,
            'demo_five_size_median_mean_expanded_points_per_unique_glyph': None,
            'version': font['version'], 'creator_hinter_markers': extra['creator_hinter_markers'],
            'TTFA_present': extra['TTFA_present'], 'maxp': font['maxp'],
        }
        if 'glyf' in font['tables']:
            row['ascii94_program_mean_bytes_per_unique_glyph'] = mean(ascii94['direct_glyf_program_bytes_unique_glyphs'])
            row['ascii94_expanded_mean_points_per_unique_glyph'] = mean(ascii94['expanded_points_unique_glyphs'])
            row['demo_five_size_median_mean_program_bytes_per_unique_glyph'] = statistics.median(
                mean(profile['direct_glyf_program_bytes_unique_glyphs']) for profile in demo)
            row['demo_five_size_median_mean_expanded_points_per_unique_glyph'] = statistics.median(
                mean(profile['expanded_points_unique_glyphs']) for profile in demo)
        rows.append(row)
    controls = {r['label']: r for r in rows if r['label'] in ['Rye-Regular', 'Vollkorn-Medium']}
    assert len(controls) == 2
    prediction_keys = ['ascii94_program_mean_bytes_per_unique_glyph', 'ascii94_expanded_mean_points_per_unique_glyph',
                       'demo_five_size_median_mean_program_bytes_per_unique_glyph',
                       'demo_five_size_median_mean_expanded_points_per_unique_glyph']
    for row in rows:
        row['ratios_vs_Rye'] = {key: row[key] / controls['Rye-Regular'][key] if row[key] is not None else None
                                for key in prediction_keys}
    proof = {
        'complete': True, 'reporter_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'inspection_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'hinter_metadata_sha256': hashlib.sha256(metadata_source.read_bytes()).hexdigest(),
        'method': 'Independent static priors: ASCII94 unique glyph means and median of five logical-size English-demo unique-graphic-glyph means. Original demo UTF-8 corpora are retained alongside ASCII-graphic subsets. Unscaled unhinted default-instance composite-expanded points and direct stored glyph bytes are separate predictors; neither measures dynamic function/loop execution or performance. No fonts are mutated or dropped for aliases.',
        'fonts': rows,
    }
    out = ROOT / 'supporting/static-priors.json'
    out.write_text(json.dumps(proof, indent=2) + '\n')
    flat = [{**{k: v for k, v in r.items() if k not in ['creator_hinter_markers', 'maxp', 'ratios_vs_Rye']},
             **{'maxp_' + k: v for k, v in r['maxp'].items()},
             **{'Rye_ratio_' + k: v for k, v in r['ratios_vs_Rye'].items()}} for r in rows]
    fields = list(flat[0]) + sorted(set().union(*(set(row) for row in flat)) - set(flat[0]))
    with out.with_suffix('.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader(); writer.writerows(flat)
    for key in prediction_keys:
        print('\n' + key)
        for row in sorted(rows, key=lambda r: r[key] or -1, reverse=True):
            print(row['label'], f'{row[key]:.3f}' if row[key] is not None else 'NA',
                  'RyeRatio', f'{row["ratios_vs_Rye"][key]:.3f}' if row[key] is not None else 'NA',
                  'ASCIIunique', row['ascii94_unique_glyphs'])
    print(json.dumps({'complete': True, 'output': str(out), 'font_faces': len(rows)}))


if __name__ == '__main__':
    main()
