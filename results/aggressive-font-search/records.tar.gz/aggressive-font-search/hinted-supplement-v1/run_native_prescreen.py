#!/usr/bin/env python3
"""Freeze, collect, or independently analyze the exploratory native prescreen.

Only collect executes timing kernels. It delegates unchanged to the preserved
screen.py, retaining all rejected font processes and their stderr. Root owns
quiet collection scheduling. No build or font transformation is performed.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OLD = Path('/private/tmp/femtovg-font-stress-search-20261002')
AUDITOR = Path('/private/tmp/femtovg-cjk-font-search-20261002/supporting/audit_native_screens.py')
PROTOCOL = ROOT / 'native-prescreen-protocol-v1.json'
CAMPAIGN = ROOT / 'native-prescreen-v1'
BUILD = OLD / 'build/build.json'
CONTROL_HASHES = {
    'Rye-Regular': ('fonts/rye/Rye-Regular.ttf', 'b7edee5e615ae1b6b07e9d030c1309152bf3672a0e8a2a46293e273730f5adba'),
    'Vollkorn-Medium': ('fonts/controls/Vollkorn-Medium.ttf', 'b704817fe4433aa674c54f87141f2541d88d7d48342d98ec727a5eed4873a892'),
}


def info(path, expected=None):
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if expected is not None:
        assert digest == expected, str(path)
    return {'path': str(path), 'sha256': digest, 'bytes': len(raw)}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def freeze():
    assert not PROTOCOL.exists(), 'Keep the original frozen protocol; use a separate version for changes.'
    manifest = ROOT / 'acquired-files.json'
    acquired = json.loads(manifest.read_text())
    assert acquired['complete']
    built = json.loads(BUILD.read_text())
    assert built['complete']
    inputs = json.loads((OLD / 'inputs.json').read_text())
    bindings = [info(manifest), info(BUILD), info(OLD / 'inputs.json', built['source_inputs_sha256']),
                info(OLD / 'screen.py', built['driver_sha256']), info(built['binary'], built['binary_sha256']),
                info(OLD / 'build/metadata.json', built['metadata_sha256']),
                info(OLD / 'Cargo.lock', built['lock_sha256']), info(AUDITOR), info(Path(__file__))]
    bindings += [info(OLD / name, digest) for name, digest in inputs['screen_files'].items()]
    native = inputs['native_sources']
    bindings += [info(Path(native[key]) / name, digest)
                 for key in ['registry_swash_source', 'local_swash_source']
                 for name, digest in native['source_files'].items()]
    inspection_path = ROOT / 'supporting/font-inspection.json'
    static_path = ROOT / 'supporting/static-priors.json'
    inspection = json.loads(inspection_path.read_text())
    static = json.loads(static_path.read_text())
    assert inspection['complete'] and static['complete']
    bindings += [info(inspection_path, static['inspection_sha256']), info(static_path)]
    fonts = []
    for item in acquired['files']:
        path = Path(item['path'])
        if path.suffix.lower() not in ['.ttf', '.ttc', '.otf']:
            continue
        bound = info(path, item['sha256']); assert bound['bytes'] == item['bytes']
        fonts.append({'label': path.stem, 'control': False, **bound})
    for label, (relative, digest) in CONTROL_HASHES.items():
        fonts.append({'label': label, 'control': True, **info(OLD / relative, digest)})
    assert len({font['label'] for font in fonts}) == len(fonts)
    inspected = {(item['label'], item['sha256']) for item in inspection['fonts']}
    assert {(font['label'], font['sha256']) for font in fonts} == inspected
    bindings += [{k: value for k, value in font.items() if k in ['path', 'sha256', 'bytes']} for font in fonts]
    collect = [sys.executable, '-B', str(OLD / 'screen.py'), 'run', '--build', str(BUILD),
               '--output', str(CAMPAIGN), '--mode', 'timing', '--trials', '4', '--repeats', '3',
               '--rounds', '1', '--timeout', '180']
    for font in fonts:
        collect += ['--font', font['label'], font['path']]
    legacy = [sys.executable, '-B', str(OLD / 'screen.py'), 'analyze', '--root', str(CAMPAIGN)]
    independent = [sys.executable, '-B', str(AUDITOR), '--screen', 'aggressive', str(CAMPAIGN),
                   '--output', str(ROOT / 'supporting/native-prescreen-audit.json')]
    write(PROTOCOL, {
        'complete': True, 'source_only_protocol': True, 'collection_executed': False,
        'font_count_including_controls': len(fonts), 'fonts': fonts, 'bindings': bindings,
        'collect_command': collect, 'legacy_analyze_command': legacy, 'independent_audit_command': independent,
        'trials': 4, 'repeats': 3, 'rounds': 1, 'timeout_seconds': 180,
        'scope': 'Exploratory prepared native font-cost prescreen only; unchanged old screen.py and executable. Preserve all rejected fonts. Analyze each profile/DPR separately: per-case trial medians followed by median of five logical sizes. DPR1 outlines match actual first-paint 11/12/14/15/16px sizes; DPR2 outlines are 22/24/28/30/32px. No confidence intervals, cache overhead, predicted application savings or percentage claims.',
    })
    print(json.dumps({'complete': True, 'font_processes': len(fonts), 'protocol': str(PROTOCOL), 'timing_executed': False}))


def guard():
    protocol = json.loads(PROTOCOL.read_text())
    assert protocol['complete'] and protocol['source_only_protocol']
    for binding in protocol['bindings']:
        actual = info(binding['path'], binding['sha256'])
        assert actual['bytes'] == binding['bytes']
    return protocol


def execute(name, command):
    record_path = ROOT / ('supporting/' + name + '-execution.json')
    assert not record_path.exists(), 'Retain the original execution record.'
    record = {'complete': False, 'command': command, 'protocol': info(PROTOCOL)}
    write(record_path, record)
    with (ROOT / ('supporting/' + name + '.stdout')).open('w') as out, (ROOT / ('supporting/' + name + '.stderr')).open('w') as err:
        result = subprocess.run(command, stdout=out, stderr=err)
    record.update(complete=result.returncode == 0, exit_code=result.returncode)
    write(record_path, record)
    assert result.returncode == 0, f'{name}: {result.returncode}'


def collect():
    protocol = guard()
    assert not CAMPAIGN.exists(), 'Retain old attempts; do not overwrite a campaign.'
    execute('native-prescreen-collect', protocol['collect_command'])
    guard()
    print(json.dumps({'complete': True, 'campaign': str(CAMPAIGN)}))


def analyze():
    protocol = guard()
    execute('native-prescreen-legacy-analysis', protocol['legacy_analyze_command'])
    execute('native-prescreen-independent-audit', protocol['independent_audit_command'])
    source = ROOT / 'supporting/native-prescreen-audit.json'
    audited = json.loads(source.read_text())
    assert audited['complete']
    assert len(audited['screens']) == 1
    screen = audited['screens'][0]
    assert (screen['trials'], screen['repeats'], screen['rounds']) == (4, 3, 1)
    rows = sorted(audited['profile_dpr_medians'], key=lambda row: (row['dpr'], row['profile'], -row['native_outline_us_per_glyph']))
    out = ROOT / 'supporting/native-prescreen-ranking.json'
    write(out, {'complete': True, 'audit': info(source), 'protocol': info(PROTOCOL),
                'method': protocol['scope'], 'rows': rows, 'rejections': screen['rejected_launches'],
                'rows_checked': screen['raw_rows_checked'], 'reporter': info(Path(__file__))})
    with out.with_suffix('.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    guard()
    print(json.dumps({'complete': True, 'output': str(out), 'rejected_launches': len(screen['rejected_launches']),
                      'rows_checked': screen['raw_rows_checked']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['freeze', 'collect', 'analyze'])
    args = parser.parse_args()
    {'freeze': freeze, 'collect': collect, 'analyze': analyze}[args.command]()
