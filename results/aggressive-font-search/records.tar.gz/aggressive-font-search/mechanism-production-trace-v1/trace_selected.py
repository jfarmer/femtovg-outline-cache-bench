#!/usr/bin/env python3
"""Collect untimed English cache events with the sealed old trace binaries.

No builds, modified fonts or timing results. Fresh traces bind exact atlas
counts to preserved application stdout. Collection is explicitly separate.
"""
import argparse
import ast
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
CJK = Path('/private/tmp/femtovg-cjk-font-search-20261002')
SEALED = CJK / 'mechanism-production-trace-v2'
ORIGINAL_DRIVER = CJK / 'production_count_trace_v2.py'
ORIGINAL_ANALYZER = CJK / 'analyze_production_count_trace.py'
CHOICES = {
    'WaterBrush-Regular': BASE / 'ornate-supplement-v1/demo-screen-v1/cpu-provenance.json',
    'LavishlyYours-Regular': BASE / 'ornate-supplement-v1/demo-screen-v1/cpu-provenance.json',
    'Rye-Regular': BASE / 'ornate-supplement-v1/demo-screen-v1/cpu-provenance.json',
    'Vollkorn-Medium': BASE / 'ornate-supplement-v1/demo-screen-v1/cpu-provenance.json',
    'DiplomataSC-Regular': BASE / 'demo-screen-v1/cpu-provenance.json',
    'FleurDeLeah-Regular': BASE / 'hinted-supplement-v1/demo-screen-v1/cpu-provenance.json',
}


def info(path):
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def sealed_guard():
    spec = importlib.util.spec_from_file_location('original_sealed_production_trace', ORIGINAL_DRIVER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    prepared = module.check_prepare()
    built = json.loads((SEALED / 'build.json').read_text())
    audited = json.loads((SEALED / 'independent-count-audit.json').read_text())
    assert prepared['complete'] and built['complete'] and audited['complete']
    assert audited['prepare'] == info(SEALED / 'prepare.json')
    assert audited['build'] == info(SEALED / 'build.json')
    assert prepared['driver'] == info(ORIGINAL_DRIVER)
    by_name = {item['name']: item for item in built['launches']}
    for version in ['master', 'final']:
        item = by_name['en-' + version]
        assert item['complete'] and info(item['binary']['path']) == item['binary']
        assert info(item['lockfile']['path']) == item['lockfile']
    return by_name


def collect():
    assert not (ROOT / 'trace-campaign.json').exists(), 'Keep prior and failed trace attempts.'
    builds = sealed_guard()
    record = {
        'complete': False, 'driver': info(Path(__file__)), 'sealed_driver': info(ORIGINAL_DRIVER),
        'build': info(SEALED / 'build.json'), 'prepare': info(SEALED / 'prepare.json'),
        'sealed_source_and_graph_audit': info(SEALED / 'independent-count-audit.json'),
        'launches': [],
        'method': 'One CPU-only Void replay per regular-font override/version using sealed English trace executables, requested DPR2,184 frames including119 warmups. Event streams and atlas counts only; every diagnostic duration is ignored. This is neither timing nor a pixel proof.',
    }
    write(ROOT / 'trace-campaign.json', record)
    for label, reference_path in CHOICES.items():
        reference = json.loads(reference_path.read_text())
        assert reference['complete'] and reference['mode'] == 'cpu'
        font = reference['font_files'][label]
        assert info(font['path']) == font
        for version in ['master', 'final']:
            built = builds['en-' + version]
            binary = built['binary']
            original = next(item for item in reference['launches']
                            if item['font'] == label and item['version'] == version and item['block'] == 1 and item['dpi'] == 2)
            assert original['validated'] and original['exit_code'] == 0
            assert info(original['stdout']) == original['stdout_info']
            command = [binary['path'], 'cpu', '1', '2']
            environment = {'FEMTOVG_REPLAY_TEXT_FONT': font['path']}
            tag = 'en-' + label + '-' + version
            entry = {
                'locale': 'en', 'font_label': label, 'version': version, 'font': font,
                'binary': binary, 'command': command, 'cwd': str(SEALED / ('runners/en-' + version)),
                'override': environment, 'complete': False,
                'actual_demo_reference': info(reference_path),
                'actual_demo_stdout': original['stdout_info'],
            }
            record['launches'].append(entry)
            write(ROOT / 'trace-campaign.json', record)
            out = ROOT / (tag + '.stdout.csv')
            err = ROOT / (tag + '.events.tsv')
            env = os.environ.copy()
            env.update(environment)
            with out.open('x') as stdout, err.open('x') as stderr:
                status = subprocess.run(command, cwd=entry['cwd'], env=env, stdout=stdout, stderr=stderr, timeout=180).returncode
            entry.update(exit_code=status, complete=status == 0, stdout=info(out), events=info(err))
            write(ROOT / 'trace-campaign.json', record)
            assert status == 0, 'Failed trace and partial artifacts retained.'
            assert info(font['path']) == font and info(binary['path']) == binary
            print('TRACE ' + tag + ': complete; duration columns ignored', flush=True)
    sealed_guard()
    record['complete'] = True
    write(ROOT / 'trace-campaign.json', record)
    print(json.dumps({'complete': True, 'processes': 12, 'timing_results': False}))


def analyze():
    campaign = json.loads((ROOT / 'trace-campaign.json').read_text())
    assert campaign['complete'] and campaign['driver'] == info(Path(__file__))
    assert not (ROOT / 'analysis-execution.json').exists()
    sealed_guard()
    original = ORIGINAL_ANALYZER.read_text()
    adapted = original
    edits = []

    def replace(old, new):
        nonlocal adapted
        assert adapted.count(old) == 1, old
        adapted = adapted.replace(old, new)
        edits.append({'old': old, 'new': new})

    replace('ROOT=Path(__file__).resolve().parent\nWORK=ROOT/\'mechanism-production-trace-v2\'',
            f'ROOT=Path({str(CJK)!r})\nWORK=Path({str(ROOT)!r})')
    replace('  original_root=ROOT/\'english-demo-selection\' if run[\'locale\']==\'en\' else ROOT/f"confirm-{run[\'locale\']}-v2/confirm-cpu"\n  original=original_root/\'cpu-runs\'/f"01-{public_label}-dpi2-{run[\'version\']}.stdout.csv"',
            '  assert info(run["actual_demo_reference"]["path"]) == run["actual_demo_reference"]\n  assert info(run["actual_demo_stdout"]["path"]) == run["actual_demo_stdout"]\n  original=Path(run["actual_demo_stdout"]["path"])')
    ast.parse(adapted)
    auditor = ROOT / 'analyze_selected_trace.py'
    auditor.write_text(adapted)
    write(ROOT / 'analyzer-adaptation.json', {
        'complete': True, 'original': info(ORIGINAL_ANALYZER), 'adapted': info(auditor),
        'literal_source_edits': edits,
        'scope': 'Original event state machine and request-identity/atlas guards unchanged; only fresh output paths and exact actual-demo stdout bindings adapted.',
    })
    command = [sys.executable, '-B', str(auditor)]
    with (ROOT / 'analysis.stdout').open('x') as out, (ROOT / 'analysis.stderr').open('x') as err:
        status = subprocess.run(command, stdout=out, stderr=err).returncode
    write(ROOT / 'analysis-execution.json', {
        'complete': status == 0, 'command': command, 'exit_code': status,
        'analyzer': info(auditor), 'stdout': info(ROOT / 'analysis.stdout'), 'stderr': info(ROOT / 'analysis.stderr'),
    })
    assert status == 0
    analysis = json.loads((ROOT / 'counts-analysis.json').read_text())
    assert analysis['complete'] and len(analysis['runs']) == 12 and len(analysis['comparisons']) == 6
    report = {
        'complete': False, 'auditor': info(Path(__file__)), 'campaign': info(ROOT / 'trace-campaign.json'),
        'analysis': info(ROOT / 'counts-analysis.json'), 'raw_checks': [], 'elapsed_time_columns_read': 0,
        'method': 'Separate raw event recount of R/Q/H/M/B and exact requested size/glyph/coords/phase stream identity, compared with original state-machine analysis. Source/feature graphs remain sealed by prior reconstructed-edit audit and current full source guards.',
    }
    streams = {}
    for launch, item in zip(campaign['launches'], analysis['runs']):
        assert info(launch['events']['path']) == launch['events'] == item['events']
        counts = {}
        phase = None
        sequence = {'R': [], 'Q': []}
        for raw in Path(launch['events']['path']).read_text().splitlines():
            fields = raw.split('\t')
            if fields[0] == 'FVGPHASE':
                phase = fields[2] if fields[1] == 'BEGIN' else None
                continue
            assert fields[0] == 'FVGCOUNT' and phase is not None
            code = fields[1]
            if code in ['R', 'Q', 'H', 'M', 'B']:
                role = 'regular' if int(fields[2]) == launch['font']['bytes'] else 'icons'
                counts.setdefault((phase, role), Counter())[code] += 1
                if code in sequence:
                    sequence[code].append((phase, role, *fields[5:]))
        for phase_name, phase_data in item['phases'].items():
            for role, bucket in phase_data['roles'].items():
                recounted = counts.get((phase_name, role), Counter())
                if launch['version'] == 'master':
                    assert recounted['R'] == bucket['native_calls']
                else:
                    for code, field in [('Q', 'requests'), ('H', 'hits'), ('M', 'misses'), ('B', 'scaler_builds')]:
                        assert recounted[code] == bucket[field]
        streams[launch['font_label'], launch['version']] = sequence
        report['raw_checks'].append({'font': launch['font_label'], 'version': launch['version'],
                                    'events': launch['events'], 'render_requests': len(sequence['R']),
                                    'outline_requests': len(sequence['Q'])})
    for comparison in analysis['comparisons']:
        label = comparison['font_label']
        assert streams[label, 'master']['R'] == streams[label, 'final']['Q']
        assert comparison['master_render_requests_equals_final_outline_requests']
    sealed_guard()
    report['complete'] = True
    write(ROOT / 'independent-count-audit.json', report)
    print((ROOT / 'analysis.stdout').read_text(), end='')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['collect', 'analyze'])
    args = parser.parse_args()
    {'collect': collect, 'analyze': analyze}[args.mode]()
