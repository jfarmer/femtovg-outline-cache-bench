#!/usr/bin/env python3
"""Audit observational cache events; never read diagnostic elapsed-time columns."""
from pathlib import Path
from collections import Counter
import csv, hashlib, json, struct, sys

ROOT=Path('/private/tmp/femtovg-cjk-font-search-20261002')
WORK=Path('/private/tmp/femtovg-aggressive-font-search-20261002/mechanism-production-trace-v1')
def info(p):
 p=Path(p).resolve(strict=True);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
def f32(bits):return struct.unpack('!f',struct.pack('!I',int(bits)))[0]
def phase_rows(p):
 rows=list(csv.DictReader(Path(p).open())); out={}
 for r in rows:
  if r['scene']=='demo' and r['trial']=='0':out[r['phase']]=dict(frames=int(r['frames']),new_atlas_entries=int(r['new_atlas_entries']))
 assert list(out)==['first_paint','warm','zoom_in','zoom_out','pan']
 return out
def main():
 campaign=json.loads((WORK/'trace-campaign.json').read_text());assert campaign['complete']
 output=WORK/'counts-analysis.json';assert not output.exists()
 result=dict(complete=False,analyzer=info(__file__),campaign=info(WORK/'trace-campaign.json'),method='Exact event counts from one untimed instrumented replay; all 184 original frames retained. No diagnostic elapsed-time columns are read. Native keys are font role/glyph/exact size bits/full coords; phase is excluded. Counts are not predicted frame savings.',runs=[],comparisons=[])
 keyed={}
 for run in campaign['launches']:
  assert run['complete'] and info(run['events']['path'])==run['events'] and info(run['stdout']['path'])==run['stdout']
  label=run['font_label']; public_label={'NotoSansSC[wght]':'NotoSansSC-VF','NotoSerifSC[wght]':'NotoSerifSC-VF'}.get(label,label)
  assert info(run["actual_demo_reference"]["path"]) == run["actual_demo_reference"]
  assert info(run["actual_demo_stdout"]["path"]) == run["actual_demo_stdout"]
  original=Path(run["actual_demo_stdout"]["path"])
  atlas=phase_rows(run['stdout']['path']); expected=phase_rows(original);assert atlas==expected,(label,run['version'],atlas,expected)
  icon=info(Path('/private/tmp/femtovg-updated-cache-bench-20261002/runtime/assets/entypo.ttf'))
  roles={run['font']['bytes']:'regular',icon['bytes']:'icons'};assert len(roles)==2
  phase=None; phase_data={}; native_stream=[]; requests=[]; cache=set(); seen=set(); last=None; font_keys={}; rejected=[]
  def bucket(role):
   return phase_data[phase]['roles'].setdefault(role,dict(events={},native_calls=0,unique_native_keys=set(),native_first_ever_keys=0,native_repeated_keys=0,requests=0,hits=0,misses=0,scaler_builds=0,admissions=0,outline_points=0,outline_verbs=0,coords=set(),sizes=set()))
  for line in Path(run['events']['path']).read_text().splitlines():
   f=line.split('\t')
   if f[0]=='FVGPHASE':
    if f[1]=='BEGIN':
     assert phase is None;phase=f[2];assert phase not in phase_data
     phase_data[phase]=dict(frames=int(f[3]),roles={},clears=[],admitted_keys_start=len(cache))
    else:
     assert phase==f[2] and phase_data[phase]['frames']==int(f[3]);phase_data[phase]['admitted_keys_end']=len(cache);phase=None
    continue
   if f[0]!='FVGCOUNT':rejected.append(line);continue
   assert phase is not None,(run['events']['path'],line)
   code=f[1]
   if code in ('R','Q','H','M','B'):
    _,_,length,offset,font_key,glyph,size,coords,subpixel=f
    role=roles[int(length)];assert offset=='0'
    font_keys.setdefault(font_key,role);assert font_keys[font_key]==role
    coord=tuple(json.loads(coords));key=(role,int(glyph),int(size),coord);phase_key=key+(int(subpixel),)
    b=bucket(role);b['events'][code]=b['events'].get(code,0)+1;b['coords'].add(coord);b['sizes'].add(int(size))
    if code=='R':
     native_stream.append((phase,phase_key));b['native_calls']+=1;b['unique_native_keys'].add(key)
     b['native_first_ever_keys']+=key not in seen;b['native_repeated_keys']+=key in seen;seen.add(key)
    if code=='Q':
     requests.append((phase,phase_key));b['requests']+=1;last=key
    if code=='H':assert last==key and key in cache;b['hits']+=1
    if code=='M':assert last==key and key not in cache;b['misses']+=1;b['native_calls']+=1;b['unique_native_keys'].add(key)
    if code=='B':b['scaler_builds']+=1
   elif code=='O':
    assert last is not None;b=bucket(last[0]);b['events'][code]=b['events'].get(code,0)+1
    b['outline_points']+=int(f[3]);b['outline_verbs']+=int(f[4]);assert f[2]=='true'
   elif code=='A':
    _,_,font_key,glyph,size,metadata,coords,points,verbs,pointcap,verbcap=f
    key=(font_keys[font_key],int(glyph),int(size),tuple(json.loads(coords)));assert key==last and key not in cache
    cache.add(key);b=bucket(key[0]);b['admissions']+=1
    phase_data[phase]['admitted_keys_high_water']=max(phase_data[phase].get('admitted_keys_high_water',0),len(cache))
    phase_data[phase]['last_arena_capacities']={'points':int(pointcap),'verbs':int(verbcap)}
   elif code=='E':
    _,_,entries,points,verbs,pointcap,verbcap,retained,budget=f;assert len(cache)==int(entries)
    phase_data[phase]['clears'].append(dict(entries=int(entries),points=int(points),verbs=int(verbs),point_capacity=int(pointcap),verb_capacity=int(verbcap),retained_bytes=int(retained),soft_budget=int(budget)))
    cache.clear()
   elif code in ('C','N'):
    b=bucket(last[0]);b['events'][code]=b['events'].get(code,0)+1
   else:raise ValueError(line)
  assert phase is None and list(phase_data)==['first_paint','warmup','warm','zoom_in','zoom_out','pan']
  assert sum(x['frames'] for x in phase_data.values())==184 and not rejected,rejected
  for ph,d in phase_data.items():
   for role,b in d['roles'].items():
    if run['version']=='final':assert b['requests']==b['hits']+b['misses']
    b['unique_native_key_count']=len(b.pop('unique_native_keys'));b['coords']=[list(x) for x in sorted(b['coords'])];b['sizes']=[dict(bits=x,value=f32(x)) for x in sorted(b['sizes'])]
   if ph in atlas:d['original_atlas']=atlas[ph]
  item=dict(locale=run['locale'],font_label=public_label,version=run['version'],original_atlas_matches=True,original_csv=info(original),diagnostic_csv=run['stdout'],events=run['events'],font=run['font'],icons=icon,phases=phase_data)
  result['runs'].append(item);keyed[(run['locale'],public_label,run['version'])]=(item,native_stream,requests)
 for locale,label in sorted({(a,b) for a,b,_ in keyed}):
  master,ms,_=keyed[(locale,label,'master')];final,_,qs=keyed[(locale,label,'final')]
  comparison=dict(locale=locale,font_label=label,master_render_requests_equals_final_outline_requests=ms==qs,phases={})
  for phase in master['phases']:
   m=master['phases'][phase];f=final['phases'][phase];by_role={}
   for role in ('regular','icons'):
    mb=m['roles'].get(role,{});fb=f['roles'].get(role,{})
    by_role[role]=dict(master_native_render_calls=mb.get('native_calls',0),master_unique_native_keys=mb.get('unique_native_key_count',0),master_repeated_native_keys=mb.get('native_repeated_keys',0),final_outline_requests=fb.get('requests',0),final_hits=fb.get('hits',0),final_misses=fb.get('misses',0),final_scaler_builds=fb.get('scaler_builds',0),final_admissions=fb.get('admissions',0),final_outline_points=fb.get('outline_points',0),final_outline_verbs=fb.get('outline_verbs',0),final_coords=fb.get('coords',[]))
   comparison['phases'][phase]=dict(roles=by_role,clears=f['clears'],master_atlas=m.get('original_atlas'),final_atlas=f.get('original_atlas'))
  result['comparisons'].append(comparison)
 result['complete']=True;result['audit_counts']=dict(processes=len(result['runs']),phases=sum(len(x['phases']) for x in result['runs']),original_atlas_rows=sum(5 for _ in result['runs']),frames_per_process=184,elapsed_time_columns_read=0)
 output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result['audit_counts'],indent=2))
 for c in result['comparisons']:
  r=c['phases']['first_paint']['roles']['regular'];cl=sum(len(p['clears']) for p in c['phases'].values())
  print(c['locale'],c['font_label'],'first:',r,'sequence clears:',cl,'request sequence equal:',c['master_render_requests_equals_final_outline_requests'])
if __name__=='__main__':main()
