#!/usr/bin/env python3
"""Acquire unchanged pinned Google Fonts assets, recording every HTTP attempt."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
PIN = "9710da1eacb3be272583c3224dcb70f9da6eadbb"
FAMILIES = ['mysteryquest', 'fontdinerswanky', 'frijole', 'diplomata', 'diplomatasc', 'kranky', 'spirax', 'snowburstone']

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def info(path):
    path = Path(path).resolve(strict=True)
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")

def download(item):
    relative = item["repository_path"]
    url = "https://raw.githubusercontent.com/google/fonts/" + PIN + "/" + relative
    destination = ROOT / "fonts" / item["family"] / Path(relative).name
    cached = Path("/private/tmp/femtovg-font-stress-search-20261002/fonts") / item["family"] / Path(relative).name
    if cached.is_file():
        raw = cached.read_bytes()
        cached_blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        if cached_blob == item["repository_blob_sha1"]:
            destination.parent.mkdir(parents=True, exist_ok=True)
            assert not destination.exists()
            destination.write_bytes(raw)
            return {**item, "url": url, "browser_url": "https://github.com/google/fonts/blob/" + PIN + "/" + relative,
                **info(destination), "reused_from": info(cached), "acquisition": "Verified pinned unchanged local copy; no download", "attempts": [], "complete": True}
    logdir = ROOT / "supporting/acquisition-v3" / item["family"] / Path(relative).name
    logdir.mkdir(parents=True)
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists(), "Unchanged assets require fresh destinations"
    attempts = []
    for number in range(1, 4):
        body = logdir / f"attempt-{number}.body"
        headers = logdir / f"attempt-{number}.headers"
        command = ["curl", "-L", "--silent", "--show-error", "--max-time", "90",
            "--dump-header", str(headers), "--output", str(body),
            "--write-out", "%{http_code}", url]
        started = datetime.now(timezone.utc).isoformat()
        result = subprocess.run(command, capture_output=True, text=True)
        (logdir / f"attempt-{number}.stdout").write_text(result.stdout)
        (logdir / f"attempt-{number}.stderr").write_text(result.stderr)
        success = result.returncode == 0 and result.stdout.strip() == "200"
        attempt = {"number": number, "command": command, "started_utc": started,
            "finished_utc": datetime.now(timezone.utc).isoformat(),
            "exit_code": result.returncode, "http_status": result.stdout.strip(),
            "success": success, "response_body": info(body) if body.exists() else None,
            "headers": info(headers) if headers.exists() else None}
        attempts.append(attempt)
        write(logdir / f"attempt-{number}.json", attempt)
        if success:
            raw = body.read_bytes()
            git_blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            assert git_blob == item["repository_blob_sha1"], (relative, "pinned tree blob mismatch")
            body.replace(destination)  # Retain the original response bytes as the asset.
            attempt["response_body"] = {**info(destination), "successful_body_moved_to_asset": True}
            write(logdir / f"attempt-{number}.json", attempt)
            return {**item, "url": url, "browser_url": "https://github.com/google/fonts/blob/" + PIN + "/" + relative,
                **info(destination), "attempts": attempts, "complete": True}
    return {**item, "url": url, "attempts": attempts, "complete": False}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    assert 1 <= args.workers <= 6
    manifest = ROOT / "additional-eight-files.json"
    assert not manifest.exists(), "Fresh acquisition manifest required"
    tree_path = ROOT / "supporting/acquisition/google-fonts-tree.json"
    tree = json.loads(tree_path.read_text())
    assert tree["truncated"] is False
    blobs = {item["path"]: item for item in tree["tree"] if item["type"] == "blob"}
    candidates, files = [], []
    for family in FAMILIES:
        directories = [root + "/" + family + "/" for root in ("ofl", "apache", "ufl")
                       if any(path.startswith(root + "/" + family + "/") for path in blobs)]
        assert len(directories) == 1, (family, "Unique pinned source directory required", directories)
        directory = directories[0]
        ttf = [path for path in blobs if path.startswith(directory) and path.endswith(".ttf")]
        regular = [path for path in ttf if Path(path).name.endswith("-Regular.ttf")]
        selected = regular[0] if len(regular) == 1 else ttf[0] if len(ttf) == 1 else None
        assert selected is not None, (family, "Explicit font selection required", ttf)
        license_id = {"ofl": "OFL-1.1", "apache": "Apache-2.0", "ufl": "Ubuntu-Font-License-1.0"}[directory.split("/")[0]]
        license_file = "OFL.txt" if directory.startswith("ofl/") else "LICENSE.txt"
        required = [selected, directory + license_file, directory + "METADATA.pb"]
        assert all(path in blobs for path in required), (family, "License or metadata missing")
        if directory + "DESCRIPTION.en_us.html" in blobs:
            required.append(directory + "DESCRIPTION.en_us.html")
        candidates.append({"family": family, "font_repository_path": selected,
            "license": license_id, "source_repository": "google/fonts", "source_commit": PIN,
            "selection_reason": "Untouched distributed decorative TrueType candidate; dynamic hinting/outline cost remains unmeasured."})
        for path in required:
            files.append({"family": family, "repository_path": path,
                "repository_blob_sha1": blobs[path]["sha"], "repository_bytes": blobs[path]["size"]})
    record = {"complete": False, "created_utc": datetime.now(timezone.utc).isoformat(),
        "driver": info(__file__), "source_commit": PIN, "tree": info(tree_path),
        "tree_request_url": "https://api.github.com/repos/google/fonts/git/trees/" + PIN + "?recursive=1",
        "candidates": candidates, "files": [],
        "scope": "8 additional unchanged openly licensed decorative Latin candidates. No font transformation, rehinting, subsetting, building or rendering. Bytes verified against pinned tree Git blob identities; failures retained."}
    write(manifest, record)
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        for result in executor.map(download, files):
            record["files"].append(result)
            write(manifest, record)
            print(result["family"], Path(result["repository_path"]).name, result["complete"], flush=True)
    record["complete"] = all(item["complete"] for item in record["files"])
    record["finished_utc"] = datetime.now(timezone.utc).isoformat()
    write(manifest, record)
    if not record["complete"]:
        raise SystemExit("One or more recorded downloads failed")
    for candidate in record["candidates"]:
        candidate["assets"] = [item for item in record["files"] if item["family"] == candidate["family"]]
    write(manifest, record)
    print("Complete:", len(candidates), "fonts", len(files), "assets", manifest)

if __name__ == "__main__":
    main()
