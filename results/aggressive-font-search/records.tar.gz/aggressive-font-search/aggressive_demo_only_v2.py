#!/usr/bin/env python3
"""Prepare a five-phase unchanged-demo replay and native offset oracle."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,difflib,hashlib,json,re,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent;STUDY=ROOT/'demo-only-replay-v2'
CJK=Path('/private/tmp/femtovg-cjk-font-search-20261002');OLD=Path('/private/tmp/femtovg-updated-cache-bench-20261002');SEARCH=Path('/private/tmp/femtovg-font-stress-search-20261002')
def info(p):
 p=Path(p).resolve(strict=True);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def files(root):return {str(p.relative_to(root)):info(p) for p in sorted(root.rglob('*')) if p.is_file() and 'target' not in p.parts}
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def change(p,old,new):
 value=p.read_text();assert value.count(old)==1,(str(p),value.count(old));p.write_text(value.replace(old,new))
 return dict(path=str(p),old=old,new=new,before_sha256=hashlib.sha256(value.encode()).hexdigest(),after_sha256=info(p)['sha256'],diff=''.join(difflib.unified_diff(value.splitlines(True),p.read_text().splitlines(True))))
def graph(m):
 packages={p['id']:p for p in m['packages']};root=m['resolve']['root']
 def identity(k):
  p=packages[k];return ['<runner>' if k==root else p['name'],p['version'],p['source'] or ('<runner>' if k==root else '<femtovg>')]
 return sorted([[identity(n['id']),sorted(n['features']),sorted([[e['name'],identity(e['pkg']),sorted(json.dumps(k,sort_keys=True) for k in e['dep_kinds'])] for e in n['deps']])] for n in m['resolve']['nodes']])

IDENTITY=r'''def input_identity(study):
    prep_path = study / 'prepare.json'
    build_path = study / 'build.json'
    prep, build = load(prep_path), load(build_path)
    require(prep.get('complete') is True and build.get('complete') is True, 'Demo prepare/build incomplete')
    require(info(prep_path) == build['prepare'], 'Demo preparation changed')
    require(info(prep['driver']['path']) == prep['driver'] and info(build['builder']['path']) == build['builder'], 'Demo builder changed')
    require(info(prep['original_collector']['path']) == prep['original_collector'], 'Original full collector changed')
    require(info(study / 'replay_campaign.py') == prep['collector'], 'Demo collector changed')
    require(info(prep['ablation_build']['path']) == prep['ablation_build'] and info(prep['ablation_prepare']['path']) == prep['ablation_prepare'], 'Reused demo source/build proof changed')
    require(info(prep['ablation_independent_audit']['path']) == prep['ablation_independent_audit'], 'Reused independent audit changed')
    require(load(prep['ablation_independent_audit']['path']).get('complete') is True, 'Reused independent audit incomplete')
    def file_infos(root):
        root = Path(root)
        return {str(p.relative_to(root)): info(p) for p in sorted(root.rglob('*')) if p.is_file() and 'target' not in p.parts}
    def same_bytes(a, b):
        return {k:(v['sha256'],v['bytes']) for k,v in a.items()} == {k:(v['sha256'],v['bytes']) for k,v in b.items()}
    for version, entry in prep['libraries'].items():
        require(file_infos(entry['root']) == entry['files'], 'Frozen library changed: ' + version)
    for version, entry in prep['reused'].items():
        require(file_infos(entry['runner_root']) == entry['runner_files'], 'Reused runner changed: ' + version)
        require(info(entry['binary']['path']) == entry['binary'], 'Reused executable changed: ' + version)
        require(info(entry['metadata']['path']) == entry['metadata'], 'Reused metadata changed: ' + version)
    oracle_root = Path(prep['oracle_runner_root'])
    actual = file_infos(oracle_root)
    require({k:v for k,v in actual.items() if k!='Cargo.lock'} == {k:v for k,v in prep['oracle_runner_files'].items() if k!='Cargo.lock'}, 'Oracle drawing source changed')
    require(same_bytes(file_infos(oracle_root/'src'), prep['demo_source']), 'Oracle and reused demo source differ')
    require(file_infos(prep['original_runner_root']) == prep['original_runner_files'], 'Original drawing source changed')
    require(file_infos(prep['shared_common_root']) == prep['shared_common'], 'Shared common source changed')
    require(file_infos(prep['assets_root']) == prep['assets'], 'Demo assets changed')
    for entry in build['oracle'].values():
        if isinstance(entry, dict) and 'path' in entry and 'sha256' in entry:
            require(info(entry['path']) == entry, 'Oracle build artifact changed')
    require(build['oracle']['dependency_feature_graph_matches'] is True, 'Oracle graph differs')
    require(info(prep['native_oracle_prepare']['path']) == prep['native_oracle_prepare'] and info(prep['native_oracle_build']['path']) == prep['native_oracle_build'], 'Original native oracle proof changed')
    return {'binaries': {v:prep['reused'][v]['binary'] for v in ALL_VERSIONS},
            'oracle_binary':build['oracle']['binary'],
            'sources':{v:prep['libraries'][v]['files'] for v in ('master','final','no_retention','oracle')},
            'assets':{k:v['sha256'] for k,v in prep['assets'].items()},
            'runner_source':{k:v['sha256'] for k,v in prep['demo_source'].items()},
            'compiler':build['compiler'],'cargo':build['cargo'],
            'demo_prepare':info(prep_path),'demo_build':info(build_path),
            'shared_common':prep['shared_common'],
            'scope':'Original English demo drawing; only scene selection and common path adaptation. Five phases, 119 warmups. Source-proven master/final runners reused; new source-identical native-offset-oracle runner.'}


'''

def prepare():
 STUDY.mkdir(exist_ok=False)
 ablation=CJK/'mechanism-retention-ablation';ap=json.loads((ablation/'prepare.json').read_text());ab=json.loads((ablation/'build.json').read_text());aa=json.loads((ablation/'independent-audit.json').read_text());assert ap['complete'] and ab['complete'] and aa['complete']
 proof=dict(complete=False,driver=info(__file__),created_utc=datetime.now(timezone.utc).isoformat(),ablation_prepare=info(ablation/'prepare.json'),ablation_build=info(ablation/'build.json'),ablation_independent_audit=info(ablation/'independent-audit.json'),reused={},libraries={},changes=[],scope='Original English demo only; no text, geometry, phase schedule, warmup or feature change. No timing or pixel campaign performed by prepare/build.')
 for v in ('master','final','no_retention'):
  entry=next(x for x in ab['launches'] if x['name']=='en-'+v);runner=Path(ap['runners']['en-'+v]['root']);assert info(entry['binary']['path'])==entry['binary'] and files(runner)=={**ap['runners']['en-'+v]['files'],'Cargo.lock':info(runner/'Cargo.lock')}
  assert info(entry['metadata']['path'])==entry['metadata'];assert entry['dependency_feature_graph_matches']
  proof['reused'][v]=dict(binary=entry['binary'],metadata=entry['metadata'],runner_root=str(runner),runner_files=files(runner),package=ap['runners']['en-'+v]['package'])
  library=(OLD/'runtime/core/replay-sources'/v) if v!='no_retention' else (ablation/'no-retention-library');proof['libraries'][v]=dict(root=str(library),files=files(library))
 source=Path(proof['reused']['master']['runner_root']);runner=STUDY/'oracle-runner';shutil.copytree(source,runner,ignore=shutil.ignore_patterns('target','.git'))
 proof['oracle_runner_root']=str(runner);proof['demo_source']=files(source/'src')
 manifest=runner/'Cargo.toml';oldname=re.search(r'^name = ".*"$',manifest.read_text(),re.M).group(0);proof['changes'].append(change(manifest,oldname,'name = "femtovg-aggressive-demo-native-offset-oracle-v2"'))
 dep=re.search(r'^femtovg = .*$',manifest.read_text(),re.M).group(0);oracle=OLD/'native-master-offset-oracle/replay-sources/master'
 proof['changes'].append(change(manifest,dep,'femtovg = { path = "'+str(oracle)+'", features = ["swash", "wgpu"] }'))
 proof['libraries']['oracle']=dict(root=str(oracle),files=files(oracle));proof['oracle_runner_files']=files(runner)
 original=OLD/'runtime/core/runner';proof['original_runner_root']=str(original);proof['original_runner_files']=files(original)
 common=OLD/'runtime/core/snapshots/master/tests/common';proof['shared_common_root']=str(common);proof['shared_common']=files(common)
 assets=OLD/'runtime/assets';proof['assets_root']=str(assets);proof['assets']=files(assets)
 proof['native_oracle_prepare']=info(OLD/'native-master-offset-oracle/prepare.json');proof['native_oracle_build']=info(OLD/'native-master-offset-oracle/build.json')
 original_collector=SEARCH/'replay_campaign.py';proof['original_collector']=info(original_collector);text=original_collector.read_text();original_text=text
 text=text.replace("DEFAULT_STUDY = Path('/private/tmp/femtovg-updated-cache-bench-20261002')","DEFAULT_STUDY = Path('"+str(STUDY)+"')")
 text=text.replace("ALL_VERSIONS = ('master', 'prior', 'updated45', 'final')","ALL_VERSIONS = ('master', 'final', 'no_retention')")
 a=text.index('PHASES = {');b=text.index('\nFIELDS =',a);text=text[:a]+"PHASES = {'demo': {'first_paint': 1, 'warm': 30, 'zoom_in': 12, 'zoom_out': 12, 'pan': 10}}\n"+text[b:]
 text=text.replace('default=list(ALL_VERSIONS)', 'default=["master", "final"]')
 text=text.replace("reference = 'oracle' if version == 'final' else 'master'", "reference = 'oracle' if version in ('final', 'no_retention') else 'master'")
 a=text.index('def input_identity(study):');b=text.index('def pixel_phase_records(',a);text=text[:a]+IDENTITY+text[b:]
 text=text.replace("'cwd': str(study / 'runtime/core')","'cwd': str(study)")
 text=text.replace("'scope': 'Unchanged 19 example phases and nine controlled phases; regular font override only; variation controls always Roboto'","'scope': 'Unchanged original English demo drawing, five phases plus119 warmups; regular-font environment override only; no other scenes run'")
 a=text.index("    if args.mode == 'pixels':\n        controls =");b=text.index("    require(input_identity(study) == identity",a)
 text=text[:a]+"""    if args.mode == 'pixels':
        by_config = {(r['font'], r['dpi']): {p['phase']:p for p in r['phases']}
                     for r in provenance['pixel_configurations']}
        provenance['font_override_controls'] = [
            {'font':font,'reference_font':labels[0],'dpi':dpi,
             'regular_first_paint_changed':by_config[labels[0],dpi]['first_paint']['snapshots']['master']['sha256'] !=
                                           by_config[font,dpi]['first_paint']['snapshots']['master']['sha256']}
            for dpi in args.dpis for font in labels[1:]]
"""+text[b:]
 collector=STUDY/'replay_campaign.py';collector.write_text(text);proof['collector']=info(collector);proof['collector_diff']=''.join(difflib.unified_diff(original_text.splitlines(True),text.splitlines(True)))
 proof['complete']=True;write(STUDY/'prepare.json',proof);print('Prepared source-proven master/final reuse and new native-offset oracle; no builds or collection')

def guard():
 p=json.loads((STUDY/'prepare.json').read_text());assert p['complete'] and info(p['driver']['path'])==p['driver'];assert info(STUDY/'replay_campaign.py')==p['collector']
 for e in p['libraries'].values():assert files(Path(e['root']))==e['files']
 for e in p['reused'].values():assert files(Path(e['runner_root']))==e['runner_files'] and info(e['binary']['path'])==e['binary'] and info(e['metadata']['path'])==e['metadata']
 actual=files(Path(p['oracle_runner_root']));assert {k:v for k,v in actual.items() if k!='Cargo.lock'}=={k:v for k,v in p['oracle_runner_files'].items() if k!='Cargo.lock'}
 assert files(Path(p['assets_root']))==p['assets'] and files(Path(p['shared_common_root']))==p['shared_common']
 for key in ('native_oracle_prepare','native_oracle_build','ablation_prepare','ablation_build','ablation_independent_audit','original_collector'):assert info(p[key]['path'])==p[key]
 return p

def build():
 p=guard();output=STUDY/'build.json';assert not output.exists();runner=Path(p['oracle_runner_root']);target=ROOT/'targets/demo-only-oracle-v2'
 cmd=['cargo','build','--offline','--release','--manifest-path',str(runner/'Cargo.toml'),'--target-dir',str(target)]
 record=dict(complete=False,builder=info(__file__),prepare=info(STUDY/'prepare.json'),compiler=subprocess.run(['rustc','--version'],text=True,check=True,capture_output=True).stdout.strip(),cargo=subprocess.run(['cargo','--version'],text=True,check=True,capture_output=True).stdout.strip(),command=cmd,cwd=str(runner),oracle={});write(output,record)
 with (STUDY/'oracle-build.stdout.txt').open('x') as out,(STUDY/'oracle-build.stderr.txt').open('x') as err:status=subprocess.run(cmd,cwd=runner,stdout=out,stderr=err).returncode
 record['exit_code']=status;write(output,record)
 if status:raise SystemExit(status)
 command=['cargo','metadata','--offline','--locked','--format-version','1','--manifest-path',str(runner/'Cargo.toml')];metadata=subprocess.run(command,cwd=runner,check=True,text=True,capture_output=True).stdout;mp=STUDY/'oracle-metadata.json';mp.write_text(metadata)
 ref=OLD/'native-master-offset-oracle/metadata.json';assert graph(json.loads(metadata))==graph(json.loads(ref.read_text()))
 binary=STUDY/'oracle-runner-bin';shutil.copy2(target/'release/femtovg-aggressive-demo-native-offset-oracle-v2',binary)
 record['oracle']=dict(binary=info(binary),lockfile=info(runner/'Cargo.lock'),metadata=info(mp),reference_metadata=info(ref),dependency_feature_graph_matches=True)
 guard();record['complete']=True;write(output,record)
 # Exercise the standalone collector's full read-only identity gate, without running a replay.
 import importlib.util
 spec=importlib.util.spec_from_file_location('aggressive_demo_collector',STUDY/'replay_campaign.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);identity=module.input_identity(STUDY);write(STUDY/'input-identity.json',identity)
 print('Built and graph-audited demo-only native oracle; standalone identity gate passed; no timing or image collection')

if __name__=='__main__':
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('mode',choices=['prepare','build']);args=a.parse_args();globals()[args.mode]()
