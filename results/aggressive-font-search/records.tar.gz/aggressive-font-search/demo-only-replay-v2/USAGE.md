# Unchanged English demo replay

The active collector is `replay_campaign_v3.py`. Its narrow Python correction is bound by `collector-no-retention-count-fix.json`; it uses the unchanged v2 oracle binary and frozen source-proven English master/final/no-retention ablation binaries. The original collector, preparations and all source/build proofs remain preserved. `input-identity-v3.json` records the passed read-only identity gate. No collection has run during preparation.

Only the original demo runs: first paint, 119 warmup frames, 30 warm frames, 12 zoom-in, 12 zoom-out and 10 pan frames. The drawing source, assets, font environment override, phase schedule, shaders and dependency/feature settings remain unchanged. The original dense-font controlled grids and other scenes do not run.

Primary confirmation uses only master/final, a separately frozen font selection, a completed matching native-offset-oracle pixel campaign, 12 balanced blocks and five trials per CPU process. For example, after supplying the chosen font labels/paths:

```sh
python3 -B replay_campaign_v3.py --mode pixels --versions master final --dpi 2 --output FRESH_PIXELS --font LABEL FONT_PATH
python3 -B replay_campaign_v3.py --mode cpu --versions master final --dpi 2 --blocks 12 --trials 5 --pixel-proof FRESH_PIXELS/pixels-provenance.json --selection-manifest FROZEN_SELECTION --output FRESH_CONFIRMATION --font LABEL FONT_PATH
```

`no_retention` is optional. Three-arm diagnostics use six balanced blocks and five trials, after winner selection is frozen. Confirmation with a pixel proof requires that proof to cover every selected version; capture `--versions master final no_retention` if those image comparisons are desired. Otherwise a separately labelled `--exploratory` three-arm diagnostic can run without claiming a new no-retention image proof.

The collector compares optional no-retention atlas counts with final, which shares the negative-phase fix, and compares final/no-retention pixel captures with the unchanged native actual-offset oracle. Master remains the performance baseline, and any differences between original master and the native oracle are retained. Every output directory must be fresh; all failures and raw attempts are preserved.
