#!/usr/bin/env python3
"""Combine immutable21 and additional8 manifests without replacing evidence."""
import hashlib
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def info(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size}

def main():
    primary_path = ROOT / "supporting/completed-21-font-manifest.json"
    extra_path = ROOT / "additional-eight-files.json"
    current = ROOT / "acquired-files.json"
    assert current.read_bytes() == primary_path.read_bytes(), "Primary21 manifest must remain unchanged until combination"
    primary = json.loads(primary_path.read_text())
    extra = json.loads(extra_path.read_text())
    assert primary["complete"] and extra["complete"]
    assert len(primary["candidates"]) == 21 and len(extra["candidates"]) == 8
    assert primary["source_commit"] == extra["source_commit"]
    candidates = primary["candidates"] + extra["candidates"]
    assert len({candidate["family"] for candidate in candidates}) == 29
    files = primary["files"] + extra["files"]
    assert len([item for item in files if item["repository_path"].endswith(".ttf")]) == 29
    for item in files:
        path = Path(item["path"])
        assert item["complete"] and info(path) == {key: item[key] for key in ("path", "sha256", "bytes")}
    proof_path = ROOT / "supporting/eight-preflight-path-correction/proof.json"
    old = ROOT / "supporting/eight-preflight-path-correction/acquire_fonts_v3.py"
    corrected = ROOT / "acquire_fonts_v3.py"
    proof = {"complete": True, "original_source": info(old), "corrected_source": info(corrected),
        "failed_command": info(ROOT / "supporting/eight-preflight-path-correction/failed-command.json"),
        "changes": ["Resolve each family from the pinned tree's ofl/apache/ufl directory rather than assuming ofl", "Choose matching official OFL.txt or LICENSE.txt and license identifier"],
        "scope": "Ordinary preflight directory/license correction before HTTP; same eight selected families, commit, original font bytes and purpose. Failed source, stdout/stderr and command retained."}
    proof_path.write_text(json.dumps(proof, indent=2) + "\n")
    combined = {"complete": True, "source_commit": primary["source_commit"], "driver": info(Path(__file__)),
        "candidates": candidates, "files": files, "primary_manifest": info(primary_path),
        "additional_manifest": info(extra_path), "primary20_manifest": info(ROOT / "supporting/completed-20-font-manifest.json"),
        "source_corrections": [info(proof_path), info(ROOT / "supporting/acquisition-v2-source-proof.json")],
        "scope": "29 unchanged openly licensed distributed TrueType candidates: original20, one pinned local RubikPixels control, eight additional rough/ornamental families. All bytes match official pinned Git blob identities; original manifests, HTTP failures, source preflight failure and successful provenance preserved. No rehinting, subsetting, font transformation, rendering or performance claim."}
    current.write_text(json.dumps(combined, indent=2) + "\n")
    frozen = ROOT / "supporting/completed-29-font-manifest.json"
    assert not frozen.exists()
    frozen.write_bytes(current.read_bytes())
    print(json.dumps({"complete": True, "fonts": 29, "assets": len(files), "manifest": str(current), "frozen": str(frozen)}))

if __name__ == "__main__":
    main()
