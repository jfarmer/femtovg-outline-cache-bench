#!/usr/bin/env python3
"""Prepare and verify direct curl acquisition of unchanged pinned ornate fonts.

This driver never invokes a network command. The exact curl requests in the
plan are run through the tool's normal network approval policy, and their
actual returned results are retained before this driver verifies the bytes.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
PIN = "9710da1eacb3be272583c3224dcb70f9da6eadbb"
FAMILIES = ["comforterbrush", "waterbrush", "mysoul", "imperialscript", "meaculpa", "luxuriousscript", "birthstonebounce", "lavishlyyours"]

def stamp():
    return datetime.now(timezone.utc).isoformat()

def info(path):
    path = Path(path).resolve(strict=True)
    with path.open("rb") as f:
        digest = hashlib.file_digest(f, "sha256").hexdigest()
    return {"path": str(path), "sha256": digest, "bytes": path.stat().st_size}

def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")

def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()

def prepare():
    manifest_path = ROOT / "acquired-files.json"
    assert not manifest_path.exists(), "Own fresh acquisition manifest required"
    source_tree = PARENT / "supporting/acquisition/google-fonts-tree.json"
    tree_path = ROOT / "supporting/acquisition/google-fonts-tree.json"
    tree_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source_tree, tree_path)
    source_headers = source_tree.with_suffix(".headers")
    if source_headers.is_file():
        shutil.copyfile(source_headers, tree_path.with_suffix(".headers"))
    tree = json.loads(tree_path.read_text())
    assert tree["truncated"] is False
    blobs = {x["path"]: x for x in tree["tree"] if x["type"] == "blob"}
    candidates, requests, files = [], [], []
    for family in FAMILIES:
        directories = [p + "/" + family + "/" for p in ("ofl", "apache", "ufl") if any(x.startswith(p + "/" + family + "/") for x in blobs)]
        assert len(directories) == 1, (family, directories)
        directory = directories[0]
        regulars = [x for x in blobs if x.startswith(directory) and x.endswith("-Regular.ttf")]
        assert len(regulars) == 1, (family, regulars)
        selected = regulars[0]
        license_file = "OFL.txt" if directory.startswith("ofl/") else "LICENSE.txt"
        required = [selected, directory + license_file, directory + "METADATA.pb", directory + "DESCRIPTION.en_us.html", directory + "upstream_info.md"]
        assert all(x in blobs for x in required), (family, "Required pinned primary source missing")
        candidates.append({"family": family, "font_repository_path": selected, "license": "OFL-1.1" if directory.startswith("ofl/") else "Apache-2.0", "source_repository": "google/fonts", "source_commit": PIN,
            "selection_reason": "Untouched regular brush/cursive distribution from the related modern production pipeline suggested by FleurDeLeah's measured hinting cost; actual hint streams and cost are unmeasured for this cohort."})
        for relative in required:
            name = Path(relative).name
            destination = ROOT / "fonts" / family / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            assert not destination.exists(), "Fresh asset destination required"
            entry = {"family": family, "repository_path": relative, "repository_blob_sha1": blobs[relative]["sha"], "repository_bytes": blobs[relative]["size"], "url": "https://raw.githubusercontent.com/google/fonts/" + PIN + "/" + relative, "browser_url": "https://github.com/google/fonts/blob/" + PIN + "/" + relative, "path": str(destination)}
            cached = Path("/private/tmp/femtovg-font-stress-search-20261002/fonts") / family / name
            if cached.is_file() and blob(cached.read_bytes()) == entry["repository_blob_sha1"]:
                shutil.copyfile(cached, destination)
                files.append({**entry, **info(destination), "reused_from": info(cached), "acquisition": "Pinned Git blob-verified unchanged local copy; no network", "attempts": [], "complete": True})
                continue
            logdir = ROOT / "supporting/acquisition" / family / name
            logdir.mkdir(parents=True)
            body, headers = logdir / "attempt-1.body", logdir / "attempt-1.headers"
            command = ["curl", "-fL", "--silent", "--show-error", "--max-time", "90", "--dump-header", str(headers), "--output", str(body), "--write-out", "%{http_code}", entry["url"]]
            requests.append({**entry, "request_id": family + "/" + name, "command": command, "response_body_path": str(body), "headers_path": str(headers), "attempt": 1})
    preparation = {"complete": True, "prepared_utc": stamp(), "driver": info(__file__), "source_tree": info(source_tree), "copied_tree": info(tree_path), "source_commit": PIN, "families": FAMILIES, "selection": "Only the unique shipped Regular TTF per family; no transformation or rehinting", "requests": requests}
    write(ROOT / "acquisition-preparation.json", preparation)
    write(ROOT / "request-plan.json", {"complete": True, "requests": requests})
    write(manifest_path, {"complete": False, "created_utc": stamp(), "driver": info(__file__), "source_commit": PIN, "tree": info(tree_path), "tree_request_url": "https://api.github.com/repos/google/fonts/git/trees/" + PIN + "?recursive=1", "candidates": candidates, "files": files, "scope": "Eight separately frozen unchanged openly licensed Latin brush/script candidates; pinned source, licensing, metadata and upstream descriptions retained. No build, rehinting, subsetting or timing."})
    print(json.dumps({"prepared": True, "families": len(candidates), "pending_requests": len(requests), "reused_assets": len(files), "plan": str(ROOT / "request-plan.json")}))

def finalize():
    manifest_path = ROOT / "acquired-files.json"
    record = json.loads(manifest_path.read_text())
    assert record["complete"] is False
    plan = json.loads((ROOT / "request-plan.json").read_text())
    results = json.loads((ROOT / "request-results.json").read_text())
    actual = {x["request_id"]: x for x in results["results"]}
    assert set(actual) == {x["request_id"] for x in plan["requests"]}
    for request in plan["requests"]:
        result = actual[request["request_id"]]
        assert result["command"] == request["command"]
        body, headers = Path(request["response_body_path"]), Path(request["headers_path"])
        success = result["exit_code"] == 0 and result["output"].strip() == "200"
        attempt = {"number": request["attempt"], **result, "success": success, "headers": info(headers) if headers.exists() else None, "response_body": info(body) if body.exists() else None}
        entry = {k: request[k] for k in ("family", "repository_path", "repository_blob_sha1", "repository_bytes", "url", "browser_url", "path")}
        if success:
            assert body.is_file()
            raw = body.read_bytes()
            assert len(raw) == request["repository_bytes"] and blob(raw) == request["repository_blob_sha1"], (request["request_id"], "Pinned Git blob mismatch")
            destination = Path(request["path"])
            assert not destination.exists()
            body.replace(destination)
            attempt["response_body"] = {**info(destination), "successful_body_moved_to_asset": True}
            entry.update(info(destination))
        entry.update(attempts=[attempt], complete=success)
        write(headers.parent / "attempt-1.json", attempt)
        record["files"].append(entry)
    record["complete"] = all(x["complete"] for x in record["files"]) and len(record["files"]) == len(FAMILIES) * 5
    record["finished_utc"] = stamp()
    for candidate in record["candidates"]:
        candidate["assets"] = [x for x in record["files"] if x["family"] == candidate["family"]]
    write(manifest_path, record)
    if not record["complete"]:
        raise SystemExit("Recorded failed request; preserve this manifest and retry in a separately recorded attempt")
    print(json.dumps({"complete": True, "fonts": len(record["candidates"]), "assets": len(record["files"]), "manifest": str(manifest_path)}))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("prepare", "finalize"))
    options = parser.parse_args()
    prepare() if options.mode == "prepare" else finalize()
