// Retained original orchestration source; do not execute during timing.
// The fully quoted executable caused approval-prefix matching to use the
// shell wrapper rather than the already approved literal curl -fL prefix.
const requests = load("ornate_requests");
const results = [];
const quote = s => "'" + s.replace(/'/g, "'\\''") + "'";
for (let start = 0; start < requests.length; start += 8) {
  const batch = await Promise.allSettled(requests.slice(start, start + 8).map(async request => {
    const started_utc = new Date().toISOString();
    const r = await tools.exec_command({
      cmd: request.command.map(quote).join(" "),
      sandbox_permissions: "require_escalated",
      justification: "Allow downloading these eight openly licensed, pinned Google Fonts candidates and their licenses/metadata for the requested cache benchmark?",
      prefix_rule: ["curl", "-fL"],
      yield_time_ms: 10000,
      max_output_tokens: 1000
    });
    return {request_id: request.request_id, command: request.command, started_utc, finished_utc: new Date().toISOString(), ...r};
  }));
  for (let i = 0; i < batch.length; i++) {
    const value = batch[i].status === "fulfilled" ? batch[i].value : {request_id: requests[start+i].request_id, command: requests[start+i].command, exception: String(batch[i].reason)};
    results.push(value);
    text({request: value.request_id, exit_code: value.exit_code, output: value.output, session_id: value.session_id, exception: value.exception});
  }
  store("ornate_results", results);
}
store("ornate_results", results);
text({requests_completed: results.length});
