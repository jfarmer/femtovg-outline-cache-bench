#!/usr/bin/env python3
"""Prepare an explicitly scoped copy of the earlier engine source auditor.

The original 55-face audit is preserved. Only input scope and expected counts
change; source hashes, registry guards and raw-table checks are unchanged.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = ROOT.parent / 'supporting/audit_engine_selection.py'
original = source.read_text()
edits = [
    ("inspections = [ROOT / 'supporting/font-inspection.json',\n"
     "                   ROOT / 'hinted-supplement-v1/supporting/font-inspection.json',\n"
     "                   CJK / 'supporting/font-inspection.json']",
     "inspections = [ROOT / 'supporting/font-inspection.json']"),
    ('assert len(rows) == 55', 'assert len(rows) == 10'),
    ("assert len([r for r in rows if not r['prefer_interpreter']]) == 4",
     "assert len([r for r in rows if not r['prefer_interpreter']]) == 0"),
    ('55 unique unmodified TrueType faces:39 aggressive candidates+Rye/Vollkorn controls, plus14 previous CJK faces.',
     '10 unique unmodified TrueType faces:8 ornate candidates+Rye/Vollkorn controls; the prior 55-face audit remains unchanged.'),
]
adapted = original
for old, new in edits:
    assert adapted.count(old) == 1, old
    adapted = adapted.replace(old, new)
destination = ROOT / 'supporting/audit_engine_selection.py'
assert not destination.exists(), 'Do not overwrite a previously scoped auditor'
destination.write_text(adapted)
proof = {
    'complete': True,
    'original': {'path': str(source), 'sha256': hashlib.sha256(original.encode()).hexdigest()},
    'adapted': {'path': str(destination), 'sha256': hashlib.sha256(adapted.encode()).hexdigest()},
    'changes': [{'old': old, 'new': new} for old, new in edits],
    'purpose': 'Separate ornate-supplement source/engine audit; no execution or timing instrumentation.',
}
(ROOT / 'supporting/engine-auditor-adaptation.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof))
