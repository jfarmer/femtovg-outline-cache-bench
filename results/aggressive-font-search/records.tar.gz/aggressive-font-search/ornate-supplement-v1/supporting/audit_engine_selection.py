#!/usr/bin/env python3
"""Bind actual Skrifa/Swash engine selection to unmodified inspected fonts.

This is a static source audit, not an executed-hint counter or timing kernel.
No registry, checkout, font or production source is changed.
"""
import csv
import hashlib
import json
from pathlib import Path

from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[1]
CJK = Path('/private/tmp/femtovg-cjk-font-search-20261002')
OLD = Path('/private/tmp/femtovg-font-stress-search-20261002')
REGISTRY = Path('/Users/jesse/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f')


def info(path, expected=None):
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if expected is not None:
        assert digest == expected, str(path)
    return {'path': str(path), 'sha256': digest, 'bytes': len(raw)}


def main():
    baseline_path = CJK / 'mechanism-diagnostic/prepare.json'
    baseline = json.loads(baseline_path.read_text())
    skrifa = Path(baseline['original_skrifa'])
    expected = baseline['original_skrifa_files']
    actual = {str(p.relative_to(skrifa)): info(p)['sha256'] for p in skrifa.rglob('*') if p.is_file()}
    assert actual == expected, 'Original registry Skrifa differs from the preserved diagnostic baseline'
    inputs_path = OLD / 'inputs.json'
    inputs = json.loads(inputs_path.read_text())
    swash = Path(inputs['native_sources']['registry_swash_source'])
    for name, digest in inputs['native_sources']['source_files'].items():
        info(swash / name, digest)
    sources = []
    ranges = {
        'src/outline/glyf/mod.rs': (72, 118),
        'src/outline/hint.rs': (14, 80),
        'src/outline/mod.rs': (675, 704),
    }
    for name, (start, end) in ranges.items():
        path = skrifa / name
        lines = path.read_text().splitlines()
        sources.append({**info(path, expected[name]), 'lines_start': start, 'lines_end': end,
                        'excerpt': '\n'.join(lines[start - 1:end])})
    hint = (skrifa / 'src/outline/hint.rs').read_text()
    assert 'let engine = options.engine.resolve_auto_fallback(outlines);' in hint
    assert 'engine: Engine::AutoFallback' in hint
    assert 'impl From<HintingMode> for HintingOptions' in hint
    assert 'let prefer_interpreter = !(max_instructions == 0 && fpgm.is_empty() && prep.is_empty());' in (skrifa / 'src/outline/glyf/mod.rs').read_text()
    sources.append({**info(swash / 'scale/hinting_cache.rs', inputs['native_sources']['source_files']['scale/hinting_cache.rs']),
                    'excerpt': (swash / 'scale/hinting_cache.rs').read_text(), 'lines_start': 1})
    sources.append({**info(skrifa / 'src/outline/hint.rs', expected['src/outline/hint.rs']),
                    'lines_start': 239, 'lines_end': 269,
                    'excerpt': '\n'.join(hint.splitlines()[238:269])})
    inspections = [ROOT / 'supporting/font-inspection.json']
    fonts = {}
    inspection_bindings = []
    for path in inspections:
        inspection_bindings.append(info(path))
        data = json.loads(path.read_text()); assert data['complete']
        for record in data['fonts']:
            key = (record['sha256'], record['face_index'])
            if key in fonts:
                fonts[key]['inspection_occurrences'].append({'inspection': str(path), 'label': record['label']})
                continue
            font_path = Path(record['path'])
            bound = info(font_path, record['sha256'])
            assert bound['bytes'] == record['file_bytes']
            with TTFont(font_path, fontNumber=record['face_index'], lazy=True) as font:
                assert 'glyf' in font and 'VARC' not in font, 'This predicate report is scoped to ordinary TrueType glyf'
                max_instructions = getattr(font['maxp'], 'maxSizeOfInstructions', 0)
                programs = {tag: font.reader[tag] if tag in font else b'' for tag in ['fpgm', 'prep']}
            assert max_instructions == record['maxp'].get('maxSizeOfInstructions', 0)
            for tag, raw in programs.items():
                assert len(raw) == record['embedded_program_tables'][tag]['table_bytes']
            prefer = not (max_instructions == 0 and not programs['fpgm'] and not programs['prep'])
            fonts[key] = {
                'label': record['label'], 'font': bound, 'face_index': record['face_index'],
                'maxp_maxSizeOfInstructions': max_instructions,
                'raw_fpgm_bytes': len(programs['fpgm']), 'raw_prep_bytes': len(programs['prep']),
                'raw_fpgm_sha256': hashlib.sha256(programs['fpgm']).hexdigest(),
                'raw_prep_sha256': hashlib.sha256(programs['prep']).hexdigest(),
                'whole_font_direct_glyph_program_bytes': record['direct_glyf_program_bytes_all_glyphs']['total'],
                'prefer_interpreter': prefer, 'resolved_AutoFallback_engine': 'Interpreter' if prefer else 'Auto(None)',
                'inspection_occurrences': [{'inspection': str(path), 'label': record['label']}],
            }
    rows = list(fonts.values())
    assert len(rows) == 10
    assert len([r for r in rows if not r['prefer_interpreter']]) == 0
    for name, digest in expected.items():
        info(skrifa / name, digest)
    out = ROOT / 'supporting/engine-selection-audit.json'
    result = {
        'complete': True, 'count_only': False, 'static_source_audit_only': True,
        'auditor': info(Path(__file__)), 'skrifa_original_baseline': info(baseline_path),
        'original_registry_skrifa_files_checked_before_and_after': len(expected),
        'swash_source_baseline': info(inputs_path), 'swash_registry_source_files_checked': len(inputs['native_sources']['source_files']),
        'source_bindings_and_excerpts': sources, 'inspection_bindings': inspection_bindings,
        'predicate': 'prefer_interpreter = !(maxSizeOfInstructions == 0 && raw_fpgm_bytes == 0 && raw_prep_bytes == 0)',
        'selection_chain': 'Swash HintingInstance::new/reconfigure with HintingMode -> HintingOptions::from(HintingMode) -> Target.into() -> Engine::AutoFallback -> OutlineGlyphCollection::prefer_interpreter -> TrueType glyf prefer_interpreter predicate -> Interpreter or Auto(None).',
        'scope': '10 unique unmodified TrueType faces:8 ornate candidates+Rye/Vollkorn controls; the prior 55-face audit remains unchanged. Source predicate uses declared maxp instruction maximum and raw fpgm/prep table lengths, not observed glyph program bytes. It identifies the preferred engine when hinting is enabled; font programs can subsequently disable hinting. Zero TT VM dispatch does not imply absence of native runtime autohint work. This audit neither measures execution cost nor supplies an empirical cache-admission threshold.',
        'fonts': rows,
    }
    out.write_text(json.dumps(result, indent=2) + '\n')
    flat = [{**{k: v for k, v in row.items() if k not in ['font', 'inspection_occurrences']},
             'font_path': row['font']['path'], 'font_sha256': row['font']['sha256']} for row in rows]
    with out.with_suffix('.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(flat[0])); writer.writeheader(); writer.writerows(flat)
    print(json.dumps({'complete': True, 'font_faces': len(rows), 'interpreter': sum(r['prefer_interpreter'] for r in rows),
                      'auto': [r['label'] for r in rows if not r['prefer_interpreter']], 'output': str(out)}))


if __name__ == '__main__':
    main()
