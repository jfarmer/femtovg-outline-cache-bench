#!/usr/bin/env python3
"""Prepare source-only five-phase confirmation analysis and independent audit.

Retain the existing process estimators, bootstrap seed/index schedule and
control-difference estimator. Adapt source/build bindings to the frozen demo
collector; no renderer, timing, font selection or production edit is performed.
"""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = Path('/private/tmp/femtovg-font-stress-search-20261002')
CJK = Path('/private/tmp/femtovg-cjk-font-search-20261002')
OUTPUT = ROOT / 'demo-confirmation-analysis-v1'

IDENTITY = r'''def audit_identity(reader, identity):
    for name in ('demo_prepare', 'demo_build', 'active_collector', 'collector_correction_proof'):
        reader.check_info(identity[name])
    prep = reader.load(identity['demo_prepare']['path'])
    build = reader.load(identity['demo_build']['path'])
    require(prep['complete'] and build['complete'] and build['prepare'] == identity['demo_prepare'], 'Demo prepare/build binding differs')
    require(build['compiler'] == identity['compiler'] and build['cargo'] == identity['cargo'], 'Compiler differs')
    require(build['builder'] == prep['driver'], 'Demo preparation/build source differs')
    for field in ('driver','collector','original_collector','ablation_prepare','ablation_build','ablation_independent_audit','native_oracle_prepare','native_oracle_build'):
        reader.check_info(prep[field])
    require(reader.load(prep['ablation_independent_audit']['path'])['complete'], 'Reused runner independent proof incomplete')
    require(set(identity['binaries']) == {'master','final','no_retention'}, 'Reused demo executable set differs')
    require(set(identity['sources']) == {'master','final','no_retention','oracle'}, 'Frozen library set differs')
    def source_infos(root, expected):
        if reader.metadata_only:
            reader.skipped_live.append({'source_root':root,'files':len(expected)})
            return
        real = reader.resolve(root)
        actual = {str(path.relative_to(real)) for path in real.rglob('*') if path.is_file() and 'target' not in path.parts}
        require(actual == set(expected), 'Source file set differs: ' + str(root))
        for name,record in expected.items():
            require(record['path'] == str(Path(root)/name), 'Source record path differs')
            reader.check_info(record)
    for version,entry in prep['libraries'].items():
        require(identity['sources'][version] == entry['files'], 'Library identity differs: '+version)
        source_infos(entry['root'],entry['files'])
    for version,entry in prep['reused'].items():
        require(identity['binaries'][version] == entry['binary'], 'Reused binary binding differs: '+version)
        reader.check_info(entry['binary'],live=True)
        reader.check_info(entry['metadata'])
        source_infos(entry['runner_root'],entry['runner_files'])
    oracle = build['oracle']
    require(oracle['dependency_feature_graph_matches'] is True and identity['oracle_binary'] == oracle['binary'], 'Oracle binding differs')
    for field in ('metadata','reference_metadata','lockfile'):
        reader.check_info(oracle[field])
    reader.check_info(oracle['binary'],live=True)
    require(identity['runner_source'] == {name:record['sha256'] for name,record in prep['demo_source'].items()}, 'Drawing source differs')
    require(identity['shared_common'] == prep['shared_common'], 'Shared common binding differs')
    require(identity['assets'] == {name:record['sha256'] for name,record in prep['assets'].items()}, 'Assets differ')
    source_infos(prep['original_runner_root'],prep['original_runner_files'])
    source_infos(prep['shared_common_root'],prep['shared_common'])
    source_infos(prep['assets_root'],prep['assets'])
    # Cargo.lock is populated at build; its exact bytes are bound separately.
    oracle_source = dict(prep['oracle_runner_files'])
    oracle_source['Cargo.lock'] = oracle['lockfile']
    source_infos(prep['oracle_runner_root'],oracle_source)
    correction = reader.load(identity['collector_correction_proof']['path'])
    require(correction['complete'] and correction['before'] == prep['collector'] and correction['after'] == identity['active_collector'], 'Collector correction binding differs')
    for field in ('before','after','patcher'):
        reader.check_info(correction[field])
    source = reader.resolve(correction['before']['path']).read_text()
    for change in correction['changes']:
        require(source.count(change['old']) == 1, 'Collector correction source no longer applies')
        source = source.replace(change['old'],change['new'])
    require(source == reader.resolve(correction['after']['path']).read_text(), 'Collector changed beyond narrow correction')
    def graph(path):
        metadata = reader.load(path)
        root = metadata['resolve']['root']
        labels = {}
        for package in metadata['packages']:
            name = '<runner>' if package['id']==root else ('femtovg' if package['name']=='femtovg-mechanism-no-retention' else package['name'])
            labels[package['id']] = [name,package['version'],package['source'] or ('<runner>' if package['id']==root else '<femtovg>')]
        nodes = []
        for node in metadata['resolve']['nodes']:
            edges = [[edge['name'],labels[edge['pkg']],sorted(json.dumps(kind,sort_keys=True) for kind in edge['dep_kinds'])] for edge in node['deps']]
            nodes.append([labels[node['id']],sorted(node['features']),sorted(edges)])
        return sorted(nodes)
    baseline = graph(oracle['reference_metadata']['path'])
    require(graph(oracle['metadata']['path']) == baseline, 'Oracle dependency/feature graph differs')
    for entry in prep['reused'].values():
        require(graph(entry['metadata']['path']) == baseline, 'Reused dependency/feature graph differs')
    return prep
'''


def replace_once(source, old, new):
    assert source.count(old)==1, old[:100]
    return source.replace(old,new)


def info(path):
    path=Path(path).resolve(strict=True);raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def prepare():
    assert not OUTPUT.exists(), 'Preserve previous prepared analysis; use a fresh version'
    original = OLD/'analyze_font_confirm.py'
    text = original.read_text()
    text=replace_once(text,"VERSIONS = ('master', 'prior', 'updated45', 'final')","VERSIONS = ('master', 'final', 'no_retention')")
    start=text.index('PHASES = {');end=text.index('\nRAW_FIELDS = ',start)
    text=text[:start]+"PHASES = {'demo': {'first_paint': 1, 'warm': 30, 'zoom_in': 12, 'zoom_out': 12, 'pan': 10}}\nSEQUENCE_FRAMES = {'demo': 65}\n"+text[end:]
    start=text.index('def audit_identity(reader, identity):');end=text.index('\ndef audit_processes(',start)
    text=text[:start]+IDENTITY+text[end:]
    text=replace_once(text,"'phase_comparisons': len(expected) * 28 * (len(pixel_versions) - 1)","'phase_comparisons': len(expected) * sum(map(len, PHASES.values())) * (len(pixel_versions) - 1)")
    text=replace_once(text,"reference = 'oracle' if version == 'final' else 'master'","reference = 'oracle' if version in ('final','no_retention') else 'master'")
    text=replace_once(text,"reader.check_info(metadata['driver'])\n", "reader.check_info(metadata['driver'])\n    require(metadata['driver'] == metadata['identity']['active_collector'], 'Active collector binding differs')\n")
    text=replace_once(text,"'final' in versions and len(set(versions)) == len(versions) and set(versions) <= set(VERSIONS)","versions == ['master','final']")
    text=replace_once(text,"return (weights @ numpy.asarray(values, dtype=numpy.float64) / len(values)).tolist()","return ((weights * numpy.asarray(values, dtype=numpy.float64)).sum(axis=1) / len(values)).tolist()")
    text=replace_once(text,"parser.add_argument('--control-font', default='vollkorn')","parser.add_argument('--control-font', default='Rye-Regular')")
    text=replace_once(text,"demo65/text88/variations63 frames","demo65 frames")
    text=replace_once(text,"additional savings versus Vollkorn are separate claims","additional savings versus the prespecified control are separate claims")
    text=replace_once(text,"'controls_scope': 'Roboto variation controls remain fixed across regular-font factors and are not independent evidence for each selected font'","'controls_scope': 'Original icon, emoji and fallback fonts remain fixed across regular-font factors; only the unchanged demo is rendered. Rye and Vollkorn are freshly measured controls.'")
    ast.parse(text)
    audit_original=CJK/'independent_localized_confirmation_audit_v2.py'
    audit=audit_original.read_text()
    start=audit.index('PHASES = {');end=audit.index('\n\ndef main():',start)
    audit=audit[:start]+"PHASES = {'demo': {'first_paint': 1, 'warm': 30, 'zoom_in': 12, 'zoom_out': 12, 'pan': 10}}\n"+audit[end:]
    start=audit.index('    def localized_identity(identity):');end=audit.index('\n    values, backend_proofs, bootstrap',start)
    # The independent audit embeds the source proof and never imports the
    # collector/analyzer. Compiled/RGBA/font bodies remain an archive-integrity
    # prerequisite; metadata, graphs, drivers and correction bytes are checked.
    adapter='''    class IdentityReader:
        metadata_only = True
        skipped_live = []
        def resolve(self,path): return resolve(path)
        def load(self,path): return read(path)
        def check_info(self,record,live=False):
            if not live: check_info(record)
        def info(self,path):
            return {'path':str(path),'bytes':resolve(path).stat().st_size,'sha256':sha(path)}
    def require(ok,message):
        assert ok,message
'''
    embedded='\n'.join('    '+line if line else '' for line in IDENTITY.splitlines())+'\n'
    audit=audit[:start]+adapter+embedded+audit[end:]
    audit=replace_once(audit,"prep = localized_identity(meta['identity'])","prep = audit_identity(IdentityReader(),meta['identity'])")
    start=audit.index("        if meta['driver'] != prep['collector']:");end=audit.index("        assert meta['selection_manifest'] is not None",start)
    audit=audit[:start]+"        assert meta['driver'] == meta['identity']['active_collector']\n        check_info(meta['driver'])\n"+audit[end:]
    audit=replace_once(audit,"assert phases_per_trial == 28","assert phases_per_trial == 5")
    audit=replace_once(audit,"assert launch['cwd'] == str(Path(meta['identity']['prepare_provenance']['path']).parent / 'runtime/core')","assert launch['cwd'] == str(Path(meta['identity']['demo_prepare']['path']).parent)")
    audit=replace_once(audit,"'localized_source_metadata_bound':True","'demo_source_metadata_bound':True, 'live_source_font_binary_rgba_checks_in_completed_analysis':True")
    audit=replace_once(audit,'localized-confirmation effect','demo-confirmation effect')
    ast.parse(audit)
    OUTPUT.mkdir()
    paths={OUTPUT/'analyze_demo_confirm.py':(original,text), OUTPUT/'independent_demo_confirmation_audit.py':(audit_original,audit)}
    changes=[]
    for path,(before,after) in paths.items():
        path.write_text(after)
        changes.append({'before':info(before),'after':info(path),'diff':''.join(difflib.unified_diff(before.read_text().splitlines(True),after.splitlines(True),fromfile=str(before),tofile=str(path)))})
    (OUTPUT/'source-preparation.json').write_text(json.dumps({'complete':True,'source_only':True,'collection_executed':False,
        'preparer':info(Path(__file__)),'changes':changes,
        'statistics':'Original 12 paired process medians; 10,000 shared whole-block bootstrap indices, linear percentile intervals, per-trial weighted 65-frame sequence and control difference estimator preserved. Equivalent elementwise NumPy weighted means replace the BLAS matrix operation; separate direct-indexed independent resampling remains unchanged.',
        'scope':'Only the original five-phase demo. Frozen demo-only collector/build/source identity schema; strict master/final primary confirmation. Optional no-retention pixel preflight accepted, but six-block retention estimates require separate exploratory analysis.'},indent=2)+'\n')
    (OUTPUT/'USAGE.md').write_text('''# Primary unchanged-demo confirmation analysis

Font selection and matching native-offset-oracle pixels must be frozen before
fresh CPU collection: master/final, DPR2, 12 balanced blocks, five trials.
This preparation executes no collection or selection.

```sh
python3 -B analyze_demo_confirm.py --cpu CONFIRM_CPU --output FRESH_ANALYSIS --control-font Rye-Regular
python3 -B independent_demo_confirmation_audit.py --root ROOT --cpu CONFIRM_CPU --analysis FRESH_ANALYSIS --control-font Rye-Regular --output FRESH_INDEPENDENT_AUDIT
```

Default analysis verifies live source, executable, font and retained RGBA
bytes. The independent auditor separately recomputes original stdout medians,
weighted trial sequences, launch balance, seeded bootstrap indices, intervals
and same-block additional savings against Rye. Compiled/font/RGBA archive
integrity is a prerequisite for its offline mathematical audit.

Absolute microseconds and milliseconds are the primary report. Ratio fields
are retained as secondary diagnostics, and all phase costs and uncertain
intervals remain visible. Each chosen-font interval is conditional on the
exploratory selection; this is one machine and an unchanged demonstration
workload, not a population-level font threshold or end-to-end launch result.
''')
    print(OUTPUT)


if __name__=='__main__':
    prepare()
