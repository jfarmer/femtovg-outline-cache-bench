#!/usr/bin/env python3
"""Keep all v2 Rust artifacts and correct only optional retention count checks."""
from pathlib import Path
import difflib,hashlib,importlib.util,json
ROOT=Path(__file__).resolve().parent;STUDY=ROOT/'demo-only-replay-v2'
def info(p):
 p=Path(p).resolve(strict=True);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
PATCH_GATE=r'''# Bind this Python-only correction to the preserved v2 collector and Rust proof.
_original_input_identity = input_identity
def input_identity(study):
    identity = _original_input_identity(study)
    proof_path = study / 'collector-no-retention-count-fix.json'
    proof = load(proof_path)
    require(proof.get('complete') is True, 'Collector correction proof incomplete')
    require(info(proof['before']['path']) == proof['before'], 'Preserved v2 collector changed')
    require(info(Path(__file__)) == proof['after'], 'Active v3 collector changed')
    original = Path(proof['before']['path']).read_text()
    for change in proof['changes']:
        require(original.count(change['old']) == 1, 'Collector correction no longer matches original')
        original = original.replace(change['old'], change['new'])
    require(original == Path(__file__).read_text(), 'Collector differs beyond recorded corrections')
    require(info(proof['patcher']['path']) == proof['patcher'], 'Collector patch generator changed')
    identity['active_collector'] = proof['after']
    identity['collector_correction_proof'] = info(proof_path)
    return identity


'''
def main():
 old=STUDY/'replay_campaign.py';new=STUDY/'replay_campaign_v3.py';proof_path=STUDY/'collector-no-retention-count-fix.json';assert not new.exists() and not proof_path.exists()
 original=old.read_text();value=original
 changes=[dict(old="elif version != 'final' and reference is not None:",new="elif version not in ('final', 'no_retention') and reference is not None:"),
          dict(old="                provenance['count_comparisons'].append",new="                if 'no_retention' in captured and 'final' in captured:\n                    require(counts(captured['no_retention'][0]) == counts(captured['final'][0]), 'Retention ablation changed bitmap atlas counts')\n                provenance['count_comparisons'].append"),
          dict(old="if __name__ == '__main__':",new=PATCH_GATE+"if __name__ == '__main__':")]
 for change in changes:assert value.count(change['old'])==1;value=value.replace(change['old'],change['new'])
 new.write_text(value)
 proof=dict(complete=True,before=info(old),after=info(new),patcher=info(__file__),changes=changes,diff=''.join(difflib.unified_diff(original.splitlines(True),value.splitlines(True))),method='Python-only optional no-retention atlas validation. Reuse the completed v2 oracle, original libraries and already built English ablation binaries. No Rust, drawing, timing schedule, source/build proof or original collector mutation.')
 proof_path.write_text(json.dumps(proof,indent=2)+'\n')
 spec=importlib.util.spec_from_file_location('demo_collector_v3',new);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);identity=module.input_identity(STUDY)
 (STUDY/'input-identity-v3.json').write_text(json.dumps(identity,indent=2)+'\n')
 print('Python-only v3 identity gate passed using unchanged v2 Rust binaries; no collection')
if __name__=='__main__':main()
