#!/usr/bin/env python3
"""Acquire the separate pinned ten-family hinted-font supplement."""
import json
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parent / "hinted-supplement-v1"
command = [sys.executable, "-B", str(ROOT / "acquire_fonts.py"), "--workers", "4"]
result = subprocess.run(command, capture_output=True, text=True)
base = ROOT / "supporting/acquisition-command"
base.with_suffix(".stdout").write_text(result.stdout)
base.with_suffix(".stderr").write_text(result.stderr)
base.with_suffix(".json").write_text(json.dumps({"command": command, "exit_code": result.returncode}, indent=2) + "\n")
print(result.stdout)
print(result.stderr)
raise SystemExit(result.returncode)
