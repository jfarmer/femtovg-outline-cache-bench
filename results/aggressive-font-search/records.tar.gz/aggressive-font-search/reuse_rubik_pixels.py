#!/usr/bin/env python3
"""Add the pinned historical Rubik Pixels asset through verified local reuse."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
OLD = Path("/private/tmp/femtovg-font-stress-search-20261002")
PIN = "9710da1eacb3be272583c3224dcb70f9da6eadbb"

def info(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size}

def main():
    manifest = ROOT / "acquired-files.json"
    original = manifest.read_bytes()
    value = json.loads(original)
    assert value["complete"] and len(value["candidates"]) == 20
    retained = ROOT / "supporting/completed-20-font-manifest.json"
    assert not retained.exists()
    retained.write_bytes(original)
    tree = json.loads((ROOT / "supporting/acquisition/google-fonts-tree.json").read_text())
    assert not tree["truncated"]
    blobs = {item["path"]: item for item in tree["tree"] if item["type"] == "blob"}
    assets = []
    for name in ("RubikPixels-Regular.ttf", "OFL.txt", "METADATA.pb"):
        repository = "ofl/rubikpixels/" + name
        blob = blobs[repository]
        source = OLD / "fonts/rubikpixels" / name
        raw = source.read_bytes()
        actual = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        assert actual == blob["sha"], (name, "Historical asset does not match the pinned tree")
        destination = ROOT / "fonts/rubikpixels" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        assert not destination.exists()
        shutil.copyfile(source, destination)
        assert destination.read_bytes() == raw
        assets.append({"complete": True, "family": "rubikpixels", "repository_path": repository,
            "repository_blob_sha1": blob["sha"], "repository_bytes": blob["size"],
            "url": "https://raw.githubusercontent.com/google/fonts/" + PIN + "/" + repository,
            "browser_url": "https://github.com/google/fonts/blob/" + PIN + "/" + repository,
            "acquisition": "Verified unchanged local copy; no download", "reused_from": info(source),
            **info(destination), "attempts": []})
    candidate = {"family": "rubikpixels", "font_repository_path": "ofl/rubikpixels/RubikPixels-Regular.ttf",
        "license": "OFL-1.1", "source_repository": "google/fonts", "source_commit": PIN,
        "selection_reason": "Retained historical dynamic-outline challenger/control; previous application benefit was below Rye, so this is not a claimed new net-performance winner.",
        "assets": assets}
    value["candidates"].append(candidate)
    value["files"].extend(assets)
    value["extensions"] = [{"driver": info(Path(__file__)), "retained_primary_manifest": info(retained),
        "candidate": "rubikpixels", "acquisition": "All three font/license/metadata bytes match pinned official Git blob SHA-1; copied locally unchanged."}]
    manifest.write_text(json.dumps(value, indent=2) + "\n")
    retained21 = ROOT / "supporting/completed-21-font-manifest.json"
    assert not retained21.exists()
    retained21.write_bytes(manifest.read_bytes())
    print(json.dumps({"complete": True, "candidates": 21, "assets": len(value["files"]), "manifest": str(manifest), "reused_assets": len(assets)}))

if __name__ == "__main__":
    main()
