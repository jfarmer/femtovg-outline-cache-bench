#!/usr/bin/env python3
"""Preserve the live Fraction auditor and prepare an archive-capable variant.

Only omitted compiled executable bodies may be accepted explicitly. All
retained fonts, Rust/Python sources, build and dependency metadata, frozen
protocols, original raw stdout and exact arithmetic remain mandatory.
"""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BEFORE=ROOT/'supporting/audit_demo_screen_effects.py'
AFTER=ROOT/'supporting/audit_demo_screen_effects_archive.py'
PROOF=ROOT/'supporting/archive-demo-auditor-source-proof.json'

RESOLVER='''PATH_MAP = []
ALLOW_MISSING_BINARIES = False

def resolve(path):
    value = str(path)
    for old,new in PATH_MAP:
        if value==old or value.startswith(old.rstrip('/')+'/'):
            return Path(new+value[len(old):])
    return Path(value)

'''

GUARD='''def archived_guard(root):
    protocol_path = root/'demo-selection-v1/protocol.json'
    protocol=load(protocol_path)
    require(protocol['complete'] and protocol['source_only_protocol'],'Frozen protocol incomplete')
    require(info(protocol['selection']['path'])==protocol['selection'],'Frozen selection changed')
    require(info(protocol['driver']['path'])==protocol['driver'],'Frozen wrapper source changed')
    selection=load(protocol['selection']['path'])
    for name in ('collector','native_protocol','native_ranking','static_inspection','freezer'):
        require(info(selection[name]['path'])==selection[name],'Frozen input changed: '+name)
    for name in ('static_priors','demo_corpus_proof','source_derivation'):
        if name in selection:
            require(info(selection[name]['path'])==selection[name],'Frozen input changed: '+name)
    if 'native_rejection' in selection:
        for name in ('stdout_info','stderr_info'):
            record=selection['native_rejection'][name]
            require(info(record['path'])==record,'Retained native rejection changed')
    for font in selection['fonts']:
        require(info(font['path'])=={k:font[k] for k in ('path','bytes','sha256')},'Font changed: '+font['label'])
    identity=selection['input_identity']
    parent=Path(identity['demo_prepare']['path']).parent.parent
    analyzer_path=parent/'demo-confirmation-analysis-v1/analyze_demo_confirm.py'
    source_proof_path=parent/'demo-confirmation-analysis-v1/source-preparation.json'
    source_proof=load(source_proof_path)
    require(source_proof['complete'] and source_proof['source_only'],'Identity adapter preparation incomplete')
    require(info(source_proof['preparer']['path'])==source_proof['preparer'],'Identity adapter generator changed')
    bound=[entry for entry in source_proof['changes'] if entry['after']['path']==str(analyzer_path)]
    require(len(bound)==1 and info(analyzer_path)==bound[0]['after'],'Identity adapter source changed')
    spec=importlib.util.spec_from_file_location('frozen_demo_identity_adapter',resolve(analyzer_path))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    binary_records=[*identity['binaries'].values(),identity['oracle_binary']]
    class ArchiveReader(module.Reader):
        def __init__(self):
            super().__init__(dict(PATH_MAP),False)
            self.missing_compiled_bodies=[]
        def check_info(self,record,live=False):
            if live:
                require(record in binary_records,'Missing-body policy can only apply to recorded executables')
                if not self.resolve(record['path']).exists():
                    require(ALLOW_MISSING_BINARIES,'Executable is missing; pass explicit --allow-missing-binaries for an archive audit')
                    self.missing_compiled_bodies.append(record)
                    return
            super().check_info(record,live=False)
    reader=ArchiveReader()
    module.audit_identity(reader,identity)
    # The wrapper/collector are checked as source bytes and never imported or
    # called. Stored source identity is verified by the frozen adapter instead.
    require(selection['collector']==identity['active_collector'],'Selected collector differs from source identity')
    return protocol,selection,{
        'allow_missing_binaries_explicit':ALLOW_MISSING_BINARIES,
        'omitted_compiled_bodies':reader.missing_compiled_bodies,
        'identity_adapter':info(analyzer_path),'identity_adapter_source_proof':info(source_proof_path),
        'font_source_build_dependency_metadata_checks_retained':True,
        'wrapper_and_collector_imported':False,
        'path_map':dict(PATH_MAP)}

'''

def info(path):
    raw=Path(path).read_bytes()
    return {'path':str(Path(path).resolve()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def main():
    assert not AFTER.exists() and not PROOF.exists(), 'Keep original and failed preparations'
    original=BEFORE.read_text();source=original
    edits=[]
    def replace(old,new):
        nonlocal source
        assert source.count(old)==1,old[:100]
        source=source.replace(old,new);edits.append({'old':old,'new':new})
    replace("PHASES = {'first_paint':1",RESOLVER+"PHASES = {'first_paint':1")
    replace("path=Path(path).resolve(strict=True);raw=path.read_bytes()\n    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}","reported=str(Path(path));actual=resolve(path).resolve(strict=True);raw=actual.read_bytes()\n    return {'path':reported,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}")
    replace("return json.loads(Path(path).read_text())","return json.loads(resolve(path).read_text())")
    replace("def audit(root, output):\n    wrapper=root/'run_aggressive_demo_screen.py'\n    spec=importlib.util.spec_from_file_location('guarded_demo_wrapper',wrapper)\n    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)\n    protocol,selection=module.guard()",GUARD+"def audit(root, output):\n    root=resolve(root)\n    wrapper=root/'run_aggressive_demo_screen.py'\n    protocol,selection,archive_policy=archived_guard(root)")
    replace("with Path(launch['stdout']).open(newline='') as stream:","with resolve(launch['stdout']).open(newline='') as stream:")
    replace("'new_application_pixel_proof':False}","'new_application_pixel_proof':False,'archive_policy':archive_policy}")
    replace("output.write_text(json.dumps(result,indent=2)+'\\n');print(json.dumps(result,indent=2))","output.parent.mkdir(parents=True,exist_ok=True)\n    output.write_text(json.dumps(result,indent=2)+'\\n');print(json.dumps(result,indent=2))")
    replace("args=parser.parse_args();audit(args.root,args.output)","parser.add_argument('--path-map',type=Path,help='JSON mapping frozen original roots to extracted archive roots')\n    parser.add_argument('--allow-missing-binaries',action='store_true',help='Explicitly allow omitted compiled bodies only; verify every existing body and all fonts/source/build/raw/order identities')\n    args=parser.parse_args()\n    PATH_MAP=sorted((json.loads(args.path_map.read_text()) if args.path_map else {}).items(),key=lambda pair:-len(pair[0]))\n    ALLOW_MISSING_BINARIES=args.allow_missing_binaries\n    audit(args.root,args.output)")
    ast.parse(source)
    AFTER.write_text(source)
    PROOF.write_text(json.dumps({'complete':True,'source_only':True,'numeric_verification_executed':False,
        'original':info(BEFORE),'archive_auditor':info(AFTER),'preparer':info(Path(__file__)),
        'changes':edits,'diff':''.join(difflib.unified_diff(original.splitlines(True),source.splitlines(True),fromfile=str(BEFORE),tofile=str(AFTER))),
        'arithmetic_unchanged':True,
        'policy':'No live wrapper/collector imports. Reuse the separately frozen source/build identity adapter with all mandatory font/source/build/dependency/raw/order checks. Explicitly allow only missing recorded compiled executable bodies; reject altered existing bodies. Two-block Fraction medians, sequences, effects/ranges/signs and raw atlas annotations remain byte-identical.'},indent=2)+'\n')
    print(AFTER)


if __name__=='__main__':
    main()
