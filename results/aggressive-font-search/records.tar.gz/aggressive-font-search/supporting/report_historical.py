#!/usr/bin/env python3
"""Summarize retained historical selection evidence without running kernels."""
import csv
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[1]
OLD = Path('/private/tmp/femtovg-font-stress-search-20261002')


def info(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def main():
    rows, sources = [], []
    for cohort in ['native-screen', 'native-screen-wave2']:
        for source in sorted((OLD / cohort).glob('*/provenance.json')):
            provenance = json.loads(source.read_text())
            assert provenance['complete'] and provenance['mode'] == 'timing'
            sources.append(info(source))
            summary = source.parent / 'screen-summary.json'
            assert summary.exists()
            sources.append(info(summary))
            data = json.loads(summary.read_text())
            assert data['complete']
            label = next(iter(provenance['fonts']))
            assert len(provenance['fonts']) == 1
            for profile in ['ascii94', 'demo_unique']:
                row = {'cohort': cohort, 'font': label, 'profile': profile,
                       'font_path': provenance['fonts'][label]['path'],
                       'font_sha256': provenance['fonts'][label]['sha256'],
                       'trials': provenance['trials'], 'repeats': provenance['repeats'],
                       'rounds': provenance['rounds'], 'successful_launches': provenance['successful_launches'],
                       'rejected_launches': provenance['rejected_launches'],
                       'provenance_path': str(source), 'summary_path': str(summary)}
                for dpr in [1, 2]:
                    cases = [r for r in data['rows'] if r['profile'] == profile and r['dpr'] == dpr]
                    assert len(cases) in [0, 5]
                    for key in ['native_outline_us_per_glyph', 'native_outline_unhinted_us_per_glyph', 'hinting_increment_us_per_glyph',
                                'native_render_us_per_glyph', 'geometry_reuse_us_per_glyph', 'potential_saved_us_per_glyph']:
                        row[f'dpr{dpr}_{key}'] = statistics.median(r[key] for r in cases) if cases else None
                rows.append(row)
    app_source = OLD / 'demo-selection/ranking.json'
    app = json.loads(app_source.read_text())
    sources.append(info(app_source))
    app_by_label = {item['font']['label']: item for item in app['rows']}
    for row in rows:
        context = app_by_label.get(row['font'])
        if context:
            assert context['font']['sha256'] == row['font_sha256']
            for key in ['paired_blocks', 'first_master_us', 'first_final_us', 'first_saved_us', 'sequence_saved_us']:
                row['historical_demo_' + key] = context[key]
    application_context = {label: app_by_label[label] for label in ['Rye-Regular', 'RubikPixels-Regular', 'Vollkorn-Medium']}
    out = ROOT / 'supporting/historical-native-ranking.json'
    out.write_text(json.dumps({
        'complete': True, 'historical_campaigns': len(rows) // 2,
        'reporter_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'sources': sources, 'rows': rows, 'historical_application_context': application_context,
        'method': 'Read-only aggregation of retained historical screen-summary per-case trial medians. Each profile/DPR value is the median of five logical-size case medians, at 11/12/14/15/16 logical pixels. Hinting increment and potential avoided use the median of per-case median differences, rather than the difference of overview medians. No kernel was executed; no new independent raw audit or confidence claim is supplied by this report. Original raw logs and provenance remain unchanged. Historical native cohorts had four trials and one repeat; historical application selection had two paired blocks. Separate cohorts should not be treated as a contemporaneous matched benchmark. RubikPixels has slightly greater prepared outline cost than Rye but no positive hinting increment and smaller recorded application savings: native cost does not establish heavy glyph hinting or a greater net-cache benefit.',
    }, indent=2) + '\n')
    ranked = sorted(rows, key=lambda row: (row['profile'], -(row['dpr1_native_outline_us_per_glyph'] or -1), row['font']))
    with out.with_suffix('.csv').open('w', newline='') as stream:
        fields = list(ranked[0]) + sorted(set().union(*(set(row) for row in ranked)) - set(ranked[0]))
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader(); writer.writerows(ranked)
    for row in ranked:
        if row['profile'] == 'demo_unique':
            print(row['cohort'], row['font'],
                  f'DPR1 {row["dpr1_native_outline_us_per_glyph"]:.4f}',
                  f'DPR2 {row["dpr2_native_outline_us_per_glyph"]:.4f}')
    print(json.dumps({'complete': True, 'campaigns': len(rows) // 2, 'output': str(out)}))


if __name__ == '__main__':
    main()
