#!/usr/bin/env python3
"""Check actual exploration dependencies before reports/manifest are finalized.

This never writes a completed study manifest, invokes a collector, changes a
frozen source, or runs timing. It independently checks the field/byte contracts
used by the installer and preserves an explicit source-bound preflight proof.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REPO = Path("/Users/jesse/github/femtovg-outline-cache-bench")
COHORTS = (("broad-29", "", 29), ("hinted-10", "hinted-supplement-v1", 10), ("ornate-8", "ornate-supplement-v1", 8))


def load(path):
    value = json.loads(Path(path).read_text())
    if value.get("complete") is not True:
        raise ValueError("Completed real evidence required: " + str(path))
    return value


def info(path):
    path = Path(path)
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"bytes": path.stat().st_size, "sha256": checksum}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("Fresh preflight output required")
    index = json.loads((REPO / "results/index.json").read_text())
    assert (len(index["campaigns"]), len(index["analysis_audits"])) == (31, 15)
    checked = {}
    def check(path, expected=None):
        path = Path(path)
        actual = info(path)
        if expected is not None and actual != {k: expected[k] for k in ("bytes", "sha256")}:
            raise ValueError("Actual dependency changed: " + str(path))
        checked[str(path)] = actual
        return actual
    native_reader = check(REPO / "scripts/independent_cjk_native_audit.py")
    demo_reader = check(ROOT / "supporting/audit_demo_screen_effects_archive.py")
    cohorts = []
    for label, child, candidates in COHORTS:
        root = ROOT / child
        acquired = load(root / "acquired-files.json")
        assert len(acquired["candidates"]) == candidates
        check(root / "acquired-files.json")
        for asset in acquired["files"]:
            assert asset["complete"]
            check(asset["path"], asset)
            raw = Path(asset["path"]).read_bytes()
            assert len(raw) == asset["repository_bytes"]
            assert hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == asset["repository_blob_sha1"]
        protocol = load(root / "native-prescreen-protocol-v1.json")
        assert protocol["source_only_protocol"] and (protocol["trials"],protocol["repeats"],protocol["rounds"]) == (4,3,1)
        assert protocol["font_count_including_controls"] == candidates + 2
        check(root / "native-prescreen-protocol-v1.json")
        for binding in protocol["bindings"]:
            check(binding["path"], binding)
        native = load(root / "supporting/native-prescreen-audit.json")
        assert native["inspector_sha256"] == native_reader["sha256"] and not native["missing_binaries_explicit_archive_mode"]
        assert len(native["screens"]) == 1
        screen = native["screens"][0]
        assert Path(screen["root"]).resolve() == (root / "native-prescreen-v1").resolve()
        assert len(screen["successful_launches"]) + len(screen["rejected_launches"]) == candidates + 2
        check(root / "supporting/native-prescreen-audit.json")
        for path, binding in native["inputs"].items():
            check(path, binding)
        demo = load(root / "demo-screen-v1/independent-analysis/archive-fraction-audit.json")
        assert demo["auditor"]["sha256"] == demo_reader["sha256"]
        policy = demo["archive_policy"]
        assert policy["font_source_build_dependency_metadata_checks_retained"]
        assert policy["wrapper_and_collector_imported"] is False and not policy["omitted_compiled_bodies"]
        for field in ("wrapper", "protocol", "selection", "provenance", "analysis"):
            check(demo[field]["path"], demo[field])
        for field in ("identity_adapter", "identity_adapter_source_proof"):
            check(policy[field]["path"], policy[field])
        assert (demo["processes_checked"],demo["raw_original_stdout_rows_checked"]) == ((candidates+2)*4,(candidates+2)*60)
        check(root / "demo-screen-v1/independent-analysis/archive-fraction-audit.json")
        cohorts.append({"label":label,"candidate_fonts":candidates,"native_successes":len(screen["successful_launches"]),"native_rejections":len(screen["rejected_launches"]),"native_rows":screen["raw_rows_checked"],"demo_processes":demo["processes_checked"],"demo_rows":demo["raw_original_stdout_rows_checked"]})
    check(ROOT / "install_aggressive_study.py")
    check(ROOT / "finalize_aggressive_manifest.py")
    check(Path(__file__))
    result = {"complete":True,"scope":"Actual installed baseline31/15 and full live exploration byte/field dependencies only; no final report, confirmation statistics or archive-stage claim", "cohorts":cohorts,"inputs":checked}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"complete":True,"cohorts":cohorts,"checked_files":len(checked),"output":str(args.output)}))


if __name__ == "__main__":
    main()
