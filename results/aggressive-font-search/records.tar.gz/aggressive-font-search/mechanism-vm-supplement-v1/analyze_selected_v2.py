#!/usr/bin/env python3
"""Audit count-only outputs and summarize dynamic VM work, never timings."""
from collections import defaultdict
import csv
import hashlib
import json
from pathlib import Path
import statistics

BASE = Path(__file__).resolve().parents[1]
ROOT = Path('/private/tmp/femtovg-cjk-font-search-20261002/mechanism-diagnostic')
RUNS = Path('/private/tmp/femtovg-aggressive-font-search-20261002/mechanism-vm-supplement-v1')
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def tree(path):
    return {str(p.relative_to(path)): sha(p) for p in sorted(path.rglob("*")) if p.is_file()}
def read(path):
    return json.loads(Path(path).read_text())
prep = read(ROOT / "prepare.json")
run = read(RUNS / "provenance.json")
assert prep["complete"] and run["complete"] and run["count_only"] and run["no_timing_results"]
assert sha(ROOT / "prepare.json") == run["prepare_sha256"]
assert tree(Path(prep["original_skrifa"])) == prep["original_skrifa_files"]
assert tree(ROOT / "vendor/skrifa") == prep["instrumented_skrifa_files"]
assert prep["changed_existing_skrifa_files"] == ["src/lib.rs", "src/outline/glyf/hint/engine/dispatch.rs"]
assert prep["added_skrifa_files"] == ["src/femtovg_diagnostic.rs"]
assert sha(ROOT / "package-native/src/main.rs") == sha(ROOT / "package-counted/src/main.rs") == prep["driver_sha256"]
all_rows = {}
checked = {str(ROOT / "prepare.json"): sha(ROOT / "prepare.json"), str(RUNS / "provenance.json"): sha(RUNS / "provenance.json")}
case_rows = []
total_vm_errors = 0
matched_alpha_cases = 0
for locale, reference in prep["native_references"].items():
    assert sha(reference["provenance"]) == reference["provenance_sha256"]
    assert sha(reference["build"]) == reference["build_sha256"]
    assert sha(reference["source"]) == reference["source_sha256"]
for launch in run["launches"]:
    assert launch["complete"] and launch["exit_code"] == 0
    assert sha(launch["build"]) == launch["build_sha256"]
    build = read(launch["build"])
    assert build["complete"] and sha(build["binary"]) == build["binary_sha256"]
    assert build["mode"] == launch["mode"]
    assert sha(launch["font_file"]["path"]) == launch["font_file"]["sha256"]
    package = ROOT / ("package-" + launch["mode"])
    assert tree(package / "src") == build["source_files"]
    assert sha(package / "Cargo.toml") == build["manifest_sha256"]
    assert sha(package / "Cargo.lock") == build["lock_sha256"]
    assert sha(Path(launch["build"]).parent / "metadata.json") == build["metadata_sha256"]
    for field in ("stdout", "stderr"):
        assert sha(launch[field]) == launch[field + "_sha256"]
        checked[launch[field]] = launch[field + "_sha256"]
    rows = [json.loads(line) for line in Path(launch["stdout"]).read_text().splitlines()]
    assert len(rows) == launch["rows"]
    key = launch["locale"], launch["font"], launch["mode"]
    assert key not in all_rows
    all_rows[key] = rows
    grouped = defaultdict(list)
    for row in rows:
        assert row["kind"] in ("setup", "glyph", "audit")
        assert row["size"] == row["logical_size"] * row["dpr"]
        grouped[row["profile"], row["dpr"], row["logical_size"]].append(row)
        if row["kind"] != "audit":
            assert len(row["counts"]) == 3
            for initial, counts in enumerate(row["counts"]):
                assert counts["initial"] == initial
                assert all(isinstance(counts[field], int) and counts[field] >= 0 for field in ("runs", "errors", "instructions"))
                assert counts["errors"] <= counts["runs"]
                assert counts["instructions"] == sum(counts["opcodes"].values()) == sum(counts["origin_instructions"])
                assert all(0 <= int(opcode) <= 255 and isinstance(count, int) and count > 0 for opcode, count in counts["opcodes"].items())
                total_vm_errors += counts["errors"]
                if not row["hinted"] or launch["mode"] == "native":
                    assert counts["runs"] == counts["errors"] == counts["instructions"] == 0
    assert len(grouped) == 20
    assert sha(launch["native_reference"]["path"]) == launch["native_reference"]["sha256"]
    assert sha(launch["native_reference_stdout"]["path"]) == launch["native_reference_stdout"]["sha256"]
    checked[launch["native_reference"]["path"]] = launch["native_reference"]["sha256"]
    checked[launch["native_reference_stdout"]["path"]] = launch["native_reference_stdout"]["sha256"]
    reference = read(launch["native_reference"]["path"])
    reference_launch = next(item for item in reference["launches"] if item["font"] == launch["font"])
    original = list(csv.DictReader(Path(reference_launch["stdout"]).open()))
    for (profile, dpr, logical_size), case in grouped.items():
        audits = [row for row in case if row["kind"] == "audit"]
        assert len(audits) == 1
        audit = audits[0]
        original_case = [row for row in original if (row["profile"], int(row["dpr"]), float(row["logical_size"])) == (profile, dpr, logical_size)]
        assert len(original_case) == 16
        for row in original_case:
            assert row["audit_digest"] == audit["audit_digest"]
            assert all(int(row[field]) == audit[field] for field in ("glyphs", "points", "verbs", "audit_images"))
        matched_alpha_cases += 1
        assert len([row for row in case if row["kind"] == "setup"]) == 4
        for hinted in (True, False):
            glyphs = [row for row in case if row["kind"] == "glyph" and row["hinted"] == hinted]
            assert len(glyphs) == len({row["glyph"] for row in glyphs}) == audit["glyphs"]
            setups = {row["stage"]: row for row in case if row["kind"] == "setup" and row["hinted"] == hinted}
            assert set(setups) == {"builder", "warmup"}
            for initial in range(3):
                assert sum(row["counts"][initial]["instructions"] for row in glyphs) == setups["warmup"]["counts"][initial]["instructions"]
            if not hinted or launch["mode"] != "counted":
                continue
            assert all(row["counts"][initial]["instructions"] == row["counts"][initial]["runs"] == 0 for row in glyphs for initial in (0, 1))
            builder = setups["builder"]["counts"]
            assert builder[2]["runs"] == builder[2]["instructions"] == 0
            def mean(field):
                return statistics.mean(row[field] for row in glyphs)
            def op_mean(opcodes):
                return sum(sum(row["counts"][2]["opcodes"].get(str(op), 0) for op in opcodes) for row in glyphs) / len(glyphs)
            case_rows.append({
                "locale": launch["locale"], "font": launch["font"], "font_sha256": launch["font_file"]["sha256"], "profile": profile, "dpr": dpr, "logical_size": logical_size, "glyphs": len(glyphs),
                "mean_glyph_completed_dispatches": statistics.mean(row["counts"][2]["instructions"] for row in glyphs),
                "maximum_glyph_completed_dispatches": max(row["counts"][2]["instructions"] for row in glyphs),
                "mean_glyph_engine_runs": statistics.mean(row["counts"][2]["runs"] for row in glyphs),
                "mean_fpgm_origin_dispatches_during_glyph": statistics.mean(row["counts"][2]["origin_instructions"][0] for row in glyphs),
                "mean_prep_origin_dispatches_during_glyph": statistics.mean(row["counts"][2]["origin_instructions"][1] for row in glyphs),
                "mean_glyf_origin_dispatches_during_glyph": statistics.mean(row["counts"][2]["origin_instructions"][2] for row in glyphs),
                "mean_call_dispatches": op_mean([0x2B]), "mean_loopcall_dispatches": op_mean([0x2A]), "mean_jump_dispatches": op_mean([0x1C, 0x78, 0x79]),
                "mean_push_dispatches": op_mean([0x40, 0x41, *range(0xB0, 0xC0)]), "mean_mdrp_mirp_dispatches": op_mean(range(0xC0, 0x100)),
                "mean_points": mean("points"), "mean_verbs": mean("verbs"), "builder_font_dispatches": builder[0]["instructions"], "builder_prep_dispatches": builder[1]["instructions"],
                "audit_digest": audit["audit_digest"],
            })
assert len(all_rows) == 6 and matched_alpha_cases == run["original_native_alpha_case_matches"] == 120
for locale, fonts in run["choices"].items():
    for font in fonts:
        native = all_rows[locale, font, "native"]
        counted = all_rows[locale, font, "counted"]
        assert len(native) == len(counted)
        for a, b in zip(native, counted):
            assert {key: value for key, value in a.items() if key != "counts"} == {key: value for key, value in b.items() if key != "counts"}
assert total_vm_errors == 0
groups = defaultdict(list)
for row in case_rows:
    groups[row["locale"], row["font"], row["profile"], row["dpr"]].append(row)
overview = []
identity_fields = {"locale", "font", "font_sha256", "profile", "dpr", "logical_size", "glyphs", "audit_digest"}
for key, rows in sorted(groups.items()):
    assert len(rows) == 5
    result = dict(zip(("locale", "font", "profile", "dpr"), key))
    result["font_sha256"] = rows[0]["font_sha256"]
    for field in rows[0]:
        if field not in identity_fields:
            result[field] = statistics.median(row[field] for row in rows)
    overview.append(result)
out = RUNS / "analysis"
out.mkdir(exist_ok=True)
result = {"complete": True, "count_only": True, "no_timing_results": True, "analyzer_sha256": sha(__file__), "prepare_sha256": sha(ROOT / "prepare.json"), "runs_provenance_sha256": sha(RUNS / "provenance.json"), "checked_raw_files": checked, "processes": 6, "matched_native_alpha_cases": matched_alpha_cases, "native_counted_hinted_and_unhinted_geometry_hashes_exact": True, "vm_error_count": total_vm_errors, "method": "Existing Engine::run completed-dispatch count, plus local opcode/origin counters, recorded once per program invocation; called and looped function bodies expand dynamically. Initial-program attribution separates Font/ControlValue/Glyph; source-origin attribution identifies called fpgm code during Glyph execution. Builder preparation and warmup recorded separately, then reset before each single glyph. Per-case means over unique profile glyphs; profile/DPR overview is median across five logical sizes. No performance numbers, cache overhead estimates, or program-count performance predictions. PUSH operands, skipped branch/function-definition scanning, point loops inside an opcode, scratch setup, memory copies, parsing and rasterization are not separate dispatched instructions.", "cases": case_rows, "profile_dpr_medians": overview}
(out / "count-summary.json").write_text(json.dumps(result, indent=2) + "\n")
for name, rows in (("count-cases.csv", case_rows), ("count-overview.csv", overview)):
    with (out / name).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
for path, expected in checked.items():
    assert sha(path) == expected
assert tree(Path(prep["original_skrifa"])) == prep["original_skrifa_files"]
print(json.dumps({"complete": True, "processes": 6, "matched_native_alpha_cases": matched_alpha_cases, "vm_errors": total_vm_errors, "output": str(out)}))
