#!/usr/bin/env python3
"""Finish the preserved six successful count runs; never rerun their binaries.

The original wrapper failed while adapting its analyzer after collection. Keep
that source and its stderr unchanged; adapt only analysis paths and cardinality.
"""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
DIAGNOSTIC = Path('/private/tmp/femtovg-cjk-font-search-20261002/mechanism-diagnostic')
ORIGINAL = Path('/private/tmp/femtovg-cjk-font-search-20261002/supporting/analyze_mechanism_diagnostic.py')


def info(path):
    raw = Path(path).read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    run = json.loads((ROOT / 'provenance.json').read_text())
    assert run['complete'] and run['count_only'] and len(run['launches']) == 6
    assert info(ROOT / 'run_selected.py')['sha256'] == run['driver_sha256']
    assert not (ROOT / 'analysis-execution-v2.json').exists()
    original = ORIGINAL.read_text()
    tail = original[original.index('lines = ["Dynamic TrueType execution diagnostic"'):]
    adapted = original[:-len(tail)]
    edits = [{'old': tail, 'new': 'Historical Markdown tail replaced by final source/raw-file guards and a six-process completion record.'}]
    def replace(old, new):
        nonlocal adapted
        assert adapted.count(old) == 1, old
        adapted = adapted.replace(old, new)
        edits.append({'old': old, 'new': new})
    replace('ROOT = BASE / "mechanism-diagnostic"', f'ROOT = Path({str(DIAGNOSTIC)!r})\nRUNS = Path({str(ROOT)!r})')
    replace('run = read(ROOT / "runs-01/provenance.json")', 'run = read(RUNS / "provenance.json")')
    replace('checked = {str(ROOT / "prepare.json"): sha(ROOT / "prepare.json"), str(ROOT / "runs-01/provenance.json"): sha(ROOT / "runs-01/provenance.json")}',
            'checked = {str(ROOT / "prepare.json"): sha(ROOT / "prepare.json"), str(RUNS / "provenance.json"): sha(RUNS / "provenance.json")}')
    replace('    reference = read(prep["native_references"][launch["locale"]]["provenance"])',
            '    assert sha(launch["native_reference"]["path"]) == launch["native_reference"]["sha256"]\n    assert sha(launch["native_reference_stdout"]["path"]) == launch["native_reference_stdout"]["sha256"]\n    checked[launch["native_reference"]["path"]] = launch["native_reference"]["sha256"]\n    checked[launch["native_reference_stdout"]["path"]] = launch["native_reference_stdout"]["sha256"]\n    reference = read(launch["native_reference"]["path"])')
    replace('assert len(all_rows) == 28 and matched_alpha_cases == run["original_native_alpha_case_matches"] == 560',
            'assert len(all_rows) == 6 and matched_alpha_cases == run["original_native_alpha_case_matches"] == 120')
    replace('out = ROOT / "analysis"', 'out = RUNS / "analysis"')
    replace('sha(ROOT / "runs-01/provenance.json")', 'sha(RUNS / "provenance.json")')
    replace('"processes": 28, "matched_native_alpha_cases"', '"processes": 6, "matched_native_alpha_cases"')
    adapted += 'for path, expected in checked.items():\n    assert sha(path) == expected\nassert tree(Path(prep["original_skrifa"])) == prep["original_skrifa_files"]\nprint(json.dumps({"complete": True, "processes": 6, "matched_native_alpha_cases": matched_alpha_cases, "vm_errors": total_vm_errors, "output": str(out)}))\n'
    ast.parse(adapted)
    path = ROOT / 'analyze_selected_v2.py'; path.write_text(adapted)
    write(ROOT / 'auditor-adaptation-v2.json', {
        'complete': True, 'original_auditor': info(ORIGINAL), 'adapted_auditor': info(path),
        'literal_source_edits': edits, 'original_failed_collector': info(ROOT / 'run_selected.py'),
        'original_failure_stderr': info(ROOT / 'collector.stderr'),
        'method': 'Original dynamic-count arithmetic and source/geometry/alpha checks retained. Fresh paths, stronger native-reference final guards, and six/120 cardinality adapted; historical CJK Markdown tail omitted. No count binary is rerun.',
    })
    command = [sys.executable, '-B', str(path)]
    with (ROOT / 'analysis-v2.stdout').open('w') as out, (ROOT / 'analysis-v2.stderr').open('w') as err:
        result = subprocess.run(command, stdout=out, stderr=err)
    write(ROOT / 'analysis-execution-v2.json', {
        'complete': result.returncode == 0, 'command': command, 'exit_code': result.returncode,
        'adapter': info(Path(__file__)), 'adapted_auditor': info(path),
        'stdout': info(ROOT / 'analysis-v2.stdout'), 'stderr': info(ROOT / 'analysis-v2.stderr'),
    })
    assert result.returncode == 0
    print((ROOT / 'analysis-v2.stdout').read_text(), end='')


if __name__ == '__main__':
    main()
