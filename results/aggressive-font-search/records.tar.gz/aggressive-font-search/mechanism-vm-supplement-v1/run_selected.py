#!/usr/bin/env python3
"""Run sealed count-only native/count binaries for Fleur/Rye/Vollkorn.

No timings, compilation, production changes or dependency modifications.
Reuse the original diagnostic auditor's arithmetic with explicit fresh run and
native-reference bindings; keep all original diagnostic artifacts untouched.
"""
import ast
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
DIAGNOSTIC = Path('/private/tmp/femtovg-cjk-font-search-20261002/mechanism-diagnostic')
ORIGINAL_AUDITOR = Path('/private/tmp/femtovg-cjk-font-search-20261002/supporting/analyze_mechanism_diagnostic.py')
REFERENCE = ROOT.parent / 'hinted-supplement-v1/native-prescreen-v1/provenance.json'
LABELS = ['FleurDeLeah-Regular', 'Rye-Regular', 'Vollkorn-Medium']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def info(path):
    return {'path': str(path), 'sha256': sha(path), 'bytes': Path(path).stat().st_size}


def tree(path):
    return {str(p.relative_to(path)): sha(p) for p in sorted(Path(path).rglob('*')) if p.is_file()}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    assert not (ROOT / 'provenance.json').exists(), 'Use a fresh count campaign; preserve previous attempts.'
    prep = json.loads((DIAGNOSTIC / 'prepare.json').read_text()); assert prep['complete']
    assert tree(Path(prep['original_skrifa'])) == prep['original_skrifa_files']
    assert tree(DIAGNOSTIC / 'vendor/skrifa') == prep['instrumented_skrifa_files']
    assert sha(DIAGNOSTIC / 'package-native/src/main.rs') == sha(DIAGNOSTIC / 'package-counted/src/main.rs') == prep['driver_sha256']
    reference = json.loads(REFERENCE.read_text()); assert reference['complete']
    proof = {'complete': False, 'count_only': True, 'no_timing_results': True,
             'driver_sha256': sha(Path(__file__)), 'prepare_sha256': sha(DIAGNOSTIC / 'prepare.json'),
             'choices': {'en': LABELS}, 'native_reference': info(REFERENCE), 'launches': [],
             'scope': 'Sealed existing native/count binaries; default coordinates, English ASCII94/demo_unique sizes11/12/14/15/16 at both native DPRs. Counted execution is not timed.'}
    write(ROOT / 'provenance.json', proof)
    for mode in ['native', 'counted']:
        build_path = DIAGNOSTIC / ('build-' + mode + '-01/build.json')
        built = json.loads(build_path.read_text()); assert built['complete']
        assert sha(built['binary']) == built['binary_sha256']
        for label in LABELS:
            font = reference['fonts'][label]
            assert sha(font['path']) == font['sha256']
            stem = mode + '-en-' + label
            command = [built['binary'], font['path'], font['sha256'], 'en']
            launch = {'complete': False, 'mode': mode, 'locale': 'en', 'font': label,
                      'font_file': font, 'build': str(build_path), 'build_sha256': sha(build_path),
                      'native_reference': info(REFERENCE), 'command': command,
                      'stdout': str(ROOT / (stem + '.jsonl')), 'stderr': str(ROOT / (stem + '.stderr'))}
            proof['launches'].append(launch); write(ROOT / 'provenance.json', proof)
            with Path(launch['stdout']).open('w') as out, Path(launch['stderr']).open('w') as err:
                result = subprocess.run(command, stdout=out, stderr=err, timeout=120)
            launch.update(exit_code=result.returncode, stdout_sha256=sha(launch['stdout']), stderr_sha256=sha(launch['stderr']))
            write(ROOT / 'provenance.json', proof)
            assert result.returncode == 0, 'Count run failed; original partial output retained'
            rows = [json.loads(line) for line in Path(launch['stdout']).read_text().splitlines()]
            audits = [row for row in rows if row['kind'] == 'audit']; assert len(audits) == 20
            native_launch = next(item for item in reference['launches'] if item['font'] == label)
            assert native_launch['complete']
            originals = list(csv.DictReader(Path(native_launch['stdout']).open()))
            for audit in audits:
                matches = [row for row in originals if (row['profile'], int(row['dpr']), float(row['logical_size'])) ==
                           (audit['profile'], audit['dpr'], audit['logical_size'])]
                assert len(matches) == 16
                for original in matches:
                    assert all(int(original[field]) == audit[field] for field in ['glyphs', 'points', 'verbs', 'audit_images'])
                    assert original['audit_digest'] == audit['audit_digest']
            assert sha(font['path']) == font['sha256'] and sha(built['binary']) == built['binary_sha256']
            launch.update(complete=True, rows=len(rows), case_audits=20,
                          native_retained_counts_and_alpha_digests_exact=True,
                          native_reference_stdout=info(Path(native_launch['stdout'])))
            write(ROOT / 'provenance.json', proof)
            print(stem + ': native counts and ten-phase alpha digest exact', flush=True)
    for label in LABELS:
        launches = [item for item in proof['launches'] if item['font'] == label]
        raw = [[json.loads(line) for line in Path(item['stdout']).read_text().splitlines()] for item in launches]
        assert len(raw[0]) == len(raw[1])
        for native, counted in zip(*raw):
            assert {key: value for key, value in native.items() if key != 'counts'} == {key: value for key, value in counted.items() if key != 'counts'}
    assert tree(Path(prep['original_skrifa'])) == prep['original_skrifa_files']
    assert tree(DIAGNOSTIC / 'vendor/skrifa') == prep['instrumented_skrifa_files']
    proof.update(complete=True, original_native_alpha_case_matches=120,
                 native_counted_hinted_and_unhinted_outline_hashes_exact=True)
    write(ROOT / 'provenance.json', proof)
    original_source = ORIGINAL_AUDITOR.read_text()
    adapted = original_source
    edits = []
    def replace(old, new):
        nonlocal adapted
        assert adapted.count(old) == 1, old
        adapted = adapted.replace(old, new)
        edits.append({'old': old, 'new': new})
    replace('ROOT = BASE / "mechanism-diagnostic"', f'ROOT = Path({str(DIAGNOSTIC)!r})\nRUNS = Path({str(ROOT)!r})')
    replace('run = read(ROOT / "runs-01/provenance.json")', 'run = read(RUNS / "provenance.json")')
    replace('checked = {str(ROOT / "prepare.json"): sha(ROOT / "prepare.json"), str(ROOT / "runs-01/provenance.json"): sha(ROOT / "runs-01/provenance.json")}',
            'checked = {str(ROOT / "prepare.json"): sha(ROOT / "prepare.json"), str(RUNS / "provenance.json"): sha(RUNS / "provenance.json")}')
    replace('    reference = read(prep["native_references"][launch["locale"]]["provenance"])',
            '    assert sha(launch["native_reference"]["path"]) == launch["native_reference"]["sha256"]\n    assert sha(launch["native_reference_stdout"]["path"]) == launch["native_reference_stdout"]["sha256"]\n    reference = read(launch["native_reference"]["path"])')
    replace('assert len(all_rows) == 28 and matched_alpha_cases == run["original_native_alpha_case_matches"] == 560',
            'assert len(all_rows) == 6 and matched_alpha_cases == run["original_native_alpha_case_matches"] == 120')
    replace('out = ROOT / "analysis"', 'out = RUNS / "analysis"')
    replace('sha(ROOT / "runs-01/provenance.json")', 'sha(RUNS / "provenance.json")')
    replace('"processes": 28, "matched_native_alpha_cases"', '"processes": 6, "matched_native_alpha_cases"')
    old_tail = adapted[adapted.index('lines = ["Dynamic TrueType execution diagnostic"'):]
    new_tail = 'for path, expected in checked.items():\n    assert sha(path) == expected\nassert tree(Path(prep["original_skrifa"])) == prep["original_skrifa_files"]\nprint(json.dumps({"complete": True, "processes": 6, "matched_native_alpha_cases": matched_alpha_cases, "vm_errors": total_vm_errors, "output": str(out)}))\n'
    replace(old_tail, new_tail)
    ast.parse(adapted)
    adapted_path = ROOT / 'analyze_selected.py'; adapted_path.write_text(adapted)
    write(ROOT / 'auditor-adaptation.json', {'complete': True, 'original_auditor': info(ORIGINAL_AUDITOR),
                                           'adapted_auditor': info(adapted_path), 'literal_source_edits': edits,
                                           'method': 'Original arithmetic and raw-count/geometry/source checks retained; only fresh artifact paths, native-reference guards, six/120 expected counts and irrelevant historical Markdown tail changed.'})
    command = [sys.executable, '-B', str(adapted_path)]
    with (ROOT / 'analysis.stdout').open('w') as out, (ROOT / 'analysis.stderr').open('w') as err:
        result = subprocess.run(command, stdout=out, stderr=err)
    write(ROOT / 'analysis-execution.json', {'complete': result.returncode == 0, 'command': command,
                                           'exit_code': result.returncode, 'adapted_auditor': info(adapted_path),
                                           'stdout': info(ROOT / 'analysis.stdout'), 'stderr': info(ROOT / 'analysis.stderr')})
    assert result.returncode == 0, 'Count analysis failed; all output retained'
    print(json.dumps({'complete': True, 'processes': 6, 'native_alpha_cases': 120, 'output': str(ROOT / 'analysis')}))


if __name__ == '__main__':
    main()
