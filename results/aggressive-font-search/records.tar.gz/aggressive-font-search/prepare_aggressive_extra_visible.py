#!/usr/bin/env python3
"""Declare completed causal report/proof copies without changing result bytes."""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DESTINATION = "analysis/aggressive-font-search/"
FILES = [
    "supporting/selected-mechanism-report.json",
    "supporting/selected-mechanism-report.md",
    "supporting/selected-mechanism-vm-profiles.csv",
    "supporting/selected-mechanism-trace-phases.csv",
    "supporting/selected-mechanism-hit-weighted-first-paint.csv",
    "supporting/selected-mechanism-input-bindings.json",
    "supporting/report_selected_mechanism.py",
    "supporting/installer-dependency-preflight-v2.json",
    "supporting/production-unchanged-final.json",
    "supporting/final-report-review-v1.json",
    "supporting/review_final_reports_v1.py",
    "mechanism-production-trace-v1/trace-campaign.json",
    "mechanism-production-trace-v1/counts-analysis.json",
    "mechanism-production-trace-v1/independent-count-audit.json",
    "mechanism-production-trace-v1/analysis-execution.json",
    "mechanism-production-trace-v1/analyzer-adaptation.json",
    "mechanism-production-trace-v1/outer-execution-record.json",
    "mechanism-vm-ornate-v1/auditor-adaptation.json",
    "mechanism-vm-ornate-v1/analysis-execution.json",
    "mechanism-vm-ornate-v1/outer-execution-record.json",
    "mechanism-vm-supplement-v1/auditor-adaptation-v2.json",
    "mechanism-vm-supplement-v1/analysis-execution-v2.json",
    "demo-confirmation-analysis-v1/source-preparation.json",
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("Fresh explicit copy map required")
    for path in FILES:
        if not (ROOT / path).is_file():
            raise ValueError("Completed declared output missing: " + path)
    report = json.loads((ROOT / "supporting/selected-mechanism-report.json").read_text())
    bindings = json.loads((ROOT / "supporting/selected-mechanism-input-bindings.json").read_text())
    if not report.get("complete") or not bindings.get("complete"):
        raise ValueError("Completed causal report and input bindings required")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({path: DESTINATION + path for path in FILES}, indent=2, sort_keys=True) + "\n")
    print("Prepared explicit causal report/proof copy map:", args.output)


if __name__ == "__main__":
    main()
