#!/usr/bin/env python3
"""Prepare a separate eight-font extension and reuse verified cached assets."""
import ast
import hashlib
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent
FAMILIES = ["mysteryquest", "fontdinerswanky", "frijole", "diplomata",
            "diplomatasc", "kranky", "spirax", "snowburstone"]
source = ROOT / "acquire_fonts.py"
text = source.read_text()
node = next(node for node in ast.parse(text).body if isinstance(node, ast.Assign)
            and any(isinstance(target, ast.Name) and target.id == "FAMILIES" for target in node.targets))
lines = text.splitlines(keepends=True)
text = "".join(lines[:node.lineno - 1]) + "FAMILIES = " + repr(FAMILIES) + "\n" + "".join(lines[node.end_lineno:])
assert text.count('manifest = ROOT / "acquired-files.json"') == 1
text = text.replace('manifest = ROOT / "acquired-files.json"', 'manifest = ROOT / "additional-eight-files.json"')
text = text.replace('"20 unchanged openly licensed decorative Latin candidates.', '"8 additional unchanged openly licensed decorative Latin candidates.')
marker = '    logdir = ROOT / "supporting/acquisition" / item["family"] / Path(relative).name\n'
assert text.count(marker) == 1
reuse = '''    cached = Path("/private/tmp/femtovg-font-stress-search-20261002/fonts") / item["family"] / Path(relative).name
    if cached.is_file():
        raw = cached.read_bytes()
        cached_blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\\0" + raw).hexdigest()
        if cached_blob == item["repository_blob_sha1"]:
            destination.parent.mkdir(parents=True, exist_ok=True)
            assert not destination.exists()
            destination.write_bytes(raw)
            return {**item, "url": url, "browser_url": "https://github.com/google/fonts/blob/" + PIN + "/" + relative,
                **info(destination), "reused_from": info(cached), "acquisition": "Verified pinned unchanged local copy; no download", "attempts": [], "complete": True}
    logdir = ROOT / "supporting/acquisition-v3" / item["family"] / Path(relative).name
'''
text = text.replace(marker, reuse)
destination = ROOT / "acquire_fonts_v3.py"
assert not destination.exists()
ast.parse(text)
destination.write_text(text)
proof = {"complete": True, "families": FAMILIES,
    "original": {"path": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest()},
    "prepared": {"path": str(destination), "sha256": hashlib.sha256(destination.read_bytes()).hexdigest()},
    "changes": ["Choose only the eight explicitly selected extra families", "Keep original20 and completed21 manifests untouched; write additional-eight-files.json", "Reuse prior local assets only when their Git blob bytes match the same pinned official tree", "Use fresh HTTP logs for assets requiring download"]}
(ROOT / "supporting/acquisition-v3-source-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print("Prepared eight-font extension", destination)
