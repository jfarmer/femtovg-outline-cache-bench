#!/usr/bin/env python3
"""Freeze the broad demo exploration, collect on request, and audit raw effects.

Collection is a separate explicit command. It uses the frozen unchanged demo
collector and executables. Analysis independently parses original stdout with
Decimal arithmetic; two blocks provide exploratory estimates, not confidence
intervals or confirmation evidence.
"""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
STUDY = ROOT / 'demo-only-replay-v2'
COLLECTOR = STUDY / 'replay_campaign_v3.py'
SELECTION = ROOT / 'demo-selection-v1'
CAMPAIGN = ROOT / 'demo-screen-v1'
PHASES = {'first_paint': 1, 'warm': 30, 'zoom_in': 12, 'zoom_out': 12, 'pan': 10}
ENDPOINTS = ('draw_us', 'submit_us', 'complete_us')
FIELDS = ['scene', 'phase', 'trial', 'frames', *ENDPOINTS, 'new_atlas_entries']
ALL_FIELDS = ['backend', 'font', 'dpi', 'block', 'version', *FIELDS]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def info(path):
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def collector_module():
    spec = importlib.util.spec_from_file_location('aggressive_demo_frozen_collector', COLLECTOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def freeze():
    require(not SELECTION.exists(), 'Keep the original frozen selection; create a new version for changes')
    native_path = ROOT / 'native-prescreen-protocol-v1.json'
    ranking_path = ROOT / 'supporting/native-prescreen-ranking.json'
    inspection_path = ROOT / 'supporting/font-inspection.json'
    native, ranking, inspection = load(native_path), load(ranking_path), load(inspection_path)
    require(native['complete'] and ranking['complete'] and inspection['complete'], 'Native/static inputs incomplete')
    require(info(native_path) == ranking['protocol'], 'Native ranking does not bind this protocol')
    require(info(ranking['audit']['path']) == ranking['audit'] and load(ranking['audit']['path'])['complete'], 'Native independent audit changed/incomplete')
    require(not ranking['rejections'], 'All 31 fonts must have passed native coverage collection')
    fonts = native['fonts']
    require(len(fonts) == 31 and sum(f['control'] for f in fonts) == 2, 'Expected all 29 candidates plus Rye/Voll controls')
    require(len({f['label'] for f in fonts}) == len(fonts), 'Duplicate labels')
    static = {f['label']: f for f in inspection['fonts']}
    coverage = []
    for font in fonts:
        require(info(font['path']) == {k:font[k] for k in ('path', 'bytes', 'sha256')}, 'Font changed: '+font['label'])
        item = static[font['label']]
        require(item['sha256'] == font['sha256'], 'Static font identity differs')
        ascii_coverage = item['scripts']['ascii95']
        require(ascii_coverage['requested_distinct_characters'] == 95 and
                ascii_coverage['mapped_distinct_characters'] == 95 and
                ascii_coverage['missing_codepoints'] == [], 'Printable ASCII coverage incomplete')
        coverage.append({'font':font['label'], 'ascii_including_space':95,
                         'mapped_unique_glyphs':ascii_coverage['mapped_unique_glyphs'],
                         'native_graphic_ascii_outline_glyphs':94,
                         'note':'Static mapping includes space; completed unchanged native screen verifies all 94 distinct nonblank graphic ASCII glyphs. Demo icon/emoji/fallback sources remain unchanged.'})
    identity = collector_module().input_identity(STUDY)
    SELECTION.mkdir()
    selection_path = SELECTION / 'selection.json'
    write(selection_path, {
        'complete':True, 'source_only_selection':True, 'created_utc':datetime.now(timezone.utc).isoformat(),
        'selection_rule':'Retain every acquired candidate, independent of native rank, plus the unchanged Rye and Vollkorn controls. No application timing has been inspected for this selection.',
        'fonts':fonts, 'coverage':coverage,
        'native_protocol':info(native_path), 'native_ranking':info(ranking_path),
        'static_inspection':info(inspection_path), 'collector':info(COLLECTOR),
        'input_identity':identity, 'freezer':info(Path(__file__)),
        'scope':'Exploratory unchanged English demo at requested DPR2. First-paint Swash atlas outline sizes are 11/12/14/15/16px, not doubled native DPR2 sizes. Font metrics and wrapping may differ. This selection adds no application pixel proof.'})
    command = [sys.executable, '-B', str(COLLECTOR), '--mode', 'cpu', '--versions', 'master', 'final',
               '--dpi', '2', '--blocks', '2', '--trials', '3', '--exploratory',
               '--selection-manifest', str(selection_path), '--output', str(CAMPAIGN)]
    for font in fonts:
        command += ['--font', font['label'], font['path']]
    write(SELECTION / 'protocol.json', {
        'complete':True, 'source_only_protocol':True, 'collection_executed':False,
        'selection':info(selection_path), 'driver':info(Path(__file__)), 'collect_command':command,
        'font_count':31, 'candidate_font_count':29, 'control_font_count':2,
        'versions':['master','final'], 'requested_dpr':2, 'blocks':2, 'trials_per_process':3,
        'expected_processes':124, 'expected_raw_rows':1860, 'phases':PHASES,
        'unmeasured_warmup_frames_per_trial':119, 'sequence_frames':65,
        'version_order':'Each font uses one master/final and one final/master process order. Configuration order rotates one place between blocks, as implemented by the frozen collector.',
        'analysis':'Original stdout independently parsed with Decimal. For each phase/endpoint use the median of three within-process trials, then the mean of the two paired master-minus-final block differences. The 65-frame sequence is formed per trial before taking its process median. Retain both blocks and their range; no confidence intervals, significance claims, exclusions, or percentages.',
        'selection_after_screen':'Root freezes independent primary confirmation candidates from these exploratory application results. Confirmation uses fresh 12 balanced blocks, five trials, matching native-offset-oracle pixels, and unchanged Rye/Voll controls.',
        'claims':'Application timing exploration only. No new pixel preflight is claimed for these fonts. Timings compare complete current patch against frozen master; they do not isolate outline retention or hinting.'})
    print(json.dumps({'complete':True,'selection':str(selection_path),'protocol':str(SELECTION/'protocol.json'),
                      'expected_processes':124,'expected_raw_rows':1860,'collection_executed':False}))


def guard():
    protocol = load(SELECTION / 'protocol.json')
    require(protocol['complete'] and protocol['source_only_protocol'], 'Exploration protocol incomplete')
    require(info(protocol['selection']['path']) == protocol['selection'], 'Frozen selection changed')
    require(info(protocol['driver']['path']) == protocol['driver'], 'Screen driver changed')
    selection = load(protocol['selection']['path'])
    require(info(selection['collector']['path']) == selection['collector'], 'Frozen collector changed')
    for key in ('native_protocol','native_ranking','static_inspection','freezer'):
        require(info(selection[key]['path']) == selection[key], 'Frozen input changed: '+key)
    for font in selection['fonts']:
        require(info(font['path']) == {k:font[k] for k in ('path','bytes','sha256')}, 'Font changed: '+font['label'])
    require(collector_module().input_identity(STUDY) == selection['input_identity'], 'Demo source/build identities changed')
    return protocol, selection


def collect():
    protocol, _ = guard()
    require(not CAMPAIGN.exists(), 'Retain previous and failed campaigns; use a fresh version')
    record_path = SELECTION / 'collect-execution.json'
    require(not record_path.exists(), 'Retain previous execution records')
    record = {'complete':False, 'protocol':info(SELECTION/'protocol.json'), 'command':protocol['collect_command']}
    write(record_path, record)
    with (SELECTION/'collect.stdout.txt').open('x') as out, (SELECTION/'collect.stderr.txt').open('x') as err:
        result = subprocess.run(protocol['collect_command'], stdout=out, stderr=err)
    record.update(complete=result.returncode==0, exit_code=result.returncode)
    write(record_path, record)
    require(result.returncode == 0, 'Demo exploration failed; original attempt retained')
    guard()
    print(json.dumps({'complete':True,'campaign':str(CAMPAIGN)}))


def read_rows(path, fields):
    with Path(path).open(newline='') as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == fields, 'Unexpected CSV fields: '+str(path))
        return list(reader)


def numeric_rows(rows, trials):
    result = {}
    for row in rows:
        require(row['scene']=='demo' and row['phase'] in PHASES, 'Unexpected demo phase')
        trial = int(row['trial']); phase = row['phase']
        require(0<=trial<trials and int(row['frames'])==PHASES[phase], 'Unexpected trial/frame count')
        require((trial,phase) not in result, 'Duplicate raw phase row')
        values = [Decimal(row[key]) for key in ENDPOINTS]
        require(all(value.is_finite() and value>=0 for value in values) and values==sorted(values), 'Invalid cumulative timing')
        count = int(row['new_atlas_entries']); require(count>=0, 'Invalid atlas count')
        result[trial,phase] = dict(zip(ENDPOINTS,values), new_atlas_entries=count)
    require(set(result)=={(trial,phase) for trial in range(trials) for phase in PHASES}, 'Incomplete raw process rows')
    return result


def analyze():
    protocol, selection = guard()
    provenance_path = CAMPAIGN/'cpu-provenance.json'
    provenance = load(provenance_path)
    require(provenance['complete'] and provenance['mode']=='cpu' and provenance['exploratory'] is True, 'Campaign incomplete or wrong mode')
    require(provenance['identity']==selection['input_identity'] and provenance['driver']==selection['collector'], 'Campaign source identity differs')
    require(provenance['selection_manifest']==protocol['selection'], 'Campaign selection differs')
    require(provenance['versions']==protocol['versions'] and provenance['blocks']==2 and provenance['trials_per_process']==3 and provenance['dpis']==[2], 'Campaign protocol differs')
    require(provenance['phases']=={'demo':PHASES} and provenance['pixel_proof'] is None, 'Exploration phase/pixel scope differs')
    require(provenance['fonts']==[f['label'] for f in selection['fonts']], 'Font order differs')
    require(provenance['font_files']=={f['label']:{k:f[k] for k in ('path','bytes','sha256')} for f in selection['fonts']}, 'Font identities differ')
    csv_path = CAMPAIGN/'cpu-results.csv'
    require(info(csv_path)==provenance['results'], 'Combined raw CSV changed')
    combined = read_rows(csv_path, ALL_FIELDS)
    require(len(combined)==1860 and len(provenance['launches'])==124, 'Expected 124 processes and 1,860 phase rows')
    expected_order = []
    labels = provenance['fonts']
    for block in range(2):
        rotate=block%len(labels)
        for font in labels[rotate:]+labels[:rotate]:
            versions=['master','final'] if (block+labels.index(font))%2==0 else ['final','master']
            expected_order += [f'{block+1:02}-{font}-dpi2-{v}' for v in versions]
    require([x['label'] for x in provenance['launches']]==expected_order and sum(provenance['order'],[])==expected_order, 'Balanced launch schedule differs')
    observed = []
    process = {}
    original_atlas = []
    for launch in provenance['launches']:
        require(launch['validated'] and launch['exit_code']==0 and launch['rows']==15, 'Incomplete/rejected process')
        font,block,version=launch['font'],launch['block'],launch['version']
        require(launch['dpi']==2 and launch['command']==[selection['input_identity']['binaries'][version]['path'],'cpu','3','2'], 'Wrong command')
        require(launch['cwd']==str(STUDY) and launch['environment']=={'FEMTOVG_REPLAY_TEXT_FONT':provenance['font_files'][font]['path']}, 'Wrong font/workdir')
        for field in ('stdout','stderr'):
            require(info(launch[field])==launch[field+'_info'], 'Raw process artifact changed')
        raw=read_rows(launch['stdout'],FIELDS)
        values=numeric_rows(raw,3)
        key=(font,block,version); require(key not in process,'Duplicate process')
        process[key]=values
        observed += [{'backend':'cpu','font':font,'dpi':'2','block':str(block),'version':version,**row} for row in raw]
        for (trial,phase),value in values.items():
            original_atlas.append({'font':font,'block':block,'version':version,'trial':trial,'phase':phase,'entries':value['new_atlas_entries']})
    require(observed==combined, 'Combined CSV differs from original stdout')
    require(len(process)==124, 'Incomplete process matrix')
    medians={}
    for key,values in process.items():
        for endpoint in ENDPOINTS:
            for phase in PHASES:
                medians[*key,phase,endpoint]=statistics.median(values[t,phase][endpoint] for t in range(3))
            medians[*key,'sequence_65_frames',endpoint]=statistics.median(
                sum(values[t,phase][endpoint]*frames for phase,frames in PHASES.items()) for t in range(3))
    effects=[]
    for font in labels:
        for phase in [*PHASES,'sequence_65_frames']:
            for endpoint in ENDPOINTS:
                blocks=[{'block':b,'master':medians[font,b,'master',phase,endpoint],
                         'final':medians[font,b,'final',phase,endpoint]} for b in (1,2)]
                for row in blocks: row['saving']=row['master']-row['final']
                savings=[row['saving'] for row in blocks]
                effects.append({'font':font,'phase':phase,'endpoint':endpoint,
                    'unit':'microseconds per 65-frame sequence' if phase=='sequence_65_frames' else 'microseconds per frame',
                    'master_mean_process_median':float(sum(row['master'] for row in blocks)/2),
                    'final_mean_process_median':float(sum(row['final'] for row in blocks)/2),
                    'master_minus_final_mean':float(sum(savings)/2),
                    'paired_block_range':[float(min(savings)),float(max(savings))],
                    'positive_blocks':sum(x>0 for x in savings),'negative_blocks':sum(x<0 for x in savings),
                    'blocks':[{k:float(v) if isinstance(v,Decimal) else v for k,v in row.items()} for row in blocks]})
    require(len(effects)==558,'Expected all phase/sequence endpoints for all 31 fonts')
    output = CAMPAIGN/'independent-analysis'
    require(not output.exists(),'Retain all earlier analyses; use a fresh output for changes')
    output.mkdir()
    result={'complete':True,'exploratory':True,'no_confidence_intervals':True,
        'protocol':info(SELECTION/'protocol.json'),'selection':info(SELECTION/'selection.json'),
        'collector':selection['collector'],'auditor':info(Path(__file__)),'provenance':info(provenance_path),
        'raw_csv':info(csv_path),'processes_checked':124,'raw_rows_checked':1860,
        'source_and_build_guard_passed':True,'original_stdout_agreement':True,
        'balanced_two_block_order_checked':True,'effects_checked':len(effects),
        'method':protocol['analysis'],'effects':effects,'original_atlas_counts':original_atlas,
        'scope':protocol['claims'],
        'ranking_first_paint_draw':sorted([row for row in effects if row['phase']=='first_paint' and row['endpoint']=='draw_us'],key=lambda row:-row['master_minus_final_mean']),
        'ranking_sequence_draw':sorted([row for row in effects if row['phase']=='sequence_65_frames' and row['endpoint']=='draw_us'],key=lambda row:-row['master_minus_final_mean'])}
    write(output/'analysis.json',result)
    with (output/'effects.csv').open('x',newline='') as stream:
        fields=[key for key in effects[0] if key!='blocks']; writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        writer.writerows({key:json.dumps(value) if isinstance(value,list) else value for key,value in row.items() if key!='blocks'} for row in effects)
    lines=['# Broad unchanged-demo exploration','',
           'All 29 acquired candidates and unchanged Rye/Voll controls were retained. This is two paired blocks with three trials per process: estimates support font selection, not confirmation or significance claims. No new application pixel campaign accompanies this screen.','',
           'Positive values save CPU draw time against frozen master. Phases use the median of each process\'s three trial averages. The 65-frame sequence is summed within each trial before its process median; 119 warmup frames are excluded. Both paired blocks are retained.','',
           '| Font | First paint saving (µs) | Two-block range (µs) | 65-frame saving (ms) | Two-block range (ms) |','|---|---:|---:|---:|---:|']
    sequence={row['font']:row for row in result['ranking_sequence_draw']}
    for row in result['ranking_first_paint_draw']:
        seq=sequence[row['font']]
        lines.append(f"| {row['font']} | {row['master_minus_final_mean']:.2f} | {row['paired_block_range'][0]:.2f} to {row['paired_block_range'][1]:.2f} | {seq['master_minus_final_mean']/1000:.3f} | {seq['paired_block_range'][0]/1000:.3f} to {seq['paired_block_range'][1]/1000:.3f} |")
    lines += ['', 'Font widths, wrapping, rendered geometry and cache pressure differ with the regular-font override. A large complete-patch saving can include avoided generic outline classification and run preparation as well as retained Swash outlines. Native outlines at matching first-paint 11–16px help identify costly geometry/hinting, but do not predict application reuse. Optional retention ablation is a separate later diagnostic.','',
              f'Independent checks: 124 process invocations, 1,860 original stdout rows, both balanced orders, all frozen font/source/build identities and 558 phase/sequence endpoint effects. All raw timings and atlas counts are retained; no exclusions or retries.']
    (output/'summary.md').write_text('\n'.join(lines)+'\n')
    guard()
    print(json.dumps({'complete':True,'analysis':str(output/'analysis.json'),'processes_checked':124,'raw_rows_checked':1860,'effects':558}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['freeze','guard','collect','analyze'])
    args=parser.parse_args()
    try:
        if args.command=='guard':
            guard();print(json.dumps({'complete':True,'guard':True}))
        else:
            globals()[args.command]()
    except (OSError,ValueError,KeyError,subprocess.SubprocessError) as error:
        print(f'{type(error).__name__}: {error}',file=sys.stderr);sys.exit(1)
