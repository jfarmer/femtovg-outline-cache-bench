#!/usr/bin/env python3
"""Create the PT Sans report/plot after root has completed every timing batch.

Consumes completed summaries only; never launches an app or benchmark.
"""
from pathlib import Path
import json
import os

ROOT = Path('/private/tmp/pt-sans-outline-review')
REPLAY = Path('/private/tmp/femtovg-pt-sans-outline-review')
APP = Path('/private/tmp/alustin-pt-sans-outline-review')
FONTS = [('ptsans', 'PT Sans Regular'), ('vollkorn', 'Vollkorn Medium')]
BACKENDS = [('winit-femtovg-wgpu', 'WGPU'), ('winit-femtovg', 'OpenGL')]


def read(path):
    return json.loads(path.read_text())


def percent(value):
    digits = 2 if value != 0 and abs(value) < .05 else 1
    return f'{value:+.{digits}f}%'.replace('-', '−')


def effect(value, ci):
    return f'{percent(value)} [{percent(ci[0])}, {percent(ci[1])}]'


def main():
    plan = read(ROOT/'measurement-plan.json')
    replay = read(REPLAY/'analysis/summary.json')
    app = read(APP/'analysis/summary.json')
    for mode in ('cpu', 'gpu', 'pixels'):
        assert read(REPLAY/f'{mode}-provenance.json')['complete'] is True
    for batch in app['batches']:
        assert read(Path(batch['path'])/'summary.json')['complete'] is True
    assert {batch['mode'] for batch in app['batches']} == {'cpu', 'startup', 'pixels'}

    def r(font, dpi, scene, phase, mode='cpu', metric='draw_us'):
        rows = [row for row in replay if row['font']==font and row['dpi']==dpi
                and row['scene']==scene and row['phase']==phase and row['backend']==mode]
        assert len(rows)==1, (font, dpi, scene, phase, mode)
        return rows[0][metric]

    def a(font, backend, metric, mode='cpu'):
        rows = [row for row in app['results'] if row['font']==font and row['backend']==backend
                and row['metric']==metric and row['mode']==mode]
        assert len(rows)==1, (font, backend, metric, mode)
        return rows[0]

    def reffect(row):
        return effect(row['paired_delta_pct'], row['paired_bootstrap95'])

    def aeffect(row):
        return effect(row['median_paired_change_pct'], row['median_paired_change_pct_ci95'])

    out = []
    add = out.append
    add('PT Sans Regular improves first-render CPU duration against master by 12.0% in the DPR-2 FemtoVG demo replay, 6.9% in Alustin WGPU, and 2.9% in Alustin OpenGL. All three exploratory paired-bootstrap intervals exclude zero. The fresh Vollkorn control remains substantially faster with the patch: 33.3%, 21.9%, and 19.7% respectively. The earlier four-font and original benchmarks remain preserved.\n')
    add(f"Frozen FemtoVG revisions: master `{plan['comparison']['master']}`, patch `{plan['comparison']['patch']}`. The patch is the existing Swash outline cache with a one-MiB logical budget; no production code or cache settings changed for this experiment. [Existing binary audit](existing-binary-audit.json) confirms that the binaries also match those used for the earlier four-font comparison.\n")
    add('The table shows first-render CPU duration changes. Negative means faster; brackets contain exploratory paired-bootstrap 95% intervals. Demo measures `Canvas<Void>` drawing CPU at DPR 2; Alustin measures renderer-thread CPU. Their absolute durations cover different scopes.\n')
    add('| Font | Demo first paint, DPR 2 | Alustin WGPU | Alustin OpenGL |\n|---|---:|---:|---:|')
    chart_rows = []
    for font, family in FONTS:
        demo = r(font, 2, 'demo', 'first_paint')
        apps = [a(font, backend, 'first_frame.render.thread_cpu_ms') for backend, _ in BACKENDS]
        add(f'| {family} | {reffect(demo)} | {aeffect(apps[0])} | {aeffect(apps[1])} |')
        chart_rows.append({'font':font, 'family':family, 'environment':'Demo replay · DPR 2',
                           'change_pct':demo['paired_delta_pct'], 'ci95':demo['paired_bootstrap95'],
                           'pairs':demo['process_pairs']})
        for row, (_, name) in zip(apps, BACKENDS):
            chart_rows.append({'font':font, 'family':family, 'environment':f'Alustin · {name}',
                              'change_pct':row['median_paired_change_pct'],
                              'ci95':row['median_paired_change_pct_ci95'], 'pairs':row['n_pairs']})
    add('\n[Comparison chart](first-render-comparison.png), [SVG](first-render-comparison.svg), and [plot data](first-render-comparison-data.json).\n')
    add('| Font / backend | First-render CPU, master → patch | Median paired saving | Search-render CPU change |\n|---|---:|---:|---:|')
    for font, family in FONTS:
        for backend, name in BACKENDS:
            row = a(font, backend, 'first_frame.render.thread_cpu_ms')
            search = a(font, backend, 'search_frame.render.thread_cpu_ms')
            add(f"| {family} / {name} | {row['master_median']:.3f} → {row['patch_median']:.3f} ms | {(-row['median_paired_delta']):.3f} ms | {aeffect(search)} |")
    add('\nThe replay retains the existing demo and text drawing helpers. CPU uses a no-op renderer with the same black-box barriers; the offscreen Metal/WGPU replay waits for GPU completion. Draw, submit, and complete are cumulative measurements and must not be added. Each font/DPR has nine fresh master/patch process pairs, five CPU trials per process, and three GPU trials per process. Trial medians become process observations before paired effects are calculated. Version order alternates and font/DPR order rotates. All validated timing observations in the completed cohorts are included.\n')
    add('Selected replay phases are below. Each cell shows DPR 1 / DPR 2 paired percentage changes. Detailed intervals and all 19 phases remain in the [replay summary](../femtovg-pt-sans-outline-review/analysis/summary.csv).\n')
    add('| Font / phase | Drawing CPU | Completed GPU |\n|---|---:|---:|')
    selected = [('demo','first_paint','Demo first paint'), ('demo','zoom_in','Demo zoom in'),
                ('demo','zoom_out','Demo zoom out'), ('text','first_paint','Text first paint'),
                ('text','x_advance','Horizontal text movement'), ('text','size_advance','Text size increase')]
    for font, family in FONTS:
        for scene, phase, name in selected:
            cpu = ' / '.join(percent(r(font, dpi, scene, phase)['paired_delta_pct']) for dpi in (1,2))
            gpu = ' / '.join(percent(r(font, dpi, scene, phase, 'gpu', 'complete_us')['paired_delta_pct']) for dpi in (1,2))
            add(f'| {family}: {name} | {cpu} | {gpu} |')
    add('\nFor PT Sans, every CPU interval in this selected table excludes zero. Completed-GPU gains are established for demo zoom-in (7.4% / 8.9%), zoom-out (8.7% / 13.4%), and text size increase (6.9% / 8.5%) at both DPIs. At DPR 2, text first paint and horizontal movement also improve by 8.2% and 13.1%, with intervals excluding zero. Demo first-paint completion has positive point estimates at both DPIs, but both intervals cross zero; this experiment establishes neither a completion gain nor a regression there. DPR-1 text first paint and horizontal movement also remain uncertain. CPU savings therefore do not imply a completed-GPU improvement in every phase.\n')
    add('\nThe six variable-font phases always use the unchanged Roboto Flex control. They are not PT Sans or Vollkorn variation workloads. Warm redraws and return phases usually hit the existing atlas, so the outline cache has little opportunity to help. Their timings and the Roboto weight/slant control are retained in the full summary, including potential regressions.\n')
    add('Alustin uses app commit `ac35d4e0b5c52edb7defb9feccdadfd584635c14`, the same large save, catalog, icon pack, and a DPR-2 2560×1600 physical viewport. System-font discovery is disabled and the requested font is registered before first render. Twelve fresh pairs per font/backend were collected separately for CPU and startup; startup disables renderer diagnostics. CPU spans are nested and overlap. Alustin CPU/startup timings do not measure GPU completion or compositor scanout. Separate untimed screenshots verify the actual selected primary face and the existing Inter fallback. The replay uses Swash 0.2.10 / Skrifa 0.44.0; Alustin uses Swash 0.2.10 / Skrifa 0.40.0. Locks remain fixed within each comparison.\n')
    for excluded in app['excluded_batches']:
        add(f"The initial Alustin CPU batch was interrupted by a 120-second harness timeout while waiting for an interactive response. Its cause is unknown. The entire incomplete batch ({excluded['raw_launches']} raw launches, {excluded['validated_launches']} validated launches) is excluded, archived with its raw reports, and disclosed in [batch-exclusion.json](../alustin-pt-sans-outline-review/cpu-aborted-timeout/batch-exclusion.json). The full cohort was restarted with unchanged binaries/settings; no individual timing-based exclusions were made.\n")
    add('| Font / backend | Diagnostics-off launch to search readiness | Startup peak RSS change | First-render final-flush CPU change |\n|---|---:|---:|---:|')
    for font, family in FONTS:
        for backend, name in BACKENDS:
            startup = a(font, backend, 'observed_search_response_ms', 'startup')
            rss = a(font, backend, 'peak_rss_mib', 'startup')
            flush = a(font, backend, 'first_frame.final_flush.thread_cpu_ms')
            rssci = rss['median_paired_delta_ci95']
            add(f"| {family} / {name} | {aeffect(startup)} | {rss['median_paired_delta']:+.3f} MiB [{rssci[0]:+.3f}, {rssci[1]:+.3f}] | {aeffect(flush)} |")
    add('\nStartup and RSS are noisier than isolated renderer CPU. Intervals crossing zero do not establish a benefit or regression. Intervals are exploratory across many phases and metrics with no multiplicity adjustment. Independent median times and median paired effects are different statistics, so their ratios need not match.\n')
    add('PT Sans’s search-frame render CPU and diagnostics-off startup intervals cross zero in both backends. Its first-render component-item CPU falls by about 0.64 ms WGPU and 0.60 ms OpenGL; final-flush CPU is uncertain in all four font/backend cells. Peak RSS has no established increase in the diagnostics-off cohort. The diagnostic CPU cohort does show a small Vollkorn OpenGL increase of 0.45 MiB [0.23, 1.24 MiB], while its separate startup cohort does not; the logical one-MiB cache charge is not a bound on process memory.\n')
    add('The unchanged Roboto variation control retains downsides: in the PT Sans-labelled DPR-2 CPU cohort, advancing weight regresses by 1.9% [0.8%, 7.9%] and returning weight by 2.3% [0.6%, 2.9%]. These are Roboto effects, not PT Sans variation behavior. Vollkorn’s DPR-1 warm text phase also has a small CPU regression of 2.8% [0.3%, 3.7%]. These exploratory effects remain in the results. Most warm/return and control intervals cross zero, and completed-GPU variation intervals remain uncertain. The cache still imposes lookup/ownership work on misses; neither this experiment nor a larger bytecode count proves a better cache admission policy or size.\n')
    pixels = read(REPLAY/'pixels-provenance.json')
    rc = pixels['pixel_comparisons']
    add(f"All {len(rc)} replay master/patch phase images and all four Alustin screenshot pairs are identical decoded RGBA. The replay pixel batch includes stock Roboto as an additional font-override control. Alustin pixel checks and actual-face diagnostics are retained in [its pixel batch](../alustin-pt-sans-outline-review/pixels-font-validation/summary.json); [visual inspection](visual-check.json) covers PT Sans.\n")
    add('PT Sans has 162,235 glyph-program bytes and 37,433 ASCII glyph-program bytes, versus Vollkorn’s 85,955 and 6,907. Those static counts do not measure execution frequency or work performed by function calls, loops, and composites, or the actual glyph/size mix. More bytecode is not equivalent to more executed hint work, and these font replacements also differ in geometry, metrics, and default weight (PT Sans Regular 400; Vollkorn Medium 500). The experiment measures the patch’s workload benefit, rather than an isolated interpreter-cost effect. [Font and bytecode audit](../femtovg-open-font-search/candidate-agent/independent-audit.json).\n')
    add('The [reproduction instructions](REPRODUCE.md) cover the retained [measurement plan](measurement-plan.json), [used-runner provenance](used-runner-provenance.json), replay [CPU provenance](../femtovg-pt-sans-outline-review/cpu-provenance.json)/[GPU provenance](../femtovg-pt-sans-outline-review/gpu-provenance.json), [replay methodology](../femtovg-pt-sans-outline-review/analysis/summary-methodology.json), and [Alustin raw-validated analysis](../alustin-pt-sans-outline-review/analysis/summary.json). The runners used for this experiment are archived under `used-runners/`; the report/chart are reproduced by `report-work/create_report.py` after the summary scripts finish. Earlier [four-font evidence](../femtovg-liberation-example-review/REPORT.md) is a prior cohort and is not pooled with these observations. `previous-runners/` preserves the older runner source.\n')
    if (ROOT/'independent-audit.json').exists():
        audit = read(ROOT/'independent-audit.json')
        assert audit['complete'] is True
        add('An [independent audit](independent-audit.json) rechecks raw timing arithmetic, bootstrap intervals, paired retention, decoded pixels, and binary/font provenance.\n')
    (ROOT/'REPORT.md').write_text('\n'.join(out))
    (ROOT/'first-render-comparison-data.json').write_text(json.dumps(chart_rows, indent=2)+'\n')
    plot(chart_rows)
    print(json.dumps(chart_rows, indent=2))


def plot(rows):
    os.environ.setdefault('MPLCONFIGDIR', str(ROOT/'report-work/matplotlib-cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    series = [('Demo replay · DPR 2', '#2866a3', -.20),
              ('Alustin · WGPU', '#ac4a30', .0), ('Alustin · OpenGL', '#48874c', .20)]
    fig, ax = plt.subplots(figsize=(9.5, 4.9))
    fig.subplots_adjust(left=.18, right=.98, top=.88, bottom=.28)
    for label, color, offset in series:
        values = [row for row in rows if row['environment']==label]
        xs = [row['change_pct'] for row in values]
        lows = [row['change_pct']-row['ci95'][0] for row in values]
        highs = [row['ci95'][1]-row['change_pct'] for row in values]
        ax.errorbar(xs, [i+offset for i in range(len(values))], xerr=[lows,highs],
                    fmt='o', color=color, capsize=3, markersize=7, linewidth=1.6, label=label)
    ax.axvline(0, color='#777777', linewidth=1)
    ax.set_yticks(range(len(FONTS)), [family for _, family in FONTS])
    ax.invert_yaxis()
    ax.set_ylim(1.45, -.45)
    all_bounds = [bound for row in rows for bound in row['ci95']]
    ax.set_xlim(min(-5, min(all_bounds))-3, max(0, max(all_bounds))+3)
    ax.set_xlabel('Paired change in first-render CPU duration (%) · negative is faster')
    ax.set_title('PT Sans and fresh Vollkorn control: patch versus master', loc='left', fontweight='bold')
    ax.grid(axis='x', alpha=.15)
    ax.spines[['top','right','left']].set_visible(False)
    ax.legend(loc='lower right', frameon=False)
    fig.text(.18, .025,
             'Replay: Canvas<Void> drawing CPU, 9 process pairs. Alustin: renderer-thread CPU, 12 process pairs.\n'
             'Bars: exploratory paired-bootstrap 95% intervals. Scopes differ; compare effects, not absolute times.\n'
             'Fresh completed cohorts for both fonts; all included timings retained.', fontsize=9)
    for suffix in ('png','svg'):
        fig.savefig(ROOT/f'first-render-comparison.{suffix}', dpi=160, bbox_inches='tight')
    plt.close(fig)


if __name__ == '__main__':
    main()
