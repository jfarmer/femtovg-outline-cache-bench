#!/usr/bin/env python3
"""Run paired offscreen example replays; never opens a window.

cpu/gpu collect timings. pixels runs separate GPU readbacks with one trial.
Each round rotates font/DPR configurations and alternates adjacent master/patch
processes. CPU defaults to five trials per process; GPU to three.
"""

import argparse
import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
ASSETS = Path("/Users/jesse/github/femtovg/examples/assets")
LIBERATION = Path("/private/tmp/femtovg-liberation-font-review/liberation-fonts-ttf-2.1.5/LiberationSerif-Regular.ttf")
VOLLKORN = Path("/Users/jesse/github/alustin-gui-v2/crates/alustin-gui/assets/fonts/Vollkorn-Medium.ttf")
ARIAL = Path("/System/Library/Fonts/Supplemental/Arial.ttf")
PHASES = {
    "demo": {"first_paint": 1, "warm": 30, "zoom_in": 12, "zoom_out": 12, "pan": 10},
    "text": {"first_paint": 1, "warm": 30, "x_advance": 10, "x_return": 10, "y_advance": 10,
             "size_advance": 12, "size_return": 12, "reflow": 3},
    "font_variations": {"first_paint": 1, "warm": 30, "weight_advance": 6, "weight_return": 6,
                        "slant_advance": 10, "slant_return": 10},
}
CSV_FIELDS = ["scene", "phase", "trial", "frames", "draw_us", "submit_us", "complete_us", "new_atlas_entries"]
RESULT_FIELDS = ["backend", "font", "dpi", "pair", "version", *CSV_FIELDS]


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def info(path):
    path = Path(path).resolve(strict=True)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}


def parse_rows(stdout, trials):
    reader = csv.DictReader(io.StringIO(stdout))
    if reader.fieldnames != CSV_FIELDS:
        raise ValueError(f"unexpected replay CSV header: {reader.fieldnames}")
    rows = list(reader)
    expected = {(trial, scene, phase) for trial in range(trials) for scene, phases in PHASES.items() for phase in phases}
    seen = set()
    for row in rows:
        key = (int(row["trial"]), row["scene"], row["phase"])
        if key not in expected or key in seen:
            raise ValueError(f"unexpected/duplicate replay row: {key}")
        seen.add(key)
        if int(row["frames"]) != PHASES[key[1]][key[2]]:
            raise ValueError(f"unexpected frame count: {key}")
        if int(row["new_atlas_entries"]) < 0:
            raise ValueError(f"negative atlas count: {key}")
        times = [float(row[name]) for name in ("draw_us", "submit_us", "complete_us")]
        if any(not math.isfinite(value) or value < 0 for value in times) or times != sorted(times):
            raise ValueError(f"invalid cumulative timings: {key}: {times}")
    if seen != expected:
        raise ValueError(f"missing replay rows: {sorted(expected - seen)}")
    return rows


def validate_pair(master, patch):
    keys = lambda rows: {(row["scene"], row["phase"], int(row["trial"])):
                         (int(row["frames"]), int(row["new_atlas_entries"])) for row in rows}
    if keys(master) != keys(patch):
        raise ValueError("master/patch workload frame or atlas-entry counts differ")


def write_provenance(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")


def snapshots(master, patch, font, dpi):
    expected = {f"{scene}-{phase}.rgba" for scene, phases in PHASES.items() for phase in phases}
    actual_master = {path.name for path in master.glob("*.rgba")}
    actual_patch = {path.name for path in patch.glob("*.rgba")}
    if actual_master != expected or actual_patch != expected:
        raise ValueError(f"unexpected snapshot set for {font}/DPR{dpi}: master={actual_master ^ expected}, patch={actual_patch ^ expected}")
    comparisons = []
    for name in sorted(expected):
        width, height = (800, 700) if name.startswith("font_variations-") else (1000, 600)
        a, b = master / name, patch / name
        expected_bytes = width * height * 4
        if a.stat().st_size != expected_bytes or b.stat().st_size != expected_bytes:
            raise ValueError(f"unexpected RGBA dimensions/length for {name}: expected {width}x{height}")
        comparisons.append({"font": font, "dpi": dpi, "snapshot": name, "width": width, "height": height,
                            "master": info(a), "patch": info(b), "rgba_identical": a.read_bytes() == b.read_bytes()})
    return comparisons


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("cpu", "gpu", "pixels"))
    parser.add_argument("--pairs", type=int, default=9)
    parser.add_argument("--trials", type=int)
    parser.add_argument("--fonts", choices=("stock", "liberation", "vollkorn", "arial"), nargs="+", default=["stock", "liberation", "vollkorn", "arial"])
    parser.add_argument("--dpis", choices=(1, 2), type=int, nargs="+", default=[1, 2])
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, default=ROOT)
    parser.add_argument("--master", type=Path)
    parser.add_argument("--patch", type=Path)
    parser.add_argument("--assets", type=Path, default=ASSETS)
    parser.add_argument("--liberation-font", type=Path, default=LIBERATION)
    parser.add_argument("--vollkorn-font", type=Path, default=VOLLKORN)
    parser.add_argument("--arial-font", type=Path, default=ARIAL)
    parser.add_argument("--gpu-backend", default="metal")
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()
    if args.pairs < 1 or args.timeout < 1 or (args.trials is not None and args.trials < 1):
        parser.error("pairs, trials, and timeout must be positive")
    if len(set(args.fonts)) != len(args.fonts) or len(set(args.dpis)) != len(args.dpis):
        parser.error("font and DPR factors must be unique")
    root = args.root.resolve(strict=True)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    run_directory = output / f"{args.mode}-runs"
    run_directory.mkdir(exist_ok=False)
    csv_path = output / f"{args.mode}-results.csv"
    provenance_path = output / f"{args.mode}-provenance.json"
    if csv_path.exists() or provenance_path.exists():
        raise ValueError("result/provenance output exists; choose a new --output directory")
    backend = "gpu" if args.mode == "pixels" else args.mode
    pairs = 1 if args.mode == "pixels" else args.pairs
    trials = 1 if args.mode == "pixels" else args.trials or (5 if backend == "cpu" else 3)
    binaries = {"master": (args.master or root / "master-runner").resolve(strict=True),
                "patch": (args.patch or root / "patch-runner").resolve(strict=True)}
    binary_info = {version: info(path) for version, path in binaries.items()}
    assets = args.assets.resolve(strict=True)
    font_info = {name: info(assets / file) for name, file in (
        ("stock_regular_and_variable", "RobotoFlex-VariableFont.ttf"),
        ("amiri_fallback", "amiri-regular.ttf"), ("entypo_icons", "entypo.ttf"))}
    font_info["liberation_regular"] = info(args.liberation_font)
    font_info["vollkorn_regular"] = info(args.vollkorn_font)
    font_info["arial_regular"] = info(args.arial_font)
    env = dict(os.environ)
    for name in ("FEMTOVG_REPLAY_TEXT_FONT", "SLINT_FONT_PATH", "SLINT_DEFAULT_FONT", "MTL_SHADER_CACHE_SIZE"):
        env.pop(name, None)
    env["FEMTOVG_REQUIRE_GPU"] = args.gpu_backend
    source_files = {}
    for relative in ("runner/Cargo.lock", "runner/Cargo.toml", "runner/src/main.rs", "runner/src/demo.rs",
                     "runner/src/text.rs", "runner/src/font_variations.rs", "runner/src/perf_graph.rs",
                     "source-hashes.txt"):
        path = root / relative
        if path.exists():
            source_files[relative] = info(path)
    provenance = {
        "mode": args.mode, "backend": backend, "pairs": pairs, "trials_per_process": trials,
        "fonts": args.fonts, "dpis": args.dpis, "platform": platform.platform(),
        "source_revisions": {"master": "f57a2c39e9836c146556c58c98d80c5bf7899029",
                             "patch": "7a278ca4f947658d01c355c450edc6abcdbe3958"},
        "binaries": binary_info, "font_files": font_info, "source_files": source_files,
        "fixed_environment": {"FEMTOVG_REQUIRE_GPU": args.gpu_backend},
        "font_environment": {"stock": {},
                             "liberation": {"FEMTOVG_REPLAY_TEXT_FONT": font_info["liberation_regular"]["path"]},
                             "vollkorn": {"FEMTOVG_REPLAY_TEXT_FONT": font_info["vollkorn_regular"]["path"]},
                             "arial": {"FEMTOVG_REPLAY_TEXT_FONT": font_info["arial_regular"]["path"]}},
        "scope": "Original example drawing replay; CPU Void or WGPU offscreen only; regular demo/text font override; font_variations retains Roboto",
        "measurement": "One process runs all trials and phases; rows are per-trial phase averages. Readbacks are separate and excluded from timing statistics.",
        "order": [], "launches": [], "pixel_comparisons": [], "complete": False,
    }
    write_provenance(provenance_path, provenance)
    with csv_path.open("x", newline="") as stream:
        csv.DictWriter(stream, fieldnames=RESULT_FIELDS).writeheader()
    configurations = [(font, dpi) for dpi in args.dpis for font in args.fonts]
    pixel_paths = {}
    for pair_index in range(pairs):
        offset = pair_index % len(configurations)
        ordered = configurations[offset:] + configurations[:offset]
        versions = ["master", "patch"] if pair_index % 2 == 0 else ["patch", "master"]
        round_order = []
        provenance["order"].append(round_order)
        for font, dpi in ordered:
            pair_rows = {}
            for version in versions:
                label = f"{pair_index + 1:02}-{font}-dpi{dpi}-{version}"
                round_order.append(label)
                launch_env = dict(env)
                launch_env.update(provenance["font_environment"][font])
                command = [str(binaries[version]), backend, str(trials), str(dpi)]
                if args.mode == "pixels":
                    destination = run_directory / f"{font}-dpi{dpi}-{version}-pixels"
                    command.append(str(destination))
                    pixel_paths[font, dpi, version] = destination
                launch = {"label": label, "pair": pair_index + 1, "font": font, "dpi": dpi, "version": version,
                          "command": command, "environment": provenance["font_environment"][font], "validated": False,
                          "stdout": str(run_directory / f"{label}.stdout.csv"), "stderr": str(run_directory / f"{label}.stderr.txt")}
                provenance["launches"].append(launch)
                write_provenance(provenance_path, provenance)
                with Path(launch["stdout"]).open("w") as stdout, Path(launch["stderr"]).open("w") as stderr:
                    result = subprocess.run(command, cwd=root, env=launch_env, stdout=stdout, stderr=stderr,
                                            timeout=args.timeout)
                launch["exit_code"] = result.returncode
                write_provenance(provenance_path, provenance)
                if result.returncode:
                    raise RuntimeError(f"{label} exited {result.returncode}; raw files retained")
                if sha(binaries[version]) != binary_info[version]["sha256"]:
                    raise ValueError(f"binary changed during experiment: {version}")
                rows = parse_rows(Path(launch["stdout"]).read_text(), trials)
                pair_rows[version] = rows
                launch["validated"] = True
                launch["rows"] = len(rows)
                with csv_path.open("a", newline="") as stream:
                    writer = csv.DictWriter(stream, fieldnames=RESULT_FIELDS)
                    writer.writerows({"backend": backend, "font": font, "dpi": dpi, "pair": pair_index + 1,
                                      "version": version, **row} for row in rows)
                write_provenance(provenance_path, provenance)
                print(f"{args.mode} pair {pair_index + 1}/{pairs}, {font}, DPR {dpi}, {version}: {len(rows)} rows validated", flush=True)
            validate_pair(pair_rows["master"], pair_rows["patch"])
            if args.mode == "pixels":
                comparisons = snapshots(pixel_paths[font, dpi, "master"], pixel_paths[font, dpi, "patch"], font, dpi)
                provenance["pixel_comparisons"].extend(comparisons)
                write_provenance(provenance_path, provenance)
                if not all(row["rgba_identical"] for row in comparisons):
                    raise ValueError(f"RGBA parity failed: {font}, DPR {dpi}")
                print(f"pixels {font}, DPR {dpi}: all {len(comparisons)} RGBA snapshots identical", flush=True)
    if args.mode == "pixels" and "stock" in args.fonts and len(args.fonts) > 1:
        controls = []
        for dpi in args.dpis:
            for version in ("master", "patch"):
                for font in args.fonts:
                    if font == "stock":
                        continue
                    stock = pixel_paths["stock", dpi, version]
                    alternate = pixel_paths[font, dpi, version]
                    variables = [f"font_variations-{phase}.rgba" for phase in PHASES["font_variations"]]
                    unchanged = all(sha(stock / name) == sha(alternate / name) for name in variables)
                    changed = {scene: sha(stock / f"{scene}-first_paint.rgba") != sha(alternate / f"{scene}-first_paint.rgba")
                               for scene in ("demo", "text")}
                    controls.append({"dpi": dpi, "version": version, "font": font, "variation_scene_unchanged": unchanged,
                                     "regular_font_first_paint_changed": changed})
        provenance["font_override_controls"] = controls
        write_provenance(provenance_path, provenance)
        if not all(row["variation_scene_unchanged"] and all(row["regular_font_first_paint_changed"].values()) for row in controls):
            raise ValueError("font override/control pixel check failed; raw snapshots retained")
    provenance["complete"] = True
    write_provenance(provenance_path, provenance)
    print(f"Completed {len(provenance['launches'])} offscreen processes; artifacts in {output}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        print(f"Replay failed: {error}", file=sys.stderr)
        sys.exit(1)
