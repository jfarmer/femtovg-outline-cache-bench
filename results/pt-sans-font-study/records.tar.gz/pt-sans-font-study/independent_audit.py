"""Independent raw evidence audit; never launches benchmark or GUI processes."""
from collections import defaultdict
import csv
import functools
import hashlib
import json
import math
from pathlib import Path
import random
import statistics

from PIL import Image

ROOT = Path('/private/tmp/pt-sans-outline-review')
REPLAY = Path('/private/tmp/femtovg-pt-sans-outline-review')
APP = Path('/private/tmp/alustin-pt-sans-outline-review')
REFS = {'master': 'f57a2c39e9836c146556c58c98d80c5bf7899029',
        'patch': '7a278ca4f947658d01c355c450edc6abcdbe3958'}
FONT_SHA = {'ptsans': '9cc831490532009bae2b3ce0d39c62adfc889060beb421593bfd9d2396d0f10a',
            'vollkorn': 'b704817fe4433aa674c54f87141f2541d88d7d48342d98ec727a5eed4873a892'}
PHASES = {
    'demo': {'first_paint': 1, 'warm': 30, 'zoom_in': 12, 'zoom_out': 12, 'pan': 10},
    'text': {'first_paint': 1, 'warm': 30, 'x_advance': 10, 'x_return': 10,
             'y_advance': 10, 'size_advance': 12, 'size_return': 12, 'reflow': 3},
    'font_variations': {'first_paint': 1, 'warm': 30, 'weight_advance': 6,
                        'weight_return': 6, 'slant_advance': 10, 'slant_return': 10}}
REPORT = {'complete': False, 'scope': 'Independent provenance, raw-report/CSV arithmetic, paired bootstrap, exact pixels and actual font blobs; no benchmark or GUI launches',
          'comparison': REFS, 'checks': [], 'selected_effects': [], 'font_files': FONT_SHA}

def read(path):
    return json.loads(Path(path).read_text())

@functools.lru_cache(maxsize=None)
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def check_info(info):
    path = Path(info['path'])
    assert path.stat().st_size == info['bytes'], info
    assert sha(str(path)) == info['sha256'], info

def close(a, b):
    assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-11), (a, b)

def pctile(values, quantile):
    ordered = sorted(values)
    position = (len(ordered) - 1) * quantile
    lower, upper = math.floor(position), math.ceil(position)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)

def bootstrap(a, b, indices, percentages_direct=False):
    deltas = [y-x for x, y in zip(a, b)]
    ratios = [y/x for x, y in zip(a, b)]
    fractions = [100*(r-1) for r in ratios] if percentages_direct else ratios
    delta_samples = [statistics.median(deltas[i] for i in ix) for ix in indices]
    ratio_samples = [statistics.median(fractions[i] for i in ix) for ix in indices]
    delta_ci = [pctile(delta_samples, q) for q in (.025, .975)]
    pct_ci = [pctile(ratio_samples, q) for q in (.025, .975)]
    if not percentages_direct:
        pct_ci = [100*(x-1) for x in pct_ci]
    return delta_ci, pct_ci

replay_summary = read(REPLAY / 'analysis/summary.json')
replay_lookup = {(r['backend'], r['font'], r['dpi'], r['scene'], r['phase']): r for r in replay_summary}
replay_method = read(REPLAY / 'analysis/summary-methodology.json')
replay_point_checks = replay_ci_checks = 0
replay_process_counts = {}
for mode, trials in (('cpu', 5), ('gpu', 3)):
    manifest = read(REPLAY / f'{mode}-provenance.json')
    assert manifest['complete'] and manifest['pairs'] == 9 and manifest['trials_per_process'] == trials
    assert set(manifest['fonts']) == {'ptsans', 'vollkorn'} and manifest['dpis'] == [1, 2]
    assert manifest['source_revisions'] == REFS and len(manifest['launches']) == 72
    for info in (*manifest['binaries'].values(), *manifest['font_files'].values(), *manifest['source_files'].values()):
        check_info(info)
    for font in FONT_SHA:
        assert manifest['font_files'][font+'_regular']['sha256'] == FONT_SHA[font]
    old = read(Path('/private/tmp/femtovg-liberation-example-review/results') / f'{mode}-provenance.json')
    assert manifest['binaries'] == old['binaries'] and manifest['fixed_environment'] == old['fixed_environment']
    expected_launches = {(f, d, n, v) for f in manifest['fonts'] for d in [1,2]
                        for n in range(1,10) for v in ['master','patch']}
    observed_launches, raw_rows = set(), {}
    for launch in manifest['launches']:
        key = (launch['font'], launch['dpi'], launch['pair'], launch['version'])
        assert key in expected_launches and key not in observed_launches
        observed_launches.add(key)
        assert launch['validated'] and launch['exit_code'] == 0 and launch['rows'] == 19*trials
        assert launch['environment']['FEMTOVG_REPLAY_TEXT_FONT'] == manifest['font_files'][launch['font']+'_regular']['path']
        assert launch['command'][:4] == [manifest['binaries'][launch['version']]['path'], mode, str(trials), str(launch['dpi'])]
        with Path(launch['stdout']).open() as stream:
            rows = list(csv.DictReader(stream))
        expected = {(s,p,t) for s, phases in PHASES.items() for p in phases for t in range(trials)}
        seen = set()
        for row in rows:
            phase_key = (row['scene'], row['phase'], int(row['trial']))
            assert phase_key in expected and phase_key not in seen
            seen.add(phase_key)
            assert int(row['frames']) == PHASES[phase_key[0]][phase_key[1]]
            values = [float(row[x]) for x in ['draw_us','submit_us','complete_us']]
            assert all(math.isfinite(x) and x >= 0 for x in values) and values == sorted(values)
            raw_rows[key + phase_key] = row
        assert seen == expected
    assert observed_launches == expected_launches
    with (REPLAY / f'{mode}-results.csv').open() as stream:
        retained = list(csv.DictReader(stream))
    assert len(retained) == len(raw_rows)
    retained_seen = set()
    groups = defaultdict(list)
    for row in retained:
        key = (row['font'], int(row['dpi']), int(row['pair']), row['version'], row['scene'], row['phase'], int(row['trial']))
        assert key not in retained_seen and row['backend'] == mode
        retained_seen.add(key)
        assert {k: row[k] for k in raw_rows[key]} == raw_rows[key]
        groups[row['font'],int(row['dpi']),row['scene'],row['phase']].append(row)
    assert retained_seen == set(raw_rows) and len(groups) == 76
    for (font,dpi,scene,phase), rows in groups.items():
        entry = replay_lookup[mode,font,dpi,scene,phase]
        counts = {(int(r['frames']),int(r['new_atlas_entries'])) for r in rows}
        assert counts == {(entry['frames'],entry['new_atlas_entries'])}
        token = f'{mode}/{font}/{dpi}/{scene}/{phase}'
        rng = random.Random(replay_method['seed'] ^ int.from_bytes(hashlib.sha256(token.encode()).digest()[:8], 'big'))
        indices = [[rng.randrange(9) for _ in range(9)] for _ in range(replay_method['bootstrap_resamples'])]
        for metric in ['draw_us','submit_us','complete_us']:
            selected = entry[metric]
            a = [statistics.median(float(r[metric]) for r in rows if int(r['pair'])==n and r['version']=='master') for n in range(1,10)]
            b = [statistics.median(float(r[metric]) for r in rows if int(r['pair'])==n and r['version']=='patch') for n in range(1,10)]
            assert selected['process_pairs']==9 and selected['trials_per_process']==trials
            close(selected['master_process_median'], statistics.median(a))
            close(selected['patch_process_median'], statistics.median(b))
            close(selected['master_median'], statistics.median(float(r[metric]) for r in rows if r['version']=='master'))
            close(selected['patch_median'], statistics.median(float(r[metric]) for r in rows if r['version']=='patch'))
            close(selected['paired_delta_us'], statistics.median(y-x for x,y in zip(a,b)))
            close(selected['paired_delta_pct'], statistics.median(100*(y/x-1) for x,y in zip(a,b)))
            for pair, x,y in zip(selected['pairs'],a,b):
                close(pair['master'], x); close(pair['patch'], y)
            replay_point_checks += 1
            interesting = ((scene=='demo' and phase in ['first_paint','zoom_in','zoom_out']) or
                           (scene=='text' and phase in ['first_paint','x_advance','size_advance']) or
                           (scene=='font_variations' and phase in ['weight_advance','slant_advance']))
            if interesting and metric == ('draw_us' if mode=='cpu' else 'complete_us'):
                delta_ci,pct_ci = bootstrap(a,b,indices,True)
                for old,new in zip(selected['paired_delta_us_ci95'],delta_ci): close(old,new)
                for old,new in zip(selected['paired_bootstrap95'],pct_ci): close(old,new)
                replay_ci_checks += 1
                REPORT['selected_effects'].append({'environment':'replay','mode':mode,'font':font,'dpi':dpi,
                    'scene':scene,'phase':phase,'metric':metric,'master':statistics.median(a),
                    'patch':statistics.median(b),'paired_change_pct':selected['paired_delta_pct'],'ci95':pct_ci})
    replay_process_counts[mode] = len(observed_launches)

app_analysis = read(APP / 'analysis/summary.json')
app_lookup = {(r['mode'],r['backend'],r['font'],r['metric']):r for r in app_analysis['results']}
app_checks, app_counts = 0, {}
app_manifests = {}
for mode, folder in [('cpu','cpu-12'),('startup','startup-12')]:
    manifest = read(APP / folder / 'summary.json')
    app_manifests[mode]=manifest
    assert manifest['complete'] and manifest['rounds']==12 and len(manifest['launches'])==96 and len(manifest['accepted_pairs'])==48
    assert set(manifest['fonts'])==set(FONT_SHA) and manifest['source_revisions']==REFS
    assert manifest['actual_font_diagnostics']['enabled'] is False
    assert manifest['environment']['ALUSTIN_FEMTOVG_DIAGNOSTICS']==('1' if mode=='cpu' else '0')
    assert manifest['environment']['SLINT_STARTUP_DIAGNOSTICS']==('1' if mode=='cpu' else '0')
    old = read(Path('/private/tmp/alustin-font-outline-review') / folder / 'summary.json')
    for field in ['binaries','harness','inputs','environment','app_commit','source_revisions','backends']:
        assert manifest[field] == old[field], field
    for info in [*manifest['binaries'].values(),manifest['harness'],*manifest['inputs'].values()]: check_info(info)
    for font in FONT_SHA:
        assert manifest['fonts'][font]['file']['sha256']==FONT_SHA[font]
        check_info(manifest['fonts'][font]['file'])
    raw = defaultdict(dict)
    for launch in manifest['launches']:
        assert launch['included'] and launch['validated'] and launch['exit_code']==0 and launch['attempt']==1
        assert 'ALUSTIN_FONT_DIAGNOSTICS_DIR' not in launch['environment']
        report = read(launch['report']); assert len(report['samples'])==1
        sample=report['samples'][0]
        events={e['event']:e for e in sample['events']}
        assert sample['executable_path']==manifest['binaries'][launch['version']]['path']
        assert sample['backend_requested']==launch['backend']
        assert sample['system_fonts_disabled'] and report['system_fonts_disabled']
        assert report['font_path']==manifest['fonts'][launch['font']]['file']['path']
        assert events['benchmark_font_configured']['details']=={'family':manifest['fonts'][launch['font']]['family'],'font_path':report['font_path']}
        assert events['first_frame_rendered']['details']=={'physical_width':2560,'physical_height':1600,'scale_factor':2.0}
        assert events['interactive_frame_rendered']['details']['query']=='a'
        assert events['renderer_setup']['details']['graphics_api']==('WGPU30' if launch['backend']=='winit-femtovg-wgpu' else 'OpenGL')
        values={'observed_search_response_ms':sample['launch_to_probe_observed_ms'],
                'first_frame_since_main_ms':events['first_frame_rendered']['since_main_ms'],
                'search_frame_since_main_ms':events['interactive_frame_rendered']['since_main_ms'],
                'search_after_first_frame_ms':events['interactive_frame_rendered']['since_main_ms']-events['first_frame_rendered']['since_main_ms'],
                'first_callback_wall_ms':events['first_frame_rendered']['since_main_ms']-events['first_render_started']['since_main_ms'],
                'spawn_to_main_ms':sample['spawn_to_main_ms'],'peak_rss_mib':sample['peak_rss_bytes']/2**20}
        if mode=='cpu':
            spans=sample['slint_internal_spans']
            for phase, marker_name in [('first_frame','first_frame_rendered'),('search_frame','interactive_frame_rendered')]:
                markers=[s for s in spans if s['name']==marker_name]; assert len(markers)==1
                point=markers[0]['start_ns']
                renders=[s for s in spans if s['name']=='femtovg.render' and s['start_ns']<=point<=s['start_ns']+s['duration_ns']]
                assert len(renders)==1
                start,end=renders[0]['start_ns'],renders[0]['start_ns']+renders[0]['duration_ns']
                for part in ['render','component_items','final_flush']:
                    for measure in ['wall','thread_cpu']:
                        name='femtovg.'+part+('.thread_cpu_ns' if measure=='thread_cpu' else '')
                        selected=[s for s in spans if s['name']==name and start<=s['start_ns'] and s['start_ns']+s['duration_ns']<=end]
                        assert selected
                        values[f'{phase}.{part}.{measure}_ms']=sum(s['amount'] if measure=='thread_cpu' else s['duration_ns'] for s in selected)/1e6
        key=launch['backend'],launch['font'],launch['round']
        assert launch['version'] not in raw[key]
        raw[key][launch['version']]=values
    for backend in manifest['backends']:
        for font in FONT_SHA:
            pairs=[raw[backend,font,n] for n in range(1,13)]
            assert all(set(p)=={'master','patch'} for p in pairs)
            rng=random.Random(app_analysis['statistics']['seed'] ^ int.from_bytes(hashlib.sha256(f'{folder}/{backend}/{font}'.encode()).digest()[:8],'big'))
            indices=[[rng.randrange(12) for _ in range(12)] for _ in range(app_analysis['statistics']['bootstrap_resamples'])]
            for metric in pairs[0]['master']:
                row=app_lookup[mode,backend,font,metric]
                a=[p['master'][metric] for p in pairs]; b=[p['patch'][metric] for p in pairs]
                assert row['n_pairs']==12
                close(row['master_median'],statistics.median(a)); close(row['patch_median'],statistics.median(b))
                close(row['median_paired_delta'],statistics.median(y-x for x,y in zip(a,b)))
                close(row['median_paired_change_pct'],100*(statistics.median(y/x for x,y in zip(a,b))-1))
                delta_ci,pct_ci=bootstrap(a,b,indices)
                for old,new in zip(row['median_paired_delta_ci95'],delta_ci): close(old,new)
                for old,new in zip(row['median_paired_change_pct_ci95'],pct_ci): close(old,new)
                app_checks+=1
                if metric in ['first_frame.render.thread_cpu_ms','search_frame.render.thread_cpu_ms','observed_search_response_ms','peak_rss_mib','first_callback_wall_ms']:
                    REPORT['selected_effects'].append({'environment':'alustin','mode':mode,'font':font,'backend':backend,
                        'metric':metric,'master':statistics.median(a),'patch':statistics.median(b),
                        'paired_change_pct':row['median_paired_change_pct'],'paired_delta':row['median_paired_delta'],
                        'delta_ci95':delta_ci,'ci95':pct_ci})
    assert len(raw)==48
    app_counts[mode]=len(manifest['launches'])
for field in ['app_commit','source_revisions','binaries','harness','inputs','fonts','backends']:
    assert app_manifests['cpu'][field]==app_manifests['startup'][field]

excluded=read(APP / 'cpu-aborted-timeout/summary.json')
exclusion=read(APP / 'cpu-aborted-timeout/batch-exclusion.json')
assert excluded['complete'] is False and len(excluded['launches'])==20 and len(excluded['accepted_pairs'])==9
assert exclusion['included_in_primary_analysis'] is False
assert len(app_analysis['excluded_batches'])==1 and app_analysis['excluded_batches'][0]['raw_launches']==20
for field in ['binaries','harness','inputs','fonts','backends','environment']:
    assert excluded[field]==app_manifests['cpu'][field]
for launch in excluded['launches']:
    prefix=APP / 'cpu-12'
    archived_report=APP / 'cpu-aborted-timeout' / Path(launch['report']).relative_to(prefix)
    if launch.get('validated'): assert archived_report.exists()
    for suffix in ['harness.stdout','harness.stderr']:
        assert (APP / 'cpu-aborted-timeout' / (launch['label']+'.'+suffix)).exists()

replay_pixels=read(REPLAY / 'pixels-provenance.json')
assert replay_pixels['complete'] and len(replay_pixels['pixel_comparisons'])==114
for row in replay_pixels['pixel_comparisons']:
    check_info(row['master']); check_info(row['patch'])
    assert row['rgba_identical'] and row['master']['sha256']==row['patch']['sha256']
    assert Path(row['master']['path']).read_bytes()==Path(row['patch']['path']).read_bytes()
for control in replay_pixels['font_override_controls']:
    assert control['variation_scene_unchanged'] and all(control['regular_font_first_paint_changed'].values())
    dpi,version,font=control['dpi'],control['version'],control['font']
    stock=REPLAY / 'pixels-runs' / f'stock-dpi{dpi}-{version}-pixels'
    alternate=REPLAY / 'pixels-runs' / f'{font}-dpi{dpi}-{version}-pixels'
    for phase in PHASES['font_variations']:
        assert sha(str(stock / f'font_variations-{phase}.rgba'))==sha(str(alternate / f'font_variations-{phase}.rgba'))
    for scene in ['demo','text']:
        assert sha(str(stock / f'{scene}-first_paint.rgba'))!=sha(str(alternate / f'{scene}-first_paint.rgba'))

app_pixels=read(APP / 'pixels-font-validation/summary.json')
assert app_pixels['complete'] and len(app_pixels['launches'])==8 and len(app_pixels['pixel_comparisons'])==4
faces=[]
for launch in app_pixels['launches']:
    assert launch['validated'] and launch['included'] and launch['font_verification_exit_code']==0
    actual=launch['actual_fonts']; assert actual['complete']
    assert sorted(f['role'] for f in actual['actual_fonts'])==['fallback','primary']
    for face in actual['actual_fonts']:
        metadata_path=Path(face['metadata_file']); metadata=read(metadata_path)
        blob=metadata_path.parent / metadata['blob_file']
        assert blob.stat().st_size==metadata['bytes'] and sha(str(blob))==face['sha256']
        assert bytes.fromhex(metadata['family_utf8_hex']).decode()==face['family']
        if face['role']=='primary':
            assert face['sha256']==FONT_SHA[launch['font']] and face['family']==app_pixels['fonts'][launch['font']]['family'] and face['face_index']==0
        else:
            assert face['family']=='Inter' and face['sha256']==app_pixels['actual_font_diagnostics']['fallback']['sha256']
        faces.append({'label':launch['label'],'family':face['family'],'role':face['role'],'sha256':face['sha256']})
for row in app_pixels['pixel_comparisons']:
    decoded=[]
    for version in ['master','patch']:
        check_info(row[version+'_png'])
        with Image.open(row[version+'_png']['path']) as image:
            assert image.size==(2560,1600)
            rgba=image.convert('RGBA').tobytes()
        assert hashlib.sha256(rgba).hexdigest()==row[version+'_rgba_sha256']
        decoded.append(rgba)
    assert decoded[0]==decoded[1] and row['rgba_identical']
for row in app_pixels['font_override_controls']:
    assert row['pixels_differ_from_vollkorn']

REPORT.update(complete=True, replay_timed_processes=replay_process_counts, app_timed_processes=app_counts,
              retained_every_completed_timing_process=True, completed_batch_retries=0,
              excluded_entire_incomplete_batch={'path':str(APP/'cpu-aborted-timeout'),'launches':20,'validated':19,'accepted_pairs_before_abort':9,'same_binary_font_input_environment_identity_as_replacement':True,'old_paths_remapped_only_for_archive_audit':True},
              replay_point_summaries_verified=replay_point_checks,replay_selected_ci_summaries_verified=replay_ci_checks,
              app_all_metric_summaries_and_ci_verified=app_checks,
              replay_pixel_pairs_independently_rehashed_and_byte_compared=114,
              app_pixel_pairs_independently_decoded_with_pillow=4,
              actual_font_blobs_verified=faces,source_and_font_provenance_matching_across_environments=True)
(ROOT / 'independent-audit.json').write_text(json.dumps(REPORT,indent=2)+'\n')
print(json.dumps({k:v for k,v in REPORT.items() if k not in ['selected_effects','actual_font_blobs_verified']},indent=2))
