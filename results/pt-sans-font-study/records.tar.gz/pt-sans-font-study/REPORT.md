PT Sans Regular improves first-render CPU duration against master by 12.0% in the DPR-2 FemtoVG demo replay, 6.9% in Alustin WGPU, and 2.9% in Alustin OpenGL. All three exploratory paired-bootstrap intervals exclude zero. The fresh Vollkorn control remains substantially faster with the patch: 33.3%, 21.9%, and 19.7% respectively. The earlier four-font and original benchmarks remain preserved.

Frozen FemtoVG revisions: master `f57a2c39e9836c146556c58c98d80c5bf7899029`, patch `7a278ca4f947658d01c355c450edc6abcdbe3958`. The patch is the existing Swash outline cache with a one-MiB logical budget; no production code or cache settings changed for this experiment. [Existing binary audit](existing-binary-audit.json) confirms that the binaries also match those used for the earlier four-font comparison.

The table shows first-render CPU duration changes. Negative means faster; brackets contain exploratory paired-bootstrap 95% intervals. Demo measures `Canvas<Void>` drawing CPU at DPR 2; Alustin measures renderer-thread CPU. Their absolute durations cover different scopes.

| Font | Demo first paint, DPR 2 | Alustin WGPU | Alustin OpenGL |
|---|---:|---:|---:|
| PT Sans Regular | −12.0% [−15.2%, −6.2%] | −6.9% [−8.8%, −3.3%] | −2.9% [−7.2%, −0.3%] |
| Vollkorn Medium | −33.3% [−34.1%, −31.1%] | −21.9% [−22.9%, −20.4%] | −19.7% [−21.6%, −15.5%] |

[Comparison chart](first-render-comparison.png), [SVG](first-render-comparison.svg), and [plot data](first-render-comparison-data.json).

| Font / backend | First-render CPU, master → patch | Median paired saving | Search-render CPU change |
|---|---:|---:|---:|
| PT Sans Regular / WGPU | 16.239 → 15.092 ms | 1.110 ms | −0.4% [−6.2%, +6.1%] |
| PT Sans Regular / OpenGL | 18.885 → 18.270 ms | 0.544 ms | −3.1% [−10.4%, +0.9%] |
| Vollkorn Medium / WGPU | 23.529 → 18.334 ms | 5.180 ms | −5.0% [−9.3%, −0.4%] |
| Vollkorn Medium / OpenGL | 26.617 → 21.410 ms | 5.198 ms | −9.9% [−12.5%, −1.9%] |

The replay retains the existing demo and text drawing helpers. CPU uses a no-op renderer with the same black-box barriers; the offscreen Metal/WGPU replay waits for GPU completion. Draw, submit, and complete are cumulative measurements and must not be added. Each font/DPR has nine fresh master/patch process pairs, five CPU trials per process, and three GPU trials per process. Trial medians become process observations before paired effects are calculated. Version order alternates and font/DPR order rotates. All validated timing observations in the completed cohorts are included.

Selected replay phases are below. Each cell shows DPR 1 / DPR 2 paired percentage changes. Detailed intervals and all 19 phases remain in the [replay summary](../femtovg-pt-sans-outline-review/analysis/summary.csv).

| Font / phase | Drawing CPU | Completed GPU |
|---|---:|---:|
| PT Sans Regular: Demo first paint | −10.1% / −12.0% | +3.9% / +3.7% |
| PT Sans Regular: Demo zoom in | −13.7% / −12.4% | −7.4% / −8.9% |
| PT Sans Regular: Demo zoom out | −15.7% / −15.8% | −8.7% / −13.4% |
| PT Sans Regular: Text first paint | −8.1% / −7.9% | +0.2% / −8.2% |
| PT Sans Regular: Horizontal text movement | −18.4% / −16.9% | −9.3% / −13.1% |
| PT Sans Regular: Text size increase | −8.2% / −8.3% | −6.9% / −8.5% |
| Vollkorn Medium: Demo first paint | −31.6% / −33.3% | −9.7% / −15.0% |
| Vollkorn Medium: Demo zoom in | −32.8% / −33.0% | −22.5% / −22.1% |
| Vollkorn Medium: Demo zoom out | −34.2% / −35.2% | −23.8% / −23.7% |
| Vollkorn Medium: Text first paint | −22.7% / −22.9% | −14.6% / −13.9% |
| Vollkorn Medium: Horizontal text movement | −44.8% / −45.3% | −27.1% / −26.7% |
| Vollkorn Medium: Text size increase | −31.6% / −31.8% | −26.2% / −22.4% |

For PT Sans, every CPU interval in this selected table excludes zero. Completed-GPU gains are established for demo zoom-in (7.4% / 8.9%), zoom-out (8.7% / 13.4%), and text size increase (6.9% / 8.5%) at both DPIs. At DPR 2, text first paint and horizontal movement also improve by 8.2% and 13.1%, with intervals excluding zero. Demo first-paint completion has positive point estimates at both DPIs, but both intervals cross zero; this experiment establishes neither a completion gain nor a regression there. DPR-1 text first paint and horizontal movement also remain uncertain. CPU savings therefore do not imply a completed-GPU improvement in every phase.


The six variable-font phases always use the unchanged Roboto Flex control. They are not PT Sans or Vollkorn variation workloads. Warm redraws and return phases usually hit the existing atlas, so the outline cache has little opportunity to help. Their timings and the Roboto weight/slant control are retained in the full summary, including potential regressions.

Alustin uses app commit `ac35d4e0b5c52edb7defb9feccdadfd584635c14`, the same large save, catalog, icon pack, and a DPR-2 2560×1600 physical viewport. System-font discovery is disabled and the requested font is registered before first render. Twelve fresh pairs per font/backend were collected separately for CPU and startup; startup disables renderer diagnostics. CPU spans are nested and overlap. Alustin CPU/startup timings do not measure GPU completion or compositor scanout. Separate untimed screenshots verify the actual selected primary face and the existing Inter fallback. The replay uses Swash 0.2.10 / Skrifa 0.44.0; Alustin uses Swash 0.2.10 / Skrifa 0.40.0. Locks remain fixed within each comparison.

The initial Alustin CPU batch was interrupted by a 120-second harness timeout while waiting for an interactive response. Its cause is unknown. The entire incomplete batch (20 raw launches, 19 validated launches) is excluded, archived with its raw reports, and disclosed in [batch-exclusion.json](../alustin-pt-sans-outline-review/cpu-aborted-timeout/batch-exclusion.json). The full cohort was restarted with unchanged binaries/settings; no individual timing-based exclusions were made.

| Font / backend | Diagnostics-off launch to search readiness | Startup peak RSS change | First-render final-flush CPU change |
|---|---:|---:|---:|
| PT Sans Regular / WGPU | −2.4% [−5.0%, +1.2%] | +0.148 MiB [-0.969, +0.766] | −1.2% [−6.8%, +2.1%] |
| PT Sans Regular / OpenGL | −0.7% [−2.3%, +0.7%] | +0.445 MiB [-0.781, +1.875] | +1.1% [−2.2%, +3.5%] |
| Vollkorn Medium / WGPU | −3.7% [−5.2%, −1.7%] | +0.156 MiB [-0.656, +0.367] | −0.5% [−3.4%, +5.9%] |
| Vollkorn Medium / OpenGL | −1.8% [−3.0%, −0.01%] | +0.016 MiB [-0.703, +1.062] | −0.5% [−7.4%, +6.7%] |

Startup and RSS are noisier than isolated renderer CPU. Intervals crossing zero do not establish a benefit or regression. Intervals are exploratory across many phases and metrics with no multiplicity adjustment. Independent median times and median paired effects are different statistics, so their ratios need not match.

PT Sans’s search-frame render CPU and diagnostics-off startup intervals cross zero in both backends. Its first-render component-item CPU falls by about 0.64 ms WGPU and 0.60 ms OpenGL; final-flush CPU is uncertain in all four font/backend cells. Peak RSS has no established increase in the diagnostics-off cohort. The diagnostic CPU cohort does show a small Vollkorn OpenGL increase of 0.45 MiB [0.23, 1.24 MiB], while its separate startup cohort does not; the logical one-MiB cache charge is not a bound on process memory.

The unchanged Roboto variation control retains downsides: in the PT Sans-labelled DPR-2 CPU cohort, advancing weight regresses by 1.9% [0.8%, 7.9%] and returning weight by 2.3% [0.6%, 2.9%]. These are Roboto effects, not PT Sans variation behavior. Vollkorn’s DPR-1 warm text phase also has a small CPU regression of 2.8% [0.3%, 3.7%]. These exploratory effects remain in the results. Most warm/return and control intervals cross zero, and completed-GPU variation intervals remain uncertain. The cache still imposes lookup/ownership work on misses; neither this experiment nor a larger bytecode count proves a better cache admission policy or size.

All 114 replay master/patch phase images and all four Alustin screenshot pairs are identical decoded RGBA. The replay pixel batch includes stock Roboto as an additional font-override control. Alustin pixel checks and actual-face diagnostics are retained in [its pixel batch](../alustin-pt-sans-outline-review/pixels-font-validation/summary.json); [visual inspection](visual-check.json) covers PT Sans.

PT Sans has 162,235 glyph-program bytes and 37,433 ASCII glyph-program bytes, versus Vollkorn’s 85,955 and 6,907. Those static counts do not measure execution frequency or work performed by function calls, loops, and composites, or the actual glyph/size mix. More bytecode is not equivalent to more executed hint work, and these font replacements also differ in geometry, metrics, and default weight (PT Sans Regular 400; Vollkorn Medium 500). The experiment measures the patch’s workload benefit, rather than an isolated interpreter-cost effect. [Font and bytecode audit](../femtovg-open-font-search/candidate-agent/independent-audit.json).

The [reproduction instructions](REPRODUCE.md) cover the retained [measurement plan](measurement-plan.json), [used-runner provenance](used-runner-provenance.json), replay [CPU provenance](../femtovg-pt-sans-outline-review/cpu-provenance.json)/[GPU provenance](../femtovg-pt-sans-outline-review/gpu-provenance.json), [replay methodology](../femtovg-pt-sans-outline-review/analysis/summary-methodology.json), and [Alustin raw-validated analysis](../alustin-pt-sans-outline-review/analysis/summary.json). The runners used for this experiment are archived under `used-runners/`; the report/chart are reproduced by `report-work/create_report.py` after the summary scripts finish. Earlier [four-font evidence](../femtovg-liberation-example-review/REPORT.md) is a prior cohort and is not pooled with these observations. `previous-runners/` preserves the older runner source.

An [independent audit](independent-audit.json) rechecks raw timing arithmetic, bootstrap intervals, paired retention, decoded pixels, and binary/font provenance.
