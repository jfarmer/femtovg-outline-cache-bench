The retained experiment uses identical prebuilt binaries to the earlier four-font comparison. The master revision is `f57a2c39e9836c146556c58c98d80c5bf7899029`; the patch is `7a278ca4f947658d01c355c450edc6abcdbe3958`. No cache parameter or production-source changes were made for PT Sans.

The scripts and source paths in `used-runner-provenance.json` are the exact versions used for this cohort. `previous-runner-provenance.json` archives their earlier versions before the PT Sans factor was added. Per-mode manifests hash binaries, fonts, inputs and configuration; the replay also hashes its example drawing source. Build and source audits are retained in the original benchmark directories referenced by `existing-binary-audit.json`.

Run every measurement sequentially, with no other performance workload. Alustin opens native windows. The replay GPU and pixels modes need Metal access. Choose new output directories; the runners reject overwriting a completed mode. The following commands reproduce the accepted matrix into fresh directories:

```sh
python3 /private/tmp/femtovg-liberation-example-review/run.py pixels --fonts stock vollkorn ptsans --dpis 1 2 --output /private/tmp/femtovg-pt-sans-repeat
python3 /private/tmp/alustin-font-outline-review/run.py pixels --fonts ptsans vollkorn --actual-font-diagnostics --master /private/tmp/alustin-font-outline-review/build/bin/master/alustin-gui --patch /private/tmp/alustin-font-outline-review/build/bin/patch/alustin-gui --harness /private/tmp/alustin-font-outline-review/build/bin/startup_bench --output /private/tmp/alustin-pt-sans-repeat/pixels-font-validation
python3 /private/tmp/femtovg-liberation-example-review/run.py cpu --fonts ptsans vollkorn --dpis 1 2 --pairs 9 --trials 5 --output /private/tmp/femtovg-pt-sans-repeat
python3 /private/tmp/alustin-font-outline-review/run.py cpu --fonts ptsans vollkorn --rounds 12 --master /private/tmp/alustin-font-outline-review/build/bin/master/alustin-gui --patch /private/tmp/alustin-font-outline-review/build/bin/patch/alustin-gui --harness /private/tmp/alustin-font-outline-review/build/bin/startup_bench --output /private/tmp/alustin-pt-sans-repeat/cpu-12
python3 /private/tmp/alustin-font-outline-review/run.py startup --fonts ptsans vollkorn --rounds 12 --master /private/tmp/alustin-font-outline-review/build/bin/master/alustin-gui --patch /private/tmp/alustin-font-outline-review/build/bin/patch/alustin-gui --harness /private/tmp/alustin-font-outline-review/build/bin/startup_bench --output /private/tmp/alustin-pt-sans-repeat/startup-12
python3 /private/tmp/femtovg-liberation-example-review/run.py gpu --fonts ptsans vollkorn --dpis 1 2 --pairs 9 --trials 3 --output /private/tmp/femtovg-pt-sans-repeat
python3 /private/tmp/femtovg-liberation-example-review/summarize.py --root /private/tmp/femtovg-pt-sans-repeat --output /private/tmp/femtovg-pt-sans-repeat/analysis
python3 /private/tmp/alustin-font-outline-review/analyze.py /private/tmp/alustin-pt-sans-repeat/cpu-12 /private/tmp/alustin-pt-sans-repeat/startup-12 /private/tmp/alustin-pt-sans-repeat/pixels-font-validation --output /private/tmp/alustin-pt-sans-repeat/analysis
```

Every completed batch retains all its validated pairs and per-process trials. CPU diagnostics and actual-face dumps are disabled during the separate startup batch. Pixel checks are untimed. The variable-font replay always uses stock Roboto Flex, irrespective of the primary regular text font.

The original attempted CPU batch ended at `03-winit-femtovg-vollkorn-attempt1-patch` after a 120-second harness timeout waiting for an interactive response; its cause is unknown. Its entire incomplete matrix is excluded from primary statistics. The raw files and original manifest bytes are preserved in `/private/tmp/alustin-pt-sans-outline-review/cpu-aborted-timeout`, with `batch-exclusion.json` explaining the exclusion. Because the directory was relocated, original raw path prefixes in that archived manifest point to `cpu-12`; locate archived files by replacing that prefix with `cpu-aborted-timeout`. The completed replacement CPU batch and startup batch each contain 96 launches and 48 accepted pairs, without retries. No individual measurement was excluded based on its duration.

The actual analysis command also recorded this excluded batch:

```sh
python3 /private/tmp/alustin-font-outline-review/analyze.py /private/tmp/alustin-pt-sans-outline-review/cpu-12 /private/tmp/alustin-pt-sans-outline-review/startup-12 /private/tmp/alustin-pt-sans-outline-review/pixels-font-validation --output /private/tmp/alustin-pt-sans-outline-review/analysis --exclude /private/tmp/alustin-pt-sans-outline-review/cpu-aborted-timeout 'Entire incomplete batch retained and excluded after one harness timeout without interactive response; replacement batch uses unchanged binaries and settings.'
```
