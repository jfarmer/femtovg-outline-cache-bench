#!/usr/bin/env python3
"""Summarize offscreen master/patch pairs by font, DPR, example, and phase.

Within-process trials first become process medians. Effects use the nine paired
process medians, never trials as independent pairs. All included runs remain.
"""

import argparse
from collections import defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import sys


ROOT = Path(__file__).resolve().parent
METRICS = ("draw_us", "submit_us", "complete_us")


def percentile(values, q):
    values = sorted(values)
    position = (len(values) - 1) * q
    lo, hi = math.floor(position), math.ceil(position)
    return values[lo] + (values[hi] - values[lo]) * (position - lo)


def interval(values):
    return [percentile(values, 0.025), percentile(values, 0.975)]


def read_mode(root, mode):
    metadata = json.loads((root / f"{mode}-provenance.json").read_text())
    if not metadata.get("complete"):
        raise ValueError(f"{mode} batch is incomplete; do not summarize partial pairs")
    expected_processes = metadata["pairs"] * len(metadata["fonts"]) * len(metadata["dpis"]) * 2
    if len(metadata["launches"]) != expected_processes or any(not row.get("validated") or row.get("exit_code") != 0 for row in metadata["launches"]):
        raise ValueError(f"{mode} has missing/unvalidated processes")
    with (root / f"{mode}-results.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    expected_rows = sum(row["rows"] for row in metadata["launches"])
    if len(rows) != expected_rows:
        raise ValueError(f"{mode} CSV row count differs from validated processes")
    return metadata, rows


def metric_summary(rows, metric, expected_pairs, expected_trials, resamples, indices):
    processes, all_values = defaultdict(dict), defaultdict(list)
    for row in rows:
        key = (int(row["pair"]), row["version"])
        trial = int(row["trial"])
        if trial in processes[key]:
            raise ValueError(f"duplicate trial {trial} in process {key}")
        value = float(row[metric])
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f"invalid timing for {key}: {metric}={value}")
        processes[key][trial] = value
        all_values[row["version"]].append(value)
    expected_keys = {(pair, version) for pair in range(1, expected_pairs + 1) for version in ("master", "patch")}
    if set(processes) != expected_keys:
        raise ValueError("missing or extra process pairs")
    if any(set(trials) != set(range(expected_trials)) for trials in processes.values()):
        raise ValueError("missing or extra trials within a process")
    process_medians = {key: statistics.median(trials.values()) for key, trials in processes.items()}
    pairs = [{"pair": pair, "master": process_medians[pair, "master"], "patch": process_medians[pair, "patch"]}
             for pair in range(1, expected_pairs + 1)]
    for pair in pairs:
        pair["delta_us"] = pair["patch"] - pair["master"]
        pair["patch_over_master_ratio"] = pair["patch"] / pair["master"]
        pair["change_pct"] = 100 * (pair["patch_over_master_ratio"] - 1)
    deltas = [pair["delta_us"] for pair in pairs]
    percentages = [pair["change_pct"] for pair in pairs]
    boot_delta = [statistics.median(deltas[index] for index in sample) for sample in indices]
    boot_pct = [statistics.median(percentages[index] for index in sample) for sample in indices]
    return {
        "master_median": statistics.median(all_values["master"]),
        "patch_median": statistics.median(all_values["patch"]),
        "master_process_median": statistics.median(pair["master"] for pair in pairs),
        "patch_process_median": statistics.median(pair["patch"] for pair in pairs),
        "paired_delta_us": statistics.median(deltas), "paired_delta_us_ci95": interval(boot_delta) if boot_delta else None,
        "paired_delta_pct": statistics.median(percentages), "paired_bootstrap95": interval(boot_pct) if boot_pct else None,
        "process_pairs": expected_pairs, "trials_per_process": expected_trials,
        "samples_per_version": len(all_values["master"]), "bootstrap_resamples": resamples if indices else 0,
        "pairs": pairs,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--modes", choices=("cpu", "gpu"), nargs="+", default=["cpu", "gpu"])
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=72531)
    args = parser.parse_args()
    if args.bootstrap < 1:
        parser.error("bootstrap must be positive")
    root = args.root.resolve(strict=True)
    output = args.output.resolve() if args.output else root
    output.mkdir(parents=True, exist_ok=True)
    summary, provenance, pair_rows = [], {}, []
    for mode in args.modes:
        if not (root / f"{mode}-provenance.json").exists():
            continue
        metadata, data = read_mode(root, mode)
        provenance[mode] = metadata
        groups = defaultdict(list)
        for row in data:
            groups[row["font"], int(row["dpi"]), row["scene"], row["phase"]].append(row)
        expected_groups = len(metadata["fonts"]) * len(metadata["dpis"]) * 19
        if len(groups) != expected_groups:
            raise ValueError(f"{mode} has missing phase/configuration groups")
        for (font, dpi, scene, phase), rows in sorted(groups.items()):
            counts = {(int(row["frames"]), int(row["new_atlas_entries"])) for row in rows}
            if len(counts) != 1:
                raise ValueError(f"workload counts vary: {mode}, {font}, DPR{dpi}, {scene}, {phase}")
            frames, atlas = next(iter(counts))
            entry = {"backend": mode, "font": font, "dpi": dpi, "scene": scene, "phase": phase,
                     "frames": frames, "new_atlas_entries": atlas}
            token = f"{mode}/{font}/{dpi}/{scene}/{phase}"
            seed = args.seed ^ int.from_bytes(hashlib.sha256(token.encode()).digest()[:8], "big")
            rng = random.Random(seed)
            n = metadata["pairs"]
            # Resampling indices are shared across the three cumulative metrics.
            indices = [[rng.randrange(n) for _ in range(n)] for _ in range(args.bootstrap)] if n >= 3 else []
            for metric in METRICS:
                values = metric_summary(rows, metric, n, metadata["trials_per_process"], args.bootstrap, indices)
                entry[metric] = values
                pair_rows.extend({"backend": mode, "font": font, "dpi": dpi, "scene": scene,
                                  "phase": phase, "metric": metric, **pair} for pair in values["pairs"])
            summary.append(entry)
    if not summary:
        raise ValueError("no completed timing batches found")
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    description = {
        "bootstrap_resamples": args.bootstrap, "seed": args.seed,
        "absolute_values": "Pooled medians across all per-trial phase-average durations; process-median absolutes are also retained",
        "pairing": "Median across trials within each child process, then pair master/patch process medians by font, DPR, phase, and round",
        "effect": "Median paired patch-minus-master microseconds and median paired 100*(patch/master-1) percent; negative is faster",
        "intervals": "Percentile bootstrap of process pairs, linearly interpolated at 2.5% and 97.5%; no CI with fewer than three pairs",
        "scope": "Exploratory intervals across 19 phases, font/DPR factors, and three cumulative metrics; no multiple-comparison adjustment",
        "retention": "Every validated process/trial in each completed included batch retained; no outlier removal; pixels excluded from timing statistics",
        "units": "Microseconds per frame averaged within each phase/trial; draw/submit/complete are cumulative, not additive",
        "provenance_files": {mode: str(root / f"{mode}-provenance.json") for mode in provenance},
    }
    if (root / "pixels-provenance.json").exists():
        pixels = json.loads((root / "pixels-provenance.json").read_text())
        description["pixels"] = {"complete": pixels.get("complete", False),
                                 "comparisons": len(pixels["pixel_comparisons"]),
                                 "identical_comparisons": sum(row["rgba_identical"] for row in pixels["pixel_comparisons"]),
                                 "font_override_controls": pixels.get("font_override_controls", [])}
    (output / "summary-methodology.json").write_text(json.dumps(description, indent=2) + "\n")
    fields = ["backend", "font", "dpi", "scene", "phase", "metric", "pair", "master", "patch", "delta_us", "patch_over_master_ratio", "change_pct"]
    with (output / "paired-processes.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(pair_rows)
    flat = []
    for entry in summary:
        for metric in METRICS:
            values = entry[metric]
            flat.append({**{key: entry[key] for key in ("backend", "font", "dpi", "scene", "phase", "frames", "new_atlas_entries")},
                         "metric": metric, **{key: values[key] for key in ("master_median", "patch_median", "master_process_median", "patch_process_median", "paired_delta_us", "paired_delta_us_ci95", "paired_delta_pct", "paired_bootstrap95", "process_pairs", "trials_per_process", "samples_per_version")}})
    with (output / "summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(flat[0]))
        writer.writeheader()
        writer.writerows(flat)
    print(f"Wrote {len(summary)} phase/configuration summaries and {len(pair_rows)} paired metric rows to {output}")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError) as error:
        print(f"Summary failed: {error}", file=sys.stderr)
        sys.exit(1)
