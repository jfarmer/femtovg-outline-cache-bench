#!/usr/bin/env python3
"""Read-only independent all-metric app point/provenance audit.

The separate retained raw-CPU auditor supplies independently recalculated CIs.
This file imports no benchmark runner, analyzer, or benchmark metric helpers.
It never executes an application, renderer, or Rust build.
"""
import argparse
import csv
import datetime
import hashlib
import json
import math
from pathlib import Path

VERSIONS = ['master', 'current', 'final', 'route']
PAIRS = [('master', 'current'), ('master', 'final'), ('master', 'route'),
         ('current', 'final'), ('current', 'route'), ('route', 'final')]
FONT_HASHES = {
    'roboto': '512f759e24d81543f5629b8edc99c566140a8d161fc2277ac82e64add2f26cf9',
    'vollkorn': 'b704817fe4433aa674c54f87141f2541d88d7d48342d98ec727a5eed4873a892',
    'ptsans': '9cc831490532009bae2b3ce0d39c62adfc889060beb421593bfd9d2396d0f10a',
}
FALLBACK = 'c333e1de6d6241530a473f480cd1f59a2578cd509825828b89a751c09fb9b61c'
PRIMARY = ('first_frame.render.thread_cpu_ms', 'search_frame.render.thread_cpu_ms')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def median(values):
    values = sorted(values)
    n = len(values)
    assert n
    return values[n // 2] if n % 2 else (values[n // 2 - 1] + values[n // 2]) / 2


def close(actual, expected):
    if expected is None:
        assert actual is None, (actual, expected)
    else:
        assert math.isclose(float(actual), expected, rel_tol=1e-10, abs_tol=1e-6), (actual, expected)


def info_checked(info, fingerprints):
    path = Path(info['path'])
    if 'bytes' in info:
        assert path.stat().st_size == info['bytes'], path
    actual = sha(path)
    assert actual == info['sha256'], path
    fingerprints[str(path)] = actual


def orders():
    # Independent four-treatment Williams square, three full cycles at 12 rounds.
    return [tuple(VERSIONS[(i + rotation) % 4] for i in (0, 1, 3, 2))
            for rotation in range(4)]


def raw_metrics(sample):
    events = {}
    for event in sample['events']:
        assert event['event'] not in events, ('duplicate event', event['event'])
        events[event['event']] = event
    first = events['first_frame_rendered']['since_main_ms']
    search = events['interactive_frame_rendered']['since_main_ms']
    values = {
        'observed_search_response_ms': sample['launch_to_probe_observed_ms'],
        'first_frame_since_main_ms': first,
        'search_frame_since_main_ms': search,
        'search_after_first_frame_ms': search - first,
        'first_callback_wall_ms': first - events['first_render_started']['since_main_ms'],
        'spawn_to_main_ms': sample['spawn_to_main_ms'],
        'peak_rss_mib': sample['peak_rss_bytes'] / (2 ** 20),
    }
    spans = sample['slint_internal_spans']
    for phase, marker in [('first_frame', 'first_frame_rendered'),
                          ('search_frame', 'interactive_frame_rendered')]:
        markers = [s for s in spans if s['name'] == marker]
        assert len(markers) == 1, ('marker count', marker)
        at = markers[0]['start_ns']
        frames = [s for s in spans if s['name'] == 'femtovg.render' and
                  s['start_ns'] <= at <= s['start_ns'] + s['duration_ns']]
        assert len(frames) == 1, ('enclosing frame count', marker)
        frame = frames[0]
        lo, hi = frame['start_ns'], frame['start_ns'] + frame['duration_ns']
        for part in ('render', 'component_items', 'final_flush'):
            for measure, suffix in [('wall', ''), ('thread_cpu', '.thread_cpu_ns')]:
                name = 'femtovg.' + part + suffix
                matches = [s for s in spans if s['name'] == name and
                           lo <= s['start_ns'] and s['start_ns'] + s['duration_ns'] <= hi]
                assert len(matches) == 1, (phase, name, len(matches))
                span = matches[0]
                amount = span['amount'] if measure == 'thread_cpu' else span['duration_ns']
                values[f'{phase}.{part}.{measure}_ms'] = amount / 1_000_000
    assert len(values) == 19
    assert all(math.isfinite(v) and v >= 0 for v in values.values())
    return values, events


def validate_matrix(manifest, fingerprints, cpu):
    assert manifest['complete'] and manifest['versions'] == VERSIONS
    assert manifest['rounds'] == (12 if cpu else 1)
    assert set(manifest['fonts']) == set(FONT_HASHES)
    assert set(manifest['backends']) == {'winit-femtovg', 'winit-femtovg-wgpu'}
    assert manifest['mode'] == ('cpu' if cpu else 'pixels')
    assert manifest['app_commit'] == 'ac35d4e0b5c52edb7defb9feccdadfd584635c14'
    assert manifest['actual_font_diagnostics']['enabled'] == (not cpu)
    env = manifest['environment']
    assert env['SLINT_SCALE_FACTOR'] == '2' and env['SLINT_NO_SYSTEM_FONTS'] == '1'
    assert env['ALUSTIN_FEMTOVG_DIAGNOSTICS'] == env['SLINT_STARTUP_DIAGNOSTICS'] == ('1' if cpu else '0')
    if cpu:
        assert 'SLINT_FEMTOVG_FONT_DUMP' not in env
    for name in ('build_provenance', 'harness', 'runner', 'helpers'):
        info_checked(manifest[name], fingerprints)
    for info in [*manifest['binaries'].values(), *manifest['inputs'].values()]:
        info_checked(info, fingerprints)
    for font, record in manifest['fonts'].items():
        assert record['file']['sha256'] == FONT_HASHES[font]
        info_checked(record['file'], fingerprints)
    expected = {(backend, font, round_) for backend in manifest['backends']
                for font in manifest['fonts'] for round_ in range(1, manifest['rounds'] + 1)}
    seen = set()
    launches = manifest['launches']
    assert len({launch['label'] for launch in launches}) == len(launches)
    values, queries = {}, {}
    for launch in launches:
        assert launch['exit_code'] == 0 and launch['version'] in VERSIONS
        path = Path(launch['report'])
        fingerprints[str(path)] = sha(path)
        report = read(path)
        assert len(report['samples']) == 1
        sample = report['samples'][0]
        assert Path(sample['executable_path']).resolve() == Path(manifest['binaries'][launch['version']]['path']).resolve()
        assert sample['backend_requested'] == launch['backend']
        assert sample['system_fonts_disabled'] is True and sample['scale_requested'] == '2'
        assert sample['profile'] == 'release' and sample['slint'] == '1.18.1'
        if cpu:
            scalar, events = raw_metrics(sample)
        else:
            scalar = {}
            events = {event['event']: event for event in sample['events']}
            assert len(events) == len(sample['events'])
            assert not sample['slint_internal_spans']
        values[launch['label']] = scalar
        queries[launch['label']] = events['interactive_frame_rendered']['details']['query']
        configured = events['benchmark_font_configured']['details']
        font = manifest['fonts'][launch['font']]
        assert configured == {'family': font['family'], 'font_path': font['file']['path']}
        assert launch['font_configured_event'] == events['benchmark_font_configured']
        window = events['first_frame_rendered']['details']
        assert window == {'physical_width': 2560, 'physical_height': 1600, 'scale_factor': 2.0}
        api = events['renderer_setup']['details']['graphics_api']
        assert api == ('WGPU30' if launch['backend'].endswith('wgpu') else 'OpenGL')
        if cpu:
            assert 'actual_fonts' not in launch
    grouped, accepted_labels, retries = {}, set(), 0
    for block in manifest['accepted_blocks']:
        key = block['backend'], block['font'], block['round']
        assert key in expected and key not in seen
        seen.add(key)
        assert 1 <= block['attempt'] <= manifest['max_attempts']
        attempts = [launch for launch in launches if
                    (launch['backend'], launch['font'], launch['round']) == key]
        assert len(attempts) == len(VERSIONS) * block['attempt']
        for attempt in range(1, block['attempt'] + 1):
            rows = [launch for launch in attempts if launch['attempt'] == attempt]
            assert tuple(row['version'] for row in rows) == orders()[(block['round'] + attempt - 2) % 4]
            contaminated = [row for row in rows if queries[row['label']] != 'a']
            if attempt < block['attempt']:
                retries += 1
                assert contaminated
                assert all(not row['included'] and row['exclusion_reason'].startswith('Whole block excluded: ') for row in rows)
            else:
                assert not contaminated and set(block['labels']) == {row['label'] for row in rows}
                assert all(row['included'] and row['validated'] for row in rows)
                grouped[key] = {row['version']: {'values': values[row['label']],
                                'round': block['round'], 'attempt': attempt,
                                'label': row['label']} for row in rows}
                accepted_labels.update(block['labels'])
    assert seen == expected
    assert accepted_labels == {launch['label'] for launch in launches if launch['included']}
    assert len(accepted_labels) == len(expected) * len(VERSIONS)
    return grouped, {'raw_launches': len(launches), 'accepted_launches': len(accepted_labels),
                     'accepted_blocks': len(expected), 'retry_attempts_revalidated': retries}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--primary-audit', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    primary_path = args.primary_audit or root / 'independent-app-primary-cpu-audit.json'
    paths = {'cpu_manifest': root / 'cpu-12/summary.json', 'pixel_manifest': root / 'pixels/summary.json',
             'analysis': root / 'analysis/summary.json', 'analysis_csv': root / 'analysis/summary.csv',
             'experiment': root / 'experiment.json', 'primary_audit': primary_path}
    fingerprints = {str(path): sha(path) for path in paths.values()}
    manifest, pixels, analysis, primary = (read(paths[name]) for name in
                                          ('cpu_manifest', 'pixel_manifest', 'analysis', 'primary_audit'))
    assert read(paths['experiment'])['versions'] == VERSIONS
    assert analysis['statistics']['comparisons'] == [list(pair) for pair in PAIRS]
    assert analysis['statistics']['bootstrap_resamples'] == 10000
    assert not analysis['excluded_batches']
    assert primary['complete'] and primary['versions'] == VERSIONS
    assert primary['point_effects_recomputed'] == primary['cpu_ci_rows_recomputed'] == 72
    assert primary['input_sha256'][str(paths['analysis'])] == fingerprints[str(paths['analysis'])]
    primary_tools = root / 'independent-audit-tools'
    assert sha(primary_tools / 'independent_raw_app_audit.py') == primary['auditor_sha256']
    assert sha(primary_tools / 'independent_audit_math.py') == primary['math_helper_sha256']
    for name in ('independent_raw_app_audit.py', 'independent_audit_math.py', 'benchlib.py'):
        fingerprints[str(primary_tools / name)] = sha(primary_tools / name)
    for path, expected in primary['input_sha256'].items():
        assert sha(path) == expected, path
    grouped, counts = validate_matrix(manifest, fingerprints, cpu=True)
    pixel_groups, pixel_counts = validate_matrix(pixels, fingerprints, cpu=False)
    assert counts == {'raw_launches': 288, 'accepted_launches': 288, 'accepted_blocks': 72, 'retry_attempts_revalidated': 0}
    for field in ('app_commit', 'source_variants', 'binaries', 'harness', 'inputs', 'fonts', 'backends', 'build_provenance'):
        assert manifest[field] == pixels[field], field
    build = read(manifest['build_provenance']['path'])
    assert build['complete'] and build['app_lock_restored'] and build['final_app_inputs_match']
    assert build['app_commit'] == manifest['app_commit']
    assert build['harness'] == manifest['harness']
    assert set(build['variants']) == set(VERSIONS)
    info_checked(build['previous_build_provenance'], fingerprints)
    graph_path = root / 'build/dependency-graph.json'
    fingerprints[str(graph_path)] = sha(graph_path)
    frozen_sources = {}
    for version in VERSIONS:
        record = build['variants'][version]
        assert record['binary'] == manifest['binaries'][version]
        declared = manifest['source_variants'][version]
        assert record['source_sha256'] == declared['source_sha256']
        assert record['source_map_sha256'] == declared['source_map_sha256']
        source = Path(record['source_directory'])
        actual = {str(path.relative_to(source)): sha(path) for path in sorted(source.rglob('*')) if path.is_file()}
        assert actual == record['source_sha256'], version
        serialized = json.dumps(actual, sort_keys=True).encode()
        assert hashlib.sha256(serialized).hexdigest() == record['source_map_sha256']
        assert record['resolved_lock_sha256'] == build['resolved_lock_sha256']
        assert record['swash'] == '0.2.10' and record['skrifa'] == '0.40.0'
        assert set(record['femtovg_features']) == {'swash', 'wgpu'}
        if record['reused_binary']:
            old_build = Path(build['previous_build_provenance']['path']).parent
            metadata_path = old_build / (record['previous_label'] + '-metadata.json')
        else:
            metadata_path = root / 'build' / (version + '-metadata.json')
        fingerprints[str(metadata_path)] = sha(metadata_path)
        frozen_sources[version] = {'file_count': len(actual), 'source_map_sha256': record['source_map_sha256'],
                                   'binary_sha256': record['binary']['sha256']}
    assert sha(root / 'build/resolved.Cargo.lock') == build['resolved_lock_sha256']
    fingerprints[str(root / 'build/resolved.Cargo.lock')] = build['resolved_lock_sha256']
    actual_font_launches = 0
    actual_font_blobs = 0
    unverified_contaminated_font_launches = []
    for launch in pixels['launches']:
        if 'actual_fonts' not in launch:
            assert not launch['included'] and not launch['validated']
            assert launch['exclusion_reason'].startswith('Whole block excluded: ')
            unverified_contaminated_font_launches.append(launch['label'])
            continue
        recorded = launch['actual_fonts']
        dump = Path(launch['report']).parent / 'actual-fonts/actual-fonts.json'
        assert read(dump) == recorded and recorded['complete']
        fingerprints[str(dump)] = sha(dump)
        font = pixels['fonts'][launch['font']]
        assert recorded['configured_family'] == font['family'] and recorded['primary'] == font['file']
        assert {entry['sha256'] for entry in recorded['allowed_fallbacks']} == {FALLBACK}
        for allowed in recorded['allowed_fallbacks']:
            info_checked(allowed, fingerprints)
        found = set()
        for face in recorded['actual_fonts']:
            assert face['face_index'] == 0 and face['has_ascii'] is True
            metadata = Path(face['metadata_file'])
            blob = metadata.parent / face['blob_file']
            fingerprints[str(metadata)] = sha(metadata)
            fingerprints[str(blob)] = sha(blob)
            assert blob.stat().st_size == face['bytes'] and fingerprints[str(blob)] == face['sha256']
            assert face['sha256'] == (font['file']['sha256'] if face['role'] == 'primary' else FALLBACK)
            assert face['role'] in {'primary', 'fallback'}
            found.add(face['role'])
            actual_font_blobs += 1
        assert found == {'primary', 'fallback'}
        actual_font_launches += 1
    rows = [row for row in analysis['results'] if row['mode'] == 'cpu' and row['batch'] == 'cpu-12']
    assert len(rows) == len(analysis['results']) == 684
    index = {(row['backend'], row['font'], row['reference'], row['candidate'], row['metric']): row for row in rows}
    assert len(index) == len(rows)
    csv_rows = list(csv.DictReader(paths['analysis_csv'].open(newline='')))
    assert len(csv_rows) == len(rows)
    csv_index = {(row['backend'], row['font'], row['reference'], row['candidate'], row['metric']): row for row in csv_rows}
    assert set(csv_index) == set(index)
    checked, rss, metric_names = [], 0, set()
    for (backend, font) in sorted({key[:2] for key in grouped}):
        blocks = [grouped[backend, font, round_] for round_ in range(1, 13)]
        names = set(blocks[0]['master']['values'])
        assert all(set(block[version]['values']) == names for block in blocks for version in VERSIONS)
        metric_names.update(names)
        for reference, candidate in PAIRS:
            for name in sorted(names):
                a = [block[reference]['values'][name] for block in blocks]
                b = [block[candidate]['values'][name] for block in blocks]
                deltas = [new - old for old, new in zip(a, b)]
                ratios = [new / old for old, new in zip(a, b)] if all(old > 0 for old in a) else None
                expected = {'reference_median': median(a), 'candidate_median': median(b),
                            'reference_min': min(a), 'reference_max': max(a),
                            'candidate_min': min(b), 'candidate_max': max(b),
                            'median_paired_delta': median(deltas),
                            'median_paired_ratio': median(ratios) if ratios else None,
                            'median_paired_change_pct': 100 * (median(ratios) - 1) if ratios else None}
                key = backend, font, reference, candidate, name
                row = index[key]
                assert row['n_blocks'] == 12 and len(row['pairs']) == 12
                assert row['units'] == ('MiB' if name == 'peak_rss_mib' else 'ms')
                for field, value in expected.items():
                    close(row[field], value)
                    if field in csv_index[key]:
                        close(csv_index[key][field], value)
                for pair, block, old, new in zip(row['pairs'], blocks, a, b):
                    assert (pair['round'], pair['attempt']) == (block['master']['round'], block['master']['attempt'])
                    for field, value in [('reference', old), ('candidate', new), ('delta', new - old),
                                         ('candidate_over_reference_ratio', new / old if old > 0 else None)]:
                        close(pair[field], value)
                for field in ('median_paired_delta_ci95', 'median_paired_change_pct_ci95'):
                    assert json.loads(csv_index[key][field]) == row[field]
                if name == 'peak_rss_mib':
                    rss += 1
                checked.append({'backend': backend, 'font': font, 'reference': reference, 'candidate': candidate,
                                'metric': name, 'units': row['units'], 'n_blocks': 12, **expected})
        print(f'All-metric point audit passed for {backend}/{font}', flush=True)
    assert len(checked) == 684 and rss == 36 and len(metric_names) == 19
    assert len(primary['results']) == 72 and all(row['ci_independently_checked'] for row in primary['results'])
    report = {'complete': True, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'versions': VERSIONS, 'comparisons': PAIRS, **counts,
              'point_effects_recomputed': len(checked), 'raw_metric_count': len(metric_names),
              'peak_rss_point_effects_recomputed': rss, 'primary_cpu_ci_rows_recomputed': 72,
              'bootstrap_resamples': 10000, 'primary_cpu_audit': {'path': str(primary_path), 'sha256': sha(primary_path)},
              'primary_cpu_auditor_sha256': primary['auditor_sha256'],
              'primary_cpu_math_helper_sha256': primary['math_helper_sha256'],
              'frozen_sources_and_binaries': frozen_sources, 'untimed_pixel_matrix': pixel_counts,
              'actual_font_launches_checked': actual_font_launches, 'actual_font_blobs_checked': actual_font_blobs,
              'font_diagnostics_not_recorded_for_contaminated_launches': unverified_contaminated_font_launches,
              'point_results': checked, 'primary_cpu_ci_results': primary['results'], 'input_sha256': fingerprints,
              'auditor_sha256': sha(__file__), 'mismatches': [],
              'scope': 'Independent raw unique marker-enclosing renderer spans and raw process/event fields; all 19 point metrics, all six pairings, 10k shared whole-block primary CPU intervals. Exact frozen source/input/font/executable bytes checked. All accepted timings retained; query-only whole-block retries revalidated. Actual-font blobs checked only in separate untimed pixel launches, not timed glyph routing. RSS is process-lifetime OS high-water resident memory, not outline-only storage or GPU VRAM. No timing/build/application execution or runner/analyzer imports.',
              'limitations': ['Non-primary confidence intervals, including RSS CIs, checked for JSON/CSV consistency but not independently recomputed.',
                              'Current mutable application checkout not rehashed while independent portable builds may temporarily swap manifests/locks; recorded build tracked-input guards, restored-lock flags and exact frozen FemtoVG snapshots were checked.',
                              'Pixel PNG equality is covered by a separate pixel audit; this audit checks the raw pixel cohort launch/font matrix, not decoded image bytes.']}
    output = root / 'independent-app-statistics-audit.json'
    output.write_text(json.dumps(report, indent=2) + '\n')
    (root / 'independent-app-statistics-audit.md').write_text(
        '# Independent Alustin final-cohort audit\n\n'
        'Passed with no mismatches.\n\n'
        '- 288 timed raw launches, 288 accepted launches, 72 complete blocks, 12 rounds; zero timing retries.\n'
        '- All 684 paired point effects independently recomputed from 19 raw metrics across six font/backend configurations and six variant pairings, including route → final.\n'
        '- All 72 first/search renderer-thread CPU interval rows independently recomputed with 10,000 shared whole-block resamples.\n'
        '- All 36 process-lifetime peak-RSS point effects checked in MiB; RSS intervals only cross-checked between JSON and CSV.\n'
        f'- Four frozen source maps/executables, shared harness, selected fonts, fixture inputs, resolved lock and recorded build identities rehashed; {actual_font_launches} untimed font-diagnostic launches and {actual_font_blobs} actual face blobs verified.\n'
        '- Every accepted timing retained. Pixel-cohort query retries were checked separately; no duration/outlier exclusions.\n\n'
        'These are exploratory paired effects without multiplicity or model-selection adjustment. Renderer-thread CPU is host work; peak RSS is whole-process high-water resident memory. No renderer was launched by this audit.\n')
    print(f'Independent all-metric app audit passed: {output}')


if __name__ == '__main__':
    main()
