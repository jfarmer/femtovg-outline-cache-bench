"""Portable source and archive guards; Python standard library only."""
from __future__ import annotations
import hashlib, json, shutil, tarfile
from pathlib import Path, PurePosixPath

REPO = Path(__file__).resolve().parent.parent

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def records(root):
    root = Path(root)
    if any(p.is_symlink() for p in root.rglob('*')):
        raise ValueError(f'Symlinks are not allowed in frozen inputs: {root}')
    return {p.relative_to(root).as_posix(): {'sha256': sha(p), 'bytes': p.stat().st_size}
            for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}

def hashes(root):
    return {k: v['sha256'] for k,v in records(root).items()}

def write_json(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

def safe_relative(value):
    path = PurePosixPath(value)
    if not value or path.is_absolute() or any(p in ('', '.', '..') for p in value.split('/')):
        raise ValueError(f'Unsafe relative path: {value!r}')
    return path

def bundled_manifest(repo=REPO):
    repo = Path(repo)
    manifest = json.loads((repo/'vendor/manifest.json').read_text())
    if manifest.get('schema') != 1 or not manifest.get('complete'):
        raise ValueError('Incomplete bundled source manifest')
    observed = {}
    for name in ('vendor', 'assets'):
        observed.update({name+'/'+k: v for k,v in records(repo/name).items()
                         if name+'/'+k != 'vendor/manifest.json'})
    if observed != manifest['files']:
        changed = sorted(k for k in set(observed)|set(manifest['files']) if observed.get(k)!=manifest['files'].get(k))
        raise ValueError(f'Bundled inputs differ from pinned manifest: {changed[:12]}')
    return manifest

class ArchiveStore:
    """Verify untouched campaign archives and resolve historical absolute paths."""
    def __init__(self, repo=REPO, index=None):
        self.repo = Path(repo).resolve()
        self.index = Path(index or self.repo/'results/index.json')
        data = json.loads(self.index.read_text())
        if data.get('schema') != 1:
            raise ValueError('Unknown archive-index schema')
        self.campaigns = data['campaigns']
        self.materialized = {}

    def campaign(self, label):
        matches = [c for c in self.campaigns if c['label']==label]
        if len(matches)!=1: raise ValueError(f'Unknown/duplicate campaign: {label}')
        return matches[0]

    def original(self, path):
        raw = str(path)
        matches = [c for c in self.campaigns if raw==c['original_root'] or raw.startswith(c['original_root'].rstrip('/')+'/')]
        if not matches: raise ValueError(f'Historical path is not archived: {raw}')
        entry = max(matches, key=lambda c: len(c['original_root']))
        relative = raw[len(entry['original_root']):].lstrip('/')
        if relative: safe_relative(relative)
        return entry, relative

    def inspect(self, label, destination=None, metadata_only=False):
        """One streaming pass verifies every retained byte; optional safe extraction."""
        campaign = self.campaign(label)
        safe_relative(campaign['path'])
        directory = self.repo/campaign['path']
        manifest = json.loads((directory/'archive.json').read_text())
        if not manifest.get('complete') or manifest['schema']!=1 or manifest['label']!=label or manifest['original_root']!=campaign['original_root']:
            raise ValueError(f'Invalid archive manifest: {label}')
        for key in ('sha256','bytes'):
            if campaign['archive'][key] != manifest['archive'][key]: raise ValueError(f'Index/archive disagreement: {label}/{key}')
        safe_relative(manifest['archive']['path'])
        archive = directory/manifest['archive']['path']
        if archive.stat().st_size!=manifest['archive']['bytes'] or sha(archive)!=manifest['archive']['sha256']:
            raise ValueError(f'Compressed archive checksum mismatch: {label}')
        destination = Path(destination).resolve() if destination is not None else None
        if destination is not None:
            if destination.exists(): raise ValueError(f'Archive destination exists: {destination}')
            destination.mkdir(parents=True)
        observed={}
        with tarfile.open(archive, 'r|gz') as stream:
            for member in stream:
                prefix = label+'/'
                if not member.name.startswith(prefix) or not member.isfile(): raise ValueError(f'Unexpected tar member: {member.name}')
                relative=member.name[len(prefix):];safe_relative(relative)
                if relative in observed or relative not in manifest['files']: raise ValueError(f'Unexpected/duplicate tar member: {member.name}')
                expected=manifest['files'][relative]
                if member.size!=expected['bytes']: raise ValueError(f'Tar member size differs: {member.name}')
                # Statistical inputs and original helpers can be materialized without pixel/font/source blobs.
                keep=destination is not None and (not metadata_only or Path(relative).suffix in {'.json','.csv','.py','.stdout','.stderr','.log','.txt','.md','.lock','.diff'})
                output=None
                if keep:
                    path=destination/relative;path.parent.mkdir(parents=True,exist_ok=True);output=path.open('xb')
                digest=hashlib.sha256();size=0
                try:
                    with stream.extractfile(member) as source:
                        while chunk:=source.read(1024*1024):
                            digest.update(chunk);size+=len(chunk)
                            if output is not None: output.write(chunk)
                finally:
                    if output is not None: output.close()
                observed[relative]={'sha256':digest.hexdigest(),'bytes':size}
                if observed[relative]!=expected: raise ValueError(f'Tar member checksum differs: {member.name}')
        if observed!=manifest['files']: raise ValueError(f'Missing tar members: {label}')
        if destination is not None:self.materialized[label]=destination
        return {'label':label,'files_verified':len(observed),'raw_bytes':sum(v['bytes'] for v in observed.values()),'omitted_files':len(manifest['omitted'])}

    def mapped(self, original):
        campaign,relative=self.original(original)
        destination=self.materialized.get(campaign['label'])
        if destination is None: raise ValueError(f'Campaign has not been materialized: {campaign["label"]}')
        path=destination/relative
        if not path.exists(): raise ValueError(f'Path omitted/not materialized: {original}')
        return path

    def path_map(self):
        return {c['original_root']:str(self.materialized[c['label']]) for c in self.campaigns if c['label'] in self.materialized}

def read_path_map(path):
    mapping=json.loads(Path(path).read_text()) if path else {}
    def resolve(value):
        raw=str(value)
        matches=[original for original in mapping if raw==original or raw.startswith(original.rstrip('/')+'/')]
        if not matches:return Path(value)
        root=max(matches,key=len)
        relative=raw[len(root):].lstrip('/')
        if relative:safe_relative(relative)
        return Path(mapping[root])/relative
    return resolve
