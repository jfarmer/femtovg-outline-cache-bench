use std::{hint::black_box, time::Instant};
use femtovg::{renderer::Void, Canvas, Color, FontId, Paint};

const LABELS: &[&str] = &[
    "File Edit View Navigate Help", "Search projects and documents", "Open recent project",
    "Settings and preferences", "Changes saved automatically", "Outline cache review",
    "Rendering complete: 128 glyphs", "Zoom: 100% | Line 42, Column 17", "Filter by name",
    "Create a new document", "Refresh selected items", "Type to search...",
    "Font size: 16px", "Apply changes", "Cancel", "Save", "Loading resources...",
    "The quick brown fox jumps over the lazy dog.", "0123456789 +-*/=", "Memory usage: 32.8 MB",
    "This paragraph represents content in a scrolling document.",
    "Repeated letters arrive at different positions after shaping.",
    "The bitmap atlas remembers each rasterized subpixel variant.",
    "New content may need variants that were absent on first paint.",
];

fn draw(canvas: &mut Canvas<Void>, font: FontId, frame: usize, mode: &str) {
    for row in 0..72 {
        let text = LABELS[row % LABELS.len()];
        let size = [12.0, 16.0, 24.0][row % 3];
        let mut x = [20.0, 400.25, 780.5][row / 24];
        if mode == "reposition" { x += frame as f32 * 0.037; }
        let y = 30.0 + (row % 24) as f32 * 28.0;
        let paint = Paint::color(Color::black()).with_font(&[font]).with_font_size(size);
        black_box(canvas.fill_text(x, y, text, &paint).unwrap());
    }
    canvas.flush_to_output(());
}

fn main() {
    let font_path = std::env::args().nth(1).unwrap();
    let data = std::fs::read(&font_path).unwrap();
    for mode in ["first_paint", "warm_static", "reposition"] {
        let frames = if mode == "first_paint" { 1 } else { 30 };
        let mut samples = Vec::new();
        let mut counts = 0;
        for round in 0..81 {
            let mut canvas = Canvas::new(Void).unwrap();
            canvas.set_size(1200, 800, 1.0);
            let font = canvas.add_font_mem(&data).unwrap();
            if mode == "warm_static" { draw(&mut canvas, font, 0, mode); }
            let before = canvas.benchmark_atlas_entries();
            let begin = Instant::now();
            for frame in 0..frames { draw(&mut canvas, font, frame, mode); }
            let elapsed = begin.elapsed().as_secs_f64() * 1000.0;
            counts = canvas.benchmark_atlas_entries() - before;
            if round > 0 { samples.push(elapsed); }
            black_box(canvas);
        }
        samples.sort_by(f64::total_cmp);
        println!("{font_path},{mode},{frames},{counts},{:.4},{:.4}", samples[samples.len()/2], samples[samples.len()*95/100]);
    }
}
