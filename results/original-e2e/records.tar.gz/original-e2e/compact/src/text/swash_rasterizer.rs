use std::{borrow::Cow,cell::RefCell,mem::{size_of,size_of_val},rc::Rc};
use fnv::FnvHashMap;
use swash::{scale::{image::{Content,Image},outline::Outline,Render,ScaleContext,Source,StrikeWith},zeno::{Format,Mask,Origin,Scratch,Vector,Point,Verb,PathData},CacheKey,FontRef};
const COLOR_SOURCES: [Source;2] = [Source::ColorOutline(0),Source::ColorBitmap(StrikeWith::BestFit)];
#[derive(Debug,Hash,PartialEq,Eq)]
struct OutlineKey<'a> {font:CacheKey,glyph_id:u16,font_size:u32,normalized_coords:Cow<'a,[i16]>}
impl OutlineKey<'_> {fn owned(self)->OutlineKey<'static> {OutlineKey{font:self.font,glyph_id:self.glyph_id,font_size:self.font_size,normalized_coords:Cow::Owned(self.normalized_coords.into_owned())}}}
struct CachedPath {points:Box<[Point]>,verbs:Box<[Verb]>}
pub(crate) struct SwashRasterizer {
    scale_context:Rc<RefCell<ScaleContext>>,
    scratch:Scratch,
    temp_outline:Outline,
    outlines:FnvHashMap<OutlineKey<'static>,CachedPath>,
    outline_bytes:usize,
    outline_budget:usize,
}
impl SwashRasterizer {
    pub(crate) fn new(scale_context:Rc<RefCell<ScaleContext>>)->Self {Self::with_outline_budget(scale_context,1<<20)}
    pub(crate) fn with_outline_budget(scale_context:Rc<RefCell<ScaleContext>>,outline_budget:usize)->Self {
        Self{scale_context,scratch:Scratch::new(),temp_outline:Outline::new(),outlines:FnvHashMap::default(),outline_bytes:0,outline_budget}
    }
    pub(crate) fn probe(&self,font:FontRef<'_>,font_size:f32,glyph_id:u16,coords:&[i16])->bool {
        self.outlines.contains_key(&OutlineKey{font:font.key,glyph_id,font_size:font_size.to_bits(),normalized_coords:Cow::Borrowed(coords)})
    }
    pub(crate) fn stats(&self)->(usize,usize,usize) {(self.outlines.len(),self.outline_bytes,self.outlines.capacity())}
    pub(crate) fn render(&mut self,font:FontRef<'_>,font_size:f32,glyph_id:u16,subpixel_x:f32,normalized_coords:&[i16])->Option<Image> {
        let key=OutlineKey{font:font.key,glyph_id,font_size:font_size.to_bits(),normalized_coords:Cow::Borrowed(normalized_coords)};
        if let Some(path)=self.outlines.get(&key) {return Some(rasterize((&*path.points,&*path.verbs),&mut self.scratch,subpixel_x));}
        let mut scale_context=self.scale_context.borrow_mut();
        let mut scaler=scale_context.builder(font).size(font_size).hint(true).normalized_coords(normalized_coords).build();
        if let Some(image)=Render::new(&COLOR_SOURCES).format(Format::Alpha).offset(Vector::new(subpixel_x,0.0)).render(&mut scaler,glyph_id) {return Some(image);}
        if !scaler.has_outlines() || !scaler.scale_outline_into(glyph_id,&mut self.temp_outline) {return None;}
        drop(scale_context);
        let image=rasterize(self.temp_outline.path(),&mut self.scratch,subpixel_x);
        let bytes=size_of::<OutlineKey<'static>>()+size_of::<CachedPath>()+size_of_val(normalized_coords)+size_of_val(self.temp_outline.points())+size_of_val(self.temp_outline.verbs());
        if bytes<=self.outline_budget {
            if self.outline_bytes+bytes>self.outline_budget {self.outlines.clear();self.outline_bytes=0;}
            let path=CachedPath{points:self.temp_outline.points().into(),verbs:self.temp_outline.verbs().into()};
            self.outline_bytes+=bytes;self.outlines.insert(key.owned(),path);
        }
        Some(image)
    }
}
fn rasterize(path:impl PathData,scratch:&mut Scratch,subpixel_x:f32)->Image {
    let offset=Vector::new(subpixel_x,0.0);let mut image=Image::new();
    image.placement=Mask::with_scratch(path,scratch).format(Format::Alpha).origin(Origin::BottomLeft).offset(offset).render_offset(offset).inspect(|format,width,height|image.data.resize(format.buffer_size(width,height),0)).render_into(&mut image.data[..],None);
    image.content=Content::Mask;image.source=Source::Outline;image
}
