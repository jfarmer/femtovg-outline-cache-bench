from pathlib import Path
import csv
import statistics
import subprocess

root = Path(__file__).resolve().parent
fonts = [
    ("Arial", "/System/Library/Fonts/Supplemental/Arial.ttf"),
    ("Georgia", "/System/Library/Fonts/Supplemental/Georgia.ttf"),
    ("RobotoFlex", "/Users/jesse/github/femtovg/examples/assets/RobotoFlex-VariableFont.ttf"),
    ("Amiri", "/Users/jesse/github/femtovg/examples/assets/amiri-regular.ttf"),
]
rows = []
for name, font in fonts:
    for repeat in range(3):
        variants = ["baseline", "candidate", "compact"]
        if repeat % 2:
            variants.reverse()
        for variant in variants:
            output = subprocess.check_output([str(root / f"{variant}-runner"), font], text=True)
            for row in csv.reader(output.splitlines()):
                rows.append([name, variant, repeat, *row[1:]])
    print(name, "complete", flush=True)
with (root / "results.csv").open("w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["font", "variant", "repeat", "scenario", "frames", "atlas_misses", "median_ms", "p95_ms"])
    writer.writerows(rows)
for name, _ in fonts:
    for scenario in ["first_paint", "warm_static", "reposition"]:
        samples = {}
        for variant in ["baseline", "candidate", "compact"]:
            matches = [r for r in rows if r[0] == name and r[1] == variant and r[3] == scenario]
            samples[variant] = statistics.median(float(r[6]) for r in matches)
        example = next(r for r in rows if r[0] == name and r[3] == scenario)
        print(name, scenario, "frames", example[4], "misses", example[5],
              "ms", samples, "current_speedup", round(samples["baseline"] / samples["candidate"], 3),
              "compact_speedup", round(samples["baseline"] / samples["compact"], 3))
