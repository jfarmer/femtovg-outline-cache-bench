from pathlib import Path
import csv
import statistics
import subprocess

root = Path(__file__).resolve().parent
fonts = [
    ("Arial", "/System/Library/Fonts/Supplemental/Arial.ttf"),
    ("Georgia", "/System/Library/Fonts/Supplemental/Georgia.ttf"),
    ("RobotoFlex", "/Users/jesse/github/femtovg/examples/assets/RobotoFlex-VariableFont.ttf"),
    ("Amiri", "/Users/jesse/github/femtovg/examples/assets/amiri-regular.ttf"),
]
variants = ["baseline", "candidate", "native", "compact"]
rows = []
for name, font in fonts:
    for repeat in range(4):
        order = variants[repeat:] + variants[:repeat]
        for variant in order:
            output = subprocess.check_output([str(root / f"{variant}-runner"), font], text=True)
            for row in csv.reader(output.splitlines()):
                rows.append([name, variant, repeat, *row[1:]])
    print(name, "complete", flush=True)
with (root / "native-results.csv").open("w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["font", "variant", "repeat", "scenario", "frames", "atlas_misses", "median_ms", "p95_ms"])
    writer.writerows(rows)
for name, _ in fonts:
    for scenario in ["first_paint", "warm_static", "reposition"]:
        samples = {}
        for variant in variants:
            matches = [r for r in rows if r[0] == name and r[1] == variant and r[3] == scenario]
            samples[variant] = statistics.median(float(r[6]) for r in matches)
        example = next(r for r in rows if r[0] == name and r[3] == scenario)
        print(name, scenario, "frames", example[4], "misses", example[5],
              "ms", samples, "native_speedup_vs_master", round(samples["baseline"] / samples["native"], 3),
              "native_vs_current_percent", round(100 * (samples["native"] / samples["candidate"] - 1), 2),
              "native_vs_packed_percent", round(100 * (samples["native"] / samples["compact"] - 1), 2))
