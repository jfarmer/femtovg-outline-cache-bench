# Native outline pool versus arena: Alustin

Negative CPU percentages indicate less renderer-thread CPU work. Each cell is the median paired percentage with its 95% whole-block bootstrap interval. RSS uses paired MiB differences. Twelve accepted rounds per configuration; four variants were interleaved in a Williams square.

| Backend/font | Metric | Arena/master | Pool/master | Pool/arena |
|---|---|---:|---:|---:|
| WGPU/roboto | First CPU | -3.59% [-5.03, -0.33] | -3.17% [-4.28, -1.67] | +1.02% [-2.93, +2.65] |
| WGPU/roboto | Search CPU | -0.20% [-2.32, +1.90] | -0.53% [-4.31, +3.54] | -1.93% [-3.87, +2.29] |
| WGPU/roboto | Peak RSS | -0.10 MiB [-1.11, +0.31] | -0.46 MiB [-1.28, -0.05] | -0.59 MiB [-1.30, +0.10] |
| WGPU/ptsans | First CPU | -2.56% [-11.63, -0.49] | -4.01% [-9.57, -1.18] | -0.23% [-1.96, +2.90] |
| WGPU/ptsans | Search CPU | -4.31% [-10.06, -0.06] | -2.52% [-5.79, +0.75] | +2.11% [-1.25, +6.03] |
| WGPU/ptsans | Peak RSS | +0.19 MiB [-0.10, +1.41] | +1.06 MiB [+0.38, +2.02] | +0.52 MiB [+0.20, +1.23] |
| WGPU/vollkorn | First CPU | -23.84% [-24.39, -22.60] | -22.28% [-24.51, -20.73] | +2.32% [-0.24, +4.30] |
| WGPU/vollkorn | Search CPU | -7.35% [-10.54, -2.58] | -2.22% [-10.72, +1.57] | +2.69% [-1.55, +9.40] |
| WGPU/vollkorn | Peak RSS | -0.20 MiB [-0.91, +0.84] | +0.08 MiB [-0.45, +1.02] | +0.19 MiB [-0.30, +0.89] |
| OpenGL/roboto | First CPU | -1.97% [-4.09, +0.07] | -2.52% [-4.61, -0.93] | +0.05% [-4.86, +2.66] |
| OpenGL/roboto | Search CPU | -0.83% [-4.36, +7.51] | +2.57% [-3.31, +4.93] | -2.49% [-5.14, -0.44] |
| OpenGL/roboto | Peak RSS | +0.52 MiB [-0.65, +2.00] | -0.25 MiB [-1.81, +0.77] | -1.57 MiB [-2.23, +0.39] |
| OpenGL/ptsans | First CPU | -3.66% [-5.92, -2.01] | -4.57% [-6.61, -2.63] | -1.19% [-3.74, +3.73] |
| OpenGL/ptsans | Search CPU | -2.24% [-6.35, +1.04] | -0.51% [-5.40, +1.47] | +1.06% [-1.64, +3.54] |
| OpenGL/ptsans | Peak RSS | -0.57 MiB [-2.31, +1.35] | -0.50 MiB [-1.59, +1.38] | +0.16 MiB [-1.48, +1.27] |
| OpenGL/vollkorn | First CPU | -19.89% [-21.91, -17.17] | -20.65% [-21.51, -18.97] | -1.15% [-2.36, +0.36] |
| OpenGL/vollkorn | Search CPU | -6.79% [-9.99, -2.27] | -5.10% [-8.48, +1.43] | +1.39% [-5.49, +5.92] |
| OpenGL/vollkorn | Peak RSS | +0.09 MiB [-0.55, +1.42] | +0.22 MiB [-0.62, +1.17] | +0.09 MiB [-0.04, +0.30] |

All 300 raw timed launches preserved; 288 accepted launches across 72 complete blocks, with three query-only whole-block retries. All 684 point effects and 72 primary CPU interval rows passed independent audits. Peak-RSS intervals were checked for JSON/CSV consistency, not independently recomputed. No timing-duration exclusions.
