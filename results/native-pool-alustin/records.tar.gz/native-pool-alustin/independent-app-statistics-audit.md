# Independent Alustin final-cohort audit

Passed with no mismatches.

- 300 timed raw launches, 288 accepted launches, 72 complete blocks, 12 rounds; 3 query-only timing retries.
- All 684 paired point effects independently recomputed from 19 raw metrics across six font/backend configurations and six variant pairings, including arena final → native pool.
- All 72 first/search renderer-thread CPU interval rows independently recomputed with 10,000 shared whole-block resamples.
- All 36 process-lifetime peak-RSS point effects checked in MiB; RSS intervals only cross-checked between JSON and CSV.
- Four frozen source maps/executables, shared harness, selected fonts, fixture inputs, resolved lock and recorded build identities rehashed; 24 untimed font-diagnostic launches and 48 actual face blobs verified.
- Every accepted timing retained. Pixel-cohort query retries were checked separately; no duration/outlier exclusions.

These are exploratory paired effects without multiplicity or model-selection adjustment. Renderer-thread CPU is host work; peak RSS is whole-process high-water resident memory. No renderer was launched by this audit.
