#!/usr/bin/env python3
"""Freeze the selected final source snapshot and record its complete source hashes.

Source-only preparation: does not compile, run benchmarks, or touch Alustin.
"""
import argparse,datetime,hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
APP_ROOT=Path('/private/tmp/alustin-miss-final-review')
ALLOWED={'src/lib.rs','src/text.rs','src/text/font.rs','src/text/swash_rasterizer.rs'}
def files(base):
    return {str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(base.rglob('*')) if p.is_file()}
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--description',default='Selected final miss-cost optimization')
    args=parser.parse_args();source=args.source.resolve(strict=True);destination=ROOT/'snapshots/final'
    if destination.exists():parser.error('final snapshot already exists; preserving frozen selection')
    if (source/'Cargo.lock').exists():parser.error('selected pure snapshot contains a generated Cargo.lock')
    original=files(source);baseline=files(ROOT/'snapshots/current')
    changed={p for p in set(original)|set(baseline) if original.get(p)!=baseline.get(p)}
    if not changed or not changed<=ALLOWED:parser.error(f'unexpected candidate changes: {sorted(changed)}')
    for relative in changed:
        if 'alustin_startup' in (source/relative).read_text():parser.error('benchmark instrumentation in final source')
    shutil.copytree(source,destination)
    if files(destination)!=original:raise RuntimeError('source changed while copying final snapshot')
    provenance_path=ROOT/'snapshot-provenance.json';provenance=json.loads(provenance_path.read_text())
    experiment_path=ROOT/'experiment.json';experiment=json.loads(experiment_path.read_text())
    provenance['final']={'source_files':original,'base_ref':experiment['baseline_current'],'change':args.description,
        'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'copied_from':str(source),
        'changed_files':sorted(changed)}
    provenance_path.write_text(json.dumps(provenance,indent=2)+'\n')
    experiment['final_selection']={'source':str(source),'description':args.description,'changed_files':sorted(changed)}
    experiment_path.write_text(json.dumps(experiment,indent=2)+'\n')
    app_experiment=APP_ROOT/'experiment.json'
    if app_experiment.exists():
        app_data=json.loads(app_experiment.read_text())
        if app_data['versions']!=experiment['versions']:raise RuntimeError('app/replay version lists differ')
        app_data['final_selection']=experiment['final_selection']
        app_experiment.write_text(json.dumps(app_data,indent=2)+'\n')
    print(f'Final snapshot frozen: {destination}; changed files: {sorted(changed)}')
if __name__=='__main__':main()
