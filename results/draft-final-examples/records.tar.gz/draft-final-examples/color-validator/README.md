# Mixed-source GPU color and padding validation

Untimed source/helper; the original 28-phase replay and all pure benchmark snapshots remain untouched. Uses native WGPURenderer and existing public Canvas glyph, atlas-inspector, and image_info APIs. Native Swash source/render checks verify a checksummed nine-glyph font assembled from the repository's Bungee COLR subset: glyph 8 ordinary outline/mask, glyph 2 COLR/Color, glyph 7 sbix PNG/Color while retaining its glyf outline. All SFNT table checksums and head.checkSumAdjustment are recomputed and validated; the embedded PNG is decoded by native Swash and checked against its exact 24×24 solid RGBA payload.

The frozen v2 cohort is master/current/final/route from `/private/tmp/femtovg-miss-selection-v2-review/snapshots`. All four produced 48 images (eight scenes × cold/second/warm × configured DPR1/DPR2); all 144 candidate/master RGBA comparisons are byte-identical. Each executable also passed six observable painter-order checks: PNG-first/COLR-second input equals explicit legacy COLR-then-PNG drawing and differs from the opposite order. Read-only checks of the 24 overlap_legacy images verify exactly 576 non-background pixels equal the native PNG's [255,0,64,255]. Public image_info checks verify mask/color/path atlas formats.

Scenes cover masks, simultaneous mask/COLR/PNG, negative/fractional coordinates and partial clipping, overlapping color formats and both explicit drawing orders, stroked paths after masks, and nonuniform direct outlines after a mask plus an atlas PNG. Second use shifts the subpixel phase from 0.3 to 0.4; warm repeats 0.4. DPR changes canvas/renderer configuration and path tolerances; explicit glyph-run font size and positions remain fixed.

Production GlyphAtlas::new in master panics when a direct/nonuniform bitmap glyph initializes the ephemeral atlas while draw_glyph_run holds text_context mutably borrowed. That unsupported baseline case is preserved in `results-baseline-v3/master/{stdout,stderr}.txt` and excluded from the successful cohort; the direct case instead draws the PNG through the supported atlas path before the direct outline. No baseline fix was introduced. The public WGPU get_native_texture API returns UnsupportedImageFormat, so actual atlas format checks use public image_info and native WGPU allocation/upload code rather than exporting private library types or implementing a second renderer.

The helper enables FemtoVG's debug_inspector feature uniformly to inspect atlas image IDs. Release debug_assertions remain disabled, so inspector atlas initialization does not alter pixels. Existing runner dependencies and Cargo.lock are reused; no package version, Swash source, or library source changes.

Build/run accept dynamic versions and sources:

```
python3 build.py --versions master current final route --sources-root /private/tmp/femtovg-miss-selection-v2-review/snapshots --build-dir <new-build-directory>
python3 run.py --build-dir <new-build-directory> --output <new-result-directory>
```

Build refuses existing output and freezes source, helper, font, runner, lock, and executable hashes. Run checks frozen sources/binaries before and after actual Metal execution, preserves raw stdout/stderr/RGBA/PNG/font artifacts, and rejects pixel differences. GPU execution requires Metal access outside the sandbox. Failed earlier API probes and source/build attempts remain separately archived.

Successful proof: `build-selection-v2/provenance.json`, `results-selection-v2/summary.json`, `results-selection-v2/png-source-pixel-checks.json`. This is correctness evidence only, with no performance measurements.
