//! Test-only SFNT assembly; production lookup/rendering uses existing font APIs.
pub const MASK: u16 = 8;
pub const COLR: u16 = 2;
pub const PNG: u16 = 7;
pub const PNG_SIZE: u32 = 24;

fn checksum(bytes: &[u8]) -> u32 {
    bytes.chunks(4).fold(0u32, |sum, word| {
        let mut padded = [0u8; 4];
        padded[..word.len()].copy_from_slice(word);
        sum.wrapping_add(u32::from_be_bytes(padded))
    })
}

/// Add an sbix PNG to the existing COLR subset while keeping all glyf outlines.
/// Recompute directory checksums and head.checkSumAdjustment, unlike the
/// minimal parser-only fixture this helper was adapted from.
pub fn mixed_font(original: &[u8]) -> Vec<u8> {
    let face = swash::FontRef::from_index(original, 0).expect("source fixture font");
    let glyph_count = face.metrics(&[]).glyph_count;
    assert!(glyph_count > MASK && glyph_count > PNG && glyph_count > COLR);
    let bitmap = image::RgbaImage::from_pixel(PNG_SIZE, PNG_SIZE, image::Rgba([255, 0, 64, 255]));
    let mut png = std::io::Cursor::new(Vec::new());
    bitmap.write_to(&mut png, image::ImageFormat::Png).expect("encode fixture PNG");
    let png = png.into_inner();
    assert_eq!(&png[..8], b"\x89PNG\r\n\x1a\n");
    let mut payload = Vec::new();
    payload.extend_from_slice(&0i16.to_be_bytes());
    payload.extend_from_slice(&0i16.to_be_bytes());
    payload.extend_from_slice(b"png ");
    payload.extend_from_slice(&png);

    let mut sbix = Vec::new();
    sbix.extend_from_slice(&1u16.to_be_bytes());
    sbix.extend_from_slice(&1u16.to_be_bytes());
    sbix.extend_from_slice(&1u32.to_be_bytes());
    sbix.extend_from_slice(&12u32.to_be_bytes());
    sbix.extend_from_slice(&(PNG_SIZE as u16).to_be_bytes());
    sbix.extend_from_slice(&72u16.to_be_bytes());
    let payload_start = 4 + 4 * (u32::from(glyph_count) + 1);
    for glyph in 0..=glyph_count {
        let offset = payload_start + if glyph > PNG { payload.len() as u32 } else { 0 };
        sbix.extend_from_slice(&offset.to_be_bytes());
    }
    sbix.extend_from_slice(&payload);

    let u16_at = |offset| u16::from_be_bytes(original[offset..offset + 2].try_into().unwrap());
    let u32_at = |offset| u32::from_be_bytes(original[offset..offset + 4].try_into().unwrap()) as usize;
    let mut tables = Vec::new();
    for index in 0..usize::from(u16_at(4)) {
        let record = 12 + index * 16;
        let tag: [u8; 4] = original[record..record + 4].try_into().unwrap();
        assert_ne!(&tag, b"sbix");
        let start = u32_at(record + 8);
        let length = u32_at(record + 12);
        let mut table = original[start..start + length].to_vec();
        if &tag == b"head" {
            assert!(table.len() >= 12);
            table[8..12].fill(0);
        }
        tables.push((tag, table));
    }
    tables.push((*b"sbix", sbix));
    tables.sort_by_key(|(tag, _)| *tag);
    let table_count = tables.len() as u16;
    let entry_selector = table_count.ilog2() as u16;
    let search_range = (1u16 << entry_selector) * 16;
    let mut font = original[..4].to_vec();
    font.extend_from_slice(&table_count.to_be_bytes());
    font.extend_from_slice(&search_range.to_be_bytes());
    font.extend_from_slice(&entry_selector.to_be_bytes());
    font.extend_from_slice(&(table_count * 16 - search_range).to_be_bytes());
    let body_start = 12 + tables.len() * 16;
    let mut body = Vec::new();
    let mut head_offset = None;
    for (tag, table) in tables {
        let offset = body_start + body.len();
        if &tag == b"head" { head_offset = Some(offset); }
        font.extend_from_slice(&tag);
        font.extend_from_slice(&checksum(&table).to_be_bytes());
        font.extend_from_slice(&(offset as u32).to_be_bytes());
        font.extend_from_slice(&(table.len() as u32).to_be_bytes());
        body.extend_from_slice(&table);
        while !body.len().is_multiple_of(4) { body.push(0); }
    }
    font.extend_from_slice(&body);
    let adjustment = 0xb1b0afbau32.wrapping_sub(checksum(&font));
    let head_offset = head_offset.expect("head table");
    font[head_offset + 8..head_offset + 12].copy_from_slice(&adjustment.to_be_bytes());
    validate_checksums(&font);
    font
}

pub fn validate_checksums(font: &[u8]) {
    assert_eq!(checksum(font), 0xb1b0afba, "whole-font checkSumAdjustment");
    let count = u16::from_be_bytes(font[4..6].try_into().unwrap()) as usize;
    let mut prior_tag = None;
    for index in 0..count {
        let record = 12 + index * 16;
        let tag: [u8; 4] = font[record..record + 4].try_into().unwrap();
        if let Some(prior) = prior_tag { assert!(prior < tag); }
        prior_tag = Some(tag);
        let expected = u32::from_be_bytes(font[record + 4..record + 8].try_into().unwrap());
        let start = u32::from_be_bytes(font[record + 8..record + 12].try_into().unwrap()) as usize;
        let len = u32::from_be_bytes(font[record + 12..record + 16].try_into().unwrap()) as usize;
        assert!(start.is_multiple_of(4));
        let mut table = font[start..start + len].to_vec();
        if &tag == b"head" { table[8..12].fill(0); }
        assert_eq!(checksum(&table), expected, "table checksum: {:?}", tag);
    }
}
