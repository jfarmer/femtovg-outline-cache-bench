#!/usr/bin/env python3
"""Build only after root confirms timed jobs have ended; no implicit run."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,time

ROOT=Path(__file__).resolve().parent
CORE=Path('/private/tmp/femtovg-miss-review/runner')
VERSIONS=('master','current','final','route')

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def source_map(path):
    return {str(p.relative_to(path)):digest(p) for p in sorted(path.rglob('*'))
            if p.is_file() and '.git' not in p.parts and 'target' not in p.parts}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sources-root',type=Path,default=ROOT.parent/'snapshots')
    parser.add_argument('--versions',nargs='+',default=list(VERSIONS))
    parser.add_argument('--build-dir',type=Path,default=ROOT/'build')
    parser.add_argument('--target-dir',type=Path,default=Path('/private/tmp/femtovg-cache-bench/target'))
    args=parser.parse_args()
    work=args.build_dir
    if work.exists(): raise RuntimeError(f'Refusing to overwrite prior build: {work}')
    work.mkdir()
    provenance={'started':time.time(),'versions':{},'helper_sources':source_map(ROOT/'src'),
        'fixture':digest(ROOT/'assets/BungeeColor-Subset.ttf'),'core_lock':digest(CORE/'Cargo.lock'),
        'target_dir':str(args.target_dir),'status':'building','performance_measurement':False,'version_order':args.versions}
    (work/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    for version in args.versions:
        source=(args.sources_root/version).resolve()
        if not (source/'Cargo.toml').exists(): raise RuntimeError(f'Missing frozen source: {source}')
        frozen=source_map(source)
        runner=work/'runners'/version
        runner.mkdir(parents=True)
        shutil.copytree(ROOT/'src',runner/'src')
        shutil.copytree(ROOT/'assets',runner/'assets')
        manifest=(CORE/'Cargo.toml').read_text()
        import re
        manifest,count=re.subn(r'femtovg = \{ path = "[^"]+"',f'femtovg = {{ path = "{source}"',manifest,count=1)
        assert count==1
        assert '"wgpu"' in manifest
        manifest=manifest.replace('"wgpu"', '"wgpu", "debug_inspector"', 1)
        (runner/'Cargo.toml').write_text(manifest)
        shutil.copy2(CORE/'Cargo.lock',runner/'Cargo.lock')
        command=['cargo','build','--release','--locked','--offline','--target-dir',str(args.target_dir)]
        record={'source':str(source),'source_map':frozen,'runner_map':source_map(runner),'command':command}
        provenance['versions'][version]=record
        (work/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
        with (work/f'{version}.stdout').open('w') as stdout,(work/f'{version}.stderr').open('w') as stderr:
            result=subprocess.run(command,cwd=runner,stdout=stdout,stderr=stderr)
        record['exit_code']=result.returncode
        if result.returncode:
            provenance['status']='failed'
            (work/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
            raise RuntimeError(f'{version} build failed; see preserved stderr')
        assert source_map(source)==frozen,'frozen FemtoVG inputs changed while compiling'
        assert source_map(runner)==record['runner_map'],'locked runner inputs changed while compiling'
        binary=work/'bin'/version
        binary.parent.mkdir(exist_ok=True)
        shutil.copy2(args.target_dir/'release/femtovg-example-outline-review',binary)
        record['binary']=str(binary)
        record['binary_sha256']=digest(binary)
        (work/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
        print(f'Built {version}',flush=True)
    assert source_map(ROOT/'src')==provenance['helper_sources']
    assert digest(ROOT/'assets/BungeeColor-Subset.ttf')==provenance['fixture']
    provenance['status']='complete';provenance['completed']=time.time()
    (work/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')

if __name__=='__main__':main()
