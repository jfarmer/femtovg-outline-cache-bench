#!/usr/bin/env python3
"""Separate untimed GPU/pixel correctness cohort; requires actual Metal."""
from pathlib import Path
import argparse,csv,hashlib,json,os,subprocess,time
from build import ROOT,VERSIONS,digest,source_map

SCENES=('mask','mixed','negative_mixed','overlap_mixed','overlap_legacy','overlap_opposite','stroke_after_mask','direct_after_mask')
PHASES=('cold','second','warm')
EXPECTED_GLYPHS={'mask':1,'mixed':3,'negative_mixed':4,'overlap_mixed':2,'overlap_legacy':2,'overlap_opposite':2,'stroke_after_mask':2,'direct_after_mask':3}

def guard(provenance):
    assert provenance['status']=='complete','all requested immutable executables required'
    assert source_map(ROOT/'src')==provenance['helper_sources'],'helper inputs changed'
    assert digest(ROOT/'assets/BungeeColor-Subset.ttf')==provenance['fixture'],'font source changed'
    for record in provenance['versions'].values():
        assert digest(Path(record['binary']))==record['binary_sha256'],'executable changed'
        assert source_map(Path(record['source']))==record['source_map'],'frozen FemtoVG inputs changed'

def parse(stdout,version):
    frames=[];sources=[];orders=[]
    for row in csv.reader(stdout.splitlines()):
        if not row:continue
        if row[0]=='SOURCE':sources.append(row[1:])
        elif row[0]=='ORDER':
            assert len(row)==7 and row[1]==version
            assert row[4:6]==['legacy_exact','opposite_different_bytes'] and int(row[6])>0
            orders.append(row)
        elif row[0]=='FRAME' and row[1]!='variant':
            assert len(row)==12 and row[1]==version
            dpr=int(float(row[2]));scene=row[3];phase=row[4]
            assert dpr in (1,2) and scene in SCENES and phase in PHASES
            numbers=[int(value) for value in row[5:]]
            assert all(value>=0 for value in numbers)
            assert numbers[0]==EXPECTED_GLYPHS[scene] and numbers[-1]>0
            frames.append({'dpr':dpr,'scene':scene,'phase':phase,'public_glyphs':numbers[0],
                'gray_atlases':numbers[1],'rgba_atlases':numbers[2],
                'new_gray_atlases':numbers[3],'new_rgba_atlases':numbers[4],
                'atlas_bytes':numbers[5],'non_background_pixels':numbers[6]})
    expected={(dpr,scene,phase) for dpr in (1,2) for scene in SCENES for phase in PHASES}
    assert len(frames)==48 and {(r['dpr'],r['scene'],r['phase']) for r in frames}==expected
    assert len(orders)==6 and {(int(float(r[2])),r[3]) for r in orders}=={(dpr,phase) for dpr in (1,2) for phase in PHASES}
    assert ['checksums','valid'] in sources
    assert ['glyph_count','9'] in sources
    glyph_sources={int(row[1]):row[2:] for row in sources if row[0]=='glyph'}
    assert set(glyph_sources)=={2,7,8}
    assert glyph_sources[2][0:2]==['COLR','Color']
    assert glyph_sources[7][0:2]==['sbix_PNG','Color']
    assert glyph_sources[8][0:2]==['outline_mask','Mask']
    return {'frames':frames,'sources':sources,'orders':orders}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'results')
    parser.add_argument('--build-dir',type=Path,default=ROOT/'build')
    parser.add_argument('--gray-versions',nargs='*',default=[])
    args=parser.parse_args()
    if args.output.exists():raise RuntimeError(f'Refusing to overwrite prior observations: {args.output}')
    args.output.mkdir(parents=True)
    build=json.loads((args.build_dir/'provenance.json').read_text())
    versions=build['version_order']
    assert 'master' in versions and set(args.gray_versions)<=set(versions)
    guard(build)
    result={'started':time.time(),'status':'running','performance_measurement':False,
        'width':320,'height':240,'build_provenance_sha256':digest(args.build_dir/'provenance.json'),
        'gray_versions':args.gray_versions,'versions':{},'comparisons':[]}
    destination=args.output/'summary.json'
    destination.write_text(json.dumps(result,indent=2)+'\n')
    for version in versions:
        output=args.output/version;output.mkdir()
        command=[build['versions'][version]['binary'],str(output),version,'yes' if version in args.gray_versions else 'no']
        env=dict(os.environ,FEMTOVG_REQUIRE_GPU='metal')
        with (output/'stdout.txt').open('w') as stdout,(output/'stderr.txt').open('w') as stderr:
            completed=subprocess.run(command,env=env,stdout=stdout,stderr=stderr,timeout=180)
        if completed.returncode:
            result['status']='failed';result['failed_version']=version;result['exit_code']=completed.returncode
            destination.write_text(json.dumps(result,indent=2)+'\n')
            raise RuntimeError(f'{version} GPU validator failed; all raw output preserved')
        parsed=parse((output/'stdout.txt').read_text(),version)
        parsed['fixture_sha256']=digest(output/'mixed-colr-png.ttf')
        parsed['command']=command
        parsed['rgba_hashes']={p.name:digest(p) for p in sorted(output.glob('*.rgba'))}
        assert len(parsed['rgba_hashes'])==48
        for file in parsed['rgba_hashes']:assert (output/file).stat().st_size==320*240*4
        result['versions'][version]=parsed
        destination.write_text(json.dumps(result,indent=2)+'\n')
        print(f'Validated {version}:48 GPU images,6 observable painter-order checks',flush=True)
    master=result['versions']['master']
    for version in (v for v in versions if v!='master'):
        candidate=result['versions'][version]
        assert candidate['fixture_sha256']==master['fixture_sha256'],'font bytes differ across variants'
        assert candidate['sources']==master['sources'],'native verified sources differ'
        for file,baseline_hash in master['rgba_hashes'].items():
            baseline=(args.output/'master'/file).read_bytes();actual=(args.output/version/file).read_bytes()
            differences=sum(a!=b for a,b in zip(baseline,actual))
            row={'version':version,'file':file,'different_bytes':differences,
                'master_sha256':baseline_hash,'candidate_sha256':candidate['rgba_hashes'][file]}
            result['comparisons'].append(row)
    result['pixel_comparisons']=len(result['comparisons'])
    result['all_exact']=all(row['different_bytes']==0 for row in result['comparisons'])
    guard(build)
    result['completed']=time.time();result['status']='complete' if result['all_exact'] else 'pixel_mismatch'
    destination.write_text(json.dumps(result,indent=2)+'\n')
    print(f"{result['pixel_comparisons']} candidate/master comparisons; all_exact={result['all_exact']}")
    if not result['all_exact']:raise RuntimeError('Pixel differences preserved in summary.json')

if __name__=='__main__':main()
