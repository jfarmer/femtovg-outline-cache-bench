//! Separate untimed GPU correctness probe; no changes to the 28-phase replay.
mod fixture;
mod common;

use std::path::{Path, PathBuf};
use femtovg::{imgref, rgb, Canvas, Color, ErrorKind, FontId, Paint, PixelFormat, PositionedGlyph, renderer::WGPURenderer};
use swash::{scale::{image::Content, Render, ScaleContext, Source, StrikeWith}, zeno::{Format, Vector}};

const WIDTH: u32 = 320;
const HEIGHT: u32 = 240;
const BACKGROUND: [u8; 4] = [232, 236, 240, 255];

#[derive(Clone, Copy, Default)]
struct AtlasCounts { gray: usize, rgba: usize, bytes: usize }
fn atlas_counts(canvas: &Canvas<WGPURenderer>) -> AtlasCounts {
    let mut result = AtlasCounts::default();
    for id in canvas.debug_inspector_get_font_textures() {
        let info = canvas.image_info(id).expect("public font atlas ImageInfo");
        match info.format() {
            PixelFormat::Gray8 => { result.gray += 1; result.bytes += info.width() * info.height(); },
            PixelFormat::Rgba8 => { result.rgba += 1; result.bytes += info.width() * info.height() * 4; },
            other => panic!("unexpected font atlas format: {other:?}"),
        }

    }
    result
}

struct Gpu { device: wgpu::Device, queue: wgpu::Queue, target: wgpu::Texture }
impl Gpu {
    fn new() -> Self {
        let (device, queue) = common::headless_device().expect("color validator requires a GPU");
        let target = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("mixed font source correctness target"),
            size: wgpu::Extent3d { width: WIDTH, height: HEIGHT, depth_or_array_layers: 1 },
            mip_level_count: 1, sample_count: 1, dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8Unorm,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::COPY_SRC,
            view_formats: &[],
        });
        Self { device, queue, target }
    }
    fn read(&self, canvas: &mut Canvas<WGPURenderer>) -> Vec<u8> {
        let row_bytes = WIDTH * 4;
        let pitch = row_bytes.div_ceil(wgpu::COPY_BYTES_PER_ROW_ALIGNMENT) * wgpu::COPY_BYTES_PER_ROW_ALIGNMENT;
        let readback = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("untimed color validator readback"), size: u64::from(pitch * HEIGHT),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ, mapped_at_creation: false,
        });
        let render = canvas.flush_to_output(&self.target).expect("render command buffer");
        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor::default());
        encoder.copy_texture_to_buffer(
            wgpu::TexelCopyTextureInfo { texture: &self.target, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
            wgpu::TexelCopyBufferInfo { buffer: &readback, layout: wgpu::TexelCopyBufferLayout { offset: 0, bytes_per_row: Some(pitch), rows_per_image: Some(HEIGHT) } },
            wgpu::Extent3d { width: WIDTH, height: HEIGHT, depth_or_array_layers: 1 },
        );
        self.queue.submit([render, encoder.finish()]);
        let slice = readback.slice(..);
        let (sender, receiver) = std::sync::mpsc::channel();
        slice.map_async(wgpu::MapMode::Read, move |result| sender.send(result).unwrap());
        self.device.poll(wgpu::PollType::wait_indefinitely()).expect("GPU completion");
        receiver.recv().unwrap().expect("readback mapping");
        let mapped = slice.get_mapped_range().expect("readback bytes");
        let mut pixels = Vec::with_capacity((WIDTH * HEIGHT * 4) as usize);
        for row in mapped.chunks(pitch as usize) { pixels.extend_from_slice(&row[..row_bytes as usize]); }
        drop(mapped);
        readback.unmap();
        pixels
    }
}

fn glyph(id: u16, x: f32, y: f32) -> PositionedGlyph { PositionedGlyph { glyph_id: id, x, y } }
fn fill(canvas: &mut Canvas<WGPURenderer>, font: FontId, glyphs: impl IntoIterator<Item = PositionedGlyph>, paint: &Paint) {
    canvas.fill_glyph_run(font, &[], glyphs, paint).expect("public fill_glyph_run");
}
fn draw(canvas: &mut Canvas<WGPURenderer>, font: FontId, scene: &str, phase: f32) -> usize {
    let paint = Paint::color(Color::rgb(16, 48, 160)).with_font_size(24.0);
    match scene {
        "mask" => { fill(canvas, font, [glyph(fixture::MASK, 24.0 + phase, 72.0)], &paint); 1 },
        "mixed" => {
            fill(canvas, font, [glyph(fixture::MASK, 24.0 + phase, 72.0), glyph(fixture::COLR, 80.0 + phase, 72.0),
                glyph(fixture::PNG, 144.0 + phase, 72.0)], &paint); 3
        },
        "negative_mixed" => {
            fill(canvas, font, [glyph(fixture::MASK, -phase, 72.3), glyph(fixture::COLR, -phase, 140.3),
                glyph(fixture::PNG, 64.0 + phase, 12.3), glyph(fixture::PNG, 128.0 + phase, -phase)], &paint); 4
        },
        "overlap_mixed" => {
            fill(canvas, font, [glyph(fixture::PNG, 64.0 + phase, 140.0), glyph(fixture::COLR, 64.0 + phase, 140.0)], &paint); 2
        },
        "overlap_legacy" => {
            fill(canvas, font, [glyph(fixture::COLR, 64.0 + phase, 140.0)], &paint);
            fill(canvas, font, [glyph(fixture::PNG, 64.0 + phase, 140.0)], &paint); 2
        },
        "overlap_opposite" => {
            fill(canvas, font, [glyph(fixture::PNG, 64.0 + phase, 140.0)], &paint);
            fill(canvas, font, [glyph(fixture::COLR, 64.0 + phase, 140.0)], &paint); 2
        },
        "stroke_after_mask" => {
            fill(canvas, font, [glyph(fixture::MASK, 24.0 + phase, 72.0)], &paint);
            canvas.stroke_glyph_run(font, &[], [glyph(fixture::MASK, 24.0 + phase, 160.0)],
                &paint.clone().with_line_width(1.25)).expect("public stroke_glyph_run"); 2
        },
        "direct_after_mask" => {
            fill(canvas, font, [glyph(fixture::MASK, 24.0 + phase, 72.0)], &paint);
            // Master cannot initialize its ephemeral bitmap atlas while the
            // text context is mutably borrowed. Keep PNG on its supported atlas
            // path, then exercise the nonuniform direct outline separately.
            fill(canvas, font, [glyph(fixture::PNG, 112.0 + phase, 170.0)], &paint);
            canvas.save();
            canvas.scale(1.2, 0.9); // Nonuniform scaling forces direct outline rendering.
            fill(canvas, font, [glyph(fixture::MASK, 32.0 + phase, 170.0)], &paint);
            canvas.restore(); 3
        },
        _ => unreachable!(),
    }
}

fn verify_sources(data: &[u8]) {
    fixture::validate_checksums(data);
    println!("SOURCE,checksums,valid");
    let font = swash::FontRef::from_index(data, 0).expect("assembled mixed font");
    assert!(font.color_strikes().find_by_exact_ppem(24, fixture::PNG).is_some());
    assert!(font.color_strikes().find_by_exact_ppem(24, fixture::MASK).is_none());
    assert!(font.color_strikes().find_by_exact_ppem(24, fixture::COLR).is_none());
    let mut context = ScaleContext::new();
    println!("SOURCE,glyph_count,{}", font.metrics(&[]).glyph_count);
    for id in [fixture::MASK, fixture::COLR, fixture::PNG] {
        let mut scaler = context.builder(font).size(24.0).hint(true).build();
        let outline = scaler.scale_outline(id).expect("each fixture glyph keeps a glyf outline");
        if id != fixture::COLR { assert!(!outline.points().is_empty()); }
        let image = Render::new(&[Source::ColorOutline(0), Source::ColorBitmap(StrikeWith::BestFit), Source::Outline])
            .format(Format::Alpha).offset(Vector::new(0.3, 0.0)).render(&mut scaler, id).expect("native source render");
        let (expected_content, source_name) = if id == fixture::MASK {
            assert!(matches!(image.source, Source::Outline)); (Content::Mask, "outline_mask")
        } else if id == fixture::COLR {
            assert!(matches!(image.source, Source::ColorOutline(0))); (Content::Color, "COLR")
        } else {
            assert!(matches!(image.source, Source::ColorBitmap(StrikeWith::BestFit))); (Content::Color, "sbix_PNG")
        };
        assert_eq!(image.content, expected_content);
        assert!(image.placement.width > 0 && image.placement.height > 0);
        assert!(image.data.iter().any(|&byte| byte != 0));
        if id == fixture::PNG {
            assert_eq!((image.placement.width, image.placement.height), (24, 24));
            assert!(image.data.chunks_exact(4).all(|pixel| pixel == [255, 0, 64, 255]));
        }
        println!("SOURCE,glyph,{id},{source_name},{:?},{},{},{}", image.content,
            image.placement.width, image.placement.height, image.data.len());
    }
}

fn write_pixels(output: &Path, name: &str, pixels: &[u8]) {
    assert_eq!(pixels.len(), (WIDTH * HEIGHT * 4) as usize);
    std::fs::write(output.join(format!("{name}.rgba")), pixels).expect("write raw RGBA");
    image::save_buffer(output.join(format!("{name}.png")), pixels, WIDTH, HEIGHT, image::ColorType::Rgba8).expect("write preview PNG");
}

fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    let output = PathBuf::from(args.get(1).expect("output directory argument"));
    let variant = args.get(2).expect("variant label argument");
    let expect_gray = args.get(3).map(String::as_str).unwrap_or("no") == "yes";
    std::fs::create_dir_all(&output).unwrap();
    let data = fixture::mixed_font(include_bytes!("../assets/BungeeColor-Subset.ttf"));
    std::fs::write(output.join("mixed-colr-png.ttf"), &data).unwrap();
    verify_sources(&data);
    let gpu = Gpu::new();
    println!("FRAME,variant,dpr,scene,phase,public_glyphs,gray_atlases,rgba_atlases,new_gray_atlases,new_rgba_atlases,atlas_bytes,non_background_pixels");
    for dpr in [1.0, 2.0] {
        let mut overlapping = std::collections::BTreeMap::new();
        for scene in ["mask", "mixed", "negative_mixed", "overlap_mixed", "overlap_legacy", "overlap_opposite", "stroke_after_mask", "direct_after_mask"] {
            let renderer = WGPURenderer::new(gpu.device.clone(), gpu.queue.clone());
            let mut canvas = Canvas::new(renderer).expect("native WGPU canvas");
            canvas.set_size(WIDTH, HEIGHT, dpr);
            let font = canvas.add_font_mem(&data).expect("register valid mixed fixture");
            for (phase_name, phase) in [("cold", 0.3), ("second", 0.4), ("warm", 0.4)] {
                let before = atlas_counts(&canvas);
                canvas.clear_rect(0, 0, WIDTH, HEIGHT, Color::rgba(BACKGROUND[0], BACKGROUND[1], BACKGROUND[2], BACKGROUND[3]));
                let public_glyphs = draw(&mut canvas, font, scene, phase);
                let pixels = gpu.read(&mut canvas);
                let observed = atlas_counts(&canvas);
                let non_background = pixels.chunks_exact(4).filter(|pixel| *pixel != BACKGROUND).count();
                assert!(non_background > 0, "scene must visibly draw");
                if scene == "mask" && phase_name == "cold" {
                    assert_eq!(observed.gray, usize::from(expect_gray));
                    assert_eq!(observed.rgba, usize::from(!expect_gray));
                }
                if scene == "mixed" && phase_name == "cold" {
                    assert_eq!(observed.gray, usize::from(expect_gray));
                    assert_eq!(observed.rgba, 1);
                }
                if phase_name == "warm" {
                    assert_eq!((observed.gray, observed.rgba), (before.gray, before.rgba), "warm phase adds no font atlas");
                }
                if matches!(scene, "stroke_after_mask" | "direct_after_mask") && phase_name == "cold" {
                    assert!(observed.rgba > 0, "path/bitmap fallback keeps RGBA while the mask atlas exists");
                    if expect_gray { assert!(observed.gray > 0); }
                }
                let name = format!("dpr{}-{scene}-{phase_name}", dpr as u32);
                write_pixels(&output, &name, &pixels);
                println!("FRAME,{variant},{dpr},{scene},{phase_name},{public_glyphs},{},{},{},{},{},{non_background}",
                    observed.gray, observed.rgba, observed.gray - before.gray, observed.rgba - before.rgba, observed.bytes);
                if scene.starts_with("overlap_") { overlapping.insert((scene, phase_name), pixels); }
            }
        }
        for phase in ["cold", "second", "warm"] {
            let mixed = &overlapping[&("overlap_mixed", phase)];
            let legacy = &overlapping[&("overlap_legacy", phase)];
            let opposite = &overlapping[&("overlap_opposite", phase)];
            assert_eq!(mixed, legacy, "PNG-first input preserves legacy COLR-first, PNG-second batches");
            let differences = legacy.iter().zip(opposite).filter(|(a, b)| a != b).count();
            assert!(differences > 0, "overlap must make painter order observable");
            println!("ORDER,{variant},{dpr},{phase},legacy_exact,opposite_different_bytes,{differences}");
        }
    }
}
