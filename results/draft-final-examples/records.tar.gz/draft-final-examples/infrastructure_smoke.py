#!/usr/bin/env python3
"""Four-variant driver/build-integrity smoke checks using Python fixtures only."""
import argparse,copy,csv,importlib.util,json,subprocess,sys,uuid
from pathlib import Path
import build_replay
import run
import summarize
import sequence_totals
import statistics
ROOT=Path(__file__).resolve().parent

def execute(args,log,expected=0):
    result=subprocess.run([sys.executable,*map(str,args)],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    log.write_text(result.stdout+result.stderr)
    if result.returncode!=expected:raise AssertionError(f'{args}: exit {result.returncode}, expected {expected}: {result.stderr}')
    return result

def write_json(path,value):path.write_text(json.dumps(value,indent=2)+'\n')

def check_reuse(root):
    previous=root/'previous';previous.mkdir()
    binary=previous/'master-runner';binary.write_bytes(b'synthetic archived executable\n')
    metadata={'packages':[{'id':'serde','name':'serde','version':'1','source':'registry','manifest_path':'ignored'}],
        'resolve':{'nodes':[{'id':'serde','features':[],'deps':[]}]}}
    write_json(previous/'master-replay-metadata.json',metadata)
    record={'complete':True,'pure_source_files':{'src/lib.rs':'pure'},'timed_source_files':{'src/lib.rs':'timed'},
        'manifest':'relative dependency path and identical features','swash':['0.2.10'],'skrifa':['pinned'],
        'build_command':['cargo','build','--release','--locked','--offline','--manifest-path','/old/manifest','--target-dir','/old/target'],
        'binary_sha256':build_replay.sha(binary)}
    prior={'complete':True,'runner_source':{'main.rs':'drawing'},'resolved_lock_sha256':'lock',
        'compiler':'compiler','variants':{'master':record}}
    write_json(previous/'replay-build-provenance.json',prior)
    current=copy.deepcopy(record);current['build_command'][6]='/new/manifest';current['build_command'][8]='/new/target'
    provenance={'runner_source':prior['runner_source'],'initial_lock_sha256':'lock','compiler':'compiler'}
    assert build_replay.verify_baseline_reuse(previous,'master',current,provenance,metadata)[0]==binary
    mutations=[('drawing sources',lambda r,p,m:p.update(runner_source={'main.rs':'changed'})),
        ('lock',lambda r,p,m:p.update(initial_lock_sha256='changed')),
        ('compiler',lambda r,p,m:p.update(compiler='changed')),
        ('pure source',lambda r,p,m:r.update(pure_source_files={'src/lib.rs':'changed'})),
        ('timed source',lambda r,p,m:r.update(timed_source_files={'src/lib.rs':'changed'})),
        ('manifest',lambda r,p,m:r.update(manifest='changed')),
        ('flags',lambda r,p,m:r['build_command'].append('--features=changed')),
        ('dependency features',lambda r,p,m:m['resolve']['nodes'][0]['features'].append('changed'))]
    for label,mutate in mutations:
        r,p,m=copy.deepcopy(current),copy.deepcopy(provenance),copy.deepcopy(metadata);mutate(r,p,m)
        try:build_replay.verify_baseline_reuse(previous,'master',r,p,m)
        except ValueError:pass
        else:raise AssertionError('Accepted mismatched '+label)
    binary.write_bytes(b'changed executable\n')
    try:build_replay.verify_baseline_reuse(previous,'master',current,provenance,metadata)
    except ValueError:pass
    else:raise AssertionError('Accepted changed executable')
    return ['Accept identical baseline with relocated artifact paths','Reject changed drawing/source/manifest/compiler/lock/flags/dependency features/binary']

def check_driver(root):
    fixture=root/'fixture';fixture.mkdir()
    runner=fixture/'runner';(runner/'src').mkdir(parents=True)
    (runner/'src/main.rs').write_text('synthetic fixture; no Rust is compiled\n')
    (runner/'Cargo.lock').write_text('synthetic fixture lock\n')
    phases_file=fixture/'phases.json';write_json(phases_file,run.PHASES)
    factor_map={version:1-index*.07 for index,version in enumerate(run.VERSIONS)}
    write_json(fixture/'factors.json',factor_map)
    fake_code='#!'+sys.executable+'\n'+r'''
import csv,json,sys
from pathlib import Path
root=Path(__file__).parent
phases=json.loads((root/'phases.json').read_text());factors=json.loads((root/'factors.json').read_text())
version=Path(__file__).name.removesuffix('-runner');factor=factors[version]
w=csv.DictWriter(sys.stdout,fieldnames=['scene','phase','trial','frames','draw_us','submit_us','complete_us','new_atlas_entries']);w.writeheader()
for trial in range(int(sys.argv[2])):
 for scene,values in phases.items():
  for phase_index,(phase,frames) in enumerate(values.items()):
   base=(100+trial)*(phase_index+1)*factor
   w.writerow(dict(scene=scene,phase=phase,trial=trial,frames=frames,draw_us=base,submit_us=base*1.1,complete_us=base*1.2,new_atlas_entries=94*frames if scene.startswith('grid_') else frames))
'''
    build={'complete':True,'runner_source':build_replay.files(runner/'src'),
        'resolved_lock_sha256':build_replay.sha(runner/'Cargo.lock'),'variants':{}}
    for version in run.VERSIONS:
        for parent in ('snapshots','replay-sources'):
            directory=fixture/parent/version;directory.mkdir(parents=True)
            (directory/'Cargo.toml').write_text('synthetic '+version+' fixture\n')
        binary=fixture/(version+'-runner');binary.write_text(fake_code);binary.chmod(0o755)
        build['variants'][version]={'complete':True,'binary_sha256':build_replay.sha(binary),
            'pure_source_files':build_replay.files(fixture/'snapshots'/version),
            'timed_source_files':build_replay.files(fixture/'replay-sources'/version)}
    write_json(fixture/'replay-build-provenance.json',build)
    font=fixture/'font.ttf';font.write_text('synthetic non-font input; no font parser is called\n')
    output=root/'cpu'
    execute([ROOT/'run.py','cpu','--root',fixture,'--output',output,'--blocks',len(run.ORDER),'--trials','2',
        '--fonts','stock','--font-file','stock',font,'--dpis','2'],root/'driver.log')
    manifest=json.loads((output/'cpu-provenance.json').read_text())
    n=len(run.VERSIONS)
    assert manifest['complete'] and len(manifest['launches'])==len(run.ORDER)*n
    assert len(manifest['order'])==len(run.ORDER)
    for index,order in enumerate(manifest['order']):
        assert [manifest['launches'][index*n+j]['version'] for j in range(n)]==[run.VERSIONS[v] for v in run.ORDER[index]]
    execute([ROOT/'summarize.py','--root',output,'--modes','cpu','--bootstrap','100'],root/'summary.log')
    execute([ROOT/'sequence_totals.py','--root',output,'--modes','cpu','--bootstrap','100'],root/'totals.log')
    summary=json.loads((output/'analysis/summary.json').read_text())
    assert len(summary)==28
    for phase in summary:
        assert len(phase['comparisons'])==2*n-3
        for pair in phase['comparisons']:
            expected=100*(factor_map[pair['candidate_version']]/factor_map[pair['reference_version']]-1)
            for metric in summarize.METRICS:
                assert abs(pair[metric]['paired_delta_pct']-expected)<1e-10
                assert all(abs(bound-expected)<1e-10 for bound in pair[metric]['paired_bootstrap95'])
    totals=json.loads((output/'sequence-analysis/summary.json').read_text())
    assert len(totals)==len(run.PHASES)
    for scene in totals:
        assert scene['reported_frames']==sum(run.PHASES[scene['scene']].values())
        assert len(scene['comparisons'])==2*n-3
        for pair in scene['comparisons']:
            expected=100*(factor_map[pair['candidate_version']]/factor_map[pair['reference_version']]-1)
            assert abs(pair['draw_us']['paired_delta_pct']-expected)<1e-10
            weighted=sum(frames*(index+1) for index,frames in enumerate(run.PHASES[scene['scene']].values()))
            expected_total=100.5*weighted*factor_map[pair['reference_version']]
            assert abs(pair['draw_us']['reference_process_median']-expected_total)<1e-7
    # Summing phase medians is invalid: complete trial sums must come first.
    anti=[]
    for trial,(first,second) in enumerate([(1,100),(1,1),(100,1)]):
        for phase,value in [('first',first),('second',second)]:
            anti.append({'font':'stock','dpi':2,'scene':'grid_two_phases','block':1,'version':'master','trial':trial,
                'phase':phase,'frames':1,'new_atlas_entries':94,'draw_us':value,'submit_us':value+1,'complete_us':value+2})
    complete=sequence_totals.totals(anti)['stock',2,'grid_two_phases']
    assert statistics.median(row['draw_us'] for row in complete)==101
    assert sum(statistics.median(row['draw_us'] for row in anti if row['phase']==phase) for phase in ('first','second'))==2
    # Missing configured variants must not silently produce a partial summary.
    saved=manifest['launches'];manifest['launches']=saved[:-1];write_json(output/'cpu-provenance.json',manifest)
    result=execute([ROOT/'summarize.py','--root',output,'--modes','cpu','--bootstrap','10'],root/'missing-variant.log',1)
    assert 'missing/unvalidated processes' in result.stderr
    manifest['launches']=saved;write_json(output/'cpu-provenance.json',manifest)
    return ['Full synthetic 4-variant driver matrix and Williams launch order','Known nonzero effects across 28 phases and every reference comparison','Whole-sequence frame weighting and all comparisons','Reject missing configured variant']

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path)
    args=parser.parse_args();root=(args.output or ROOT/('smoke-'+uuid.uuid4().hex[:8])).resolve();root.mkdir(parents=True,exist_ok=False)
    assert run.VERSIONS==('master','current','final','gray8') and build_replay.VARIANTS==run.VERSIONS
    assert len(run.ORDER)==4 and len(summarize.COMPARISONS)==5
    execute([ROOT/'validation_smoke.py'],root/'parser-statistics.log')
    checks=check_reuse(root)+check_driver(root)
    write_json(root/'checks.json',{'complete':True,'scope':'Synthetic Python data/harnesses only; no application, Rust compiler, benchmark, font parser, or GPU executed',
        'variants':list(run.VERSIONS),'checks':checks,'driver_sha256':build_replay.sha(ROOT/'run.py'),
        'builder_sha256':build_replay.sha(ROOT/'build_replay.py'),'analyzer_sha256':build_replay.sha(ROOT/'summarize.py')})
    print(f'Passed final4 driver/build/statistics synthetic checks: {root}')
if __name__=='__main__':main()
