from pathlib import Path
from collections import defaultdict
import csv
import json
import random
import statistics as st

root=Path(__file__).resolve().parent
random.seed(72531)
summary=[]
for backend in ['cpu','gpu']:
    path=root/(backend+'-results.csv')
    if not path.exists(): continue
    data=list(csv.DictReader(path.open()))
    groups=defaultdict(list)
    for row in data: groups[(row['dpi'],row['scene'],row['phase'])].append(row)
    for (dpi,scene,phase),rows in groups.items():
        out=dict(backend=backend,dpi=int(dpi),scene=scene,phase=phase,
            frames=int(rows[0]['frames']),new_atlas_entries=int(rows[0]['new_atlas_entries']))
        assert len(set(r['new_atlas_entries'] for r in rows))==1
        for metric in ['draw_us','submit_us','complete_us']:
            process=defaultdict(list)
            all_values=defaultdict(list)
            for r in rows:
                value=float(r[metric])
                process[(int(r['pair']),r['version'])].append(value)
                all_values[r['version']].append(value)
            pairs=sorted(set(k[0] for k in process))
            deltas=[100*(st.median(process[(p,'patch')])/st.median(process[(p,'master')])-1) for p in pairs]
            boot=sorted(st.median(random.choices(deltas,k=len(deltas))) for _ in range(10000))
            out[metric]=dict(master_median=st.median(all_values['master']),patch_median=st.median(all_values['patch']),
                paired_delta_pct=st.median(deltas),paired_bootstrap95=[boot[250],boot[9749]],process_pairs=len(pairs),
                samples_per_version=len(all_values['master']))
        summary.append(out)
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('backend,dpi,scene,phase,master_draw_us,patch_draw_us,paired_draw_delta_pct,draw_ci95,master_complete_us,patch_complete_us,paired_complete_delta_pct,complete_ci95,new_atlas_entries')
for r in summary:
    d=r['draw_us'];c=r['complete_us']
    print(f"{r['backend']},{r['dpi']},{r['scene']},{r['phase']},{d['master_median']:.3f},{d['patch_median']:.3f},{d['paired_delta_pct']:.1f},[{d['paired_bootstrap95'][0]:.1f}:{d['paired_bootstrap95'][1]:.1f}],{c['master_median']:.3f},{c['patch_median']:.3f},{c['paired_delta_pct']:.1f},[{c['paired_bootstrap95'][0]:.1f}:{c['paired_bootstrap95'][1]:.1f}],{r['new_atlas_entries']}")
