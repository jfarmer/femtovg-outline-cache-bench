from pathlib import Path
import csv
import io
import os
import subprocess
import sys
import time
root=Path(__file__).resolve().parent
mode=sys.argv[1] if len(sys.argv)>1 else 'cpu'
rounds=int(sys.argv[2]) if len(sys.argv)>2 else 9
trials=int(sys.argv[3]) if len(sys.argv)>3 else 5
env=dict(os.environ,FEMTOVG_REQUIRE_GPU='metal')
rows=[]
log=[]
for dpi in [1,2]:
    for pair in range(rounds):
        order=['master','patch'] if pair%2==0 else ['patch','master']
        for version in order:
            result=subprocess.run([str(root/(version+'-runner')),mode,str(trials),str(dpi)],
                capture_output=True,text=True,check=True,env=env)
            log.append(f'{version} dpi={dpi} pair={pair}\n{result.stderr}')
            for row in csv.DictReader(io.StringIO(result.stdout)):
                rows.append(dict(backend=mode,dpi=dpi,pair=pair,version=version,**row))
            print(f'{mode} dpi={dpi} pair={pair+1}/{rounds} {version} complete',flush=True)
            with (root/(mode+'-results.csv')).open('w') as f:
                writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
            (root/(mode+'-adapter-log.txt')).write_text('\n'.join(log))
if mode=='gpu':
    for dpi in [1,2]:
        for version in ['master','patch']:
            dest=root/'pixels'/f'{version}-dpi{dpi}'
            result=subprocess.run([str(root/(version+'-runner')),'gpu','1',str(dpi),str(dest)],
                capture_output=True,text=True,check=True,env=env)
            (root/'pixels'/f'{version}-dpi{dpi}-run.csv').write_text(result.stdout)
        baseline=root/'pixels'/f'master-dpi{dpi}'
        candidate=root/'pixels'/f'patch-dpi{dpi}'
        for path in baseline.glob('*.rgba'):
            actual=candidate/path.name
            assert path.read_bytes()==actual.read_bytes(),f'pixel mismatch dpi={dpi} {path.name}'
        print(f'dpi={dpi}: {len(list(baseline.glob("*.rgba")))} pixel snapshots identical',flush=True)
