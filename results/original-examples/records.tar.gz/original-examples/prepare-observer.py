from pathlib import Path
import hashlib
import shutil

root = Path(__file__).resolve().parent
originals = [root / 'candidate/src/text/swash_rasterizer.rs', root / 'candidate/src/lib.rs', root / 'runner/src/main.rs', root / 'runner/Cargo.toml']
before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in originals}
shutil.copytree(root / 'candidate', root / 'observed')
shutil.copytree(root / 'runner', root / 'observed-runner')
manifest = root / 'observed-runner/Cargo.toml'
manifest.write_text(manifest.read_text().replace('../candidate', '../observed').replace('../baseline', '../observed'))

p = root / 'observed/src/text/swash_rasterizer.rs'
s = p.read_text()
s = s.replace('    outline_budget: usize,\n}', '    outline_budget: usize,\n    observer_hits: usize,\n    observer_misses: usize,\n    observer_inserts: usize,\n    observer_clears: usize,\n    observer_peak: usize,\n}')
s = s.replace('            outline_budget,\n', '            outline_budget,\n            observer_hits: 0,\n            observer_misses: 0,\n            observer_inserts: 0,\n            observer_clears: 0,\n            observer_peak: 0,\n')
s = s.replace('        if let Some(outline) = self.outlines.get(&key) {\n', '        if let Some(outline) = self.outlines.get(&key) {\n            self.observer_hits += 1;\n')
s = s.replace('        let mut scale_context = self.scale_context.borrow_mut();\n', '        self.observer_misses += 1;\n        let mut scale_context = self.scale_context.borrow_mut();\n', 1)
s = s.replace('            self.outlines.clear();\n', '            self.observer_clears += 1;\n            self.outlines.clear();\n', 1)
s = s.replace('        self.outlines.insert(key, outline);\n', '        self.outlines.insert(key, outline);\n        self.observer_inserts += 1;\n        self.observer_peak = self.observer_peak.max(self.outline_bytes);\n', 1)
marker = '    /// Caches an outline, first emptying the cache'
observer = '''    pub(crate) fn take_observer(&mut self) -> (usize, usize, usize, usize, usize, usize, usize, usize) {
        let stats = (
            self.observer_hits, self.observer_misses, self.observer_inserts,
            self.observer_clears, self.outline_bytes, self.observer_peak,
            self.outlines.len(), self.outlines.capacity(),
        );
        self.observer_hits = 0;
        self.observer_misses = 0;
        self.observer_inserts = 0;
        self.observer_clears = 0;
        self.observer_peak = self.outline_bytes;
        stats
    }

'''
assert marker in s
s = s.replace(marker, observer + marker, 1)
p.write_text(s)

p = root / 'observed/src/lib.rs'
s = p.read_text()
marker = '    /// Sets the canvas size.\n'
assert marker in s
s = s.replace(marker, '''    pub fn benchmark_outline_observer(&self) -> (usize, usize, usize, usize, usize, usize, usize, usize) {
        self.text_context.borrow().swash_rasterizer().borrow_mut().take_observer()
    }

''' + marker, 1)
p.write_text(s)

p = root / 'observed-runner/src/main.rs'
s = p.read_text().replace('use std::{time::Instant, path::PathBuf};', 'use std::path::PathBuf;')
a = s.index('struct Measurement')
b = s.index('fn run<T: Renderer>')
s = s[:a] + '''struct Measurement { misses: usize }
fn frame<T: Renderer>(c: &mut Canvas<T>, s: &mut Scene, f: &mut Frame, dpi: f32,
    flush: &mut impl FnMut(&mut Canvas<T>, Frame), wait: &mut impl FnMut()) -> Measurement {
    let before = c.benchmark_atlas_entries();
    c.set_size(f.width, f.height, dpi);
    s.draw(c, *f);
    flush(c, *f);
    wait();
    let after = c.benchmark_atlas_entries();
    f.index += 1;
    Measurement { misses: after - before }
}
fn emit<T: Renderer>(name: &str, phase: &str, trial: usize, frames: &[Measurement], c: &Canvas<T>) {
    let (hits, misses, inserts, clears, bytes, peak, entries, capacity) = c.benchmark_outline_observer();
    println!("{name},{phase},{trial},{},{},{hits},{misses},{inserts},{clears},{bytes},{peak},{entries},{capacity}",
        frames.len(), frames.iter().map(|r| r.misses).sum::<usize>());
}
''' + s[b:]
s = s.replace('emit(name,"first_paint",trial,&[first]);', 'emit(name,"first_paint",trial,&[first],&c);')
s = s.replace('    for _ in 1..120 {frame(&mut c,&mut s,&mut f,dpi,&mut flush,&mut wait);}', '''    let warmup = (1..120).map(|_|frame(&mut c,&mut s,&mut f,dpi,&mut flush,&mut wait)).collect::<Vec<_>>();
    emit(name,"warmup",trial,&warmup,&c);''')
s = s.replace('emit(name,"warm",trial,&steady);', 'emit(name,"warm",trial,&steady,&c);')
s = s.replace('emit(name,phase,trial,&results);', 'emit(name,phase,trial,&results,&c);')
s = s.replace('scene,phase,trial,frames,draw_us,submit_us,complete_us,new_atlas_entries', 'scene,phase,trial,frames,new_atlas_entries,outline_hits,outline_misses,outline_inserts,outline_full_clears,charged_bytes,peak_charged_bytes,outline_entries,map_capacity')
assert 'Instant' not in s
p.write_text(s)
after = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in originals}
assert before == after, 'Timed candidate or shared runner changed'
(root / 'observer-original-hashes.txt').write_text('\n'.join(f'{h} {p}' for p, h in before.items()) + '\n')
print('Prepared separate untimed observer; timed candidate and shared runner hashes unchanged.')
