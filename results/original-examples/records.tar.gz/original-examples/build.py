from pathlib import Path
import shutil
import subprocess
root=Path(__file__).resolve().parent
manifest=root/'runner/Cargo.toml'
for source,name in [('baseline','master'),('candidate','patch')]:
    text=manifest.read_text().replace('../baseline','../'+source).replace('../candidate','../'+source)
    manifest.write_text(text)
    subprocess.run(['cargo','build','--release','--locked','--offline','--manifest-path',str(manifest),
        '--target-dir','/private/tmp/femtovg-cache-bench/target'],check=True)
    shutil.copy2('/private/tmp/femtovg-cache-bench/target/release/femtovg-example-outline-review',root/(name+'-runner'))
