# FemtoVG example outline cache benchmark

This harness compares `master` with the final proposed branch using the drawing code from FemtoVG's existing examples. It replays their scenes offscreen; it does not launch the interactive winit applications or measure window events, swapchain presentation, or vsync. Existing rasterizer microbenchmarks remain complementary evidence about cache behavior.

## Workload provenance

The modules in `runner/src/` contain the original drawing helpers and redraw call sequences from these examples:

| Example | Preserved workload and assets |
|---|---|
| `demo.rs` | Widget labels, caret paragraph, Entypo icons, animated paths, twelve JPEG thumbnails, and performance overlay; bundled Roboto Flex and Entypo fonts. |
| `text.rs` | Baseline and alignment samples, bilingual paragraph, nineteen-size pangram ladder, multilingual fallback, stroked/gradient/image text, and performance overlay; bundled Roboto Flex, Amiri, and `pattern.jpg`. |
| `font_variations.rs` | Original labels, sample text, weight spectrum, and slant spectrum; bundled Roboto Flex. |

`source-hashes.txt` records SHA-256 hashes of the original helper source tails: `demo.rs` beginning at `draw_paragraph`, `text.rs` at `draw_baselines`, and `font_variations.rs` at `draw_demo`. The replay adapters supply scene state and asset loading around those unchanged helpers. `perf_graph.rs` preserves the example's overlay implementation.

The text replay preserves the original optional Apple Color Emoji loading and logs whether it succeeds. The demo replay disables the screenshot overlay; the debug inspector is not enabled. The cursor starts at a fixed `(500, 300)`. Animation advances deterministically by frame index, and the overlay receives a fixed `1/60` second input rather than measured benchmark duration. Its history and numeric labels still evolve during startup.

## Replay phases

Each trial creates fresh scene state. The example's original initial dimensions and settings are preserved: demo/text at 1000×600, variations at 800×700, text size 18 px at `(5, 380)`, weight 400, and slant 0. First paint is one frame; unreported redraws bring the total to 120 frames before a 30-frame warm phase. The same Canvas then receives these controls:

| Scene | Interaction sequence |
|---|---|
| Text | Ten `x += 0.1` steps, ten reverse steps, ten `y += 0.1` steps; twelve `font_size += 0.5` steps and twelve reverse steps; widths 800, 600, then 1000. |
| Demo | Twelve wheel zooms by 1.1, twelve by 0.9 around the cursor, then ten drag steps of ten screen pixels. The wheel factors intentionally follow the application and are not exact inverses. |
| Variations | Six weight increases of 50 and six reverse steps; ten slant decreases of 1 and ten reverse steps. |

## Measurement boundaries

Fonts, images, rendering devices, and offscreen targets are initialized before timed drawing; GPU setup uploads are drained first. CSV rows report arithmetic means per frame within each phase and trial. `draw_us` ends after sizing and scene drawing, `submit_us` after flush/submission, and `complete_us` after GPU completion. These are cumulative durations from the same frame start, not additive stage durations. `new_atlas_entries` sums new glyph-atlas keys across the phase, including empty/missing outcomes; it is not an outline-cache hit count.

The CPU replay uses `Canvas<Void>` and measures original scene drawing plus flush. Identical benchmark-only barriers in both snapshots preserve command data and image-update inputs against compiler elimination. This includes shaping, atlas lookup, rasterization, upload preparation, and geometry construction, but performs no GPU transfer or rendering.

The WGPU replay targets offscreen `Rgba8Unorm` textures and waits after every frame. Adapter details are logged; absence of the required adapter is a failure. Separate parity runs read back raw RGBA8 snapshots after phase boundaries, outside timing, and compare the two versions byte for byte.

## Reproduction

The runner CLI is `binary cpu|gpu trials dpi [readback-directory]`; it runs all three scenes. The supplied scripts build the two snapshots and alternate master/patch process order at DPR 1 and 2:

```sh
python3 /private/tmp/femtovg-example-outline-review/build.py
python3 /private/tmp/femtovg-example-outline-review/run.py cpu 9 5
python3 /private/tmp/femtovg-example-outline-review/run.py gpu 9 3
```

`build.py` produces `master-runner` and `patch-runner` using the same locked, offline release build with `swash` and `wgpu` enabled. `run.py` writes `cpu-results.csv`/`gpu-results.csv` and adapter logs, then performs separate GPU parity runs. Direct readback example:

```sh
FEMTOVG_REQUIRE_GPU=metal /private/tmp/femtovg-example-outline-review/master-runner gpu 1 1 /private/tmp/femtovg-example-outline-review/pixels/master-dpi1
```

This local recipe points `asset()` at `/Users/jesse/github/femtovg/examples/assets`, uses a cached target directory under `/private/tmp`, and requires Metal in `run.py`. Adjust those paths and backend requirement for another checkout or platform, keeping the same assets, source snapshots, and dependency lockfile for both versions.

## Comparison rules

Build both snapshots in release mode with the same locked dependency versions and `swash` enabled. Use identical replay inputs and instrumentation, alternate run order, and retain raw samples, phase definitions, atlas-entry deltas, adapter details, and source revisions. PR-facing results compare only `master` and the final branch; experimental native/packed representations and eviction policies are internal design evidence.

The performance overlay starts with one hundred zero history values. A steady-state phase therefore needs sufficient priming; a single initial draw does not warm every numeric text variant. Wheel changes, reflow, and font-axis changes must report actual atlas misses rather than assume every frame rerasterizes. Offscreen completion measurements do not establish interactive frame rate or presentation latency.


## Current branch results

These results compare `master` at `f57a2c39` with the current outline-cache branch at `7a278ca4`. They were collected with rustc 1.96.0 (ac68faa20), locked Swash 0.2.10, Skrifa 0.44.0, and WGPU 30.0.1, on Apple M4 Max using Metal. Optional Apple Color Emoji loading succeeded. Changes to the proposed patch require fresh snapshots and a new paired run; these measurements do not cover later implementation changes.

At each DPR, CPU measurements contain 45 trials per version from nine alternating process pairs with five trials per process. GPU measurements contain 27 trials per version from nine process pairs with three trials per process. The table shows pooled median CPU scene-drawing time (`draw_us`) in milliseconds per frame, and paired percentage changes with bootstrap 95% intervals. Negative changes mean faster; positive changes mean slower.

| Scene and phase | DPR 1 master → branch ms | Paired change [95% interval] | DPR 2 master → branch ms | Paired change [95% interval] |
|---|---:|---:|---:|---:|
| Demo first paint | 1.502 → 1.461 | -1.7% [-10.6, +4.1] | 1.470 → 1.464 | -0.3% [-3.9, +3.1] |
| Demo zoom in | 1.367 → 1.361 | -0.8% [-6.2, +1.0] | 1.348 → 1.328 | -1.4% [-1.8, +0.0] |
| Text first paint | 7.703 → 7.509 | -2.8% [-5.9, -1.3] | 7.675 → 7.579 | -1.3% [-3.5, -0.4] |
| Text x movement | 0.428 → 0.395 | -5.8% [-10.8, -3.4] | 0.419 → 0.384 | -9.4% [-9.7, -7.7] |
| Text warm | 0.267 → 0.263 | -1.4% [-2.9, +1.8] | 0.264 → 0.263 | -0.5% [-1.2, +0.1] |
| Text size increase | 5.224 → 5.062 | -2.0% [-4.1, +0.7] | 5.024 → 4.940 | -1.4% [-2.7, -0.5] |
| Weight increase | 0.511 → 0.538 | +4.3% [+1.8, +11.1] | 0.512 → 0.531 | +3.2% [+2.9, +4.8] |

The text example's new x positions show a consistent CPU benefit in this dataset: paired time falls about 6–9%, with both intervals excluding zero. That phase creates 666 new atlas entries over ten frames. First paint has a smaller CPU improvement. The warm phases create zero new atlas entries and show no clear improvement. Changing the variation example's weight creates 717 new entries over six frames and increases paired CPU time by about 3–4%, with both intervals excluding zero.

Completed GPU measurements do not establish a general improvement. Their paired intervals mostly span zero, and no completed-GPU phase has an interval entirely below zero. Some DPR 2 phases have positive intervals, including phases without new atlas entries, so the complete data should be considered alongside the narrower CPU effects. Separate validation runs produced 19 matching phase-endpoint RGBA8 snapshots at each DPR: all 38 master/branch comparisons were byte-identical.

Each trial contributes its phase-average per-frame duration. `summarize.py` takes each process's median across trials, calculates the branch/master percentage ratio within each of the nine paired processes, and reports the median paired change. It bootstraps those nine paired changes 10,000 times for percentile intervals. Paired changes therefore need not equal the ratio of the displayed pooled medians. These are exploratory per-phase intervals across 19 phases and two DPRs, without adjustment for multiple comparisons; the trials within a process are not treated as independent process pairs.

Raw data and complete phase summaries are in `cpu-results.csv`, `gpu-results.csv`, and `summary.json`; `cpu-adapter-log.txt` and `gpu-adapter-log.txt` record the run environment. Regenerate the summary with:

```sh
python3 /private/tmp/femtovg-example-outline-review/summarize.py
```

## Untimed cache occupancy

A separate instrumented copy (`observed/`, `observed-runner/`) replayed one DPI 1 trial without timing. It did not modify the timed snapshots or runner. Every phase had zero full-cache clears. Peak logical charge was 845,072 bytes for demo (2,204 outlines), 1,018,182 bytes for text (2,414 outlines), and 609,890 bytes for font variations (1,658 outlines). These figures exclude vector capacity, layer allocations, spare map capacity, and allocator overhead; they do not measure retained heap.

All 666 rasterizer requests during horizontal text movement hit the outline cache. Text size advancement had 4,340 hits and 1,726 misses; weight/slant advancement had 407 hits and 1,468 misses. Warm redraws, reverse text sizes, reverse variations, and demo pan made no rasterizer calls. See `observer-counts-dpi1.csv` for phase counts.

Increasing the 1 MiB logical budget would not improve any phase in this observed trace. Text approaches the existing cap, so these examples do not support a large reduction either. Budget decisions still need complementary working-set and cache-pressure microbenchmarks.
