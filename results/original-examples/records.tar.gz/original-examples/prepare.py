from pathlib import Path
import hashlib
import io
import subprocess
import tarfile

repo = Path('/Users/jesse/github/femtovg')
root = Path('/private/tmp/femtovg-example-outline-review')
root.mkdir(exist_ok=True)
for ref, name in [('master', 'baseline'), ('HEAD', 'candidate')]:
    dest = root / name
    dest.mkdir(exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git', 'archive', ref], cwd=repo))) as archive:
        archive.extractall(dest, filter='data')
    source = dest / 'src/lib.rs'
    text = source.read_text()
    marker = '    pub fn set_size(&mut self, width: u32, height: u32, dpi: f32) {'
    counter = '    pub fn benchmark_atlas_entries(&self) -> usize { self.glyph_atlas.rendered_glyphs.borrow().len() }\n\n    /// Sets the canvas size.\n'
    source.write_text(text.replace(marker, counter + marker, 1))
    source = dest / 'src/renderer/void.rs'
    text = source.read_text()
    text = text.replace('        data.check_update(&image.info, x, y)', '        std::hint::black_box(&data);\n        data.check_update(&image.info, x, y)', 1)
    text = text.replace('    ) {\n    }', '    ) {\n        std::hint::black_box(images);\n        std::hint::black_box(verts);\n        std::hint::black_box(&commands);\n    }', 1)
    source.write_text(text)

crate = root / 'runner'
(crate / 'src').mkdir(parents=True, exist_ok=True)
(crate / 'Cargo.lock').write_bytes((repo / 'Cargo.lock').read_bytes())
(crate / 'Cargo.toml').write_text('''[package]
name = "femtovg-example-outline-review"
version = "0.0.0"
edition = "2021"
[dependencies]
femtovg = { path = "../baseline", features = ["swash", "wgpu"] }
wgpu = "30.0.0"
pollster = "1.0"
image = { version = "0.25.0", default-features = false, features = ["jpeg", "png"] }
[features]
debug_inspector = []
[profile.release]
debug = 1
''')

imports = 'use femtovg::{Align, Baseline, Canvas, Color, FillRule, FontId, ImageFlags, ImageId, LineCap, LineJoin, Paint, Path, Renderer, Solidity};\nuse std::f32::consts::PI;\nuse crate::{asset, Frame, Size};\nuse crate::perf_graph::PerfGraph;\n'
digests = []
for name, marker in [('demo', 'fn draw_paragraph'), ('text', 'fn draw_baselines'), ('font_variations', 'fn draw_demo')]:
    original = (repo / 'examples' / (name + '.rs')).read_text()
    source = original[original.index(marker):]
    digests.append((name, hashlib.sha256(source.encode()).hexdigest()))
    if name == 'demo':
        body = original[original.index('                    draw_graph('):original.index('                    surface.present(&mut canvas);')]
        wrapper = '''
struct Fonts { regular: FontId, icons: FontId }
pub struct Scene { fonts: Fonts, images: Vec<ImageId>, perf: PerfGraph }
impl Scene {
    pub fn new<T: Renderer>(canvas: &mut Canvas<T>) -> Self {
        let fonts = Fonts {
            regular: canvas.add_font_mem(&asset("RobotoFlex-VariableFont.ttf")).unwrap(),
            icons: canvas.add_font_mem(&asset("entypo.ttf")).unwrap(),
        };
        let images = (1..=12).map(|n| canvas.load_image_mem(&asset(&format!("images/image{n}.jpg")), ImageFlags::empty()).unwrap()).collect();
        Self { fonts, images, perf: PerfGraph::new() }
    }
    pub fn draw<T: Renderer>(&mut self, canvas: &mut Canvas<T>, f: Frame) {
        let mut canvas = canvas;
        let size = Size { width: f.width, height: f.height };
        let width = size.width as f32;
        let height = size.height as f32;
        let fonts = &self.fonts;
        let images = &self.images;
        let perf = &mut self.perf;
        perf.update(1.0 / 60.0);
        let t = f.index as f32 / 60.0;
        let mousex = f.mousex;
        let mousey = f.mousey;
        let (rel_mousex, rel_mousey) = canvas.transform().inverse().transform_point(mousex, mousey);
        let screenshot_image_id: Option<ImageId> = None;
        canvas.clear_rect(0, 0, size.width, size.height, Color::rgbf(0.3, 0.3, 0.32));
''' + body + '\n    }\n}\n'
    elif name == 'text':
        body = original[original.index('                draw_baselines('):original.index('                surface.present(&mut canvas);')]
        wrapper = '''
pub struct Scene { font: FontId, image: ImageId, perf: PerfGraph, supports_emojis: bool }
impl Scene {
    pub fn new<T: Renderer>(canvas: &mut Canvas<T>) -> Self {
        let font = canvas.add_font_mem(&asset("RobotoFlex-VariableFont.ttf")).unwrap();
        canvas.add_font_mem(&asset("amiri-regular.ttf")).unwrap();
        let supports_emojis = canvas.add_font("/System/Library/Fonts/Apple Color Emoji.ttc").is_ok();
        eprintln!("text example optional Apple Color Emoji: {supports_emojis}");
        let flags = ImageFlags::GENERATE_MIPMAPS | ImageFlags::REPEAT_X | ImageFlags::REPEAT_Y;
        let image = canvas.load_image_mem(&asset("pattern.jpg"), flags).unwrap();
        Self { font, image, perf: PerfGraph::new(), supports_emojis }
    }
    pub fn draw<T: Renderer>(&mut self, canvas: &mut Canvas<T>, f: Frame) {
        let mut canvas = canvas;
        let size = Size { width: f.width, height: f.height };
        let font = self.font;
        let image_id = self.image;
        let perf = &mut self.perf;
        perf.update(1.0 / 60.0);
        let elapsed = f.index as f32 / 60.0;
        let font_size = f.font_size;
        let x = f.x;
        let y = f.y;
        let supports_emojis = self.supports_emojis;
        canvas.clear_rect(0, 0, size.width, size.height, Color::rgbf(0.9, 0.9, 0.9));
''' + body + '\n    }\n}\n'
    else:
        wrapper = '''
pub struct Scene { font: FontId }
impl Scene {
    pub fn new<T: Renderer>(canvas: &mut Canvas<T>) -> Self {
        Self { font: canvas.add_font_mem(&asset("RobotoFlex-VariableFont.ttf")).unwrap() }
    }
    pub fn draw<T: Renderer>(&mut self, canvas: &mut Canvas<T>, f: Frame) {
        canvas.clear_rect(0, 0, f.width, f.height, Color::rgbf(0.95, 0.95, 0.95));
        draw_demo(canvas, self.font, f.weight, f.slant);
    }
}
'''
    (crate / 'src' / (name + '.rs')).write_text('#![allow(unused)]\n' + imports + source + '\n' + wrapper)
(crate / 'src/perf_graph.rs').write_bytes((repo / 'examples/helpers/perf_graph.rs').read_bytes())
(root / 'source-hashes.txt').write_text('\n'.join(f'{name}: {digest}' for name, digest in digests) + '\n')
print(root)
