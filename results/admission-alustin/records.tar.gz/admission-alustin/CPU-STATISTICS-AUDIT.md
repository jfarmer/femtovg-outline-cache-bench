# Independent Alustin CPU statistics audit

**Passed.** Independently read all 288 raw CPU reports, identified the unique renderer frame containing each first/search marker, extracted its thread CPU counter, and rebuilt paired effects from all 72 accepted four-version blocks. No benchmark runner or analyzer functions were imported. All 36 requested first/search CPU summaries match the final analysis. Five selected 10,000-resample percentile intervals also match exactly with the recorded deterministic seeds. Each configuration has 12 blocks; no incomplete or partial startup rows enter the CPU data.

Values below are median within-block percentage changes with exploratory 95% bootstrap intervals. Negative means less renderer thread CPU. These are paired effects; the ratio of separate process medians is a different statistic. Intervals are not adjusted for the many comparisons.

| First render | Current / master | Optimized / current | Admission / current |
|---|---:|---:|---:|
| WGPU Vollkorn | -23.79% [-24.84, -18.53] | +0.10% [-4.44, +4.11] | +11.30% [+7.67, +13.18] |
| WGPU PT Sans | -2.97% [-6.75, -0.57] | -2.52% [-6.06, -0.43] | +0.71% [-4.52, +5.62] |
| WGPU Roboto | -1.11% [-7.19, +1.49] | +1.80% [-1.85, +8.72] | -0.71% [-1.98, +4.29] |
| OpenGL Vollkorn | -17.68% [-19.55, -16.96] | +0.84% [-3.24, +2.99] | +8.06% [+7.05, +10.03] |
| OpenGL PT Sans | -3.82% [-6.11, -2.12] | -0.05% [-1.76, +2.38] | +2.15% [+0.98, +5.40] |
| OpenGL Roboto | -1.97% [-5.38, -0.37] | -0.38% [-1.20, +4.23] | +2.64% [+0.47, +5.25] |

The isolated **PT Sans WGPU optimized/current gain is real in this cohort: −2.52%, interval [−6.06%, −0.43%]**, with a paired median saving of 0.349 ms. The other five optimized/current first-render intervals include zero. It should be acknowledged when explaining why the original eager implementation was retained. Admission loses substantial first-render benefit for Vollkorn in both backends and also regresses PT Sans and Roboto in OpenGL relative to current. The evidence supports a tradeoff, not a universal claim that every optimization is slower.

| Filtered search frame | Current / master | Optimized / current | Admission / current |
|---|---:|---:|---:|
| WGPU Vollkorn | -4.16% [-8.03, -2.30] | +1.59% [-3.43, +3.27] | +2.10% [+0.74, +6.15] |
| WGPU PT Sans | -2.25% [-4.13, +1.73] | +0.85% [-1.05, +3.82] | +2.73% [-4.34, +6.37] |
| WGPU Roboto | -0.17% [-5.95, +3.52] | +4.94% [+2.80, +9.91] | +1.01% [-0.69, +5.61] |
| OpenGL Vollkorn | -5.47% [-11.34, -3.28] | -1.59% [-5.19, +1.74] | +0.35% [-2.32, +2.98] |
| OpenGL PT Sans | -0.89% [-3.14, +2.19] | -1.57% [-7.04, +4.77] | +1.18% [-3.74, +4.27] |
| OpenGL Roboto | -1.02% [-4.13, +2.20] | +3.54% [+2.65, +5.38] | +0.83% [-0.65, +5.71] |

For the search frame, current saves approximately **0.099 ms in WGPU and 0.123 ms in OpenGL for Vollkorn**, much less than its first-render savings. Current/master search intervals for PT Sans and Roboto include zero. Optimized/current regresses Roboto search CPU in both backends: **+4.94% WGPU (about 0.102 ms)** and **+3.54% OpenGL (about 0.075 ms)**, with both intervals above zero. Those regressions provide useful context for the isolated PT Sans first-render gain.

This is an actual filtered second frame, not proof of a completely warm glyph atlas. Existing atlas hits bypass the outline cache; glyphs at new positions, sizes, or subpixel phases can still trigger atlas misses. First-render and search results must therefore be distinguished from the unchanged-scene warm-redraw control in the replay, which verifies that the outline cache is bypassed when the atlas is warm. No untimed per-glyph observer was inserted into these app timing binaries, so these CPU differences alone do not identify which internal operation changed.

All **589 diagnostics-off startup launches** from the three incomplete cohorts are excluded wholly. Startup effects remain unavailable; observed readiness recorded in the CPU cohort includes diagnostics and is not a substitute. The separate untimed pixel cohort retains 24 validated launches and **18 exact RGBA comparisons**.

The restored workspace Swash rasterizer matches the original current implementation, SHA-256 `55325dc71d59cee6224ab1aaef38af7e2e1b9a52f2a3a96dc47963f04eeb1167`. This audit made no performance launches, builds, or changes to existing inputs, binaries, manifests, analysis, or production source.

[Machine-readable audit](cpu-statistics-audit.json) · [Independent auditor](audit_cpu_statistics.py) · [Startup limitation](STARTUP-LIMITATION.md)
