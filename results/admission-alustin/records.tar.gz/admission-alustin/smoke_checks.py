#!/usr/bin/env python3
"""Synthetic app-benchmark integrity checks; no app or GUI is launched."""
import argparse
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import uuid
from benchmark_helpers import file_info

HERE=Path(__file__).resolve().parent
OLD=Path('/private/tmp/alustin-font-outline-review')

def write_json(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def execute(args,output,expected=0):
    result=subprocess.run([sys.executable,*map(str,args)],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    output.write_text(result.stdout+result.stderr)
    if result.returncode!=expected:raise AssertionError(f'{args}: exit {result.returncode}, expected {expected}: {result.stderr}')
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path)
    args=parser.parse_args();output=(args.output or HERE/f'smoke-{uuid.uuid4().hex[:8]}').resolve();output.mkdir(parents=True,exist_ok=False)
    old=json.loads((OLD/'cpu-12/summary.json').read_text());template=Path(next(row['report'] for row in old['launches'] if row['included']))
    write_json(output/'template.json',json.loads(template.read_text()))
    for name in ['font.ttf','save','catalog','icons']:(output/name).write_bytes(b'synthetic fixture only\n')
    variants={}
    for version in ['master','current','optimized','admission']:
        binary=output/f'{version}-app';binary.write_text('# synthetic unused executable\n');binary.chmod(0o755)
        variants[version]={'label':version,'base_ref':'synthetic','source_directory':str(output),'source_map_sha256':'synthetic','source_sha256':{},'binary':file_info(binary)}
    harness=output/'harness'
    harness.write_text('#!'+sys.executable+'\n'+r'''
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--binary');p.add_argument('--output');p.add_argument('--backend');p.add_argument('--font-path');a,_=p.parse_known_args()
r=json.loads((Path(__file__).parent/'template.json').read_text());sample=r['samples'][0]
sample['executable_path']=a.binary;sample['backend_requested']=a.backend;sample['system_fonts_disabled']=True;r['system_fonts_disabled']=True;r['font_path']=a.font_path
for event in sample['events']:
 if event['event']=='renderer_setup':event['details']['graphics_api']='WGPU30' if a.backend=='winit-femtovg-wgpu' else 'OpenGL'
 if event['event']=='benchmark_font_configured':event['details'].update(family='Vollkorn',font_path=a.font_path)
 if event['event']=='interactive_frame_rendered':event['details']['query']='aX' if '01-' in Path(a.output).name and 'attempt1-current' in Path(a.output).name else 'a'
out=Path(a.output);out.mkdir();(out/'summary.json').write_text(json.dumps(r))
''');harness.chmod(0o755)
    build={'complete':True,'app_lock_restored':True,'final_app_inputs_match':True,'app_commit':old['app_commit'],'harness':file_info(harness),'variants':variants}
    write_json(output/'build.json',build)
    command=[HERE/'run.py','cpu','--build-provenance',output/'build.json','--output',output/'cpu','--rounds','4','--backends','winit-femtovg-wgpu','--fonts','vollkorn','--font','vollkorn','Vollkorn',output/'font.ttf','--save',output/'save','--catalog',output/'catalog','--icon-pack',output/'icons']
    execute(command,output/'driver.log')
    manifest=json.loads((output/'cpu/summary.json').read_text())
    assert manifest['complete'] and len(manifest['launches'])==20 and len(manifest['accepted_blocks'])==4
    assert manifest['accepted_blocks'][0]['attempt']==2 and sum(r['included'] for r in manifest['launches'])==16
    assert len([r for r in manifest['launches'] if r.get('exclusion_reason')])==4
    execute([HERE/'analyze.py',output/'cpu','--output',output/'analysis','--bootstrap','100'],output/'analysis.log')
    analysis=json.loads((output/'analysis/summary.json').read_text())
    assert len(analysis['results'])==6*19 and len(json.loads((output/'analysis/launches.json').read_text()))==16
    assert all(row['median_paired_change_pct']==0 for row in analysis['results'])
    # A previous complete block may only be rejected when at least one actual
    # query was contaminated. Changing its sole contaminated query must fail.
    contam=next(r for r in manifest['launches'] if r['version']=='current' and r['round']==1 and r['attempt']==1)
    path=Path(contam['report']);saved=path.read_bytes();report=json.loads(saved)
    next(e for e in report['samples'][0]['events'] if e['event']=='interactive_frame_rendered')['details']['query']='a';write_json(path,report)
    result=execute([HERE/'analyze.py',output/'cpu','--output',output/'bad-query','--bootstrap','10'],output/'bad-query.log',1)
    assert 'Excluded an uncontaminated whole block' in result.stderr;path.write_bytes(saved)
    # Post-build executable tampering must fail before analysis.
    app=output/'optimized-app';saved=app.read_bytes();app.write_bytes(saved+b'changed\n')
    result=execute([HERE/'analyze.py',output/'cpu','--output',output/'bad-binary','--bootstrap','10'],output/'bad-binary.log',1)
    assert 'Input/binary changed' in result.stderr;app.write_bytes(saved)
    # A fatal harness error must preserve an incomplete, non-retried manifest.
    saved=harness.read_bytes();harness.write_text('#!'+sys.executable+'\nimport sys\nsys.exit(7)\n');build['harness']=file_info(harness);write_json(output/'build.json',build)
    fatal=copy.copy(command);fatal[fatal.index('--output')+1]=output/'fatal'
    result=execute(fatal,output/'fatal.log',1)
    failed=json.loads((output/'fatal/summary.json').read_text());assert failed['complete'] is False and len(failed['launches'])==1 and failed['launches'][0]['exit_code']==7
    harness.write_bytes(saved);build['harness']=file_info(harness);write_json(output/'build.json',build)
    write_json(output/'checks.json',{'complete':True,'scope':'Synthetic script harness only; no application builds/windows','checks':['Whole four-version retry on query contamination, with all 20 launches retained','Raw analysis of all 16 accepted launches across all six variant comparisons','Refuse exclusion of an uncontaminated prior block','Reject post-build binary tampering','Fatal harness error preserves incomplete batch without retry'], 'driver':file_info(HERE/'run.py'),'analyzer':file_info(HERE/'analyze.py')})
    print(f'Passed five synthetic integrity checks; no app or GUI launched: {output}')

if __name__=='__main__':main()
