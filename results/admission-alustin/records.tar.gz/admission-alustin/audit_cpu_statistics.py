#!/usr/bin/env python3
"""Independent raw paired CPU arithmetic and selected interval verification.

No imports of the benchmark runner/analyzer. No application launches or builds.
"""
from collections import defaultdict
import datetime
import hashlib
import json
from pathlib import Path
import random

ROOT=Path('/private/tmp/alustin-admission-review')
VARIANTS=('master','current','optimized','admission')
PAIRS=(('master','current'),('current','optimized'),('current','admission'))

def read(path):return json.loads(path.read_text())
def median(values):
    ordered=sorted(values);n=len(ordered)
    return ordered[n//2] if n%2 else (ordered[n//2-1]+ordered[n//2])/2

def percentile(values,q):
    ordered=sorted(values);position=(len(ordered)-1)*q;lo=int(position);hi=min(lo+1,len(ordered)-1)
    return ordered[lo]+(ordered[hi]-ordered[lo])*(position-lo)

def close(a,b):return abs(a-b)<1e-10

def raw_frame_cpu(sample,marker):
    spans=sample['slint_internal_spans'];markers=[span for span in spans if span['name']==marker]
    assert len(markers)==1
    at=markers[0]['start_ns']
    frames=[span for span in spans if span['name']=='femtovg.render' and span['start_ns']<=at<=span['start_ns']+span['duration_ns']]
    assert len(frames)==1
    frame=frames[0];lo=frame['start_ns'];hi=lo+frame['duration_ns']
    counters=[span for span in spans if span['name']=='femtovg.render.thread_cpu_ns' and lo<=span['start_ns'] and span['start_ns']+span['duration_ns']<=hi]
    assert len(counters)==1
    return sum(span['amount'] for span in counters)/1_000_000

def main():
    manifest=read(ROOT/'cpu-12/summary.json');analysis=read(ROOT/'analysis/summary.json')
    assert manifest['complete'] and manifest['mode']=='cpu' and len(manifest['launches'])==288
    assert len(manifest['accepted_blocks'])==72 and all(row['included'] and row['validated'] and row['exit_code']==0 for row in manifest['launches'])
    raw_analysis=read(ROOT/'analysis/launches.json')
    assert len(raw_analysis)==288 and {row['label'] for row in raw_analysis}=={row['label'] for row in manifest['launches']}
    assert all(row['mode']=='cpu' and row['batch']=='cpu-12' for row in raw_analysis)
    source_values={};by_label={row['label']:row for row in manifest['launches']}
    for launch in manifest['launches']:
        report=read(Path(launch['report']));assert len(report['samples'])==1
        sample=report['samples'][0]
        events={event['event']:event for event in sample['events']}
        assert events['interactive_frame_rendered']['details']['query']=='a'
        source_values[launch['label']]={
            'first_frame.render.thread_cpu_ms':raw_frame_cpu(sample,'first_frame_rendered'),
            'search_frame.render.thread_cpu_ms':raw_frame_cpu(sample,'interactive_frame_rendered'),
        }
    grouped=defaultdict(list)
    for block in manifest['accepted_blocks']:
        group={by_label[label]['version']:{'round':block['round'],'values':source_values[label]} for label in block['labels']}
        assert set(group)==set(VARIANTS)
        grouped[block['backend'],block['font']].append(group)
    assert len(grouped)==6 and all(len(blocks)==12 for blocks in grouped.values())
    output_rows=[]
    selected_ci={
      ('winit-femtovg-wgpu','ptsans','current','optimized','first_frame.render.thread_cpu_ms'),
      ('winit-femtovg-wgpu','vollkorn','master','current','first_frame.render.thread_cpu_ms'),
      ('winit-femtovg','vollkorn','current','admission','first_frame.render.thread_cpu_ms'),
      ('winit-femtovg-wgpu','roboto','current','optimized','search_frame.render.thread_cpu_ms'),
      ('winit-femtovg','roboto','current','optimized','search_frame.render.thread_cpu_ms'),
    }
    samples_by_config={};seed_by_config={}
    for (backend,font),blocks in sorted(grouped.items()):
        blocks.sort(key=lambda group:group['master']['round'])
        token=f'cpu-12/{backend}/{font}'
        seed=analysis['statistics']['seed']^int.from_bytes(hashlib.sha256(token.encode()).digest()[:8],'big')
        seed_by_config[backend,font]=seed
        if any(key[:2]==(backend,font) for key in selected_ci):
            rng=random.Random(seed);samples_by_config[backend,font]=[[rng.randrange(12) for _ in range(12)] for _ in range(analysis['statistics']['bootstrap_resamples'])]
        for metric in ['first_frame.render.thread_cpu_ms','search_frame.render.thread_cpu_ms']:
            for reference,candidate in PAIRS:
                old=[block[reference]['values'][metric] for block in blocks];new=[block[candidate]['values'][metric] for block in blocks]
                differences=[b-a for a,b in zip(old,new)];ratios=[b/a for a,b in zip(old,new)]
                row=next(row for row in analysis['results'] if row['backend']==backend and row['font']==font and row['reference']==reference and row['candidate']==candidate and row['metric']==metric)
                assert row['n_blocks']==12 and all(pair['round']==i+1 for i,pair in enumerate(row['pairs']))
                assert close(row['reference_median'],median(old)) and close(row['candidate_median'],median(new))
                assert close(row['median_paired_delta'],median(differences)) and close(row['median_paired_ratio'],median(ratios))
                assert close(row['median_paired_change_pct'],100*(median(ratios)-1))
                for pair,a,b in zip(row['pairs'],old,new):
                    assert close(pair['reference'],a) and close(pair['candidate'],b) and close(pair['delta'],b-a) and close(pair['candidate_over_reference_ratio'],b/a)
                record={key:row[key] for key in ['backend','font','reference','candidate','metric','n_blocks','reference_median','candidate_median','median_paired_delta','median_paired_change_pct','median_paired_change_pct_ci95']}
                record.update(raw_arithmetic_matches=True,bootstrap_seed=seed,bootstrap_interval_independently_recomputed=False)
                if (backend,font,reference,candidate,metric) in selected_ci:
                    resampled=[median([ratios[index] for index in indices]) for indices in samples_by_config[backend,font]]
                    interval=[100*(percentile(resampled,q)-1) for q in [.025,.975]]
                    assert all(close(a,b) for a,b in zip(interval,row['median_paired_change_pct_ci95']))
                    record.update(bootstrap_interval_independently_recomputed=True,recomputed_pct_ci95=interval)
                output_rows.append(record)
    excluded=analysis['excluded_batches'];assert len(excluded)==3
    assert {Path(row['path']).name for row in excluded}=={'startup-12','startup-12-rerun-1','startup-8-final'}
    assert all(row['mode']=='startup' and not row['complete'] for row in excluded)
    assert sum(row['raw_launches'] for row in excluded)==589
    assert len(analysis['pixels'])==18 and all(row['rgba_identical'] for row in analysis['pixels'])
    assert [(batch['mode'],batch['accepted_launches']) for batch in analysis['batches']]==[('cpu',288),('pixels',24)]
    current_sha=hashlib.sha256(Path('/Users/jesse/github/femtovg/src/text/swash_rasterizer.rs').read_bytes()).hexdigest()
    assert current_sha=='55325dc71d59cee6224ab1aaef38af7e2e1b9a52f2a3a96dc47963f04eeb1167'
    audit={'complete':True,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'method':'Independent code reads raw per-process Slint spans, finds the unique render frame containing each first/search marker, reads its renderer thread CPU amount in ns, and calculates paired medians/ratios from all 12 raw four-version blocks per configuration; no runner/analyzer imports',
      'scope':'36 raw paired summaries audited: first/search frame × six font/backend configurations × current/master, optimized/current, admission/current; five selected percentile intervals independently recomputed with recorded 10,000-resample deterministic seeds',
      'timed_launches':288,'blocks':72,'configurations':6,'n_blocks_per_configuration':12,'raw_summary_arithmetic_rows':36,'independent_interval_checks':5,
      'startup_excluded_wholly':589,'startup_effects':'unavailable; CPU-mode readiness includes diagnostics and cannot replace a diagnostics-off startup cohort',
      'pixel_launches':24,'identical_pixel_comparisons':18,'restored_current_source_sha256':current_sha,
      'results':output_rows,'auditor_file_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'cpu-statistics-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(f'Independent raw CPU audit passed: {len(output_rows)} arithmetic summaries and {len(selected_ci)} selected bootstrap intervals')

if __name__=='__main__':main()
