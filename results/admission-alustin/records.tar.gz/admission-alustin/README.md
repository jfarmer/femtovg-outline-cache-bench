# Four-version Alustin outline-cache comparison

This harness keeps the existing master/current Alustin build and font experiments intact. It compares four variants in fresh adjacent application processes: frozen upstream master, the original outline-cache patch (`current`), its reduced-overhead version (`optimized`), and the repeat-before-admission candidate (`admission`). The variant record contains a complete FemtoVG source-file hash map and digest, rather than identifying uncommitted candidates as the old patch commit. No new benchmark hooks are inserted into FemtoVG.

## Build and provenance

The new builder defaults to the current Alustin checkout, its previous benchmark build, the source snapshots supplied by the root task, and the previously warmed Cargo target directory. `--check-only` reads inputs without building or writing the app lock:

```sh
python3 /private/tmp/alustin-admission-review/build.py --check-only
python3 /private/tmp/alustin-admission-review/build.py
```

The builder checks every tracked application file except the separately managed lock against the previous app build, checks the tracked diff, original lock, HEAD, Rust/Cargo versions, both retained executable hashes, and the archived resolved lock. The master and current source maps must exactly match those of the retained binaries. Optimized/admission must differ from current solely in `src/text/swash_rasterizer.rs`. Generated crate `Cargo.lock` files are omitted from source freezing: the archived application lock governs resolution.

Optimized/admission sources are copied into immutable-in-practice build input directories before compiling. Cargo runs offline with the same archived resolved lock and `--locked`; normalized package/dependency/feature graphs must match the previous graph exactly. Only the lock is written in the app checkout, within a build transaction, then restored in `finally`. Restoration is refused if the lock changed externally. All outputs, source maps, metadata, logs, the initial/resolved locks, and executable hashes are retained. No application windows are opened during building. Build this only while nobody else is editing application inputs or its lock.

The build directory must be new. The resulting common startup harness is the verified previously built master harness; its behavior is shared by all four variants. The app binary build commands have identical features and target settings.

## Measurement

These commands open windows and should be run serially, without other performance jobs:

```sh
python3 /private/tmp/alustin-admission-review/run.py cpu --output /private/tmp/alustin-admission-review/cpu-12
python3 /private/tmp/alustin-admission-review/run.py startup --output /private/tmp/alustin-admission-review/startup-12
python3 /private/tmp/alustin-admission-review/run.py pixels --actual-font-diagnostics --output /private/tmp/alustin-admission-review/pixels
```

Defaults are Vollkorn Medium, PT Sans Regular, and Roboto Flex; both WGPU and OpenGL; twelve four-version blocks per font/backend for CPU/startup, one block for screenshots. `--fonts` also supports Liberation Serif and Arial. `--font NAME FAMILY FILE` can override a configured factor. Screenshot diagnostics verify both exact primary-face bytes and bundled Inter fallback using the same previously validated helper. System font discovery remains disabled for every font factor; all fonts are explicitly registered. The normal Vollkorn embedded import remains intact in the common app.

Each font/backend/round uses a balanced four-row Williams version order. Over four rounds every version occupies each process position once and all directed carryover pairs occur once. Configuration order rotates independently. Input contamination is the sole retry trigger: final search query must be `a`. A contaminated query retries all four versions, with a maximum of three whole-block attempts. Every attempt is retained; the first structurally valid uncontaminated block is accepted without consulting duration. A timeout, nonzero harness exit, provenance/schema error, font mismatch, or pixel mismatch immediately leaves the batch incomplete. The analyzer refuses incomplete batches. OS/shader cache state remains uncontrolled and is documented.

CPU/startup/screenshot jobs are separate. CPU tracing measures host wall and renderer-thread CPU spans. Diagnostics-off startup includes readiness/IPC overhead and excludes compositor scanout. Actual font dumps run only during untimed screenshot verification. No reported CPU span claims to measure GPU completion.

## Analysis

```sh
python3 /private/tmp/alustin-admission-review/analyze.py \
  /private/tmp/alustin-admission-review/cpu-12 \
  /private/tmp/alustin-admission-review/startup-12 \
  /private/tmp/alustin-admission-review/pixels \
  --output /private/tmp/alustin-admission-review/analysis
```

The analyzer reads and revalidates raw reports, input and executable hashes, balanced launch order, complete four-version matrix, font event/graphics API/DPR, and original span aggregation. It also revalidates that all excluded earlier attempts contained an actual contaminated query. Screenshot pixels are decoded and compared again. Every accepted process stays in the analysis.

Six within-block comparisons are emitted per metric: current/optimized/admission versus master, optimized/admission versus current, and admission versus optimized. Primary effects are median paired deltas and ratios, with 10,000 block bootstrap resamples and exploratory 95% percentile intervals. The same resampled indices are used for all variants/metrics within a configuration. Output includes JSON, summary CSV, pair CSV, and raw extracted launch metrics. `--exclude BATCH REASON` records an explicitly excluded incomplete prior batch; the root task must supply the reason.

## Harness checks

```sh
python3 /private/tmp/alustin-admission-review/smoke_checks.py
```

This uses only synthetic script executables and a retained report template. It opens no GUI and builds nothing. It validates whole-block contamination retries, raw accepted-launch arithmetic across all six comparisons, refusal to reject an uncontaminated prior block, binary-tampering rejection, and fatal harness failure leaving an incomplete batch without retry. The initial synthetic checks passed in `smoke-7343b77b/checks.json`.
