# Diagnostics-off startup results unavailable

All three new diagnostics-off startup cohorts ended with a probe timeout. They are excluded **in their entirety**, including earlier successful blocks. No startup effect or startup confidence interval is reported from these cohorts. The final eight-round cohort was predeclared as the last attempt; startup launches stopped after its failure. Existing benchmark evidence is preserved.

| Cohort | Planned rounds | Launches started | Complete four-version blocks | Contaminated query attempts | Fatal timeout |
|---|---:|---:|---:|---:|---|
| `startup-12` | 12 | 263 | 62 | 3 | Round 11, WGPU, Vollkorn, current |
| `startup-12-rerun-1` | 12 | 267 | 66 | 0 | Round 12, OpenGL, Roboto, optimized |
| `startup-8-final` | 8 | 59 | 14 | 0 | Round 3, WGPU, Roboto, current |

The harness reported “no interactive response” after its configured 120-second timeout in each case. Each failed launch has no final report. All **589 startup launches** remain archived: 586 exited successfully, three failed, and three successful launches reported contaminated queries (`aW`, `a `, and `ae`). The original cohort retried all four versions for each contaminated query, retaining all 12 rejected launches. Across the incomplete cohorts, 568 launches were marked included in their manifests; **none enter the startup analysis**. No earlier rounds or successful configurations are salvaged, and no observations are excluded based on duration.

A sample of the stalled second-cohort OpenGL optimized process shows its main thread idle in the AppKit event loop, with no sampled cache/scaler/render work. Its app stderr is empty. This supports a missing probe transition as a hypothesis; it does not establish the cause. The probe buffers its report until the input-and-redraw sequence completes. Physical focus/modifier interference is one plausible explanation because its injected key does not reset modifier state. We cannot conclusively attribute the failures to the cache, probe, desktop input, or platform.

The separate CPU cohort completed **288 validated launches in 72 four-version blocks**. The untimed pixel cohort completed **24 validated launches in six blocks**, with **18 exact master/candidate RGBA comparisons** and 24 successful actual-font validations. Those completed cohorts remain usable. Their traced readiness measurements do not substitute for diagnostics-off startup evidence.

[startup-attempt-audit.json](startup-attempt-audit.json) records every startup launch, raw-report query, failure log, cohort count, and exclusion decision. Later app analysis should include the completed CPU/pixel cohorts and explicitly document all three whole-cohort exclusions.
