Independent replay audit passed: 216 timed processes, 864 within-process trials, 24,192 phase rows, all 3,888 reported comparison metrics recomputed from retained raw stdout. Selected percentile-bootstrap intervals were independently recomputed for 240 comparison metrics with the recorded seeds and whole-block pairing.

All CPU and GPU raw process outputs match the aggregate CSV exactly. All nine blocks × three fonts × four variants × 28 phases are complete; CPU uses five trials/process, GPU three. Every controlled frame creates exactly 94 atlas entries. Frame and atlas counts are invariant across variants, blocks, and trials. No run was launched or removed during this audit.

Negative means faster. CPU tables use drawing CPU duration; GPU tables use completion duration including CPU work, submission, and the completion wait. Microseconds become milliseconds by dividing by 1000. Cumulative draw/submit/complete values must not be added. Brackets contain exploratory percentile-bootstrap 95% intervals without multiplicity adjustment.

The complete two-phase sequence includes both first and second requests. Delayed admission sacrifices the second-request hit, so its isolated second phase or later hit cannot stand in for sequence performance.

| Font | Current/master CPU, complete two phases | Admission/master CPU | Admission/current CPU |
|---|---:|---:|---:|
| stock | -5.06% [-7.27, -3.46] | +18.91% [+16.94, +26.87] | +26.10% [+22.86, +32.80] |
| vollkorn | -41.03% [-41.17, -39.34] | +1.60% [+0.56, +4.19] | +71.86% [+69.12, +77.12] |
| ptsans | -26.04% [-26.57, -25.00] | +9.36% [+6.71, +12.49] | +47.83% [+46.10, +49.75] |

The complete pollution sequence includes hot-first, hot-second, 64 one-use pollution frames, and hot-return: 67 frames. Large hot-return savings therefore produce much smaller total effects.

| Font | Current/master CPU, complete pollution sequence | Admission/master CPU | Admission/current CPU | Admission/master GPU completion |
|---|---:|---:|---:|---:|
| stock | +11.20% [+7.48, +13.91] | +3.62% [-0.02, +4.77] | -6.48% [-8.79, -4.38] | +1.60% [-4.28, +8.31] |
| vollkorn | -0.24% [-12.76, +2.23] | -1.49% [-15.37, -0.58] | -2.24% [-9.84, +0.97] | -0.51% [-2.46, +1.33] |
| ptsans | +3.99% [+3.66, +6.29] | +0.33% [-3.08, +1.50] | -3.99% [-6.10, -2.17] | -0.78% [-3.78, +5.27] |

The overhead-only variant has no established first-paint CPU benefit relative to current in any of the three fonts. It also increases PT Sans complete-pollution CPU by 1.82% [0.07%, 20.39%] relative to current. All three complete two-phase optimized/current CPU intervals cross zero. A larger key changes the whole-cache-clear boundary at the same logical byte cap; this can outweigh lookup-allocation savings.

| Font | Current/master demo first-paint CPU | Optimized/current CPU | Admission/current CPU | Current/master GPU completion |
|---|---:|---:|---:|---:|
| stock | -1.31% [-3.22, +1.33] | +0.15% [-2.56, +2.52] | +2.90% [-0.47, +5.19] | -1.87% [-12.29, +18.94] |
| vollkorn | -32.64% [-33.35, -29.90] | +0.00% [-0.96, +2.81] | +19.38% [+17.13, +27.38] | -13.78% [-18.37, -10.21] |
| ptsans | -14.47% [-16.51, -11.90] | +0.59% [-2.71, +3.16] | +8.41% [+4.06, +10.55] | -5.00% [-16.40, +2.47] |

The original variation example always uses Roboto. Its apparent repetitions across regular-font factors are controls. In the stock control, current/master CPU weight advancement regresses 2.81% [0.85%, 14.08%]; overhead-only optimized/master is inconclusive at +0.41% [−1.80%, +3.86%]. Admission/master variation first paint regresses 5.29% [4.15%, 7.19%]. Optimized/master GPU completion regresses 3.21% [0.58%, 6.09%] for weight advancement and 2.61% [0.10%, 4.41%] for slant advancement. Warm CPU optimized/master has a small −1.15% [−3.73%, −0.26%] effect, but warm frames create zero atlas entries and bypass this cache; it is not evidence of an outline hit benefit. Other stock variation intervals generally cross zero.

Vollkorn unique-size marginal medians (master 1768.8 µs, current 1601.5 µs) must not be presented as a 9.5% caching gain. The paired effect is +1.70% [−17.29%, +2.48%]; early blocks have large opposing swings, and the observer has zero outline hits. Optimized/current Vollkorn hot-return has a +7.46% point estimate (+124.833 µs), but its interval [−28.47%, +10.51%] crosses zero, so the experiment does not establish a timing regression. The observer records an additional full clear; both eager variants have zero hot-return hits. This supports a possible clear-boundary cost mechanism without attributing a precise timed cost to it.

Original demo/text/variation scene sequence totals are explicitly sums of reported phases, not complete runs: each scene omits its 119 unreported warmup frames. Controlled sequences contain every frame and can support end-to-end sequence comparisons. Use Alustin for the editor workload and diagnostics-off startup conclusions.

The evidence supports a tradeoff, rather than automatic adoption of delayed admission. It reduces one-use cache pollution and preserves useful hot outlines, while losing substantial benefits when an outline receives exactly two atlas requests or repeated requests during first paint. The overhead-only optimization does not establish a net performance improvement at the current logical cap.

Evidence: `results/{cpu,gpu}-provenance.json`, retained `*-runs/*.stdout.csv`, `results/analysis/summary.csv`, `results/sequence-analysis/summary.csv`, and `FINAL-STATISTICS-AUDIT.json`. The separate untimed observer supplies cache-hit and full-clear mechanisms; it is not timing evidence.
