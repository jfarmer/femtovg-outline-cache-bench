This experiment compares frozen master, current outline cache, reduced-overhead outline cache, and experimental second-use admission. Previous benchmark files and results are preserved in their original directories.

The `runner/` retains the exact previous `demo`, `text`, `font_variations`, and performance-graph helpers, including their existing runtime primary-font override. All 19 phases remain. `grid_unique_variations`, like the existing variation example, always uses Roboto Flex; repeated copies across font factors are controls, not additional independent evidence about another font.

Nine additional phase rows exercise the public `fill_glyph_run` API with 94 distinct nonspace ASCII glyph IDs. Swash supplies the charmap and normalized variation coordinates. Font registration, glyph mapping, coordinates, and request construction happen outside the per-frame measurement. No font parser or normalization implementation is added.

| Scene | Phases | Intended outline requests |
|---|---|---|
| `grid_singleton` | `once` | Every key once: cold catalogue page |
| `grid_two_phases` | `first`, `second` | Every outline twice at two atlas horizontal phases |
| `grid_unique_sizes` | `sweep`, 32 frames | Every glyph/size once: continuous size animation with no phase reuse |
| `grid_unique_variations` | `sweep`, 32 frames | Every glyph/normalized instance once: continuous weight animation |
| `grid_pollution` | `hot_first`, `hot_second`, `pollution` (64 frames), `hot_return` | Populate reusable outlines at phases 0.0/0.1, introduce one-use sizes, request hot outlines at fresh atlas phase 0.2 |

The pollution sizes exclude the hot size. The final horizontal phase must be new: a conventional warm redraw hits the glyph atlas and never reaches the outline cache, concealing outline eviction. The driver requires exactly 94 new atlas entries per controlled frame and identical frame/atlas-entry counts for every version. The separately instrumented, untimed observer must confirm zero reuse in singleton/size/variation scenes, two requests per key in the two-phase scene, three requests for hot outlines, and cache pressure beyond the logical storage budget. Request counts establish intended key reuse; they alone do not establish actual eviction or hit counts.

Controlled grid coordinates are explicit canvas coordinates. Atlas subpixel keys use the fractional x coordinate before renderer DPR handling. Every grid begins at integer origins and shifts to 0.1/0.2. Public glyph-run sizes do not pass through the high-level text shaping API's DPR normalization. These controlled scenes isolate admission behavior; they are not estimates of full editor font shaping cost. Existing example scenes and the Alustin comparison provide that broader context.

Source layout:

- `snapshots/{master,current,optimized,admission}`: pure frozen FemtoVG sources, also suitable for Alustin.
- `replay-sources/{master,current,optimized,admission}`: copies with identical atlas-count accessor and Void black-box barriers, matching the previous replay instrumentation.
- `runner/Cargo.toml`: initially selects `../replay-sources/current`; the root agent builds each source sequentially and copies the resulting executable to `VERSION-runner`.
- `runner/Cargo.lock`: previous lock with only the existing `swash` package added to the runner's dependency list. All resolved package versions remain unchanged.

Build instructions for the root agent: point the single FemtoVG path in the runner manifest to one `../replay-sources/VERSION`, then run `cargo build --release --locked --offline --manifest-path /private/tmp/femtovg-admission-review/runner/Cargo.toml --target-dir /private/tmp/femtovg-cache-bench/target`. Copy `target/release/femtovg-example-outline-review` to `/private/tmp/femtovg-admission-review/VERSION-runner` before selecting the next variant. Capture executable, normalized dependency-graph, source-tree, lock, and unchanged helper hashes in `replay-build-provenance.json`. No instrumentation belongs in the pure snapshots. The driver requires completed build provenance and verifies all binary, source, runner, and lock hashes before launching.

The driver does not build anything or mutate its inputs. A timing run requires all four binary paths and all four source snapshots. A block contains one process for each version at the same font/DPR. Four balanced Williams orders cycle across blocks and configurations. Configuration order rotates across blocks. Nine blocks yield one version with three positions and the others with two in each configuration; all results remain.

Example commands (do not run concurrently with compilation or another timing experiment):

```sh
python3 /private/tmp/femtovg-admission-review/run.py cpu --output /private/tmp/femtovg-admission-review/results
python3 /private/tmp/femtovg-admission-review/run.py gpu --output /private/tmp/femtovg-admission-review/results
python3 /private/tmp/femtovg-admission-review/run.py pixels --output /private/tmp/femtovg-admission-review/results
python3 /private/tmp/femtovg-admission-review/summarize.py --root /private/tmp/femtovg-admission-review/results
```

Defaults are stock Roboto, Vollkorn, PT Sans; DPR 2; nine fresh blocks; five CPU or three GPU trials/process. `--fonts stock vollkorn ptsans liberation arial --dpis 1 2` expands the matrix. `--binary VERSION PATH`, `--font-file NAME PATH`, and `--build-provenance PATH` provide explicit input overrides. Pixels use one trial and one block, run separately from timing, and compare every variant with master at every one of the 28 phases. The two regular-font example images must change when the font changes; Roboto controls must remain byte-identical.

CPU uses the same Void renderer with barriers as before. GPU runs offscreen Metal/WGPU, waits for completion, and opens no native window. Draw, submit, and completion durations are cumulative microseconds/frame and must not be added. The statistics first take trial medians within each process, then compare process medians within complete four-version blocks. Bootstrap draws identify whole blocks and are shared across all six strategy comparisons and all three cumulative timing metrics. No trial is treated as an independent process observation. Intervals are exploratory, with no multiplicity correction.
