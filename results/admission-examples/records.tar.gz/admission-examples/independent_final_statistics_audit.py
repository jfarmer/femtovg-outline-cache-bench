#!/usr/bin/env python3
"""Independent arithmetic and selected-CI audit; never run a benchmark."""
import ast
from collections import defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import statistics

ROOT=Path(__file__).resolve().parent
RESULTS=ROOT/'results'
VERSIONS=('master','current','optimized','admission')
METRICS=('draw_us','submit_us','complete_us')


def read_csv(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(actual,expected):
    if not math.isclose(float(actual),expected,rel_tol=1e-10,abs_tol=1e-6):
        raise AssertionError((actual,expected))


def q(values,fraction):
    ordered=sorted(values)
    position=(len(ordered)-1)*fraction
    i=math.floor(position)
    j=math.ceil(position)
    return ordered[i]+(ordered[j]-ordered[i])*(position-i)


def bootstrap_interval(values,samples):
    boot=[statistics.median(values[index] for index in draw) for draw in samples]
    return [q(boot,.025),q(boot,.975)]


def validate_raw(mode):
    metadata=json.loads((RESULTS/f'{mode}-provenance.json').read_text())
    rows=read_csv(RESULTS/f'{mode}-results.csv')
    trials=5 if mode=='cpu' else 3
    assert metadata['complete'] and metadata['blocks']==9 and metadata['trials_per_process']==trials
    expected={(b,f,2,v) for b in range(1,10) for f in ('stock','vollkorn','ptsans') for v in VERSIONS}
    indexed=defaultdict(list)
    for row in rows:
        indexed[int(row['block']),row['font'],int(row['dpi']),row['version']].append(row)
    assert set(indexed)==expected and len(metadata['launches'])==108
    assert len(rows)==108*trials*28
    keys={(t,s,p) for t in range(trials) for s,phases in metadata['phases'].items() for p in phases}
    factors=defaultdict(set)
    for launch in metadata['launches']:
        assert launch['validated'] and launch['exit_code']==0
        key=(launch['block'],launch['font'],launch['dpi'],launch['version'])
        raw=read_csv(Path(launch['stdout']))
        aggregate=[{k:v for k,v in row.items() if k not in ('backend','font','dpi','block','version')} for row in indexed[key]]
        assert raw==aggregate and len(raw)==trials*28
        assert {(int(row['trial']),row['scene'],row['phase']) for row in raw}==keys
        for row in raw:
            assert int(row['frames'])==metadata['phases'][row['scene']][row['phase']]
            if row['scene'].startswith('grid_'):
                assert int(row['new_atlas_entries'])==94*int(row['frames'])
            times=[float(row[metric]) for metric in METRICS]
            assert times==sorted(times) and all(math.isfinite(v) and v>=0 for v in times)
            factors[launch['font'],row['scene'],row['phase']].add((int(row['frames']),int(row['new_atlas_entries'])))
    assert all(len(counts)==1 for counts in factors.values())
    return metadata,rows,{'mode':mode,'processes':108,'trials_per_process':trials,'phase_rows':len(rows),
                        'factor_configurations':len(factors),'raw_aggregate_exact':True,'controlled_atlas_entries_per_frame':94}


def main():
    raw={}
    raw_checks=[]
    phases=defaultdict(dict)
    sequences=defaultdict(dict)
    for mode in ('cpu','gpu'):
        metadata,rows,check=validate_raw(mode)
        raw[mode]=metadata,rows
        raw_checks.append(check)
        # Values indexed by original trial. Complete-sequence aggregation
        # independently adds weighted raw phase values before any medians.
        sums=defaultdict(lambda:defaultdict(float))
        for row in rows:
            block,trial=int(row['block']),int(row['trial'])
            font,dpi,scene,phase=row['font'],int(row['dpi']),row['scene'],row['phase']
            version=row['version']
            for metric in METRICS:
                phases[mode,font,dpi,scene,phase,metric][block,version,trial]=float(row[metric])
                sums[font,dpi,scene,metric][block,version,trial]+=int(row['frames'])*float(row[metric])
        for group,values in sums.items():
            sequences[(mode,*group)]=dict(values)
    phase_summary=read_csv(RESULTS/'analysis/summary.csv')
    sequence_summary=read_csv(RESULTS/'sequence-analysis/summary.csv')
    assert len(phase_summary)==3024 and len(sequence_summary)==864
    audit=[]
    audited_points=0
    samples_cache={}
    for kind,reported,source in [('phase',phase_summary,phases),('sequence',sequence_summary,sequences)]:
        for row in reported:
            mode,font,dpi,scene,metric=row['backend'],row['font'],int(row['dpi']),row['scene'],row['metric']
            group=(mode,font,dpi,scene,row['phase'],metric) if kind=='phase' else (mode,font,dpi,scene,metric)
            values=source[group]
            trials=raw[mode][0]['trials_per_process']
            reference,candidate=row['reference_version'],row['candidate_version']
            medians={version:[statistics.median(values[b,version,t] for t in range(trials)) for b in range(1,10)] for version in VERSIONS}
            a,b=medians[reference],medians[candidate]
            differences=[y-x for x,y in zip(a,b)]
            percentages=[100*(y/x-1) for x,y in zip(a,b)]
            pooled={version:[values[block,version,trial] for block in range(1,10) for trial in range(trials)] for version in (reference,candidate)}
            expected={
                'reference_median':statistics.median(pooled[reference]),'candidate_median':statistics.median(pooled[candidate]),
                'reference_process_median':statistics.median(a),'candidate_process_median':statistics.median(b),
                'paired_delta_us':statistics.median(differences),'paired_delta_pct':statistics.median(percentages),
            }
            for name,value in expected.items():
                close(row[name],value)
            assert int(row['process_blocks'])==9 and int(row['trials_per_process'])==trials
            audited_points+=1
            primary_metric=metric==('draw_us' if mode=='cpu' else 'complete_us')
            selected=(kind=='sequence' and scene in ('grid_two_phases','grid_pollution')) or (
                kind=='phase' and (scene=='demo' and row['phase']=='first_paint' or scene=='font_variations' and font=='stock' or font=='vollkorn' and scene in ('grid_unique_sizes','grid_pollution')))
            if not selected or not primary_metric:
                continue
            token=f'{mode}/{font}/{dpi}/{scene}/{row["phase"]}' if kind=='phase' else f'sequence/{mode}/{font}/{dpi}/{scene}'
            if token not in samples_cache:
                seed=72531 ^ int.from_bytes(hashlib.sha256(token.encode()).digest()[:8],'big')
                rng=random.Random(seed)
                samples_cache[token]=[[rng.randrange(9) for _ in range(9)] for _ in range(10000)]
            samples=samples_cache[token]
            ci_pct=bootstrap_interval(percentages,samples)
            ci_us=bootstrap_interval(differences,samples)
            for actual,expected_bound in zip(ast.literal_eval(row['paired_bootstrap95']),ci_pct):
                close(actual,expected_bound)
            for actual,expected_bound in zip(ast.literal_eval(row['paired_delta_us_ci95']),ci_us):
                close(actual,expected_bound)
            direction='faster' if ci_pct[1]<0 else 'slower' if ci_pct[0]>0 else 'uncertain'
            audit.append({'kind':kind,'backend':mode,'font':font,'dpi':dpi,'scene':scene,'phase':row.get('phase'),
                'metric':metric,'scope':row.get('scope','per-frame phase duration'),
                'reference_version':reference,'candidate_version':candidate,
                **expected,'paired_bootstrap95':ci_pct,'paired_delta_us_ci95':ci_us,'ci_direction':direction,
                'units':'microseconds/complete sequence' if kind=='sequence' else 'microseconds/frame',
                'reported_frames':int(row['reported_frames']) if kind=='sequence' else int(row['frames'])})
    paths=[RESULTS/'analysis/summary.csv',RESULTS/'sequence-analysis/summary.csv',
           RESULTS/'cpu-provenance.json',RESULTS/'gpu-provenance.json',
           RESULTS/'cpu-results.csv',RESULTS/'gpu-results.csv']
    fingerprints={str(path):digest(path) for path in paths}
    report={'complete':True,'raw_checks':raw_checks,'point_summary_rows_recomputed':audited_points,
            'selected_ci_rows_recomputed':len(audit),'bootstrap_resamples':10000,'seed':72531,
            'source_sha256':fingerprints,'selected':audit,
            'interpretation':'Negative candidate/reference change means faster. Sequences sum frames*per-frame duration within each trial before process medians. All intervals are exploratory, unadjusted for multiplicity. Original reported-phase totals omit119warmupframes per scene. No benchmark launched.'}
    (ROOT/'FINAL-STATISTICS-AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
    def lookup(kind,backend,font,scene,reference,candidate,phase=None):
        selected=[row for row in audit if (row['kind'],row['backend'],row['font'],row['scene'],row['reference_version'],row['candidate_version'],row['phase'])==(kind,backend,font,scene,reference,candidate,phase)]
        assert len(selected)==1
        return selected[0]
    def effect(row):
        lo,hi=row['paired_bootstrap95']
        return f"{row['paired_delta_pct']:+.2f}% [{lo:+.2f}, {hi:+.2f}]"
    lines=[
        f'Independent replay audit passed: 216 timed processes, 864 within-process trials, 24,192 phase rows, all 3,888 reported comparison metrics recomputed from retained raw stdout. Selected percentile-bootstrap intervals were independently recomputed for {len(audit)} comparison metrics with the recorded seeds and whole-block pairing.',
        '',
        'All CPU and GPU raw process outputs match the aggregate CSV exactly. All nine blocks × three fonts × four variants × 28 phases are complete; CPU uses five trials/process, GPU three. Every controlled frame creates exactly 94 atlas entries. Frame and atlas counts are invariant across variants, blocks, and trials. No run was launched or removed during this audit.',
        '',
        'Negative means faster. CPU tables use drawing CPU duration; GPU tables use completion duration including CPU work, submission, and the completion wait. Microseconds become milliseconds by dividing by 1000. Cumulative draw/submit/complete values must not be added. Brackets contain exploratory percentile-bootstrap 95% intervals without multiplicity adjustment.',
        '',
        'The complete two-phase sequence includes both first and second requests. Delayed admission sacrifices the second-request hit, so its isolated second phase or later hit cannot stand in for sequence performance.',
        '',
        '| Font | Current/master CPU, complete two phases | Admission/master CPU | Admission/current CPU |',
        '|---|---:|---:|---:|',
    ]
    for font in ('stock','vollkorn','ptsans'):
        rows=[lookup('sequence','cpu',font,'grid_two_phases',a,b) for a,b in [('master','current'),('master','admission'),('current','admission')]]
        lines.append('| '+font+' | '+' | '.join(effect(row) for row in rows)+' |')
    lines.extend(['',
        'The complete pollution sequence includes hot-first, hot-second, 64 one-use pollution frames, and hot-return: 67 frames. Large hot-return savings therefore produce much smaller total effects.',
        '',
        '| Font | Current/master CPU, complete pollution sequence | Admission/master CPU | Admission/current CPU | Admission/master GPU completion |',
        '|---|---:|---:|---:|---:|'])
    for font in ('stock','vollkorn','ptsans'):
        rows=[lookup('sequence','cpu',font,'grid_pollution',a,b) for a,b in [('master','current'),('master','admission'),('current','admission')]]
        rows.append(lookup('sequence','gpu',font,'grid_pollution','master','admission'))
        lines.append('| '+font+' | '+' | '.join(effect(row) for row in rows)+' |')
    lines.extend(['',
        'The overhead-only variant has no established first-paint CPU benefit relative to current in any of the three fonts. It also increases PT Sans complete-pollution CPU by 1.82% [0.07%, 20.39%] relative to current. All three complete two-phase optimized/current CPU intervals cross zero. A larger key changes the whole-cache-clear boundary at the same logical byte cap; this can outweigh lookup-allocation savings.',
        '',
        '| Font | Current/master demo first-paint CPU | Optimized/current CPU | Admission/current CPU | Current/master GPU completion |',
        '|---|---:|---:|---:|---:|'])
    for font in ('stock','vollkorn','ptsans'):
        rows=[lookup('phase','cpu',font,'demo',a,b,'first_paint') for a,b in [('master','current'),('current','optimized'),('current','admission')]]
        rows.append(lookup('phase','gpu',font,'demo','master','current','first_paint'))
        lines.append('| '+font+' | '+' | '.join(effect(row) for row in rows)+' |')
    lines.extend(['',
        'The original variation example always uses Roboto. Its apparent repetitions across regular-font factors are controls. In the stock control, current/master CPU weight advancement regresses 2.81% [0.85%, 14.08%]; overhead-only optimized/master is inconclusive at +0.41% [−1.80%, +3.86%]. Admission/master variation first paint regresses 5.29% [4.15%, 7.19%]. Optimized/master GPU completion regresses 3.21% [0.58%, 6.09%] for weight advancement and 2.61% [0.10%, 4.41%] for slant advancement. Warm CPU optimized/master has a small −1.15% [−3.73%, −0.26%] effect, but warm frames create zero atlas entries and bypass this cache; it is not evidence of an outline hit benefit. Other stock variation intervals generally cross zero.',
        '',
        'Vollkorn unique-size marginal medians (master 1768.8 µs, current 1601.5 µs) must not be presented as a 9.5% caching gain. The paired effect is +1.70% [−17.29%, +2.48%]; early blocks have large opposing swings, and the observer has zero outline hits. Optimized/current Vollkorn hot-return has a +7.46% point estimate (+124.833 µs), but its interval [−28.47%, +10.51%] crosses zero, so the experiment does not establish a timing regression. The observer records an additional full clear; both eager variants have zero hot-return hits. This supports a possible clear-boundary cost mechanism without attributing a precise timed cost to it.',
        '',
        'Original demo/text/variation scene sequence totals are explicitly sums of reported phases, not complete runs: each scene omits its 119 unreported warmup frames. Controlled sequences contain every frame and can support end-to-end sequence comparisons. Use Alustin for the editor workload and diagnostics-off startup conclusions.',
        '',
        'The evidence supports a tradeoff, rather than automatic adoption of delayed admission. It reduces one-use cache pollution and preserves useful hot outlines, while losing substantial benefits when an outline receives exactly two atlas requests or repeated requests during first paint. The overhead-only optimization does not establish a net performance improvement at the current logical cap.',
        '',
        'Evidence: `results/{cpu,gpu}-provenance.json`, retained `*-runs/*.stdout.csv`, `results/analysis/summary.csv`, `results/sequence-analysis/summary.csv`, and `FINAL-STATISTICS-AUDIT.json`. The separate untimed observer supplies cache-hit and full-clear mechanisms; it is not timing evidence.',
    ])
    (ROOT/'FINAL-STATISTICS-AUDIT.md').write_text('\n'.join(lines)+'\n')
    print(f'Passed: {audited_points} point summaries and {len(audit)} selected CI rows; raw CPU/GPU process validation complete. Wrote FINAL-STATISTICS-AUDIT.md/json.')


if __name__=='__main__':
    main()
