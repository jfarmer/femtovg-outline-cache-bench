#!/usr/bin/env python3
"""Build/run isolated CPU observers only after the root agent authorizes it.

Preparation is separate. Neither --build nor --run is implied by default.
Observer durations are never recorded or treated as performance evidence.
"""

from pathlib import Path
import argparse
import csv
import hashlib
import io
import json
import os
import shutil
import subprocess

from prepare_observer import ROOT, WORK, VARIANTS, primary_inputs, source_hashes


DEFAULT_FONTS = (
    ("stock", Path("/Users/jesse/github/femtovg/examples/assets/RobotoFlex-VariableFont.ttf")),
    ("vollkorn", Path("/Users/jesse/github/alustin-gui-v2/crates/alustin-gui/assets/fonts/Vollkorn-Medium.ttf")),
    ("ptsans", Path("/private/tmp/femtovg-open-font-search/candidate-agent/PTSans-Regular.ttf")),
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checked_inputs():
    provenance = json.loads((WORK / "preparation.json").read_text())
    if primary_inputs() != provenance["primary_inputs"]:
        raise ValueError("primary inputs differ from observer preparation")
    for variant in VARIANTS:
        if source_hashes(WORK / "observer-sources" / variant) != provenance["observer_sources"][variant]:
            raise ValueError(f"instrumented observer source changed: {variant}")
    if source_hashes(WORK / "observer-runner") != provenance["observer_runner"]:
        raise ValueError("observer runner source changed")
    if sha(WORK / "observer-runner/Cargo.lock") != provenance["observer_runner_lock"]:
        raise ValueError("observer lock changed")
    return provenance


def build(target):
    preparation = checked_inputs()
    manifest = WORK / "observer-runner/Cargo.toml"
    original = manifest.read_text()
    assert original.count("../observer-sources/current") == 1
    records = {}
    binaries = WORK / "bin"
    binaries.mkdir(exist_ok=True)
    try:
        for variant in VARIANTS:
            manifest.write_text(original.replace("../observer-sources/current", "../observer-sources/" + variant))
            command = ["cargo", "build", "--release", "--locked", "--offline", "--manifest-path", str(manifest), "--target-dir", str(target)]
            with (WORK / f"build-{variant}.log").open("wb") as log:
                subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
            binary = binaries / variant
            shutil.copy2(target / "release/femtovg-example-outline-review", binary)
            records[variant] = {"command": command, "binary": str(binary), "sha256": sha(binary)}
            print(f"Untimed {variant} observer built", flush=True)
    finally:
        manifest.write_text(original)
    checked_inputs()
    (WORK / "build-provenance.json").write_text(json.dumps({
        "mode": "observer only; no timings",
        "preparation": preparation,
        "variants": records,
        "target_dir": str(target),
        "runner_manifest_sha256": sha(manifest),
    }, indent=2) + "\n")


def verify(rows):
    """Check measured mechanisms, allowing early admission from fingerprints."""
    observations = []
    groups = {}
    for row in rows:
        key = (row["variant"], row["font"], row["dpi"])
        groups.setdefault(key, {})[(row["scene"], row["phase"])] = row
        assert row["requests"] == row["hits"] + row["misses"], row
        assert row["misses"] == sum(row[name] for name in ("denied", "insertions", "colors", "invalid", "oversized")), row
        assert 0 <= row["current_logical_bytes"] <= row["peak_logical_bytes"] <= 1 << 20, row
        assert row["history_bytes"] == (16384 if row["variant"] == "admission" else 0), row
    for (variant, font, dpi), phases in groups.items():
        once = phases[("grid_singleton", "once")]
        sizes = phases[("grid_unique_sizes", "sweep")]
        variations = phases[("grid_unique_variations", "sweep")]
        first = phases[("grid_two_phases", "first")]
        second = phases[("grid_two_phases", "second")]
        hot_second = phases[("grid_pollution", "hot_second")]
        pollution = phases[("grid_pollution", "pollution")]
        returned = phases[("grid_pollution", "hot_return")]
        for row in (once, sizes, variations):
            assert row["hits"] == 0, row
        assert first["hits"] == 0 and first["requests"] == 94, first
        if variant == "admission":
            assert second["hits"] == 0, second
            # Slot collisions can prevent some hot keys from being admitted on
            # their second sighting. Verify retention of the keys that actually
            # entered the cache, rather than presuming all 94 were admitted.
            assert returned["requests"] == 94 and returned["hits"] == hot_second["outline_entries"] > 0, returned
            assert pollution["clears"] == 0, pollution
            assert pollution["outline_entries"] == hot_second["outline_entries"], pollution
        else:
            assert second["hits"] == second["requests"] == 94, second
            assert pollution["clears"] > 0, pollution
        observations.append({
            "variant": variant, "font": font, "dpi": dpi,
            "singleton_hits": once["hits"], "singleton_insertions": once["insertions"],
            "unique_size_hits": sizes["hits"], "unique_size_insertions": sizes["insertions"],
            "unique_variation_hits": variations["hits"], "unique_variation_insertions": variations["insertions"],
            "two_phase_first_hits": first["hits"], "two_phase_second_hits": second["hits"],
            "two_phase_first_insertions": first["insertions"],
            "two_phase_second_insertions": second["insertions"],
            "pollution_insertions": pollution["insertions"], "pollution_clears": pollution["clears"],
            "hot_keys_admitted_before_pollution": hot_second["outline_entries"],
            "hot_return_hits": returned["hits"], "hot_return_misses": returned["misses"],
            "hot_return_entries": returned["outline_entries"],
            "hot_return_logical_bytes": returned["current_logical_bytes"],
            "history_bytes": returned["history_bytes"],
        })
    return observations


def run(fonts, dpis):
    checked_inputs()
    build_info = json.loads((WORK / "build-provenance.json").read_text())
    traces = WORK / "traces"
    if traces.exists():
        raise ValueError("observer traces already exist; refusing to overwrite evidence")
    traces.mkdir()
    records = []
    executions = []
    for variant in VARIANTS:
        binary = Path(build_info["variants"][variant]["binary"])
        assert sha(binary) == build_info["variants"][variant]["sha256"]
        for font_name, font in fonts:
            font = font.resolve(strict=True)
            for dpi in dpis:
                stem = f"{variant}-{font_name}-dpr{dpi:g}"
                env = dict(os.environ)
                env["FEMTOVG_REPLAY_TEXT_FONT"] = str(font)
                command = [str(binary), "cpu", "1", str(dpi)]
                process = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                (traces / f"{stem}.csv").write_text(process.stdout)
                (traces / f"{stem}.stderr.txt").write_text(process.stderr)
                executions.append({
                    "variant": variant, "font": font_name, "font_path": str(font), "font_sha256": sha(font),
                    "dpi": dpi, "command": command, "exit_code": process.returncode,
                    "csv_sha256": sha(traces / f"{stem}.csv"),
                })
                (WORK / "execution-provenance.json").write_text(json.dumps({"mode": "untimed CPU observer", "complete": False, "executions": executions}, indent=2) + "\n")
                process.check_returncode()
                for row in csv.DictReader(io.StringIO(process.stdout)):
                    parsed = {key: value if key in ("scene", "phase") else int(value) for key, value in row.items()}
                    records.append({"variant": variant, "font": font_name, "dpi": dpi, **parsed})
                print(f"Untimed trace {stem} recorded", flush=True)
    with (WORK / "comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    observations = verify(records)
    (WORK / "mechanism-validation.json").write_text(json.dumps({
        "passed": True, "rows": len(records), "configurations": len(observations),
        "observations": observations,
        "interpretation": "Counts describe mechanism only. Observer binaries are excluded from performance measurements.",
    }, indent=2) + "\n")
    checked_inputs()
    (WORK / "execution-provenance.json").write_text(json.dumps({"mode": "untimed CPU observer", "complete": True, "executions": executions}, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--target-dir", type=Path, default=Path("/private/tmp/femtovg-cache-bench/target"))
    parser.add_argument("--font", action="append", nargs=2, metavar=("NAME", "PATH"))
    parser.add_argument("--dpi", nargs="+", type=float, default=[1, 2])
    args = parser.parse_args()
    if args.build:
        build(args.target_dir)
    if args.run:
        fonts = [(name, Path(path)) for name, path in args.font] if args.font else DEFAULT_FONTS
        run(fonts, args.dpi)
    if not args.build and not args.run:
        print("No action. Use --build and/or --run only after primary timing is complete and the root agent authorizes it.")


if __name__ == "__main__":
    main()
