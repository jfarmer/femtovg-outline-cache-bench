use std::{
    borrow::Cow,
    cell::RefCell,
    hash::{Hash, Hasher},
    mem::{size_of, size_of_val},
    rc::Rc,
};

use fnv::FnvHashMap;
use swash::{
    scale::{
        image::{Content, Image},
        outline::Outline,
        Render, ScaleContext, Source, StrikeWith,
    },
    zeno::{Format, Mask, Origin, Scratch, Vector},
    CacheKey, FontRef,
};

/// The color sources a glyph is rendered from before falling back to its outline.
const COLOR_SOURCES: [Source; 2] = [Source::ColorOutline(0), Source::ColorBitmap(StrikeWith::BestFit)];
const SOURCES: [Source; 3] = [
    Source::ColorOutline(0),
    Source::ColorBitmap(StrikeWith::BestFit),
    Source::Outline,
];

/// Bytes the outline cache may hold, as `entry_bytes` counts them. An entry
/// for a Latin glyph takes a few hundred bytes, so this holds a couple of
/// thousand.
const OUTLINE_CACHE_BUDGET: usize = 1 << 20;

/// A bounded record of recent uncached outlines. The 16 KiB history is separate
/// from the logical outline budget and survives outline-cache clears.
const ADMISSION_HISTORY_ENTRIES: usize = 2048;

/// Identifies a hinted outline by everything the scaler hints it with.
/// Lookups borrow coordinates; only retained keys own their coordinate buffer.
#[derive(Debug, Hash, PartialEq, Eq)]
struct OutlineKey<'a> {
    font: CacheKey,
    glyph_id: u16,
    font_size: u32,
    normalized_coords: Cow<'a, [i16]>,
}

impl OutlineKey<'_> {
    fn into_owned(self) -> OutlineKey<'static> {
        OutlineKey {
            font: self.font,
            glyph_id: self.glyph_id,
            font_size: self.font_size,
            normalized_coords: Cow::Owned(self.normalized_coords.into_owned()),
        }
    }
}

#[derive(Default)]
struct OutlineObserverStats {
    requests: u64,
    hits: u64,
    misses: u64,
    denied: u64,
    insertions: u64,
    clears: u64,
    colors: u64,
    invalid: u64,
    oversized: u64,
    peak_logical_bytes: usize,
}

/// Renders glyphs with swash.
///
/// Swash hints an outline independently of the subpixel offset it is rasterized
/// at, so the hinted outline of a glyph is kept and reused for its other offsets.
/// Glyphs that render from a color source aren't cached, since those images
/// depend on the offset.
pub(crate) struct SwashRasterizer {
    scale_context: Rc<RefCell<ScaleContext>>,
    scratch: Scratch,
    outlines: FnvHashMap<OutlineKey<'static>, Outline>,
    outline_bytes: usize,
    outline_budget: usize,
    observer: OutlineObserverStats,
    admission_history: [u64; ADMISSION_HISTORY_ENTRIES],
}

impl SwashRasterizer {
    /// Observer-only counters, reset between phases. Retained cache and history
    /// are unchanged; a phase's peak begins at its current retained footprint.
    pub(crate) fn take_observer_stats(&mut self) -> [u64; 13] {
        let stats = [
            self.observer.requests, self.observer.hits, self.observer.misses,
            self.observer.denied, self.observer.insertions, self.observer.clears,
            self.outline_bytes as u64, self.observer.peak_logical_bytes as u64,
            self.outlines.len() as u64, (ADMISSION_HISTORY_ENTRIES * size_of::<u64>()) as u64,
            self.observer.colors, self.observer.invalid, self.observer.oversized,
        ];
        self.observer = OutlineObserverStats {
            peak_logical_bytes: self.outline_bytes,
            ..OutlineObserverStats::default()
        };
        stats
    }

    pub(crate) fn new(scale_context: Rc<RefCell<ScaleContext>>) -> Self {
        Self::with_outline_budget(scale_context, OUTLINE_CACHE_BUDGET)
    }

    fn with_outline_budget(scale_context: Rc<RefCell<ScaleContext>>, outline_budget: usize) -> Self {
        Self {
            scale_context,
            scratch: Scratch::new(),
            outlines: FnvHashMap::default(),
            outline_bytes: 0,
            outline_budget,
            observer: OutlineObserverStats::default(),
            admission_history: [0; ADMISSION_HISTORY_ENTRIES],
        }
    }

    /// Renders a glyph as `Render` does with color outlines, then color bitmaps,
    /// then outlines as sources, in `Format::Alpha` and offset horizontally by
    /// `subpixel_x`.
    ///
    /// `font` must be the same `FontRef` for every call with the same face, so
    /// that its cache key identifies it.
    pub(crate) fn render(
        &mut self,
        font: FontRef<'_>,
        font_size: f32,
        glyph_id: u16,
        subpixel_x: f32,
        normalized_coords: &[i16],
    ) -> Option<Image> {
        self.observer.requests += 1;
        if self.outline_budget == 0 {
            return self.render_without_outline_cache(font, font_size, glyph_id, subpixel_x, normalized_coords);
        }

        let key = OutlineKey {
            font: font.key,
            glyph_id,
            font_size: font_size.to_bits(),
            normalized_coords: Cow::Borrowed(normalized_coords),
        };

        if let Some(outline) = self.outlines.get(&key) {
            self.observer.hits += 1;
            return Some(rasterize(outline, &mut self.scratch, subpixel_x));
        }
        self.observer.misses += 1;

        let (history_slot, signature) = admission_location(&key);
        if self.admission_history[history_slot] != signature {
            let image = match self.render_without_outline_cache(font, font_size, glyph_id, subpixel_x, normalized_coords) {
                Some(image) => image,
                None => {
                    self.observer.invalid += 1;
                    return None;
                }
            };
            // Color sources and unavailable outlines do not displace useful
            // history. Swash supplies reusable buffers for this first sighting.
            if matches!(image.source, Source::Outline) {
                self.admission_history[history_slot] = signature;
                self.observer.denied += 1;
            } else {
                self.observer.colors += 1;
            }
            return Some(image);
        }

        let mut scale_context = self.scale_context.borrow_mut();
        let mut scaler = scale_context
            .builder(font)
            .size(font_size)
            .hint(true)
            .normalized_coords(normalized_coords)
            .build();

        if let Some(image) = Render::new(&COLOR_SOURCES)
            .format(Format::Alpha)
            .offset(Vector::new(subpixel_x, 0.0))
            .render(&mut scaler, glyph_id)
        {
            self.observer.colors += 1;
            return Some(image);
        }

        if !scaler.has_outlines() {
            self.observer.invalid += 1;
            return None;
        }
        let outline = match scaler.scale_outline(glyph_id) {
            Some(outline) => outline,
            None => {
                self.observer.invalid += 1;
                return None;
            }
        };
        drop(scale_context);
        let image = rasterize(&outline, &mut self.scratch, subpixel_x);
        self.insert_outline(key, outline);
        Some(image)
    }

    /// Swash keeps reusable outline and rasterization buffers on this path.
    /// Use it when an outline isn't going to be retained by our cache.
    fn render_without_outline_cache(
        &mut self,
        font: FontRef<'_>,
        font_size: f32,
        glyph_id: u16,
        subpixel_x: f32,
        normalized_coords: &[i16],
    ) -> Option<Image> {
        let mut scale_context = self.scale_context.borrow_mut();
        let mut scaler = scale_context
            .builder(font)
            .size(font_size)
            .hint(true)
            .normalized_coords(normalized_coords)
            .build();
        Render::new(&SOURCES)
            .format(Format::Alpha)
            .offset(Vector::new(subpixel_x, 0.0))
            .render(&mut scaler, glyph_id)
    }

    /// Caches an outline, first emptying the cache if the entry wouldn't fit
    /// in what remains of the budget. An entry larger than the whole budget
    /// isn't cached.
    fn insert_outline(&mut self, key: OutlineKey<'_>, outline: Outline) {
        let bytes = entry_bytes(&key, &outline);
        if bytes > self.outline_budget {
            self.observer.oversized += 1;
            return;
        }
        if self.outline_bytes + bytes > self.outline_budget {
            self.outlines.clear();
            self.observer.clears += 1;
            self.outline_bytes = 0;
        }
        self.outline_bytes += bytes;
        self.observer.insertions += 1;
        self.observer.peak_logical_bytes = self.observer.peak_logical_bytes.max(self.outline_bytes);
        self.outlines.insert(key.into_owned(), outline);
    }
}

/// A hash collision can admit an outline early, but the cache still compares
/// full keys before reusing any geometry. Zero marks an unused history slot.
/// The original low bit remains part of the slot index, so forcing it into the
/// signature does not discard a bit from the (slot, signature) pair.
fn admission_location(key: &OutlineKey<'_>) -> (usize, u64) {
    let mut hasher = fnv::FnvHasher::default();
    key.hash(&mut hasher);
    let hash = hasher.finish();
    (hash as usize & (ADMISSION_HISTORY_ENTRIES - 1), hash | 1)
}

/// Approximate bytes a cache entry holds: its key and outline, the key's
/// coordinates, and the outline's points and verbs. Unused vector capacity,
/// the outline's layer records, the map's spare buckets and allocator
/// overhead aren't counted.
fn entry_bytes(key: &OutlineKey<'_>, outline: &Outline) -> usize {
    size_of::<OutlineKey>()
        + size_of::<Outline>()
        + size_of_val(&*key.normalized_coords)
        + size_of_val(outline.points())
        + size_of_val(outline.verbs())
}

/// Rasterizes an outline as `Render` does for `Source::Outline` in `Format::Alpha`.
fn rasterize(outline: &Outline, scratch: &mut Scratch, subpixel_x: f32) -> Image {
    let offset = Vector::new(subpixel_x, 0.0);
    let mut image = Image::new();
    image.placement = Mask::with_scratch(outline.path(), scratch)
        .format(Format::Alpha)
        .origin(Origin::BottomLeft)
        .offset(offset)
        .render_offset(offset)
        .inspect(|format, width, height| image.data.resize(format.buffer_size(width, height), 0))
        .render_into(&mut image.data[..], None);
    image.content = Content::Mask;
    image.source = Source::Outline;
    image
}

#[cfg(test)]
mod tests {
    use super::*;

    fn read_font(file: &str) -> Vec<u8> {
        let path = format!("{}/examples/assets/{file}", env!("CARGO_MANIFEST_DIR"));
        std::fs::read(&path).unwrap_or_else(|err| panic!("{path}: {err}"))
    }

    /// The offsets `GlyphAtlas::render_atlas` passes: the fractional part of a
    /// glyph's position, quantized to tenths.
    fn subpixel_offsets() -> impl Iterator<Item = f32> {
        (-9..=10).map(|tenths| tenths as f32 / 10.0)
    }

    /// Renders through swash's `Render` alone, with no outline cache: the
    /// reference `SwashRasterizer::render` must match.
    fn render_uncached(
        context: &mut ScaleContext,
        font: FontRef<'_>,
        font_size: f32,
        glyph_id: u16,
        subpixel_x: f32,
        normalized_coords: &[i16],
    ) -> Option<Image> {
        let mut scaler = context
            .builder(font)
            .size(font_size)
            .hint(true)
            .normalized_coords(normalized_coords)
            .build();
        Render::new(&[
            Source::ColorOutline(0),
            Source::ColorBitmap(StrikeWith::BestFit),
            Source::Outline,
        ])
        .format(Format::Alpha)
        .offset(Vector::new(subpixel_x, 0.0))
        .render(&mut scaler, glyph_id)
    }

    /// What caching the glyph's hinted outline charges against the budget.
    fn cached_bytes(font: FontRef<'_>, font_size: f32, glyph_id: u16, normalized_coords: &[i16]) -> usize {
        let mut context = ScaleContext::new();
        let mut scaler = context
            .builder(font)
            .size(font_size)
            .hint(true)
            .normalized_coords(normalized_coords)
            .build();
        let key = OutlineKey {
            font: font.key,
            glyph_id,
            font_size: font_size.to_bits(),
            normalized_coords: normalized_coords.into(),
        };
        entry_bytes(&key, &scaler.scale_outline(glyph_id).unwrap())
    }

    fn placement(image: &Image) -> (i32, i32, u32, u32) {
        let p = image.placement;
        (p.left, p.top, p.width, p.height)
    }

    fn rasterizer() -> SwashRasterizer {
        SwashRasterizer::new(Rc::default())
    }

    fn assert_same_image(actual: Option<&Image>, expected: Option<&Image>, case: &str) {
        let (actual, expected) = match (actual, expected) {
            (Some(actual), Some(expected)) => (actual, expected),
            (None, None) => return,
            (actual, expected) => panic!("{case}: rendered {}, expected {}", actual.is_some(), expected.is_some()),
        };
        assert_eq!(placement(actual), placement(expected), "{case}: placement");
        assert_eq!(actual.content, expected.content, "{case}: content");
        assert_eq!(
            format!("{:?}", actual.source),
            format!("{:?}", expected.source),
            "{case}: source"
        );
        assert!(actual.data == expected.data, "{case}: coverage differs");
    }

    struct Face {
        name: &'static str,
        data: Vec<u8>,
        glyph_ids: std::ops::Range<u16>,
        /// Normalized coordinates to render at; the face's default instance is empty.
        instances: Vec<Vec<i16>>,
    }

    fn faces() -> Vec<Face> {
        let roboto = read_font("RobotoFlex-VariableFont.ttf");
        let axis_count = FontRef::from_index(&roboto, 0).unwrap().variations().len();
        // F2Dot14: halfway along the first axis, a quarter back along the last.
        let mut roboto_instance = vec![0; axis_count];
        roboto_instance[0] = 0x2000;
        roboto_instance[axis_count - 1] = -0x1000;

        vec![
            Face {
                name: "Roboto Flex",
                data: roboto,
                glyph_ids: 0..80,
                instances: vec![Vec::new(), roboto_instance],
            },
            Face {
                name: "Amiri",
                data: read_font("amiri-regular.ttf"),
                glyph_ids: 0..80,
                instances: vec![Vec::new()],
            },
            Face {
                name: "Entypo",
                data: read_font("entypo.ttf"),
                glyph_ids: 0..40,
                instances: vec![Vec::new()],
            },
            Face {
                name: "Bungee Color subset",
                data: read_font("BungeeColor-Subset.ttf"),
                // Glyph 9 is past the last glyph, 8.
                glyph_ids: 0..10,
                instances: vec![Vec::new()],
            },
        ]
    }

    // One rasterizer serves every face, instance and size, so an outline cached
    // under a key that left out the face, the size or the coordinates, or that
    // rounded the size, would be reused for another glyph and fail the
    // comparison.
    #[test]
    fn renders_like_swash_render_at_every_subpixel_offset() {
        let faces = faces();
        let mut rasterizer = rasterizer();
        let mut context = ScaleContext::new();

        for face in &faces {
            let font = FontRef::from_index(&face.data, 0).unwrap();
            for coords in &face.instances {
                for font_size in [9.0, 12.0, 16.1, 16.5, 16.9, 40.0] {
                    for glyph_id in face.glyph_ids.clone() {
                        for subpixel_x in subpixel_offsets() {
                            let actual = rasterizer.render(font, font_size, glyph_id, subpixel_x, coords);
                            let expected = render_uncached(&mut context, font, font_size, glyph_id, subpixel_x, coords);
                            let case = format!(
                                "{} {coords:?} glyph {glyph_id} at {font_size}px, offset {subpixel_x}",
                                face.name
                            );
                            assert_same_image(actual.as_ref(), expected.as_ref(), &case);
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn color_glyphs_render_from_color_sources_and_are_not_cached() {
        // BungeeColor-Subset.ttf is Bungee Color Regular, Version 1.000, from
        // google/fonts ofl/bungeecolor, SHA-256
        // cf21a786e54f43694f4edbb51a38f81331a4c3414217c524c8cb2d091aa7fd63,
        // subset with fontTools 4.59.1:
        //   pyftsubset BungeeColor-Regular.ttf --unicodes=U+0020,U+0041 \
        //     --layout-features='' --drop-tables+=DSIG,GSUB,GPOS --name-IDs='*'
        // Glyph 2 is A, whose COLR layers are glyphs 7 and 8.
        const COLOR_A: u16 = 2;
        const LAYER_OF_A: u16 = 7;

        let data = read_font("BungeeColor-Subset.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let mut rasterizer = rasterizer();

        let color = rasterizer.render(font, 24.0, COLOR_A, 0.3, &[]).unwrap();
        assert_eq!(color.content, Content::Color);
        assert!(matches!(color.source, Source::ColorOutline(0)));
        assert!(rasterizer.outlines.is_empty());

        // A layer glyph has no color layers of its own, so even in a color
        // face it renders from, and caches, its plain outline.
        let layer = rasterizer.render(font, 24.0, LAYER_OF_A, 0.3, &[]).unwrap();
        assert_eq!(layer.content, Content::Mask);
        assert!(matches!(layer.source, Source::Outline));
        assert!(rasterizer.outlines.is_empty(), "first outline sighting is not retained");
        rasterizer.render(font, 24.0, LAYER_OF_A, 0.4, &[]).unwrap();
        assert_eq!(rasterizer.outlines.len(), 1);
    }

    #[test]
    fn subpixel_offsets_reuse_the_cached_outline() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let glyph_id = font.charmap().map('g');
        let mut rasterizer = rasterizer();

        let first = rasterizer.render(font, 16.0, glyph_id, 0.0, &[]).unwrap();
        assert!(first.data.iter().any(|&coverage| coverage > 0));
        assert!(
            rasterizer.outlines.is_empty(),
            "first sighting uses Swash's reusable outline"
        );

        let mut context = ScaleContext::new();
        assert_same_image(
            Some(&first),
            render_uncached(&mut context, font, 16.0, glyph_id, 0.0, &[]).as_ref(),
            "first sighting",
        );
        let second = rasterizer.render(font, 16.0, glyph_id, 0.1, &[]).unwrap();
        assert_same_image(
            Some(&second),
            render_uncached(&mut context, font, 16.0, glyph_id, 0.1, &[]).as_ref(),
            "second sighting",
        );

        // Swap the cached outline for an empty one: renders at every offset must
        // then cover nothing, which they only do if they skip hinting.
        assert_eq!(rasterizer.outlines.len(), 1);
        for cached in rasterizer.outlines.values_mut() {
            *cached = Outline::new();
        }

        for subpixel_x in subpixel_offsets() {
            let image = rasterizer.render(font, 16.0, glyph_id, subpixel_x, &[]).unwrap();
            assert!(image.data.iter().all(|&coverage| coverage == 0), "offset {subpixel_x}");
        }
    }

    #[test]
    fn cache_empties_when_an_outline_would_exceed_the_budget() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let [a, b, c] = ['a', 'b', 'c'].map(|ch| font.charmap().map(ch));
        let [a_bytes, b_bytes, c_bytes] = [a, b, c].map(|id| cached_bytes(font, 16.0, id, &[]));

        let mut rasterizer = SwashRasterizer::with_outline_budget(Rc::default(), a_bytes + b_bytes);
        rasterizer.render(font, 16.0, a, 0.0, &[]);
        rasterizer.render(font, 16.0, a, 0.1, &[]);
        rasterizer.render(font, 16.0, b, 0.0, &[]);
        rasterizer.render(font, 16.0, b, 0.1, &[]);
        assert_eq!(rasterizer.outlines.len(), 2, "a and b fill the budget exactly");
        assert_eq!(rasterizer.outline_bytes, a_bytes + b_bytes);

        rasterizer.render(font, 16.0, c, 0.0, &[]);
        rasterizer.render(font, 16.0, c, 0.1, &[]);
        assert_eq!(
            rasterizer.outlines.len(),
            1,
            "c doesn't fit, so the cache empties first"
        );
        assert_eq!(rasterizer.outline_bytes, c_bytes);

        // Prior sightings remain useful after the outlined entries are evicted.
        // Neither a nor b needs two more uncached observations to be admitted.
        let expected_bytes = if c_bytes + a_bytes > a_bytes + b_bytes {
            a_bytes
        } else {
            c_bytes + a_bytes
        };
        rasterizer.render(font, 16.0, a, 0.2, &[]);
        assert_eq!(rasterizer.outline_bytes, expected_bytes);
    }

    // A whitespace glyph's outline has no points or verbs, but its entry still
    // takes memory, so it must count toward the budget like any other.
    #[test]
    fn empty_outlines_count_toward_the_budget() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let space = font.charmap().map(' ');
        let mut coords = vec![0; font.variations().len()];
        let space_bytes = cached_bytes(font, 16.0, space, &coords);
        assert!(space_bytes > 0);
        assert_eq!(
            space_bytes - cached_bytes(font, 16.0, space, &[]),
            size_of_val(&coords[..]),
            "coordinates are charged by their length"
        );

        let mut rasterizer = SwashRasterizer::with_outline_budget(Rc::default(), 4 * space_bytes);
        let mut context = ScaleContext::new();
        for first_axis in 0..20 {
            coords[0] = first_axis * 0x100;
            let actual = rasterizer.render(font, 16.0, space, 0.0, &coords);
            let expected = render_uncached(&mut context, font, 16.0, space, 0.0, &coords);
            assert_same_image(actual.as_ref(), expected.as_ref(), &format!("space at {coords:?}"));
            let actual = rasterizer.render(font, 16.0, space, 0.1, &coords);
            let expected = render_uncached(&mut context, font, 16.0, space, 0.1, &coords);
            assert_same_image(
                actual.as_ref(),
                expected.as_ref(),
                &format!("second space at {coords:?}"),
            );
            assert!(rasterizer.outlines.len() <= 4, "{} entries", rasterizer.outlines.len());
            assert_eq!(rasterizer.outline_bytes, rasterizer.outlines.len() * space_bytes);
        }
    }

    #[test]
    fn outlines_larger_than_the_budget_are_not_cached() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let glyph_id = font.charmap().map('g');

        let mut rasterizer = SwashRasterizer::with_outline_budget(Rc::default(), 1);
        let image = rasterizer.render(font, 16.0, glyph_id, 0.0, &[]).unwrap();
        assert!(image.placement.width > 0);
        let image = rasterizer.render(font, 16.0, glyph_id, 0.1, &[]).unwrap();
        assert!(image.placement.width > 0);
        assert!(rasterizer.outlines.is_empty());
        assert_eq!(rasterizer.outline_bytes, 0);
    }

    #[test]
    fn zero_budget_delegates_to_swash_render() {
        let faces = faces();
        let mut rasterizer = SwashRasterizer::with_outline_budget(Rc::default(), 0);
        let mut context = ScaleContext::new();
        for face in &faces {
            let font = FontRef::from_index(&face.data, 0).unwrap();
            for coords in &face.instances {
                for glyph_id in face.glyph_ids.clone().step_by(7) {
                    for subpixel_x in [0.0, 0.1, 0.9] {
                        let actual = rasterizer.render(font, 16.5, glyph_id, subpixel_x, coords);
                        let expected = render_uncached(&mut context, font, 16.5, glyph_id, subpixel_x, coords);
                        assert_same_image(actual.as_ref(), expected.as_ref(), face.name);
                    }
                }
            }
        }
        assert!(rasterizer.outlines.is_empty());
        assert_eq!(rasterizer.outline_bytes, 0);
    }

    #[test]
    fn admission_and_cached_geometry_keep_faces_sizes_glyphs_and_instances_distinct() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let other_face = FontRef::from_index(&data, 0).unwrap();
        let glyph_id = font.charmap().map('g');
        let other_glyph = font.charmap().map('b');
        let mut instance = vec![0; font.variations().len()];
        instance[0] = 0x2000;
        let mut rasterizer = rasterizer();
        rasterizer.render(font, 16.0, glyph_id, 0.0, &[]).unwrap();
        rasterizer.render(font, 16.0, glyph_id, 0.1, &[]).unwrap();
        for cached in rasterizer.outlines.values_mut() {
            *cached = Outline::new();
        }

        let mut context = ScaleContext::new();
        let cases = [
            (other_face, 16.0, glyph_id, Vec::new()),
            (font, 16.1, glyph_id, Vec::new()),
            (font, 16.0, other_glyph, Vec::new()),
            (font, 16.0, glyph_id, instance),
        ];
        for (face, size, glyph, coords) in cases {
            let before = rasterizer.outlines.len();
            for offset in [0.2, 0.3] {
                let actual = rasterizer.render(face, size, glyph, offset, &coords);
                let expected = render_uncached(&mut context, face, size, glyph, offset, &coords);
                assert_same_image(
                    actual.as_ref(),
                    expected.as_ref(),
                    &format!(
                        "face {:?}, size {size}, glyph {glyph}, coords {coords:?}, phase {offset}",
                        face.key
                    ),
                );
                if offset == 0.2 {
                    assert_eq!(rasterizer.outlines.len(), before, "distinct key has no prior sighting");
                }
            }
            assert_eq!(
                rasterizer.outlines.len(),
                before + 1,
                "second sighting admits the distinct key"
            );
        }
    }

    #[test]
    fn a_history_fingerprint_collision_only_admits_early() {
        let data = read_font("RobotoFlex-VariableFont.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let [a, b] = ['a', 'b'].map(|ch| font.charmap().map(ch));
        let mut rasterizer = rasterizer();
        rasterizer.render(font, 16.0, a, 0.0, &[]).unwrap();
        rasterizer.render(font, 16.0, a, 0.1, &[]).unwrap();
        for cached in rasterizer.outlines.values_mut() {
            *cached = Outline::new();
        }

        let key = OutlineKey {
            font: font.key,
            glyph_id: b,
            font_size: 16.0_f32.to_bits(),
            normalized_coords: Cow::Borrowed(&[]),
        };
        let (slot, signature) = admission_location(&key);
        // Simulate another key leaving the same fingerprint. This can grant
        // admission, but cannot make the empty cached outline for a match b.
        rasterizer.admission_history[slot] = signature;
        let actual = rasterizer.render(font, 16.0, b, 0.2, &[]);
        let expected = render_uncached(&mut ScaleContext::new(), font, 16.0, b, 0.2, &[]);
        assert_same_image(actual.as_ref(), expected.as_ref(), "fingerprint collision");
        assert_eq!(rasterizer.outlines.len(), 2);
        assert!(rasterizer.outlines.contains_key(&key));
    }

    #[test]
    fn color_glyphs_invalid_glyphs_and_disabled_caching_leave_history_untouched() {
        let data = read_font("BungeeColor-Subset.ttf");
        let font = FontRef::from_index(&data, 0).unwrap();
        let mut rasterizer = rasterizer();
        rasterizer.admission_history[17] = 42;
        let initial = rasterizer.admission_history;
        for offset in [0.0, 0.1, 0.2] {
            let color = rasterizer.render(font, 24.0, 2, offset, &[]).unwrap();
            assert_eq!(color.content, Content::Color);
            assert!(rasterizer.render(font, 24.0, 9, offset, &[]).is_none());
        }
        assert_eq!(rasterizer.admission_history, initial);
        assert!(rasterizer.outlines.is_empty());

        rasterizer.outline_budget = 0;
        let mask = rasterizer.render(font, 24.0, 7, 0.3, &[]).unwrap();
        assert_eq!(mask.content, Content::Mask);
        assert_eq!(rasterizer.admission_history, initial);
        assert!(rasterizer.outlines.is_empty());
    }
}
