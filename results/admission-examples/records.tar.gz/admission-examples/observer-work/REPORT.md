# Untimed mechanism check

All 18 CPU observer configurations completed: three cache variants, three font
factors (Roboto Flex, Vollkorn Medium, PT Sans Regular), and DPR 1 and 2. All 558
phase records are retained. The observer adds counters in separate source copies
and removes every timer from its runner. No observer result is performance
evidence. Primary source, runner, manifest, and lock hashes stayed unchanged.

The controlled singleton, unique-size, and unique-variation scenes have zero
outline hits in every configuration. They make 94, 3,008, and 3,008 requests,
respectively. Current and optimized eager caching retain their unused outlines;
the admission experiment retains no outlines for these scenes. Its history still
occupies the separately recorded fixed 16,384 bytes. The variable-coordinate
control always uses Roboto Flex regardless of the selected regular-text font.

Exactly two subpixel phases confirm the expected CPU tradeoff. Current and
optimized eager caching hit all 94 outlines on the second phase. Admission hits
none: that phase can populate the cache, and only a subsequent phase can benefit.
Roboto and PT Sans admit all 94 keys; Vollkorn admits 90, with four additional
denials caused by direct-mapped history slots replacing earlier sightings.

The pollution scene returns to the hot glyphs after 6,016 unique glyph-size keys:

| Regular text font | Current pollution clears | Optimized pollution clears | Admission pollution clears | Current/optimized hot-return hits | Admission hot-return hits |
| --- | ---: | ---: | ---: | ---: | ---: |
| Roboto Flex | 2 | 2 | 0 | 0 / 94 | 94 / 94 |
| Vollkorn Medium | 3 | 3 | 0 | 0 / 94 | 90 / 94 |
| PT Sans Regular | 2 | 2 | 0 | 0 / 94 | 94 / 94 |

These counts are the same at both DPR settings. Admission inserts no pollution
outline and retains every hot key that actually entered its cache. The four
missing Vollkorn hot keys were never admitted; pollution did not evict them.
No full fingerprint collision causing premature admission was observed in these
unique-key scenes. The bounded history's index collisions are nevertheless
measurable even for 94 hot keys, so “admit every second use” would overstate this
approximate policy.

The larger Cow key is charged rather than hidden: retaining the same 94 outlines
uses 752 more logical bytes (eight per key). At the same 1 MiB logical cap this
changes full-clear alignment. In the Vollkorn hot-return phase, optimized eager
caching clears once more while current eager caching does not; both have zero
hot-return hits. Other footprint differences after pollution can likewise reflect
where the final clear landed, rather than a different outline payload.

Two preparation/validation corrections are preserved. The initial observer build
failed because accessor documentation attached to the newly inserted method;
the helper and observer copies were repaired and the initial log/provenance
archived. After all 18 traces completed, the initial validation incorrectly
expected all 94 admission hot-return requests to hit. Validation now checks
retention against the actually admitted hot set. No runtime trace was rerun,
excluded, or altered.

Evidence:

- `comparison.csv`: all measured phase counters.
- `mechanism-validation.json`: checked identities, bounds, and per-configuration
  controlled counts.
- `traces/`: all raw stdout and stderr from the 18 launches.
- `preparation.json`, `build-provenance.json`, `execution-provenance.json`:
  frozen inputs, instrumented source hashes, commands, binary hashes, font hashes,
  and successful process exits.
- `failed-build-current-01.log`, `preparation-initial.json`, and
  `execution-provenance-initial-validation.json`: initial diagnostic failures.
