#!/usr/bin/env python3
"""Prepare isolated, untimed outline-cache observers; never build or execute.

Requires the root agent's replay-sources and runner to have been prepared.
All instrumented files live under observer-work. Primary inputs are hashed
before and after preparation and must remain unchanged.
"""

from pathlib import Path
import hashlib
import json
import re
import shutil


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "observer-work"
VARIANTS = ("current", "optimized", "admission")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hashes(directory):
    return {str(p.relative_to(directory)): sha(p) for p in sorted((directory / "src").rglob("*.rs"))}


def primary_inputs():
    result = {variant: source_hashes(ROOT / "replay-sources" / variant) for variant in VARIANTS}
    for variant in VARIANTS:
        if "src/text/swash_rasterizer.rs" not in result[variant]:
            raise ValueError(f"replay-sources/{variant} is not ready")
    result["runner"] = source_hashes(ROOT / "runner")
    result["runner_manifest"] = sha(ROOT / "runner/Cargo.toml")
    result["runner_lock"] = sha(ROOT / "runner/Cargo.lock")
    return result


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f"expected one source match for {old[:100]!r}; found {text.count(old)}")
    return text.replace(old, new, 1)


OBSERVER_STRUCT = '''#[derive(Default)]
struct OutlineObserverStats {
    requests: u64,
    hits: u64,
    misses: u64,
    denied: u64,
    insertions: u64,
    clears: u64,
    colors: u64,
    invalid: u64,
    oversized: u64,
    peak_logical_bytes: usize,
}

'''


def instrument_rasterizer(path, variant):
    text = path.read_text()
    text = replace_once(text, "/// Renders glyphs with swash.", OBSERVER_STRUCT + "/// Renders glyphs with swash.")
    text = replace_once(text, "    outline_budget: usize,\n", "    outline_budget: usize,\n    observer: OutlineObserverStats,\n")
    text = replace_once(text, "            outline_budget,\n", "            outline_budget,\n            observer: OutlineObserverStats::default(),\n")
    marker = re.search(r"pub\(crate\) fn render\([\s\S]*?\) -> Option<Image> \{", text)
    if marker is None:
        raise ValueError("render entry point is missing")
    text = text[:marker.end()] + "\n        self.observer.requests += 1;" + text[marker.end():]
    text = replace_once(text,
        "        if let Some(outline) = self.outlines.get(&key) {\n            return Some(rasterize(outline, &mut self.scratch, subpixel_x));\n        }",
        "        if let Some(outline) = self.outlines.get(&key) {\n            self.observer.hits += 1;\n            return Some(rasterize(outline, &mut self.scratch, subpixel_x));\n        }\n        self.observer.misses += 1;")
    if variant == "admission":
        text = replace_once(text,
            "            let image = self.render_without_outline_cache(font, font_size, glyph_id, subpixel_x, normalized_coords)?;",
            '''            let image = match self.render_without_outline_cache(font, font_size, glyph_id, subpixel_x, normalized_coords) {
                Some(image) => image,
                None => {
                    self.observer.invalid += 1;
                    return None;
                }
            };''')
        text = replace_once(text,
            "                self.admission_history[history_slot] = signature;\n            }\n            return Some(image);",
            "                self.admission_history[history_slot] = signature;\n                self.observer.denied += 1;\n            } else {\n                self.observer.colors += 1;\n            }\n            return Some(image);")
    text = replace_once(text,
        "        {\n            return Some(image);\n        }\n\n        if !scaler.has_outlines()",
        "        {\n            self.observer.colors += 1;\n            return Some(image);\n        }\n\n        if !scaler.has_outlines()")
    text = replace_once(text,
        "        if !scaler.has_outlines() {\n            return None;\n        }",
        "        if !scaler.has_outlines() {\n            self.observer.invalid += 1;\n            return None;\n        }")
    text = replace_once(text,
        "        let outline = scaler.scale_outline(glyph_id)?;",
        '''        let outline = match scaler.scale_outline(glyph_id) {
            Some(outline) => outline,
            None => {
                self.observer.invalid += 1;
                return None;
            }
        };''')
    text = replace_once(text,
        "        if bytes > self.outline_budget {\n            return;\n        }",
        "        if bytes > self.outline_budget {\n            self.observer.oversized += 1;\n            return;\n        }")
    text = replace_once(text,
        "            self.outlines.clear();\n            self.outline_bytes = 0;",
        "            self.outlines.clear();\n            self.observer.clears += 1;\n            self.outline_bytes = 0;")
    text = replace_once(text,
        "        self.outline_bytes += bytes;",
        "        self.outline_bytes += bytes;\n        self.observer.insertions += 1;\n        self.observer.peak_logical_bytes = self.observer.peak_logical_bytes.max(self.outline_bytes);")
    history_bytes = "(ADMISSION_HISTORY_ENTRIES * size_of::<u64>()) as u64" if variant == "admission" else "0"
    method = '''    /// Observer-only counters, reset between phases. Retained cache and history
    /// are unchanged; a phase's peak begins at its current retained footprint.
    pub(crate) fn take_observer_stats(&mut self) -> [u64; 13] {
        let stats = [
            self.observer.requests, self.observer.hits, self.observer.misses,
            self.observer.denied, self.observer.insertions, self.observer.clears,
            self.outline_bytes as u64, self.observer.peak_logical_bytes as u64,
            self.outlines.len() as u64, HISTORY_BYTES,
            self.observer.colors, self.observer.invalid, self.observer.oversized,
        ];
        self.observer = OutlineObserverStats {
            peak_logical_bytes: self.outline_bytes,
            ..OutlineObserverStats::default()
        };
        stats
    }

'''.replace("HISTORY_BYTES", history_bytes)
    text = replace_once(text, "impl SwashRasterizer {\n", "impl SwashRasterizer {\n" + method)
    path.write_text(text)


def instrument_canvas(path):
    text = path.read_text()
    marker = "    #[doc(hidden)]\n    /// Counts glyph-atlas entries for benchmark validation.\n    pub fn benchmark_atlas_entries(&self) -> usize {"
    method = '''    #[doc(hidden)]
    /// Retrieves and resets outline observer counters without clearing caches.
    #[cfg(feature = "swash")]
    pub fn benchmark_outline_observer_stats(&self) -> [u64; 13] {
        let rasterizer = self.text_context.borrow().swash_rasterizer();
        let stats = rasterizer.borrow_mut().take_observer_stats();
        stats
    }

'''
    text = replace_once(text, marker, method + marker)
    path.write_text(text)


def instrument_runner(path):
    text = path.read_text()
    text = replace_once(text, "use std::{time::Instant, path::PathBuf};", "use std::path::PathBuf;")
    text = replace_once(text, "../../snapshots/master/tests/common/mod.rs", str(ROOT / "snapshots/master/tests/common/mod.rs"))
    start = text.index("struct Measurement")
    end = text.index("fn run<T: Renderer>", start)
    text = text[:start] + '''struct Measurement { misses: usize }
fn frame<T: Renderer>(c: &mut Canvas<T>, s: &mut Scene, f: &mut Frame, dpi: f32,
    flush: &mut impl FnMut(&mut Canvas<T>, Frame), wait: &mut impl FnMut()) -> Measurement {
    let before = c.benchmark_atlas_entries();
    c.set_size(f.width, f.height, dpi);
    s.draw(c, *f);
    flush(c, *f);
    wait();
    let after = c.benchmark_atlas_entries();
    f.index += 1;
    Measurement { misses: after - before }
}
fn emit<T: Renderer>(name: &str, phase: &str, trial: usize, frames: &[Measurement], c: &Canvas<T>) {
    let [requests, hits, misses, denied, insertions, clears, bytes, peak, entries,
         history, colors, invalid, oversized] = c.benchmark_outline_observer_stats();
    println!("{name},{phase},{trial},{},{},{requests},{hits},{misses},{denied},{insertions},{clears},{bytes},{peak},{entries},{history},{colors},{invalid},{oversized}",
        frames.len(), frames.iter().map(|r| r.misses).sum::<usize>());
}
''' + text[end:]
    text = replace_once(text, 'emit(name,"first_paint",trial,&[first]);', 'emit(name,"first_paint",trial,&[first],&c);')
    text = replace_once(text,
        '    for _ in 1..120 {frame(&mut c,&mut s,&mut f,dpi,&mut flush,&mut wait);}',
        '''    let warmup = (1..120).map(|_|frame(&mut c,&mut s,&mut f,dpi,&mut flush,&mut wait)).collect::<Vec<_>>();
    emit(name,"warmup",trial,&warmup,&c);''')
    text = replace_once(text, 'emit(name,"warm",trial,&steady);', 'emit(name,"warm",trial,&steady,&c);')
    text = replace_once(text, 'emit(name,phase,trial,&results);', 'emit(name,phase,trial,&results,&c);')
    text = replace_once(text, 'emit(name,phase,trial,&measurements);', 'emit(name,phase,trial,&measurements,&c);')
    # The controlled loop repeats drawing and flushing exactly as the timed
    # runner does, but the observer has no timers and reports no durations.
    text = replace_once(text, '            let start=Instant::now();\n', '')
    text = replace_once(text, '            let draw=start.elapsed().as_secs_f64()*1e6;\n', '')
    text = replace_once(text, '            let submit=start.elapsed().as_secs_f64()*1e6;\n', '')
    text = replace_once(text, '            let complete=start.elapsed().as_secs_f64()*1e6;\n', '')
    text = replace_once(text,
        '            measurements.push(Measurement {draw,submit,complete,misses:after-before});',
        '            measurements.push(Measurement {misses:after-before});')
    text = replace_once(text,
        'scene,phase,trial,frames,draw_us,submit_us,complete_us,new_atlas_entries',
        'scene,phase,trial,frames,new_atlas_entries,requests,hits,misses,denied,insertions,clears,current_logical_bytes,peak_logical_bytes,outline_entries,history_bytes,colors,invalid,oversized')
    if "Instant" in text or "elapsed()" in text:
        raise ValueError("untimed runner still contains a timer")
    path.write_text(text)


def prepare():
    before = primary_inputs()
    provenance = WORK / "preparation.json"
    if WORK.exists():
        if not provenance.exists() or json.loads(provenance.read_text())["primary_inputs"] != before:
            raise ValueError("observer-work already exists with different or incomplete preparation")
        return before
    WORK.mkdir()
    modified = {}
    for variant in VARIANTS:
        destination = WORK / "observer-sources" / variant
        shutil.copytree(ROOT / "replay-sources" / variant, destination)
        instrument_rasterizer(destination / "src/text/swash_rasterizer.rs", variant)
        instrument_canvas(destination / "src/lib.rs")
        modified[variant] = source_hashes(destination)
    runner = WORK / "observer-runner"
    shutil.copytree(ROOT / "runner", runner)
    manifest = runner / "Cargo.toml"
    manifest.write_text(replace_once(manifest.read_text(), "../replay-sources/current", "../observer-sources/current"))
    instrument_runner(runner / "src/main.rs")
    if primary_inputs() != before:
        raise ValueError("primary sources changed during observer preparation")
    provenance.write_text(json.dumps({
        "mode": "untimed observer only; no build or run performed",
        "primary_inputs": before,
        "observer_sources": modified,
        "observer_runner": source_hashes(runner),
        "observer_runner_manifest": sha(manifest),
        "observer_runner_lock": sha(runner / "Cargo.lock"),
        "counters": "phase deltas; peak starts at retained bytes at phase entry",
        "history_memory_separate": "admission only: 16,384 bytes",
    }, indent=2) + "\n")
    return before


if __name__ == "__main__":
    prepare()
    print(f"Prepared isolated untimed observer at {WORK}; nothing built or executed")
