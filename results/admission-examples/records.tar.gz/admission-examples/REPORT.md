# Outline-cache strategy comparison

Selected strategy: retain the original 1 MiB eager outline cache. Keep repeat-before-admission experimental and leave the Cow lookup candidate out of the selected patch. The comparisons below explain the performance and storage tradeoffs.

The production implementation is restored to the original eager patch. The working tree has no tracked changes relative to HEAD; the original cache patch remains the diff against master. The Swash rasterizer matches the frozen current source, all 164 library tests pass with Swash enabled, and formatting checks pass. Both prototypes and every benchmark result remain preserved; no commit was made.

The Cow candidate has measured gains that remain part of the evidence: PT Sans Alustin/WGPU first-render CPU changes by -2.5% [-6.1, -0.4]; the other Alustin first-render intervals span zero in 5 of five cases. Stock Roboto text `x_return` changes by -1.3% [-3.7, -0.5]. PT Sans is static and passes empty variation coordinates, whose previous key already needed no coordinate allocation; its improvement cannot establish that borrowed-coordinate lookup alone caused the gain. The selected strategy weighs these mixed, mostly small gains against a larger key and changed capacity boundaries. The observed extra Vollkorn hot-return clear is real; that phase's timing interval spans zero, so it is not presented as a definitive measured slowdown.

The Cow candidate also raises Roboto's Alustin search-frame CPU by +4.9% [+2.8, +9.9] in WGPU and +3.5% [+2.6, +5.4] in OpenGL, approximately 0.102 ms and 0.075 ms. These are filtered second frames, which can introduce new atlas keys; they are distinct from a completely warm redraw. [Independent Alustin CPU audit](/private/tmp/alustin-admission-review/CPU-STATISTICS-AUDIT.md) preserves the raw paired arithmetic and intervals.

The feature remains Swash-only. Ordinary warm redraws hit the existing glyph atlas and bypass this cache. The tested admission policy improves the cost of storing one-use outlines and protects retained hot outlines during pollution, but it gives up the second atlas miss's scaling savings. Those population costs are included in the complete controlled-sequence comparisons below. No static font-bytecode cutoff follows from these results.

Cells show the median paired duration change and its **95% paired bootstrap interval**, then the median paired absolute change in milliseconds. **Negative means less duration.** `optimized/current` and `admission/current` isolate the candidate strategy from the existing patch; `current/master` is the original patch's incremental benefit. Absolute `master → current` columns show medians of process observations; they need not reproduce the median paired percentage. Full candidate/master comparisons and absolute intervals are retained in the linked CSV/JSON analyses.

## Demo first-paint CPU drawing, DPR 2

| Font | Master → current (ms) | Current/master | Optimized/current | Admission/current |
| --- | --- | --- | --- | --- |
| Roboto Flex | 1.632 → 1.600 | -1.3% [-3.2, +1.3]<br>Δ -0.021 ms | +0.1% [-2.6, +2.5]<br>Δ +0.002 ms | +2.9% [-0.5, +5.2]<br>Δ +0.046 ms |
| Vollkorn Medium | 7.293 → 4.912 | -32.6% [-33.3, -29.9]<br>Δ -2.296 ms | +0.0% [-1.0, +2.8]<br>Δ +0.000 ms | +19.4% [+17.1, +27.4]<br>Δ +0.900 ms |
| PT Sans Regular | 2.208 → 1.879 | -14.5% [-16.5, -11.9]<br>Δ -0.318 ms | +0.6% [-2.7, +3.2]<br>Δ +0.011 ms | +8.4% [+4.1, +10.6]<br>Δ +0.162 ms |

## Demo first paint through GPU completion, DPR 2

| Font | Master → current (ms) | Current/master | Optimized/current | Admission/current |
| --- | --- | --- | --- | --- |
| Roboto Flex | 10.562 → 9.996 | -1.9% [-12.3, +18.9]<br>Δ -0.175 ms | +3.4% [-11.9, +19.0]<br>Δ +0.370 ms | +0.5% [-3.3, +37.6]<br>Δ +0.054 ms |
| Vollkorn Medium | 17.083 → 14.493 | -13.8% [-18.4, -10.2]<br>Δ -2.226 ms | +0.5% [-2.4, +5.2]<br>Δ +0.068 ms | +5.1% [-3.8, +14.3]<br>Δ +0.709 ms |
| PT Sans Regular | 11.580 → 11.376 | -5.0% [-16.4, +2.5]<br>Δ -0.659 ms | -4.6% [-13.5, +8.3]<br>Δ -0.529 ms | +2.9% [-14.1, +16.2]<br>Δ +0.338 ms |

## Alustin first-render renderer-thread CPU

These are `femtovg.render.thread_cpu_ns` spans for the first rendered frame. They measure host renderer-thread work, including component rendering and final flush, rather than GPU completion or displayed-frame latency.

| Font | Backend | Master → current (ms) | Current/master | Optimized/current | Admission/current |
| --- | --- | --- | --- | --- | --- |
| Roboto Flex | WGPU | 13.870 → 13.610 | -1.1% [-7.2, +1.5]<br>Δ -0.154 ms | +1.8% [-1.8, +8.7]<br>Δ +0.236 ms | -0.7% [-2.0, +4.3]<br>Δ -0.093 ms |
| Roboto Flex | OpenGL | 16.015 → 15.716 | -2.0% [-5.4, -0.4]<br>Δ -0.323 ms | -0.4% [-1.2, +4.2]<br>Δ -0.060 ms | +2.6% [+0.5, +5.2]<br>Δ +0.416 ms |
| Vollkorn Medium | WGPU | 21.317 → 16.684 | -23.8% [-24.8, -18.5]<br>Δ -5.036 ms | +0.1% [-4.4, +4.1]<br>Δ +0.019 ms | +11.3% [+7.7, +13.2]<br>Δ +1.796 ms |
| Vollkorn Medium | OpenGL | 23.730 → 19.443 | -17.7% [-19.5, -17.0]<br>Δ -4.184 ms | +0.8% [-3.2, +3.0]<br>Δ +0.163 ms | +8.1% [+7.1, +10.0]<br>Δ +1.585 ms |
| PT Sans Regular | WGPU | 14.202 → 13.968 | -3.0% [-6.8, -0.6]<br>Δ -0.422 ms | -2.5% [-6.1, -0.4]<br>Δ -0.349 ms | +0.7% [-4.5, +5.6]<br>Δ +0.096 ms |
| PT Sans Regular | OpenGL | 16.749 → 16.128 | -3.8% [-6.1, -2.1]<br>Δ -0.632 ms | -0.0% [-1.8, +2.4]<br>Δ -0.008 ms | +2.1% [+1.0, +5.4]<br>Δ +0.343 ms |

## Complete controlled sequences

Each total sums `frames × draw duration` across every phase within an original trial, then takes trial medians within each fresh process and pairs those process medians. The two-phase sequence includes both the first and second request. The pollution sequence includes both hot-population requests, all 64 pollution frames, and the hot-return request. The isolated hot-return speedup is therefore counted together with the earlier admission penalty.

| Regular-font factor | Complete sequence | Frames | Master → current (ms) | Current/master | Optimized/current | Admission/current |
| --- | --- | --- | --- | --- | --- | --- |
| Roboto Flex | Singleton catalogue | 1 | 0.265 → 0.283 | +6.9% [+4.8, +8.9]<br>Δ +0.019 ms | -0.8% [-1.3, +0.6]<br>Δ -0.002 ms | -3.9% [-7.2, -1.2]<br>Δ -0.012 ms |
| Roboto Flex | Two horizontal phases | 2 | 0.404 → 0.382 | -5.1% [-7.3, -3.5]<br>Δ -0.020 ms | +1.1% [-0.2, +3.3]<br>Δ +0.004 ms | +26.1% [+22.9, +32.8]<br>Δ +0.100 ms |
| Roboto Flex | 32 unique sizes | 32 | 6.321 → 7.062 | +12.9% [+11.7, +17.2]<br>Δ +0.803 ms | +0.7% [-1.5, +86.6]<br>Δ +0.048 ms | -10.4% [-16.8, -9.6]<br>Δ -0.733 ms |
| Roboto Flex | 32 unique weights | 32 | 8.520 → 9.316 | +11.7% [+9.6, +14.0]<br>Δ +0.934 ms | -0.0% [-1.4, +16.3]<br>Δ -0.004 ms | -8.1% [-10.0, +78.9]<br>Δ -0.744 ms |
| Roboto Flex | Hot set plus 64-size pollution | 67 | 14.803 → 15.936 | +11.2% [+7.5, +13.9]<br>Δ +1.637 ms | +2.1% [-1.6, +3.3]<br>Δ +0.333 ms | -6.5% [-8.8, -4.4]<br>Δ -1.025 ms |
| Vollkorn Medium | Singleton catalogue | 1 | 1.729 → 1.735 | +1.8% [-0.4, +2.2]<br>Δ +0.032 ms | +0.1% [-2.2, +1.5]<br>Δ +0.002 ms | -1.4% [-3.3, -1.0]<br>Δ -0.025 ms |
| Vollkorn Medium | Two horizontal phases | 2 | 3.177 → 1.891 | -41.0% [-41.2, -39.3]<br>Δ -1.287 ms | -0.2% [-1.6, +1.6]<br>Δ -0.004 ms | +71.9% [+69.1, +77.1]<br>Δ +1.354 ms |
| Vollkorn Medium | 32 unique sizes | 32 | 56.601 → 51.249 | +1.7% [-17.3, +2.5]<br>Δ +0.834 ms | +0.0% [-2.4, +10.1]<br>Δ +0.011 ms | -1.6% [-14.8, +12.5]<br>Δ -0.933 ms |
| Vollkorn Medium | 32 unique weights | 32 | 8.714 → 9.343 | +10.8% [+9.3, +74.4]<br>Δ +0.881 ms | +0.4% [-4.5, +5.7]<br>Δ +0.039 ms | -7.7% [-10.6, -4.9]<br>Δ -0.757 ms |
| Vollkorn Medium | Hot set plus 64-size pollution | 67 | 120.198 → 107.295 | -0.2% [-12.8, +2.2]<br>Δ -0.252 ms | +0.3% [-9.3, +2.3]<br>Δ +0.358 ms | -2.2% [-9.8, +1.0]<br>Δ -2.346 ms |
| PT Sans Regular | Singleton catalogue | 1 | 0.516 → 0.543 | +5.2% [+3.3, +6.6]<br>Δ +0.026 ms | +0.3% [-2.1, +3.5]<br>Δ +0.001 ms | -2.3% [-5.5, -1.1]<br>Δ -0.012 ms |
| PT Sans Regular | Two horizontal phases | 2 | 0.851 → 0.634 | -26.0% [-26.6, -25.0]<br>Δ -0.217 ms | +0.0% [-1.0, +5.1]<br>Δ +0.000 ms | +47.8% [+46.1, +49.7]<br>Δ +0.298 ms |
| PT Sans Regular | 32 unique sizes | 32 | 12.774 → 13.943 | +7.3% [+6.3, +11.3]<br>Δ +0.936 ms | +0.7% [-3.5, +11.2]<br>Δ +0.095 ms | -5.7% [-9.5, -0.8]<br>Δ -0.752 ms |
| PT Sans Regular | 32 unique weights | 32 | 8.543 → 9.481 | +9.7% [+7.9, +13.7]<br>Δ +0.825 ms | +0.4% [-2.2, +9.4]<br>Δ +0.037 ms | -8.8% [-10.9, -6.1]<br>Δ -0.815 ms |
| PT Sans Regular | Hot set plus 64-size pollution | 67 | 28.274 → 29.509 | +4.0% [+3.7, +6.3]<br>Δ +1.131 ms | +1.8% [+0.1, +20.4]<br>Δ +0.513 ms | -4.0% [-6.1, -2.2]<br>Δ -1.176 ms |

Every controlled frame creates 94 distinct atlas entries using 94 nonspace ASCII glyph IDs. Swash supplies the charmap and normalized variation coordinates; setup is outside frame measurement. Catalogue/size/weight keys are single-use; hot requests use fresh horizontal atlas phases 0.0, 0.1, and 0.2. Pollution sizes exclude the hot size. The public glyph-run API accepts explicit canvas coordinates and does not use the high-level text shaping API's DPR normalization, so these glyph-run sizes and phase positions have the same intended key behavior at DPR 1 and 2. Controlled sizes stay below the direct-path threshold. These scenes test caching behavior, with the examples and Alustin providing scene and shaping context. The weight control always uses Roboto Flex; copies under other regular-font factors are repeated controls, not independent font evidence.

## Retained example sequences

All 19 original example phase rows remain in the measurements. These totals include every reported phase from each example, but exclude each scene's 119 unreported warmup frames; they are sums of reported phases rather than full launch-to-end durations.

| Regular-font factor | Example | Reported frames | Master → current (ms) | Current/master | Optimized/current | Admission/current |
| --- | --- | --- | --- | --- | --- | --- |
| Roboto Flex | demo | 65 | 39.932 → 38.649 | -1.4% [-4.1, -0.6]<br>Δ -0.512 ms | +1.2% [-0.3, +38.2]<br>Δ +0.470 ms | +5.4% [+1.8, +27.7]<br>Δ +2.055 ms |
| Roboto Flex | text | 88 | 103.107 → 98.932 | -3.1% [-13.4, -1.9]<br>Δ -3.164 ms | +0.7% [-2.4, +46.4]<br>Δ +0.737 ms | +2.2% [+1.2, +19.9]<br>Δ +3.345 ms |
| Roboto Flex | font_variations | 63 | 11.320 → 11.447 | +1.3% [-0.6, +3.2]<br>Δ +0.149 ms | -1.3% [-39.2, +0.7]<br>Δ -0.150 ms | +0.6% [-26.8, +2.2]<br>Δ +0.063 ms |
| Vollkorn Medium | demo | 65 | 159.112 → 103.079 | -32.3% [-41.8, -27.5]<br>Δ -48.002 ms | -0.0% [-12.0, +2.5]<br>Δ -0.006 ms | +16.4% [+6.5, +23.2]<br>Δ +15.767 ms |
| Vollkorn Medium | text | 88 | 227.938 → 149.725 | -28.3% [-41.2, -26.6]<br>Δ -58.382 ms | +1.1% [+0.1, +12.4]<br>Δ +1.631 ms | +8.9% [-12.5, +28.8]<br>Δ +13.362 ms |
| Vollkorn Medium | font_variations | 63 | 11.766 → 11.613 | +2.3% [-15.9, +4.2]<br>Δ +0.255 ms | +0.3% [-6.9, +1.6]<br>Δ +0.037 ms | +1.2% [-8.0, +9.1]<br>Δ +0.130 ms |
| PT Sans Regular | demo | 65 | 51.200 → 44.788 | -12.3% [-13.4, -11.8]<br>Δ -6.142 ms | +0.8% [-0.7, +10.0]<br>Δ +0.333 ms | +6.5% [+5.6, +13.9]<br>Δ +2.806 ms |
| PT Sans Regular | text | 88 | 109.516 → 101.418 | -7.0% [-9.0, -6.0]<br>Δ -7.339 ms | +0.7% [-0.4, +15.0]<br>Δ +0.642 ms | +2.3% [+1.6, +9.3]<br>Δ +2.195 ms |
| PT Sans Regular | font_variations | 63 | 11.435 → 11.671 | +2.0% [+0.3, +4.4]<br>Δ +0.222 ms | +0.1% [-1.5, +27.2]<br>Δ +0.015 ms | +0.6% [-1.0, +5.3]<br>Δ +0.067 ms |

The variation example retains Roboto Flex for every factor. Warm, movement, zoom, reflow, size, weight, and slant phases—including regressions and intervals spanning zero—are preserved in [the complete per-phase CSV](/private/tmp/femtovg-admission-review/results/analysis/summary.csv). [Complete sequence statistics](/private/tmp/femtovg-admission-review/results/sequence-analysis/summary.csv) and [all Alustin CPU spans and comparisons](/private/tmp/alustin-admission-review/analysis/summary.csv) include all six comparisons, including each candidate versus master.

## Storage, reuse, and implementation

All cache candidates retain the same 1 MiB logical outline cap and clear the whole outline map when an insertion would exceed it. Logical bytes include the key, outline object, coordinate values, points, and verbs; vector spare capacity, layer records, spare map buckets, and allocation overhead remain outside that approximation. The Cow key adds eight charged bytes per retained entry on this machine—752 bytes for 94 outlines—and changes where cache clears occur. In the untimed Vollkorn pollution trace, optimized eager caching performs an additional clear during hot return. That boundary effect is preserved in the timing results.

Admission adds a separate fixed 16,384-byte history (2,048 fingerprints). A first successful outline observation uses Swash's existing `Render` path, which already reuses outline and rasterization buffers. A second observation can retain an owned outline; only the third can avoid scaling. Color images and unavailable glyphs do not populate history. History survives outline-cache clears; slot collisions can delay admission, while a full fingerprint collision can only admit early because geometry reuse still compares the exact complete key. No additional font parser, hint interpreter, renderer, or outline-normalization implementation was built.

A separate untimed observer confirms the mechanism across 18 configurations and 558 phase records. The following table shows the admission candidate; its counts agree at DPR 1 and 2:

| Font | Singleton / size / weight hits | Second-phase hits | Pollution insertions | Pollution clears | Hot-return hits | Hot keys admitted |
| --- | --- | --- | --- | --- | --- | --- |
| Roboto Flex | 0 / 0 / 0 | 0 | 0 | 0 | 94 / 94 | 94 |
| Vollkorn Medium | 0 / 0 / 0 | 0 | 0 | 0 | 90 / 94 | 90 |
| PT Sans Regular | 0 / 0 / 0 | 0 | 0 | 0 | 94 / 94 | 94 |

Current and optimized eager caching hit all 94 second-phase outlines, insert all 6,016 pollution outlines, clear two or three times during pollution, and hit zero outlines on hot return. Admission stores no single-use control outlines and retains every hot outline that actually entered its cache. Four Vollkorn hot keys were never admitted because history slots collided; they were not evicted. [Observer report and archived corrections](/private/tmp/femtovg-admission-review/observer-work/REPORT.md) explain these counts and the initial overly strict all-94-hits validation expectation. No runtime trace was rerun or discarded. [Observer CSV](/private/tmp/femtovg-admission-review/observer-work/comparison.csv) is excluded from every performance estimate.

## Validation and scope

All **252 replay RGBA comparisons and 18 Alustin comparisons are byte-identical** to their corresponding master images. Actual-font dumps were confined to separate untimed application screenshot launches and verify the intended primary face and bundled Inter fallback. A font change visibly changes the regular-font scenes; the Roboto controls remain identical.

Replay uses 9 complete fresh four-version blocks per CPU configuration, with 5 trials/process, and 9 GPU blocks with 3 trials/process. CPU uses identical Void black-box barriers; GPU runs offscreen Metal/WGPU and waits for completion. Alustin uses 12 four-version blocks per font/backend, 288 accepted CPU launches, and a separate screenshot cohort. Version order follows balanced Williams cycles and configuration order rotates. Trial medians are paired within blocks; 95% percentile intervals bootstrap whole blocks with shared resampling across versions. No duration-based trimming is applied. Intervals are exploratory, with no multiplicity correction. Draw, submit, and completion durations are cumulative and must not be added.

**Diagnostics-off startup has no usable result in this experiment.** The `startup-12`, `startup-12-rerun-1`, and `startup-8-final` cohorts are incomplete after 120-second probe timeouts; all 589 raw launches are preserved and each whole cohort is explicitly excluded. Startup-like timestamps recorded in the CPU diagnostics cohort are not presented as diagnostics-off startup measurements. [Application exclusions and accepted observations](/private/tmp/alustin-admission-review/analysis/summary.json) retain the details.

Alustin uses the same modified benchmark application for every strategy, with system font discovery disabled and explicit identical font files. Its fixed save is 2,559,348 bytes, the catalog 1,195,171 bytes, and the raw icon pack 95,719,946 bytes; the physical window is 2560 × 1600 at scale factor 2. Shaders are eager, GPU warmup is enabled, and window animation is disabled. The original local Alustin outline fix is absent from all four upstream overrides. OS/shader caches, desktop scheduling, and launch readiness are not fully controlled. This is one machine and a small selected font set; changing a font also changes glyph geometry, metrics, and scene layout. Static bytecode counts therefore provide no validated admission cutoff. Profitability depends on atlas-miss reuse and avoided scaling cost, with cheap-font and unique-instance regressions retained as evidence.

## Frozen sources and retained evidence

FemtoVG master: `f57a2c39e9836c146556c58c98d80c5bf7899029`. Original eager patch: `7a278ca4f947658d01c355c450edc6abcdbe3958`. Optimized and admission are locally modified snapshots based on that patch, identified by complete source maps and executable hashes rather than represented as additional commits. Alustin main: `ac35d4e0b5c52edb7defb9feccdadfd584635c14`, on `perf/femtovg-outline-master-compare`, with common benchmark edits and unchanged dependency graphs.

| Variant | Pure snapshot tree SHA-256 | Swash rasterizer SHA-256 |
| --- | --- | --- |
| master | b6c0743ac1bc9f331c533bf21d9dc9143cd3696cd07cc724e716e6bf5610dfea | absent on master |
| current | 46814ba727321d37abb91470c4f75e1b32757206c7dc3a3416c3e2b5338fb279 | 55325dc71d59cee6224ab1aaef38af7e2e1b9a52f2a3a96dc47963f04eeb1167 |
| optimized | e270a50241ede7ebca20759d621e0b590a1bd7dd9ed685ca0ae7cb3be668de11 | 9226235027860c0ceab72937c41a8d6bed3dc04f822c7082029e76d9117ac1a7 |
| admission | b77dba4563167884d52c6455df3f84086f6c25c80980cc842f5c29ea803d92bd | af9aa4fdf8e87317d43e9d4a469a2f6d2538faf95ad7f853051585a5724312aa |

| Font | File shared by both environments | SHA-256 |
| --- | --- | --- |
| Roboto Flex | [Exact file](/Users/jesse/github/femtovg/examples/assets/RobotoFlex-VariableFont.ttf) | 512f759e24d81543f5629b8edc99c566140a8d161fc2277ac82e64add2f26cf9 |
| Vollkorn Medium | [Exact file](/Users/jesse/github/alustin-gui-v2/crates/alustin-gui/assets/fonts/Vollkorn-Medium.ttf) | b704817fe4433aa674c54f87141f2541d88d7d48342d98ec727a5eed4873a892 |
| PT Sans Regular | [Exact file](/private/tmp/femtovg-open-font-search/candidate-agent/PTSans-Regular.ttf) | 9cc831490532009bae2b3ce0d39c62adfc889060beb421593bfd9d2396d0f10a |

The report generator verifies that both environments used identical pure source maps (apart from generated crate lock files) and identical font hashes. [Replay source/build provenance](/private/tmp/femtovg-admission-review/replay-build-provenance.json), [application source/build provenance](/private/tmp/alustin-admission-review/build/provenance.json), [CPU raw arithmetic audit](/private/tmp/femtovg-admission-review/cpu-raw-arithmetic-audit.json), [sequence methodology](/private/tmp/femtovg-admission-review/results/sequence-analysis/methodology.json), and [all application accepted pairs](/private/tmp/alustin-admission-review/analysis/pairs.csv) make these comparisons reproducible. [Independent replay statistics audit](/private/tmp/femtovg-admission-review/FINAL-STATISTICS-AUDIT.md) verifies all point summaries and selected bootstrap intervals. [Startup limitation and failure audit](/private/tmp/alustin-admission-review/STARTUP-LIMITATION.md) documents every incomplete startup cohort.

[Confirmed source selection](/private/tmp/femtovg-admission-review/selection.json) and [selected-patch validation](/private/tmp/femtovg-admission-review/validation.json) record the root agent's final workspace state and checks.

Existing evidence remains intact: [original stock replay](/private/tmp/femtovg-example-outline-review/README.md) · [Roboto/Liberation/Vollkorn/Arial comparison](/private/tmp/femtovg-liberation-example-review/REPORT.md) · [prior Alustin comparison](/private/tmp/alustin-font-outline-review/REPORT.md) · [PT Sans versus master](/private/tmp/pt-sans-outline-review/REPORT.md). No prior benchmark or result was replaced.

Report inputs (SHA-256):

- [analysis/summary.json](/private/tmp/femtovg-admission-review/results/analysis/summary.json): `9273e8cd1270b61f9bcd5f53fb146de747afa53c7385242abbdc5ef61e6a69bb`
- [sequence-analysis/summary.json](/private/tmp/femtovg-admission-review/results/sequence-analysis/summary.json): `7eea04107bab8dbea001e77e380c0b57c495d5e6443607b9f0f07d3daa27eb49`
- [analysis/summary.json](/private/tmp/alustin-admission-review/analysis/summary.json): `cf018bcfb93dc93ec64b09096dc027172dce688764b2320c3c2b51163b058766`
