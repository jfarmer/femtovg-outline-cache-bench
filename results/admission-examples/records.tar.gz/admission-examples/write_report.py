#!/usr/bin/env python3
"""Write the strategy report from completed analyses; never launch or analyze timings.

Prepare this helper freely. Run it only after the root agent confirms the final
analysis outputs and strategy choice. It writes REPORT.md and reads existing
evidence without modifying any input, source snapshot, benchmark, or workspace.
"""

from pathlib import Path
import argparse
import hashlib
import json


ROOT = Path(__file__).resolve().parent
APP = Path("/private/tmp/alustin-admission-review")
FONT_ORDER = ("stock", "vollkorn", "ptsans")
FONT_LABELS = {"stock": "Roboto Flex", "vollkorn": "Vollkorn Medium", "ptsans": "PT Sans Regular"}
APP_FONTS = {"stock": "roboto", "vollkorn": "vollkorn", "ptsans": "ptsans"}
BACKENDS = (("winit-femtovg-wgpu", "WGPU"), ("winit-femtovg", "OpenGL"))
DISPLAY_PAIRS = (("master", "current"), ("current", "optimized"), ("current", "admission"))
VERSIONS = ("master", "current", "optimized", "admission")


def read(path):
    return json.loads(Path(path).read_text())


def link(label, path):
    return f"[{label}]({Path(path)})"


def table(headers, rows):
    return "\n".join([
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
        *("| " + " | ".join(str(value) for value in row) + " |" for row in rows),
    ])


def pct_ci(point, ci):
    if point is None or ci is None or len(ci) != 2:
        raise ValueError("A displayed effect lacks its paired 95% interval")
    return f"{point:+.1f}% [{ci[0]:+.1f}, {ci[1]:+.1f}]"


def replay_comparison(entry, reference, candidate, metric):
    rows = [row for row in entry["comparisons"] if (row["reference_version"], row["candidate_version"]) == (reference, candidate)]
    if len(rows) != 1:
        raise ValueError(f"Missing/duplicate replay comparison: {reference}/{candidate}")
    return rows[0][metric]


def replay_effect(entry, pair, metric):
    row = replay_comparison(entry, *pair, metric)
    return pct_ci(row["paired_delta_pct"], row["paired_bootstrap95"]) + f"<br>Δ {row['paired_delta_us'] / 1000:+.3f} ms"


def replay_absolutes(entry, metric):
    row = replay_comparison(entry, "master", "current", metric)
    return f"{row['reference_process_median'] / 1000:.3f} → {row['candidate_process_median'] / 1000:.3f}"


def find_entry(entries, backend, font, dpi, scene, phase=None):
    rows = [row for row in entries if (row["backend"], row["font"], row["dpi"], row["scene"]) == (backend, font, dpi, scene)
            and (phase is None or row.get("phase") == phase)]
    if len(rows) != 1:
        raise ValueError(f"Missing/duplicate replay row: {backend}/{font}/{dpi}/{scene}/{phase}")
    return rows[0]


def app_row(summary, font, backend, reference, candidate, metric):
    rows = [row for row in summary["results"] if (row["mode"], row["font"], row["backend"], row["reference"], row["candidate"], row["metric"])
            == ("cpu", APP_FONTS[font], backend, reference, candidate, metric)]
    if len(rows) != 1:
        raise ValueError(f"Missing/duplicate Alustin row: {font}/{backend}/{reference}/{candidate}/{metric}")
    return rows[0]


def app_effect(summary, font, backend, pair, metric):
    row = app_row(summary, font, backend, *pair, metric)
    return pct_ci(row["median_paired_change_pct"], row["median_paired_change_pct_ci95"]) + f"<br>Δ {row['median_paired_delta']:+.3f} ms"


def validate_inputs(replay, sequences, app, cpu, gpu, pixels):
    for name, metadata in (("CPU", cpu), ("GPU", gpu), ("replay pixels", pixels)):
        if not metadata.get("complete") or metadata["versions"] != list(VERSIONS):
            raise ValueError(f"{name} evidence is incomplete or not the four-version matrix")
        if set(metadata["fonts"]) != set(FONT_ORDER):
            raise ValueError(f"{name} font factors differ")
    if not replay or not sequences:
        raise ValueError("Final replay/sequence analyses are empty")
    cpu_batches = [batch for batch in app["batches"] if batch["mode"] == "cpu"]
    if len(cpu_batches) != 1 or any(row["mode"] == "startup" for row in app["results"]):
        raise ValueError("Report expects one complete CPU batch and no usable startup batch")
    cpu_batch = cpu_batches[0]
    if cpu_batch["rounds"] != 12 or cpu_batch["actual_font_diagnostics"]["enabled"]:
        raise ValueError("Alustin CPU batch differs from the intended diagnostics scope")
    for name in FONT_ORDER:
        if cpu["font_files"][name]["sha256"] != cpu_batch["fonts"][APP_FONTS[name]]["file"]["sha256"]:
            raise ValueError(f"Font file differs between environments: {name}")
    for variant in VERSIONS:
        pure_files = cpu["sources"][variant]["pure_snapshot"]["files"]
        app_files = cpu_batch["source_variants"][variant]["source_sha256"]
        if {name: digest for name, digest in pure_files.items() if name != "Cargo.lock"} != app_files:
            raise ValueError(f"FemtoVG source differs between environments: {variant}")
    exclusions = {Path(row["path"]).name: row for row in app["excluded_batches"]}
    expected_exclusions = {"startup-12", "startup-12-rerun-1", "startup-8-final"}
    if not expected_exclusions <= set(exclusions):
        raise ValueError("Every incomplete startup cohort must have an explicit exclusion")
    if any(exclusions[name]["complete"] for name in expected_exclusions):
        raise ValueError("An expected incomplete startup cohort is marked complete")
    if len(pixels["pixel_comparisons"]) != 252 or not all(row["rgba_identical"] for row in pixels["pixel_comparisons"]):
        raise ValueError("Expected 252 identical replay comparisons")
    if len(app["pixels"]) != 18 or not all(row["rgba_identical"] for row in app["pixels"]):
        raise ValueError("Expected 18 identical Alustin comparisons")
    return cpu_batch


def generate(args):
    phase_path = ROOT / "results/analysis/summary.json"
    sequence_path = ROOT / "results/sequence-analysis/summary.json"
    app_path = APP / "analysis/summary.json"
    replay = read(phase_path)
    sequences = read(sequence_path)
    app = read(app_path)
    cpu = read(ROOT / "results/cpu-provenance.json")
    gpu = read(ROOT / "results/gpu-provenance.json")
    pixels = read(ROOT / "pixels/pixels-provenance.json")
    cpu_batch = validate_inputs(replay, sequences, app, cpu, gpu, pixels)
    observer = read(ROOT / "observer-work/mechanism-validation.json")
    if not observer["passed"] or observer["configurations"] != 18:
        raise ValueError("The separate mechanism observer is incomplete")

    leads = {
        "recommendation": "Recommendation: keep the original 1 MiB eager outline cache as the default. Keep repeat-before-admission experimental; the Cow lookup candidate needs a meaningful practical advantage to justify its larger stored keys. This is a strategy recommendation pending the root agent's final choice.",
        "current": "Selected strategy: retain the original 1 MiB eager outline cache. Keep repeat-before-admission experimental and leave the Cow lookup candidate out of the selected patch. The comparisons below explain the performance and storage tradeoffs.",
        "optimized": "Selected strategy: retain eager admission with borrowed Cow lookup. Repeat-before-admission remains experimental. The comparisons below retain the larger key's costs and the performance evidence for review.",
        "admission": "Selected strategy: use repeat-before-admission with borrowed lookup. The comparisons below retain its loss of second-phase scaling reuse and its effect on real example and application workloads for review.",
    }
    paragraphs = ["# Outline-cache strategy comparison", leads[args.decision]]
    if args.decision_note:
        paragraphs.append(args.decision_note)
    pt_lookup = app_row(app, "ptsans", BACKENDS[0][0], "current", "optimized", "first_frame.render.thread_cpu_ms")
    other_app_cis = [app_row(app, font, backend, "current", "optimized", "first_frame.render.thread_cpu_ms")["median_paired_change_pct_ci95"]
                     for font in FONT_ORDER for backend, _ in BACKENDS
                     if (font, backend) != ("ptsans", BACKENDS[0][0])]
    zero_count = sum(ci[0] <= 0 <= ci[1] for ci in other_app_cis)
    return_lookup = replay_comparison(find_entry(replay, "cpu", "stock", args.dpi, "text", "x_return"), "current", "optimized", "draw_us")
    paragraphs.append("The Cow candidate has measured gains that remain part of the evidence: PT Sans Alustin/WGPU first-render CPU changes by "
                      + pct_ci(pt_lookup["median_paired_change_pct"], pt_lookup["median_paired_change_pct_ci95"])
                      + f"; the other Alustin first-render intervals span zero in {zero_count} of five cases. Stock Roboto text `x_return` changes by "
                      + pct_ci(return_lookup["paired_delta_pct"], return_lookup["paired_bootstrap95"])
                      + ". PT Sans is static and passes empty variation coordinates, whose previous key already needed no coordinate allocation; its improvement cannot establish that borrowed-coordinate lookup alone caused the gain. The selected strategy weighs these mixed, mostly small gains against a larger key and changed capacity boundaries. The observed extra Vollkorn hot-return clear is real; that phase's timing interval spans zero, so it is not presented as a definitive measured slowdown.")
    paragraphs.append("The Cow candidate also raises Roboto's Alustin search-frame CPU by +4.9% [+2.8, +9.9] in WGPU and +3.5% [+2.6, +5.4] in OpenGL, approximately 0.102 ms and 0.075 ms. These are filtered second frames, which can introduce new atlas keys; they are distinct from a completely warm redraw. " + link("Independent Alustin CPU audit", APP / "CPU-STATISTICS-AUDIT.md") + " preserves the raw paired arithmetic and intervals.")
    paragraphs.append("The feature remains Swash-only. Ordinary warm redraws hit the existing glyph atlas and bypass this cache. The tested admission policy improves the cost of storing one-use outlines and protects retained hot outlines during pollution, but it gives up the second atlas miss's scaling savings. Those population costs are included in the complete controlled-sequence comparisons below. No static font-bytecode cutoff follows from these results.")
    paragraphs.append("Cells show the median paired duration change and its **95% paired bootstrap interval**, then the median paired absolute change in milliseconds. **Negative means less duration.** `optimized/current` and `admission/current` isolate the candidate strategy from the existing patch; `current/master` is the original patch's incremental benefit. Absolute `master → current` columns show medians of process observations; they need not reproduce the median paired percentage. Full candidate/master comparisons and absolute intervals are retained in the linked CSV/JSON analyses.")

    for backend, title, metric in (("cpu", "Demo first-paint CPU drawing", "draw_us"), ("gpu", "Demo first paint through GPU completion", "complete_us")):
        rows = []
        for font in FONT_ORDER:
            entry = find_entry(replay, backend, font, args.dpi, "demo", "first_paint")
            rows.append([FONT_LABELS[font], replay_absolutes(entry, metric), *(replay_effect(entry, pair, metric) for pair in DISPLAY_PAIRS)])
        paragraphs.extend([f"## {title}, DPR {args.dpi}", table(["Font", "Master → current (ms)", "Current/master", "Optimized/current", "Admission/current"], rows)])
    paragraphs.extend(["## Alustin first-render renderer-thread CPU", "These are `femtovg.render.thread_cpu_ns` spans for the first rendered frame. They measure host renderer-thread work, including component rendering and final flush, rather than GPU completion or displayed-frame latency."])
    rows = []
    app_metric = "first_frame.render.thread_cpu_ms"
    for font in FONT_ORDER:
        for backend, name in BACKENDS:
            absolute = app_row(app, font, backend, "master", "current", app_metric)
            rows.append([FONT_LABELS[font], name, f"{absolute['reference_median']:.3f} → {absolute['candidate_median']:.3f}",
                         *(app_effect(app, font, backend, pair, app_metric) for pair in DISPLAY_PAIRS)])
    paragraphs.append(table(["Font", "Backend", "Master → current (ms)", "Current/master", "Optimized/current", "Admission/current"], rows))

    paragraphs.extend(["## Complete controlled sequences", "Each total sums `frames × draw duration` across every phase within an original trial, then takes trial medians within each fresh process and pairs those process medians. The two-phase sequence includes both the first and second request. The pollution sequence includes both hot-population requests, all 64 pollution frames, and the hot-return request. The isolated hot-return speedup is therefore counted together with the earlier admission penalty."])
    scenes = (("grid_singleton", "Singleton catalogue"), ("grid_two_phases", "Two horizontal phases"),
              ("grid_unique_sizes", "32 unique sizes"), ("grid_unique_variations", "32 unique weights"),
              ("grid_pollution", "Hot set plus 64-size pollution"))
    rows = []
    for font in FONT_ORDER:
        for scene, label in scenes:
            entry = find_entry(sequences, "cpu", font, args.dpi, scene)
            rows.append([FONT_LABELS[font], label, entry["reported_frames"], replay_absolutes(entry, "draw_us"),
                         *(replay_effect(entry, pair, "draw_us") for pair in DISPLAY_PAIRS)])
    paragraphs.append(table(["Regular-font factor", "Complete sequence", "Frames", "Master → current (ms)", "Current/master", "Optimized/current", "Admission/current"], rows))
    paragraphs.append("Every controlled frame creates 94 distinct atlas entries using 94 nonspace ASCII glyph IDs. Swash supplies the charmap and normalized variation coordinates; setup is outside frame measurement. Catalogue/size/weight keys are single-use; hot requests use fresh horizontal atlas phases 0.0, 0.1, and 0.2. Pollution sizes exclude the hot size. The public glyph-run API accepts explicit canvas coordinates and does not use the high-level text shaping API's DPR normalization, so these glyph-run sizes and phase positions have the same intended key behavior at DPR 1 and 2. Controlled sizes stay below the direct-path threshold. These scenes test caching behavior, with the examples and Alustin providing scene and shaping context. The weight control always uses Roboto Flex; copies under other regular-font factors are repeated controls, not independent font evidence.")

    paragraphs.extend(["## Retained example sequences", "All 19 original example phase rows remain in the measurements. These totals include every reported phase from each example, but exclude each scene's 119 unreported warmup frames; they are sums of reported phases rather than full launch-to-end durations."])
    rows = []
    for font in FONT_ORDER:
        for scene in ("demo", "text", "font_variations"):
            entry = find_entry(sequences, "cpu", font, args.dpi, scene)
            rows.append([FONT_LABELS[font], scene, entry["reported_frames"], replay_absolutes(entry, "draw_us"),
                         *(replay_effect(entry, pair, "draw_us") for pair in DISPLAY_PAIRS)])
    paragraphs.append(table(["Regular-font factor", "Example", "Reported frames", "Master → current (ms)", "Current/master", "Optimized/current", "Admission/current"], rows))
    paragraphs.append("The variation example retains Roboto Flex for every factor. Warm, movement, zoom, reflow, size, weight, and slant phases—including regressions and intervals spanning zero—are preserved in " + link("the complete per-phase CSV", ROOT / "results/analysis/summary.csv") + ". " + link("Complete sequence statistics", ROOT / "results/sequence-analysis/summary.csv") + " and " + link("all Alustin CPU spans and comparisons", APP / "analysis/summary.csv") + " include all six comparisons, including each candidate versus master.")

    paragraphs.extend(["## Storage, reuse, and implementation", "All cache candidates retain the same 1 MiB logical outline cap and clear the whole outline map when an insertion would exceed it. Logical bytes include the key, outline object, coordinate values, points, and verbs; vector spare capacity, layer records, spare map buckets, and allocation overhead remain outside that approximation. The Cow key adds eight charged bytes per retained entry on this machine—752 bytes for 94 outlines—and changes where cache clears occur. In the untimed Vollkorn pollution trace, optimized eager caching performs an additional clear during hot return. That boundary effect is preserved in the timing results.", "Admission adds a separate fixed 16,384-byte history (2,048 fingerprints). A first successful outline observation uses Swash's existing `Render` path, which already reuses outline and rasterization buffers. A second observation can retain an owned outline; only the third can avoid scaling. Color images and unavailable glyphs do not populate history. History survives outline-cache clears; slot collisions can delay admission, while a full fingerprint collision can only admit early because geometry reuse still compares the exact complete key. No additional font parser, hint interpreter, renderer, or outline-normalization implementation was built."])
    observer_rows = []
    for font in FONT_ORDER:
        row = next(row for row in observer["observations"] if row["variant"] == "admission" and row["font"] == font and row["dpi"] == args.dpi)
        observer_rows.append([FONT_LABELS[font], f"{row['singleton_hits']} / {row['unique_size_hits']} / {row['unique_variation_hits']}",
                              row["two_phase_second_hits"], row["pollution_insertions"], row["pollution_clears"],
                              f"{row['hot_return_hits']} / 94", row["hot_keys_admitted_before_pollution"]])
    paragraphs.append("A separate untimed observer confirms the mechanism across 18 configurations and 558 phase records. The following table shows the admission candidate; its counts agree at DPR 1 and 2:")
    paragraphs.append(table(["Font", "Singleton / size / weight hits", "Second-phase hits", "Pollution insertions", "Pollution clears", "Hot-return hits", "Hot keys admitted"], observer_rows))
    paragraphs.append("Current and optimized eager caching hit all 94 second-phase outlines, insert all 6,016 pollution outlines, clear two or three times during pollution, and hit zero outlines on hot return. Admission stores no single-use control outlines and retains every hot outline that actually entered its cache. Four Vollkorn hot keys were never admitted because history slots collided; they were not evicted. " + link("Observer report and archived corrections", ROOT / "observer-work/REPORT.md") + " explain these counts and the initial overly strict all-94-hits validation expectation. No runtime trace was rerun or discarded. " + link("Observer CSV", ROOT / "observer-work/comparison.csv") + " is excluded from every performance estimate.")

    paragraphs.extend(["## Validation and scope", "All **252 replay RGBA comparisons and 18 Alustin comparisons are byte-identical** to their corresponding master images. Actual-font dumps were confined to separate untimed application screenshot launches and verify the intended primary face and bundled Inter fallback. A font change visibly changes the regular-font scenes; the Roboto controls remain identical."])
    cpu_trials = cpu["trials_per_process"]
    gpu_trials = gpu["trials_per_process"]
    paragraphs.append(f"Replay uses {cpu['blocks']} complete fresh four-version blocks per CPU configuration, with {cpu_trials} trials/process, and {gpu['blocks']} GPU blocks with {gpu_trials} trials/process. CPU uses identical Void black-box barriers; GPU runs offscreen Metal/WGPU and waits for completion. Alustin uses {cpu_batch['rounds']} four-version blocks per font/backend, {cpu_batch['accepted_launches']} accepted CPU launches, and a separate screenshot cohort. Version order follows balanced Williams cycles and configuration order rotates. Trial medians are paired within blocks; 95% percentile intervals bootstrap whole blocks with shared resampling across versions. No duration-based trimming is applied. Intervals are exploratory, with no multiplicity correction. Draw, submit, and completion durations are cumulative and must not be added.")
    excluded_startup = sum(row["raw_launches"] for row in app["excluded_batches"] if row["mode"] == "startup")
    paragraphs.append(f"**Diagnostics-off startup has no usable result in this experiment.** The `startup-12`, `startup-12-rerun-1`, and `startup-8-final` cohorts are incomplete after 120-second probe timeouts; all {excluded_startup} raw launches are preserved and each whole cohort is explicitly excluded. Startup-like timestamps recorded in the CPU diagnostics cohort are not presented as diagnostics-off startup measurements. " + link("Application exclusions and accepted observations", app_path) + " retain the details.")
    paragraphs.append("Alustin uses the same modified benchmark application for every strategy, with system font discovery disabled and explicit identical font files. Its fixed save is 2,559,348 bytes, the catalog 1,195,171 bytes, and the raw icon pack 95,719,946 bytes; the physical window is 2560 × 1600 at scale factor 2. Shaders are eager, GPU warmup is enabled, and window animation is disabled. The original local Alustin outline fix is absent from all four upstream overrides. OS/shader caches, desktop scheduling, and launch readiness are not fully controlled. This is one machine and a small selected font set; changing a font also changes glyph geometry, metrics, and scene layout. Static bytecode counts therefore provide no validated admission cutoff. Profitability depends on atlas-miss reuse and avoided scaling cost, with cheap-font and unique-instance regressions retained as evidence.")

    paragraphs.extend(["## Frozen sources and retained evidence", f"FemtoVG master: `{cpu_batch['source_variants']['master']['base_ref']}`. Original eager patch: `{cpu_batch['source_variants']['current']['base_ref']}`. Optimized and admission are locally modified snapshots based on that patch, identified by complete source maps and executable hashes rather than represented as additional commits. Alustin main: `{cpu_batch['app_commit']}`, on `perf/femtovg-outline-master-compare`, with common benchmark edits and unchanged dependency graphs."])
    rows = []
    for variant in VERSIONS:
        source = cpu["sources"][variant]["pure_snapshot"]
        module = source["files"].get("src/text/swash_rasterizer.rs", "absent on master")
        rows.append([variant, source["tree_sha256"], module])
    paragraphs.append(table(["Variant", "Pure snapshot tree SHA-256", "Swash rasterizer SHA-256"], rows))
    rows = []
    for font in FONT_ORDER:
        info = cpu["font_files"][font]
        rows.append([FONT_LABELS[font], link("Exact file", info["path"]), info["sha256"]])
    paragraphs.append(table(["Font", "File shared by both environments", "SHA-256"], rows))
    paragraphs.append("The report generator verifies that both environments used identical pure source maps (apart from generated crate lock files) and identical font hashes. " + link("Replay source/build provenance", ROOT / "replay-build-provenance.json") + ", " + link("application source/build provenance", APP / "build/provenance.json") + ", " + link("CPU raw arithmetic audit", ROOT / "cpu-raw-arithmetic-audit.json") + ", " + link("sequence methodology", ROOT / "results/sequence-analysis/methodology.json") + ", and " + link("all application accepted pairs", APP / "analysis/pairs.csv") + " make these comparisons reproducible. " + link("Independent replay statistics audit", ROOT / "FINAL-STATISTICS-AUDIT.md") + " verifies all point summaries and selected bootstrap intervals. " + link("Startup limitation and failure audit", APP / "STARTUP-LIMITATION.md") + " documents every incomplete startup cohort.")
    if (ROOT / "selection.json").exists() and (ROOT / "validation.json").exists():
        paragraphs.append(link("Confirmed source selection", ROOT / "selection.json") + " and " + link("selected-patch validation", ROOT / "validation.json") + " record the root agent's final workspace state and checks.")
    paragraphs.append("Existing evidence remains intact: " + " · ".join([
        link("original stock replay", "/private/tmp/femtovg-example-outline-review/README.md"),
        link("Roboto/Liberation/Vollkorn/Arial comparison", "/private/tmp/femtovg-liberation-example-review/REPORT.md"),
        link("prior Alustin comparison", "/private/tmp/alustin-font-outline-review/REPORT.md"),
        link("PT Sans versus master", "/private/tmp/pt-sans-outline-review/REPORT.md"),
    ]) + ". No prior benchmark or result was replaced.")
    input_hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (phase_path, sequence_path, app_path)}
    paragraphs.append("Report inputs (SHA-256):\n\n" + "\n".join(f"- {link(Path(path).parent.name + '/summary.json', path)}: `{digest}`" for path, digest in input_hashes.items()))
    args.output.write_text("\n\n".join(paragraphs) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--decision", choices=("recommendation", "current", "optimized", "admission"), default="recommendation")
    parser.add_argument("--decision-note", default="", help="Root agent's confirmed interpretation or production status")
    parser.add_argument("--dpi", type=int, default=2)
    parser.add_argument("--output", type=Path, default=ROOT / "REPORT.md")
    args = parser.parse_args()
    generate(args)
    print(f"Wrote {args.output}; existing evidence and source inputs unchanged")


if __name__ == "__main__":
    main()
