# Admission experiment

This is an experimental snapshot, based on the frozen `optimized` candidate.
It changes only `snapshots/admission/src/text/swash_rasterizer.rs`; the working
FemtoVG tree remains under the root agent's ownership. The copied Cargo.lock
is the existing workspace lock used for focused validation, not a dependency
change.

The cache retains an ordinary outline after its second uncached observation.
Its first observation delegates rendering to Swash's existing three-source
Render path. Swash already retains reusable outline and rasterization buffers
inside ScaleContext, so this path adds no duplicate outline builder or scratch
buffer. Its second observation uses the existing owned-outline insertion path;
its third observation can avoid scaling. Different subpixel offsets share the
outline key. Warm glyph-atlas hits never call this rasterizer and therefore do
not advance the observation count.

The `optimized` snapshot's borrowed Cow coordinate lookup remains intact.
Only actual insertion owns the coordinate buffer. The full exact key remains
face CacheKey, glyph ID, exact floating-point size bits, and normalized
coordinates. The logically charged entry size includes the larger Cow key.

A direct-mapped array of 2,048 u64 signatures tracks recent successful outline
observations. This adds a fixed 16,384 bytes per rasterizer separately from the
unchanged 1 MiB logical outline budget. The existing budget remains approximate:
vector spare capacity, layer records, map spare buckets, and allocation overhead
are not charged. The history never grows and is not cleared when the outline
cache clears. Uncached color images, unavailable outlines, and zero-budget
rendering leave it untouched.

The signature uses FNV over the full borrowed outline key. Zero denotes an
unoccupied slot. The signature forces the low bit to one while the slot index
uses the original low bits, so the (slot, signature) pair preserves every bit
of the original 64-bit hash. Distinct signatures sharing a slot replace one
another and can delay admission. A full fingerprint collision can admit a key
early; it cannot reuse another key's geometry because the outline map still
compares all key fields exactly. This is a bounded approximate admission policy,
not a guarantee of retention on every key's second use.

First observations avoid persistent outline storage and use Swash's existing
buffers. The policy still adds one cache lookup and one history hash on misses.
Exactly two atlas misses for a key cannot obtain a scaling cache hit: the
second miss populates the outline and the third can hit. This loss of the second
miss's savings is the principal tradeoff to measure against eager retention.
Oversized outlines can remain eligible in history but are still rejected by
the existing logical outline budget.

Validation completed with the existing workspace target and lock:

```
cargo test --offline --locked --lib --features swash \
  --target-dir /Users/jesse/github/femtovg/target \
  text::swash_rasterizer::tests
```

All 10 focused tests passed. They include the existing exhaustive pixel parity
across fonts, sizes, variable instances, glyphs, and subpixel phases; first and
second observation parity; a poisoned-outline third-hit proof; exact key
isolation; bounded storage and history surviving cache clears; whitespace
accounting; oversized outlines; forced fingerprint collision admission safety;
and color, invalid-glyph, and disabled-cache history isolation. The only compiler
warning was the preexisting unused Transform2D import in src/paint.rs.

No performance workload or GUI was run by this implementation subtask. The
snapshot contains no diagnostic counters or benchmark instrumentation.
