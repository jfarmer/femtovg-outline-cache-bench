#!/usr/bin/env python3
"""Create the additional replay runner; never build or execute it."""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
ORIGINAL = Path('/private/tmp/femtovg-liberation-example-review/runner')
RUNNER = ROOT / 'runner'


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f'expected one match: {old!r}')
    return text.replace(old, new, 1)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if RUNNER.exists():
        raise ValueError('runner exists; preparation will not overwrite it')
    shutil.copytree(ORIGINAL, RUNNER)
    manifest = RUNNER / 'Cargo.toml'
    text = replace_once(manifest.read_text(), '../candidate', '../replay-sources/current')
    text = replace_once(text, 'wgpu = "30.0.0"', 'swash = "=0.2.10"\nwgpu = "30.0.0"')
    manifest.write_text(text)
    lock = RUNNER / 'Cargo.lock'
    text = lock.read_text()
    start = text.index('name = "femtovg-example-outline-review"')
    stop = text.index('[[package]]', start)
    block = replace_once(text[start:stop], ' "pollster",', ' "pollster",\n "swash",')
    lock.write_text(text[:start] + block + text[stop:])
    main_path = RUNNER / 'src/main.rs'
    text = main_path.read_text()
    text = replace_once(text, 'mod perf_graph;', 'mod perf_graph;\nmod controlled;')
    text = replace_once(text, '../../baseline/tests/common/mod.rs', '../../snapshots/master/tests/common/mod.rs')
    marker = 'fn main() {'
    controlled = '''fn run_controlled<T: Renderer>(name:&str,trial:usize,dpi:f32,mut c:Canvas<T>,
    mut flush:impl FnMut(&mut Canvas<T>,Frame),mut wait:impl FnMut(),
    mut setup:impl FnMut(),mut snapshot:impl FnMut(Frame,&str)) {
    let scene=controlled::Scene::new(name,&mut c,dpi);
    let mut f=Frame::new(name);
    setup();
    for (phase, requests) in scene.phases() {
        let mut measurements=Vec::with_capacity(requests.len());
        for request in requests {
            let before=c.benchmark_atlas_entries();
            let start=Instant::now();
            c.set_size(f.width,f.height,dpi);
            scene.draw(&mut c,&request);
            let draw=start.elapsed().as_secs_f64()*1e6;
            flush(&mut c,f);
            let submit=start.elapsed().as_secs_f64()*1e6;
            wait();
            let complete=start.elapsed().as_secs_f64()*1e6;
            let after=c.benchmark_atlas_entries();
            measurements.push(Measurement {draw,submit,complete,misses:after-before});
            f.index+=1;
        }
        emit(name,phase,trial,&measurements);snapshot(f,phase);
    }
}
fn run_selected<T: Renderer>(name:&str,trial:usize,dpi:f32,c:Canvas<T>,
    flush:impl FnMut(&mut Canvas<T>,Frame),wait:impl FnMut(),
    setup:impl FnMut(),snapshot:impl FnMut(Frame,&str)) {
    if name.starts_with("grid_") {
        run_controlled(name,trial,dpi,c,flush,wait,setup,snapshot);
    } else {
        run(name,trial,dpi,c,flush,wait,setup,snapshot);
    }
}
'''
    text = replace_once(text, marker, controlled + marker)
    text = replace_once(text, 'for name in ["demo","text","font_variations"] {',
        'for name in ["demo","text","font_variations","grid_singleton","grid_two_phases","grid_unique_sizes","grid_unique_variations","grid_pollution"] {')
    text = replace_once(text, '                run(name,trial,dpi,c,|c,f|',
        '                run_selected(name,trial,dpi,c,|c:&mut Canvas<WGPURenderer>,f:Frame|')
    text = replace_once(text,
        '                run(name,trial,dpi,Canvas::new(Void).unwrap(),|c,_| {c.flush_to_output(());},||{},||{},|_,_|{});',
        '                run_selected(name,trial,dpi,Canvas::new(Void).unwrap(),|c:&mut Canvas<Void>,_f:Frame| {c.flush_to_output(());},||{},||{},|_,_|{});')
    main_path.write_text(text)
    shutil.copy2(ROOT/'controlled.rs', RUNNER/'src/controlled.rs')
    # The helper modules remain byte-for-byte unchanged; their font override and
    # drawing scopes are exactly those measured in the earlier experiment.
    provenance = {
        'source_runner': str(ORIGINAL),
        'unchanged_helper_sha256': {},
        'prior_lock_sha256': digest(ORIGINAL / 'Cargo.lock'),
        'runner_lock_sha256': digest(lock),
        'lock_change': 'Only add existing swash 0.2.10 to runner dependency list; every resolved package is unchanged',
    }
    for name in ('demo.rs','text.rs','font_variations.rs','perf_graph.rs'):
        assert (ORIGINAL/'src'/name).read_bytes() == (RUNNER/'src'/name).read_bytes()
        provenance['unchanged_helper_sha256'][name] = digest(RUNNER/'src'/name)
    (ROOT/'runner-preparation.json').write_text(json.dumps(provenance,indent=2)+'\n')
    print(f'Prepared {RUNNER}; nothing built or executed')


if __name__ == '__main__':
    main()
